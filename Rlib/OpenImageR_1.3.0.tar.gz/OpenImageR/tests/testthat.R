library(testthat)
library(OpenImageR)

test_check("OpenImageR")
