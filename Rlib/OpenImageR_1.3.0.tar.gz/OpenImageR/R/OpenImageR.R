#' @useDynLib OpenImageR, .registration = TRUE
#' @importFrom Rcpp evalCpp
#' @import shiny
#' @importFrom lifecycle badge deprecate_warn
NULL
