# STILT functions

# These functions are used to generate a receptorlist and weights for
# column-averaged STILT Lagrangian particle dispersion model footprints.
# These are used to generate the Jacobian for the geostatistical inverse
# model in the level 4 product.

# There are currently two meteorological models implemented: GFS (Global
# Foreceast System, a 0.25 degree model with global coverage) and HRRR
# (High Resolution Rapid Refresh Model, a 3 km model covering the
# continental United States). Other models could be added as a TODO,
# as needed.

# There are two version of the receptorlist generation. For Level 2 data,
# where the position and attitude of the spacecraft or aircraft is well
# defined, use OrthorectifyStiltReceptorListFromGfs and
# OrthorectifyStiltReceptorListFromHrrr to calculate the intersection of the
# pixels with each meteorological model layer along the slant column. For
# level 3 data, where there is no information about the slant columns,
# use FlatStiltReceptorListFromGfs and FlatStiltReceptorListFromHrrr
# to calculate receptors in the vertical column above pre-defined pixel
# locations.

#' Write STILT receptor file name from geodetic receptor location
#'
#' STILT files use a naming convention that specify the time,
#' longitude, latitude, and altitude above ground level. This function
#' generates that file name.
#'
#' @param utc vector of UTC (Universal Coordinated Time) dates in POSIX
#'   (Portable Operating System Interface) format
#' @param lon numeric vector of longitudes
#' @param lat numeric vector of latitudes
#' @param agl numeric vector of altitudes above ground level
#'
#' @return character vector of STILT filenames
#'
#' @examples
#' StiltIdFromGeodetic(
#'   utc = "1987-02-22 00:00:00",
#'   lon = 0,
#'   lat = 0,
#'   agl = 0
#'  )
#'
#' @family stilt functions
#' @export
StiltIdFromGeodetic <- function(utc, lon, lat, agl) {

  stilt_id <-
    paste0(
      "stilt",
      # year      - 4 characters
      utc %>% lubridate::year(), "x",
      # month     - 2 characters with leading 0
      utc %>% lubridate::month() %>% stringr::str_pad(pad = 0, width = 2), "x",
      # day       - 2 characters with leading 0
      utc %>% lubridate::day() %>% stringr::str_pad(pad = 0, width = 2), "x",
      # hour      - 2 characters with leading 0
      utc %>% lubridate::hour() %>% stringr::str_pad(pad = 0, width = 2), "x",
      # minute    - 2 characters with leading 0
      (lubridate::minute(utc) + round(lubridate::second(utc) / 60)) %>%
        stringr::str_pad(pad = 0, width = 2), "x",
      # latitude  - whole number part: absolute value, 2 characters, leading 0
      lat  %>% abs() %>% trunc() %>% stringr::str_pad(pad = 0, width = 2), ".",
      # latitude  - decimal part: 4 characters, trailing 0
      lat %>% IsolateDecimal() %>% abs() %>% round(4) %>%
        format(scientific = F) %>% substr(3,6) %>%
        stringr::str_pad(pad = 0, width = 4, side = "right"),
      # latitude  - north or south
      LabelNorthSouth(lat), "x",
      # longitude - whole number part: absolute value, 3 characters, leading 0
      lon  %>% abs() %>% trunc() %>% stringr::str_pad(pad = 0, width = 3), ".",
      # longitude - decimal part: 4 characters, trailing 0
      lon %>% IsolateDecimal() %>% abs() %>% round(4) %>%
        format(scientific=F) %>% substr(3,6) %>%
        stringr::str_pad(pad = 0, width = 4, side = "right"),
      # longitude - north or south
      LabelEastWest(lon), "x",
      # altitude  - 5 characters with leading 0
      agl %>% round() %>% stringr::str_pad(pad = 0, width = 5),
      # file type netCDF
      ".nc"
    )

  return(stilt_id)

}

#' Generate a STILT column receptor list with footprint weights - GFS Version
#'
#' When computing a column-averaged STILT trajectory and footprint,
#' receptors need to be distributed through the atmospheric column.
#' A well-chosen distribution of receptors will accurately capture the
#' vertical structure of the atmosphere. Additionally, the receptors should
#' capture the slant of the column since the viewing zenith angle might be
#' large. However, L3 data makes this impossible, so a vertical column or
#' "flat" receptorlist is required.
#'
#' This function will generate STILT receptors with weights for
#' column-integrated footprints and other meteorological data extractions.
#' This version takes a vertical column at each combination of longitude and
#' latitude prescribed in the arguments. It then weights the layers according
#' to the total dry air mass density in the vertical column.To combine this
#' with orthorectification and account for the slant column, see
#' \code{OrthorectifyStiltReceptorListFromGfs}.
#'
#' This code is specialized for the GFS meteorological model because each
#' meteorological model has different variable available for calculating the
#' total dry air mass density in the vertical column. There is an another
#' version of this code called \code{FlatStiltReceptorListFromHrrr} that is
#' specialized for the HRRR (High Resolution Rapid Refresh) meteorological
#' model.
#'
#' @param utc UTC (Universal Coordinated Time) date in POSIX
#'   (Portable Operating System Interface) format
#' @param lon vector of longitudes
#' @param lat vector of latitudes
#' @param dir_nc directory where NetCDF meteorological files are stored
#' @param vars_surface character vector surface variable to extract.
#'   Subset of: "PRSS", "MSLP", "UMOF", "VMOF", "TPP6", "SHTF", "DSWF", "SPH2",
#'   "U10M", "V10M", "T02M", "TCLD", "PBLH", "LHTF", "USTR", "RGHS", "PTRO",
#'   "SHGT". Defaults to "PRSS", "U10M", "V10M", "TCLD", "PBLH", "SHGT"
#'   Defaults to "PBLH", which is the minimum needed for STILT receptor list
#'   generation and analysis.
#' @param vars_upper character vector upper layer variable to extract.
#'   Subset of: "TEMP", "UWND", "VWND", "WWND", "RELH", "PRES", "WVMR",
#'   "HGHT", "DENS". Defaults to "TEMP", "PRES", "WVMR", "HGHT", which is the
#'   minimum needed for STILT receptor list generation and analysis.
#' @param layer_max integer maximum layer to extract (up to 55).
#'   If 0 (default), then the maximum layer will be set to 3x the p.lanetary
#'   boundary layer height.
#' @param verbose logical, if TRUE (default), then the progress is reported.
#'
#' @return data.frame representing a STILT receptor list
#'
#' @family stilt functions
#' @export
FlatStiltReceptorListFromGfs <- function(
    utc,
    lon,
    lat,
    dir_nc = "/tmp/",
    vars_surface = c("PBLH"),
    vars_upper = c("TEMP", "PRES", "WVMR", "HGHT"),
    layer_max = 55,
    verbose = FALSE
) {

  # Project lon and lat to HRRR coordinates
  lon_mat <- RepeatColumns(lon, length(lat))
  lat_mat <- RepeatRows(lat, length(lon))
  geodetic <- cbind(as.vector(lon_mat), as.vector(lat_mat))

  # Retrieve meteorological file
  file_met <-
    ArlFilename(
      model = "gfs0p25",
      utc   = utc,
      nhrs  = 0,
      archive = FALSE
    )
  hour_sel <-
    ArlHour(
      model = "gfs0p25",
      utc = utc
    )
  file_met_nc <- paste0(dir_nc, "/", file_met, "_", hour_sel, ".nc")
  stopifnot(file.exists(file_met_nc))

  # Required variables

  # PBLH
  met_PBLH_raster <- raster::brick(file_met_nc, varname = "PBLH")
  pblh <-
    matrix(
      nrow = length(lon),
      ncol = length(lat),
      data = raster::extract(met_PBLH_raster, geodetic)
    )

  # Optional variables

  # PRSS
  if ("PRSS" %in% vars_surface) {
    met_PRSS_raster <- raster::brick(file_met_nc, varname = "PRSS")
    prss <-
      matrix(
        nrow = length(lon),
        ncol = length(lat),
        data = raster::extract(met_PRSS_raster, geodetic)
      )
  }
  # MSLP
  if ("MSLP" %in% vars_surface) {
    met_MSLP_raster <- raster::brick(file_met_nc, varname = "MSLP")
    mslp <-
      matrix(
        nrow = length(lon),
        ncol = length(lat),
        data = raster::extract(met_MSLP_raster, geodetic)
      )
  }
  # UMOF
  if ("UMOF" %in% vars_surface) {
    met_UMOF_raster <- raster::brick(file_met_nc, varname = "UMOF")
    umof <-
      matrix(
        nrow = length(lon),
        ncol = length(lat),
        data = raster::extract(met_UMOF_raster, geodetic)
      )
  }
  # VMOF
  if ("VMOF" %in% vars_surface) {
    met_VMOF_raster <- raster::brick(file_met_nc, varname = "VMOF")
    vmof <-
      matrix(
        nrow = length(lon),
        ncol = length(lat),
        data = raster::extract(met_VMOF_raster, geodetic)
      )
  }
  # TPP6
  if ("TPP6" %in% vars_surface) {
    met_TPP6_raster <- raster::brick(file_met_nc, varname = "TPP6")
    tpp6 <-
      matrix(
        nrow = length(lon),
        ncol = length(lat),
        data = raster::extract(met_TPP6_raster, geodetic)
      )
  }
  # SHTF
  if ("SHTF" %in% vars_surface) {
    met_SHTF_raster <- raster::brick(file_met_nc, varname = "SHTF")
    shtf <-
      matrix(
        nrow = length(lon),
        ncol = length(lat),
        data = raster::extract(met_SHTF_raster, geodetic)
      )
  }
  # DSWF
  if ("DSWF" %in% vars_surface) {
    met_DSWF_raster <- raster::brick(file_met_nc, varname = "DSWF")
    dswf <-
      matrix(
        nrow = length(lon),
        ncol = length(lat),
        data = raster::extract(met_DSWF_raster, geodetic)
      )
  }
  # SPH2
  if ("SPH2" %in% vars_surface) {
    met_SPH2_raster <- raster::brick(file_met_nc, varname = "SPH2")
    sph2 <-
      matrix(
        nrow = length(lon),
        ncol = length(lat),
        data = raster::extract(met_SPH2_raster, geodetic)
      )
  }
  # U10M
  if ("U10M" %in% vars_surface) {
    met_U10M_raster <- raster::brick(file_met_nc, varname = "U10M")
    u10m <-
      matrix(
        nrow = length(lon),
        ncol = length(lat),
        data = raster::extract(met_U10M_raster, geodetic)
      )
  }
  # V10M
  if ("V10M" %in% vars_surface) {
    met_V10M_raster <- raster::brick(file_met_nc, varname = "V10M")
    v10m <-
      matrix(
        nrow = length(lon),
        ncol = length(lat),
        data = raster::extract(met_V10M_raster, geodetic)
      )
  }
  # T02M
  if ("T02M" %in% vars_surface) {
    met_T02M_raster <- raster::brick(file_met_nc, varname = "T02M")
    t02m <-
      matrix(
        nrow = length(lon),
        ncol = length(lat),
        data = raster::extract(met_T02M_raster, geodetic)
      )
  }
  # TCLD
  if ("TCLD" %in% vars_surface) {
    met_TCLD_raster <- raster::brick(file_met_nc, varname = "TCLD")
    tcld <-
      matrix(
        nrow = length(lon),
        ncol = length(lat),
        data = raster::extract(met_TCLD_raster, geodetic)
      )
  }
  # LHTF
  if ("LHTF" %in% vars_surface) {
    met_LHTF_raster <- raster::brick(file_met_nc, varname = "LHTF")
    lhtf <-
      matrix(
        nrow = length(lon),
        ncol = length(lat),
        data = raster::extract(met_LHTF_raster, geodetic)
      )
  }
  # USTR
  if ("USTR" %in% vars_surface) {
    met_USTR_raster <- raster::brick(file_met_nc, varname = "USTR")
    ustr <-
      matrix(
        nrow = length(lon),
        ncol = length(lat),
        data = raster::extract(met_USTR_raster, geodetic)
      )
  }
  # RGHS
  if ("RGHS" %in% vars_surface) {
    met_RGHS_raster <- raster::brick(file_met_nc, varname = "RGHS")
    rghs <-
      matrix(
        nrow = length(lon),
        ncol = length(lat),
        data = raster::extract(met_RGHS_raster, geodetic)
      )
  }
  # PTRO
  if ("PTRO" %in% vars_surface) {
    met_PTRO_raster <- raster::brick(file_met_nc, varname = "PTRO")
    ptro <-
      matrix(
        nrow = length(lon),
        ncol = length(lat),
        data = raster::extract(met_PTRO_raster, geodetic)
      )
  }
  # SHGT
  if ("SHGT" %in% vars_surface) {
    met_SHGT_raster <- raster::brick(file_met_nc, varname = "SHGT")
    shgt <-
      matrix(
        nrow = length(lon),
        ncol = length(lat),
        data = raster::extract(met_SHGT_raster, geodetic)
      )
  }

  # Extract Upper Layer Variables

  # Required Variables

  # PRES
  met_PRES_raster <- raster::brick(file_met_nc, varname = "PRES")
  pres <-
    array(
      dim = c(length(lon), length(lat), layer_max),
      data = raster::extract(met_PRES_raster, geodetic)
    )
  # WVMR
  met_WVMR_raster <- raster::brick(file_met_nc, varname = "WVMR")
  wvmr <-
    array(
      dim = c(length(lon), length(lat), layer_max),
      data = raster::extract(met_WVMR_raster, geodetic)
    )
  # TEMP
  met_TEMP_raster <- raster::brick(file_met_nc, varname = "TEMP")
  temp <-
    array(
      dim = c(length(lon), length(lat), layer_max),
      data = raster::extract(met_TEMP_raster, geodetic)
    )
  # HGHT
  met_HGHT_raster <- raster::brick(file_met_nc, varname = "HGHT")
  hght <-
    array(
      dim = c(length(lon), length(lat), layer_max),
      data = raster::extract(met_HGHT_raster, geodetic)
    )

  # Optional variables

  # UWND
  if ("UWND" %in% vars_upper) {
    met_UWND_raster <- raster::brick(file_met_nc, varname = "UWND")
    uwnd <-
      array(
        dim = c(length(lon), length(lat), layer_max),
        data = raster::extract(met_UWND_raster, geodetic)
      )
  }
  # VWND
  if ("VWND" %in% vars_upper) {
    met_VWND_raster <- raster::brick(file_met_nc, varname = "VWND")
    vwnd <-
      array(
        dim = c(length(lon), length(lat), layer_max),
        data = raster::extract(met_VWND_raster, geodetic)
      )
  }
  # WWND
  if ("WWND" %in% vars_upper) {
    met_WWND_raster <- raster::brick(file_met_nc, varname = "WWND")
    wwnd <-
      array(
        dim = c(length(lon), length(lat), layer_max),
        data = raster::extract(met_WWND_raster, geodetic)
      )
  }
  # RELH
  if ("RELH" %in% vars_upper) {
    met_RELH_raster <- raster::brick(file_met_nc, varname = "RELH")
    relh <-
      array(
        dim = c(length(lon), length(lat), layer_max),
        data = raster::extract(met_RELH_raster, geodetic)
      )
  }

  # Create a flag for STILT receptors - height must be less than 3x the PBLH
  stilt_flag <- array(dim = c(length(lon), length(lat), layer_max))
  for (layer.tick in 1:layer_max) {
    stilt_flag[,,layer.tick] <- hght[,,layer.tick] < 3 * pblh
  }

  # Find the heights of the interfaces between layers
  hght_interfaces <- abind::abind(
    matrix(nrow = length(lon), ncol = length(lat), data = 0),
    (hght[,,1:(layer_max - 1)] + hght[,,2:layer_max]) / 2,
    along = 3
  )
  hght_lower <- hght_interfaces[,,1:(layer_max - 1)]
  hght_upper <- hght_interfaces[,,2:layer_max]

  # Number density across layer in mol / m^2
  dens <- array(dim = c(length(lon), length(lat), layer_max))
  for (tick in 1:(layer_max - 1)) {
    dens[,,tick] <-
      pres[,,tick] *
      (hght_upper[,,tick] - hght_lower[,,tick]) *
      (1 - wvmr[,,tick]) /
      (100 * 8.3145 * temp[,,tick])
  }
  # Add the top of the atmosphere - assume the air is dry
  dens[,,layer_max] <- pres[,,layer_max] / (100 * 9.81 * 0.028964)

  # Fraction of total air is used for the column footprint weights
  totalair <- apply(dens, c(1,2), sum)
  densfrac <- array(dim = dim(dens), data = 1)
  for (tick in 1:layer_max) {
    densfrac[,,tick] <- dens[,,tick] / totalair
  }

  # If density was requested, then calculate it
  if ("DENS" %in% vars_upper) {
    # Volume number density
    vdens <- array(dim = c(length(lon), length(lat), layer_max))
    for (tick in 1:(layer_max)) {
      vdens[,,tick] <-
        pres[,,tick] *
        (1 - wvmr[,,tick]) /
        (8.3145 * temp[,,tick])
    }
  }

  # The "allflag" is used to count indices
  allflag <- array(dim = c(length(lon), length(lat), layer_max), data = 1)

  # Return the receptor list
  output <- data.frame(
    ymd_hms       = rep(utc, length(stilt_flag[,,1:(layer_max)])),
    lon           = rep(as.vector(lon_mat), layer_max),
    lat           = rep(as.vector(lat_mat), layer_max),
    agl           = as.vector(hght[,,1:(layer_max)]),
    flag          = as.vector(stilt_flag[,,1:(layer_max)]),
    filename      =
      StiltIdFromGeodetic(
        utc = utc,
        lon = rep(as.vector(lon_mat), layer_max),
        lat = rep(as.vector(lat_mat), layer_max),
        agl = hght[,,1:(layer_max)]
      ),
    along         = which(allflag[,,1:(layer_max)] == 1, arr.ind = TRUE)[,1],
    across        = which(allflag[,,1:(layer_max)] == 1, arr.ind = TRUE)[,2],
    layer         = which(allflag[,,1:(layer_max)] == 1, arr.ind = TRUE)[,3],
    weight        = as.vector(densfrac)
  )

  # Add requested variables: surface
  if ("PRSS" %in% vars_surface) {
    output$prss <- rep(as.vector(prss), layer_max)
  }
  if ("MSLP" %in% vars_surface) {
    output$mslp <- rep(as.vector(mslp), layer_max)
  }
  if ("UMOF" %in% vars_surface) {
    output$umof <- rep(as.vector(umof), layer_max)
  }
  if ("VMOF" %in% vars_surface) {
    output$vmof <- rep(as.vector(vmof), layer_max)
  }
  if ("TPP6" %in% vars_surface) {
    output$tpp6 <- rep(as.vector(tpp6), layer_max)
  }
  if ("SHTF" %in% vars_surface) {
    output$shtf <- rep(as.vector(shtf), layer_max)
  }
  if ("DSWF" %in% vars_surface) {
    output$dswf <- rep(as.vector(dswf), layer_max)
  }
  if ("SPH2" %in% vars_surface) {
    output$sph2 <- rep(as.vector(sph2), layer_max)
  }
  if ("U10M" %in% vars_surface) {
    output$u10m <- rep(as.vector(u10m), layer_max)
  }
  if ("V10M" %in% vars_surface) {
    output$v10m <- rep(as.vector(v10m), layer_max)
  }
  if ("T02M" %in% vars_surface) {
    output$t02m <- rep(as.vector(t02m), layer_max)
  }
  if ("TCLD" %in% vars_surface) {
    output$tcld <- rep(as.vector(tcld), layer_max)
  }
  if ("PBLH" %in% vars_surface) {
    output$pblh <- rep(as.vector(pblh), layer_max)
  }
  if ("LHTF" %in% vars_surface) {
    output$lhtf <- rep(as.vector(lhtf), layer_max)
  }
  if ("USTR" %in% vars_surface) {
    output$ustr <- rep(as.vector(ustr), layer_max)
  }
  if ("RGHS" %in% vars_surface) {
    output$rghs <- rep(as.vector(rghs), layer_max)
  }
  if ("PTRO" %in% vars_surface) {
    output$ptro <- rep(as.vector(ptro), layer_max)
  }
  if ("SHGT" %in% vars_surface) {
    output$shgt <- rep(as.vector(shgt), layer_max)
  }

  # Add requested variables: upper
  if ("TEMP" %in% vars_upper) {
    output$temp <- as.vector(temp[,,1:(layer_max)])
  }
  if ("UWND" %in% vars_upper) {
    output$uwnd <- as.vector(uwnd[,,1:(layer_max)])
  }
  if ("VWND" %in% vars_upper) {
    output$vwnd <- as.vector(vwnd[,,1:(layer_max)])
  }
  if ("WWND" %in% vars_upper) {
    output$wwnd <- as.vector(wwnd[,,1:(layer_max)])
  }
  if ("RELH" %in% vars_upper) {
    output$relh <- as.vector(relh[,,1:(layer_max)])
  }
  if ("PRES" %in% vars_upper) {
    output$pres <- as.vector(pres[,,1:(layer_max)])
  }
  if ("WVMR" %in% vars_upper) {
    output$wvmr <- as.vector(wvmr[,,1:(layer_max)])
  }
  if ("HGHT" %in% vars_upper) {
    output$hght <- as.vector(hght[,,1:(layer_max)])
  }
  if ("DENS" %in% vars_upper) {
    output$dens <- as.vector(dens[,,1:(layer_max)])
  }

  return(output)

}

#' Generate a STILT column receptorlist with footprint weights - GFS Version
#'
#' When computing a column-averaged STILT trajectory and footprint,
#' receptors need to be distributed through the atmospheric column.
#' A well-chosen distribution of receptors will accurately capture the
#' vertical structure of the atmosphere. Additionally, the receptors should
#' capture the slant of the column since the viewing zenith angle might be
#' large. This function uses the msatR orthorectification code to find the
#' intersection of the instrument pixels with the layers of GFS
#' (Global Forecast System) meteorologial model. It then weights the layers
#' according to the total dry air mass density in the slant column.
#'
#' This code is specialized for the GFS meteorological model because each
#' meteorological model has different variable available for calculating the
#' total dry air mass density in the slant column. There is an another version
#' of this code called \code{OrthorectifyStiltReceptorListFromHrrr} that is
#' specialized for the HRRR (High Resolution Rapid Refresh) meteorological
#' model.
#'
#' @param spacecraft_state initial spacecraft state object. See documentation
#'   for the function \code{SpacecraftState} for more information. The entire
#'   time series will be orthorectified, so the user should restrict the file
#'   beforehand. The user should supply the spacecraft state at all indices
#'   until the end of the attitude, which likely includes one time step after
#'   the activity is labeled in the spacecraft state.
#' @param spacecraft_configuration a list containing configuration data for the
#'   spacecraft. The default is saved in package data as
#'   \code{ground_configuration} and contains initial information about
#'   MethaneSAT. See the data documentation for \code{ground_configuration}
#'   for more detail.
#' @param dir_nc directory where NetCDF meteorological files are to be stored
#' @param metvar vector of character strings with additional meteorological
#'   variables to extract along the pixel boresights. Must be a subset of the
#'   upper layer variables in the netcdf file. Some subset of
#'   "TEMP", "UWND", "VWND", "WWND", "RELH", "PRES", "WVMR", "DENS". Defaults
#'   to none.
#' @param framerate imaging frame rate in Hz (default 1 Hz for orthorectifying)
#'   simulated scans.
#' @param aggregate_alongtrack integer number of pixels to aggregate along
#'   track (default 1).
#' @param aggregate_acrosstrack integer number of pixels to aggregate across
#'   track (default 128).
#' @param layer_max integer maximum layer to extract (up to 55). If 0
#'   (default), then the maximum layer will be set to 3x the planetary
#'   boundary layer height.
#' @param dem_raster raster digital elevation map. If NULL (default) then the
#'   dem object in the package data will be used.
#' @param verbose logical, if TRUE (default), then the progress is reported.
#'
#' @return A data.frame representing a STILT receptor list
#'
#' @family stilt functions
#' @export
OrthorectifyStiltReceptorListFromGfs <- function(
    spacecraft_state,
    spacecraft_configuration,
    dir_nc,
    metvar = c(),
    framerate = 1,
    aggregate_alongtrack = 1,
    aggregate_acrosstrack = 128,
    layer_max = 0,
    dem_raster = NULL,
    verbose = TRUE
) {

  # Prepare the Digital Elevation Map (DEM)

  # If a DEM was provided by the user, use it to overwrite the package DEM
  if (!is.null(dem_raster)) {
    dem <- dem_raster
  }

  # Clip the DEM to the area around the spaccecraft. The computational expense
  # of the orthorectification is directly proportional to the number of pixels
  # in the DEM. This step reduces the DEM to what is necessary.
  dem_raster_clipped <-
    ClipDemToSpacecraftState(
      dem = dem,
      spacecraft_state = spacecraft_state,
      spacecraft_configuration = ground_configuration
    )

  # Orthorectify the center of each pixel to the Earth's surface
  orthorectified_surface <-
    OrthorectifyScanCenters(
      spacecraft_state = spacecraft_state,
      spacecraft_configuration = spacecraft_configuration,
      framerate = framerate,
      aggregate_alongtrack = aggregate_alongtrack,
      aggregate_acrosstrack = aggregate_acrosstrack,
      dem_raster = dem_raster_clipped,
      verbose = verbose
    )
  n_alongtrack <- dim(orthorectified_surface$lon)[1]
  n_acrosstrack <- dim(orthorectified_surface$lon)[2]

  # Retrieve meteorological file

  # The met file time is the start of the scan. The resolution of the
  # met file time is never better than 1 hour, so this is unlikely to be
  # a consequential choice.
  utc <- spacecraft_state$utc[1]

  # Find the meteorological file
  file_met <-
    ArlFilename(
      model = "gfs0p25",
      utc   = utc,
      nhrs  = 0,
      archive = FALSE
    )
  hour_sel <-
    ArlHour(
      model = "gfs0p25",
      utc = utc
    )
  file_met_nc <- paste0(dir_nc, "/", file_met, "_", hour_sel, ".nc")
  stopifnot(file.exists(file_met_nc))

  # Surface variables
  orthorectified_stilt_lons <- orthorectified_surface$lon
  orthorectified_stilt_lats <- orthorectified_surface$lat
  orthorectified_stilt_alts <- orthorectified_surface$alt
  met_PRSS_raster <- raster::brick(file_met_nc, varname = "PRSS")
  orthorectified_stilt_prss <-
    matrix(
      nrow = n_alongtrack,
      ncol = n_acrosstrack,
      data =
        raster::extract(
          met_PRSS_raster,
          cbind(
            as.vector(orthorectified_stilt_lons),
            as.vector(orthorectified_stilt_lats))
        )
    )

  # Get upper layer met files
  met_HGHT_raster <- raster::brick(file_met_nc, varname = "HGHT")
  met_PRES_raster <- raster::brick(file_met_nc, varname = "PRES")
  met_WVMR_raster <- raster::brick(file_met_nc, varname = "WVMR")
  met_TEMP_raster <- raster::brick(file_met_nc, varname = "TEMP")
  if ("UWND" %in% metvar) {
    met_UWND_raster <- raster::brick(file_met_nc, varname = "UWND")
  }
  if ("VWND" %in% metvar) {
    met_VWND_raster <- raster::brick(file_met_nc, varname = "VWND")
  }
  if ("WWND" %in% metvar) {
    met_WWND_raster <- raster::brick(file_met_nc, varname = "WWND")
  }
  if ("RELH" %in% metvar) {
    met_RELH_raster <- raster::brick(file_met_nc, varname = "RELH")
  }

  # Create a digital elevation map of the pblh and the layers
  met_PBLH_raster <-
    raster::raster(file_met_nc, varname = "PBLH")
  met_PBLH_raster_clipped <-
    raster::resample(met_PBLH_raster, dem_raster_clipped)
  met_PBLH_raster_clipped_WGS84 <-
    met_PBLH_raster_clipped + dem_raster_clipped
  met_HGHT_raster_clipped <-
    raster::resample(met_HGHT_raster, dem_raster_clipped)
  met_HGHT_raster_clipped_WGS84 <-
    met_HGHT_raster_clipped + dem_raster_clipped

  # Find the max layer: the highest layer within 3x the PBLH
  if (layer_max == 0) {
    layer_sel <- met_HGHT_raster_clipped < 3 * met_PBLH_raster_clipped
    for (layer.tick in 1:dim(layer_sel)[3]) {
      if (all(raster::values(layer_sel[[layer.tick]]) == 0)) {
        layer_max <- layer.tick
        break()
      }
    }
  }

  # Orthorectify Each Layer
  orthorectified_layers <- list()
  orthorectified_stilt_flag <-
    array(dim = c(dim(orthorectified_surface$lon), layer_max))
  orthorectified_stilt_lon <-
    array(dim = c(dim(orthorectified_surface$lon), layer_max))
  orthorectified_stilt_lat <-
    array(dim = c(dim(orthorectified_surface$lon), layer_max))
  orthorectified_stilt_agl <-
    array(dim = c(dim(orthorectified_surface$lon), layer_max))
  orthorectified_stilt_wvmr <-
    array(dim = c(dim(orthorectified_surface$lon), layer_max))
  orthorectified_stilt_pres <-
    array(dim = c(dim(orthorectified_surface$lon), layer_max))
  orthorectified_stilt_temp <-
    array(dim = c(dim(orthorectified_surface$lon), layer_max))
  if ("UWND" %in% metvar) {
    orthorectified_stilt_uwnd <-
      array(dim = c(dim(orthorectified_surface$lon), layer_max))
  }
  if ("VWND" %in% metvar) {
    orthorectified_stilt_vwnd <-
      array(dim = c(dim(orthorectified_surface$lon), layer_max))
  }
  if ("WWND" %in% metvar) {
    orthorectified_stilt_wwnd <-
      array(dim = c(dim(orthorectified_surface$lon), layer_max))
  }
  if ("RELH" %in% metvar) {
    orthorectified_stilt_relh <-
      array(dim = c(dim(orthorectified_surface$lon), layer_max))
  }

  for (layer.tick in 1:layer_max) {

    if (verbose) {
      cat("Orthorectifying Layer ", layer.tick, "\n")
    }

    orthorectified_layer <-
      OrthorectifyScanCenters(
        spacecraft_state = spacecraft_state,
        spacecraft_configuration = spacecraft_configuration,
        framerate = 1,
        aggregate_alongtrack = 1,
        aggregate_acrosstrack = 128,
        dem_raster = met_HGHT_raster_clipped_WGS84[[layer.tick]],
        verbose = verbose
      )

    # Longitude and latitude to extract from rasters
    extract_mat <-
      cbind(
        as.vector(orthorectified_stilt_lons),
        as.vector(orthorectified_stilt_lats)
      )

    # Save variables for this layer
    orthorectified_stilt_lon[,,layer.tick] <- orthorectified_layer$lon
    orthorectified_stilt_lat[,,layer.tick] <- orthorectified_layer$lat
    orthorectified_stilt_agl[,,layer.tick] <-
      raster::extract(met_HGHT_raster[[layer.tick]], extract_mat)
    orthorectified_stilt_wvmr[,,layer.tick] <-
      raster::extract(met_WVMR_raster[[layer.tick]], extract_mat)
    orthorectified_stilt_pres[,,layer.tick] <-
      raster::extract(met_PRES_raster[[layer.tick]], extract_mat)
    orthorectified_stilt_temp[,,layer.tick] <-
      raster::extract(met_TEMP_raster[[layer.tick]], extract_mat)
    orthorectified_stilt_flag[,,layer.tick] <-
      orthorectified_stilt_agl[,,layer.tick] <
        (3 * raster::extract(met_PBLH_raster_clipped, extract_mat))
    if ("UWND" %in% metvar) {
      orthorectified_stilt_uwnd[,,layer.tick] <-
        raster::extract(met_UWND_raster[[layer.tick]], extract_mat)
    }
    if ("VWND" %in% metvar) {
      orthorectified_stilt_vwnd[,,layer.tick] <-
        raster::extract(met_VWND_raster[[layer.tick]], extract_mat)
    }
    if ("WWND" %in% metvar) {
      orthorectified_stilt_wwnd[,,layer.tick] <-
        raster::extract(met_WWND_raster[[layer.tick]], extract_mat)
    }
    if ("RELH" %in% metvar) {
      orthorectified_stilt_relh[,,layer.tick] <-
        raster::extract(met_RELH_raster[[layer.tick]], extract_mat)
    }
  }

  # Calculate number density of air
  orthorectified_stilt_vza <- array(dim = dim(orthorectified_surface$lon))
  for (alongtrack.tick in 1:n_alongtrack) {
    orthorectified_stilt_vza[alongtrack.tick, ] <-
      ZenithAngle(
        lon_observer = orthorectified_stilt_lons[alongtrack.tick, ],
        lat_observer = orthorectified_stilt_lats[alongtrack.tick, ],
        alt_observer = orthorectified_stilt_alts[alongtrack.tick, ],
        object_ecef = spacecraft_state$pos_ecef[alongtrack.tick, ]
      )
  }

  # Height differences
  hght_interfaces <-
    abind::abind(
      matrix(nrow = n_alongtrack, ncol = n_acrosstrack, data = 0),
      (orthorectified_stilt_agl[,,1:(layer_max - 1)] +
        orthorectified_stilt_agl[,,2:layer_max]) / 2,
      along = 3
    )
  hght_lower <- hght_interfaces[,,1:(layer_max - 1)]
  hght_upper <- hght_interfaces[,,2:layer_max]

  # Number density across layer in mol / m^2
  dens <- array(dim = c(n_alongtrack, n_acrosstrack, layer_max))
  for (tick in 1:(layer_max - 1)) {
    dens[,,tick] <-
      orthorectified_stilt_pres[,,tick] *
      (hght_upper[,,tick] - hght_lower[,,tick]) *
      (1 - orthorectified_stilt_wvmr[,,tick]) /
      (100 * 8.3145 * orthorectified_stilt_temp[,,tick] *
        cos(orthorectified_stilt_vza))
  }
  # Add the top of the atmosphere - assume the air is dry
  dens[,,layer_max] <-
    orthorectified_stilt_pres[,,layer_max] /
    (100 * 9.81 * 0.028964 * cos(orthorectified_stilt_vza))

  # Fraction of total air
  totalair <- apply(dens, c(1,2), sum)
  densfrac <- array(dim = dim(dens), data = 1)
  for (tick in 1:layer_max) {
    densfrac[,,tick] <- dens[,,tick] / totalair
  }

  if ("DENS" %in% metvar) {
    # Volume number density
    vdens <- array(dim = c(n_alongtrack, n_acrosstrack, (layer_max)))
    for (tick in 1:(layer_max)) {
      vdens[,,tick] <-
        orthorectified_stilt_pres[,,tick] *
        (1 - orthorectified_stilt_wvmr[,,tick]) /
        (8.3145 * orthorectified_stilt_temp[,,tick] *
           cos(orthorectified_stilt_vza))
    }
  }
  allflag <- array(dim = dim(orthorectified_stilt_lon), data = 1)

  # Return Receptors
  # Return the receptors
  output <- data.frame(
    ymd_hms  = rep(utc, length(orthorectified_stilt_flag[,,1:(layer_max)])),
    lon      = as.vector(orthorectified_stilt_lon[,,1:(layer_max)]),
    lat      = as.vector(orthorectified_stilt_lat[,,1:(layer_max)]),
    agl      = as.vector(orthorectified_stilt_agl[,,1:(layer_max)]),
    flag     = as.vector(orthorectified_stilt_flag[,,1:(layer_max)]),
    filename =
      StiltIdFromGeodetic(
        utc = utc,
        lon = orthorectified_stilt_lon[,,1:(layer_max)],
        lat = orthorectified_stilt_lat[,,1:(layer_max)],
        agl = orthorectified_stilt_agl[,,1:(layer_max)]
      ),
    along    = which(allflag[,,1:(layer_max)] == 1, arr.ind = TRUE)[,1],
    across   = which(allflag[,,1:(layer_max)] == 1, arr.ind = TRUE)[,2],
    layer    = which(allflag[,,1:(layer_max)] == 1, arr.ind = TRUE)[,3],
    weight   = as.vector(densfrac)
  )

  if ("TEMP" %in% metvar) {
    output$temp <- as.vector(orthorectified_stilt_temp[,,1:(layer_max)])
  }
  if ("UWND" %in% metvar) {
    output$uwnd <- as.vector(orthorectified_stilt_uwnd[,,1:(layer_max)])
  }
  if ("VWND" %in% metvar) {
    output$vwnd <- as.vector(orthorectified_stilt_vwnd[,,1:(layer_max)])
  }
  if ("WWND" %in% metvar) {
    output$wwnd <- as.vector(orthorectified_stilt_wwnd[,,1:(layer_max)])
  }
  if ("RELH" %in% metvar) {
    output$relh <- as.vector(orthorectified_stilt_relh[,,1:(layer_max)])
  }
  if ("PRES" %in% metvar) {
    output$pres <- as.vector(orthorectified_stilt_pres[,,1:(layer_max)])
  }
  if ("WVMR" %in% metvar) {
    output$wvmr <- as.vector(orthorectified_stilt_wvmr[,,1:(layer_max)])
  }
  if ("DENS" %in% metvar) {
    output$dens <- as.vector(vdens)
  }

  return(output)

}

#' Generate a STILT column receptorlist with footprint weights - HRRR Version
#'
#' When computing a column-averaged STILT trajectory and footprint,
#' receptors need to be distributed through the atmospheric column.
#' A well-chosen distribution of receptors will accurately capture the
#' vertical structure of the atmosphere. Additionally, the receptors should
#' capture the slant of the column since the viewing zenith angle might be
#' large. However, L3 data makes this impossible, so a vertical column or
#' "flat" receptorlist is required.
#'
#' This function will generate STILT receptors with weights for
#' column-integrated footprints and other meteorological data extractions.
#' This version takes a vertical column at each combination of longitude and
#' latitude prescribed in the arguments. It then weights the layers according
#' to the total dry air mass density in the vertical column.To combine this
#' with orthorectification and account for the slant column, see
#' \code{OrthorectifyStiltReceptorListFromHrrr}.
#'
#' This code is specialized for the HRRR meteorological model because each
#' meteorological model has different variable available for calculating the
#' total dry air mass density in the vertical column. There is an another
#' version of this code called \code{FlatStiltReceptorListFromGfs} that is
#' specialized for the GFS (Global Forecast System) meteorological model.
#'
#' @param utc UTC (Universal Coordinated Time) date in POSIX
#'   (Portable Operating System Interface) format
#' @param lon vector of longitudes
#' @param lat vector of latitudes
#' @param dir_nc directory where NetCDF meteorological files are stored
#' @param vars_surface character vector. Surface variable to extract.
#'   Subset of: "PBLH", "PRSS", "SHGT", "MSLP", "TPP1", "DIFR", "T02M",
#'   "RH2M", "U10M", "V10M", "LHTF", "SHTF", "USTR", "RGHS", "DSWF", "TCLD",
#'   "REFC", "CAPE". Defaults to "PBLH", which is the minimum needed for
#'   STILT receptor list generation and analysis.
#' @param vars_upper character vector. Upper layer variable to extract.
#'   Subset of: "HGHT", "PRES", "WVMR", "TEMP", "UWND", "VWND", "WWND",
#'   "DIFW", "SPHU", "TKEN", "DENS". Defaults to "HGHT", "PRES", "WVMR",
#'   "TEMP" which is the minimum needed for STILT receptor list generation
#'   and analysis.
#' @param layer_max integer maximum layer to extract (up to 35).
#'   If 0 (default), then the maximum layer will be set to 3x the planetary
#'   boundary layer height.
#' @param verbose logical, if TRUE (default), then the progress is reported.
#'
#' @return data.frame representing a STILT receptor list
#'
#' @family stilt functions
#' @export
FlatStiltReceptorListFromHrrr <- function(
    utc,
    lon,
    lat,
    dir_nc = "/tmp/",
    vars_surface  = c("PBLH"),
    vars_upper    = c("HGHT", "PRES", "WVMR", "TEMP"),
    layer_max = 35,
    verbose = FALSE
) {

  # Project lon and lat to HRRR coordinates
  lon_mat <- RepeatColumns(lon, length(lat))
  lat_mat <- RepeatRows(lat, length(lon))
  geodetic <- cbind(as.vector(lon_mat), as.vector(lat_mat))
  xxyy <-
    proj4::project(
      geodetic,
      "+proj=lcc +lat_1=38.5 +lat_2=38.5 +lat_0=38.5 +lon_0=262.5 +units=m +e=0 +a=6371229",
      inverse = FALSE
    ) %>%
    as.data.frame %>%
    'colnames<-'(c("xx", "yy"))

  # Retrieve meteorological file
  file_met <-
    ArlFilename(
      model = "hrrr",
      utc   = utc,
      nhrs  = 0,
      archive = FALSE
    )
  hour_sel <-
    ArlHour(
      model = "hrrr",
      utc = utc
    )
  file_met_nc <- paste0(dir_nc, "/", file_met, "_", hour_sel, ".nc")
  stopifnot(file.exists(file_met_nc))

  # Required variables

  # PBLH
  met_PBLH_raster <- raster::brick(file_met_nc, varname = "PBLH")
  pblh <-
    matrix(
      nrow = length(lon),
      ncol = length(lat),
      data = raster::extract(met_PBLH_raster, xxyy)
    )

  # Optional variables

  # PRSS
  if ("PRSS" %in% vars_surface) {
    met_PRSS_raster <- raster::brick(file_met_nc, varname = "PRSS")
    prss <-
      matrix(
        nrow = length(lon),
        ncol = length(lat),
        data = raster::extract(met_PRSS_raster, xxyy)
      )
  }
  # SHGT
  if ("SHGT" %in% vars_surface) {
    met_SHGT_raster <- raster::brick(file_met_nc, varname = "SHGT")
    shgt <-
      matrix(
        nrow = length(lon),
        ncol = length(lat),
        data = raster::extract(met_SHGT_raster, xxyy)
      )
  }
  # MSLP
  if ("MSLP" %in% vars_surface) {
    met_MSLP_raster <- raster::brick(file_met_nc, varname = "MSLP")
    mslp <-
      matrix(
        nrow = length(lon),
        ncol = length(lat),
        data = raster::extract(met_MSLP_raster, xxyy)
      )
  }
  # TPP1
  if ("TPP1" %in% vars_surface) {
    met_TPP1_raster <- raster::brick(file_met_nc, varname = "TPP1")
    tpp1 <-
      matrix(
        nrow = length(lon),
        ncol = length(lat),
        data = raster::extract(met_TPP1_raster, xxyy))
  }
  # DIFR
  if ("DIFR" %in% vars_surface) {
    met_DIFR_raster <- raster::brick(file_met_nc, varname = "DIFR")
    difr <-
      matrix(
        nrow = length(lon),
        ncol = length(lat),
        data = raster::extract(met_DIFR_raster, xxyy)
      )
  }
  # T02M
  if ("T02M" %in% vars_surface) {
    met_T02M_raster <- raster::brick(file_met_nc, varname = "T02M")
    t02m <-
      matrix(
        nrow = length(lon),
        ncol = length(lat),
        data = raster::extract(met_T02M_raster, xxyy)
      )
  }
  # RH2M
  if ("RH2M" %in% vars_surface) {
    met_RH2M_raster <- raster::brick(file_met_nc, varname = "RH2M")
    rh2m <-
      matrix(
        nrow = length(lon),
        ncol = length(lat),
        data = raster::extract(met_RH2M_raster, xxyy)
      )
  }
  # U10M
  if ("U10M" %in% vars_surface) {
    met_U10M_raster <- raster::brick(file_met_nc, varname = "U10M")
    u10m <-
      matrix(
        nrow = length(lon),
        ncol = length(lat),
        data = raster::extract(met_U10M_raster, xxyy)
      )
  }
  # V10M
  if ("V10M" %in% vars_surface) {
    met_V10M_raster <- raster::brick(file_met_nc, varname = "V10M")
    v10m <-
      matrix(
        nrow = length(lon),
        ncol = length(lat),
        data = raster::extract(met_V10M_raster, xxyy)
      )
  }
  # LHTF
  if ("LHTF" %in% vars_surface) {
    met_LHTF_raster <- raster::brick(file_met_nc, varname = "LHTF")
    lhtf <-
      matrix(
        nrow = length(lon),
        ncol = length(lat),
        data = raster::extract(met_LHTF_raster, xxyy)
      )
  }
  # SHTF
  if ("SHTF" %in% vars_surface) {
    met_SHTF_raster <- raster::brick(file_met_nc, varname = "SHTF")
    shtf <-
      matrix(
        nrow = length(lon),
        ncol = length(lat),
        data = raster::extract(met_SHTF_raster, xxyy)
      )
  }
  # USTR
  if ("USTR" %in% vars_surface) {
    met_USTR_raster <- raster::brick(file_met_nc, varname = "USTR")
    ustr <-
      matrix(
        nrow = length(lon),
        ncol = length(lat),
        data = raster::extract(met_USTR_raster, xxyy)
      )
  }
  # RGHS
  if ("RGHS" %in% vars_surface) {
    met_RGHS_raster <- raster::brick(file_met_nc, varname = "RGHS")
    rghs <-
      matrix(
        nrow = length(lon),
        ncol = length(lat),
        data = raster::extract(met_RGHS_raster, xxyy)
      )
  }
  # DSWF
  if ("DSWF" %in% vars_surface) {
    met_DSWF_raster <- raster::brick(file_met_nc, varname = "DSWF")
    dswf <-
      matrix(
        nrow = length(lon),
        ncol = length(lat),
        data = raster::extract(met_DSWF_raster, xxyy)
      )
  }
  # TCLD
  if ("TCLD" %in% vars_surface) {
    met_TCLD_raster <- raster::brick(file_met_nc, varname = "TCLD")
    tcld <-
      matrix(
        nrow = length(lon),
        ncol = length(lat),
        data = raster::extract(met_TCLD_raster, xxyy)
      )
  }
  # REFC
  if ("REFC" %in% vars_surface) {
    met_REFC_raster <- raster::brick(file_met_nc, varname = "REFC")
    refc <-
      matrix(
        nrow = length(lon),
        ncol = length(lat),
        data = raster::extract(met_REFC_raster, xxyy)
      )
  }
  # CAPE
  if ("CAPE" %in% vars_surface) {
    met_CAPE_raster <- raster::brick(file_met_nc, varname = "CAPE")
    cape <-
      matrix(
        nrow = length(lon),
        ncol = length(lat),
        data = raster::extract(met_CAPE_raster, xxyy)
      )
  }

  # Extract Upper Layer Variables

  # Required Variables

  # HGHT
  met_HGHT_raster <- raster::brick(file_met_nc, varname = "HGHT")
  hght <-
    array(
      dim = c(length(lon), length(lat), layer_max),
      data = raster::extract(met_HGHT_raster, xxyy)
    )
  # PRES
  met_PRES_raster <- raster::brick(file_met_nc, varname = "PRES")
  pres <-
    array(
      dim = c(length(lon), length(lat), layer_max),
      data = raster::extract(met_PRES_raster, xxyy)
    )
  # WVMR
  met_WVMR_raster <- raster::brick(file_met_nc, varname = "WVMR")
  wvmr <-
    array(
      dim = c(length(lon), length(lat), layer_max),
      data = raster::extract(met_WVMR_raster, xxyy)
    )
  # TEMP
  met_TEMP_raster <- raster::brick(file_met_nc, varname = "TEMP")
  temp <-
    array(
      dim = c(length(lon), length(lat), layer_max),
      data = raster::extract(met_TEMP_raster, xxyy)
    )

  # Optional variables

  # UWND
  if ("UWND" %in% vars_upper) {
    met_UWND_raster <- raster::brick(file_met_nc, varname = "UWND")
    uwnd <-
      array(
        dim = c(length(lon), length(lat), layer_max),
        data = raster::extract(met_UWND_raster, xxyy)
      )
  }
  # VWND
  if ("VWND" %in% vars_upper) {
    met_VWND_raster <- raster::brick(file_met_nc, varname = "VWND")
    vwnd <-
      array(
        dim = c(length(lon), length(lat), layer_max),
        data = raster::extract(met_VWND_raster, xxyy)
      )
  }
  # WWND
  if ("WWND" %in% vars_upper) {
    met_WWND_raster <- raster::brick(file_met_nc, varname = "WWND")
    wwnd <-
      array(
        dim = c(length(lon), length(lat), layer_max),
        data = raster::extract(met_WWND_raster, xxyy)
      )
  }
  # DIFW
  if ("DIFW" %in% vars_upper) {
    met_DIFW_raster <- raster::brick(file_met_nc, varname = "DIFW")
    difw <-
      array(dim = c(length(lon), length(lat), layer_max),
      data = raster::extract(met_DIFW_raster, xxyy)
    )
  }
  # SPHU
  if ("SPHU" %in% vars_upper) {
    met_SPHU_raster <- raster::brick(file_met_nc, varname = "SPHU")
    sphu <-
      array(
        dim = c(length(lon), length(lat), layer_max),
        data = raster::extract(met_SPHU_raster, xxyy)
      )
  }
  # TKEN
  if ("TKEN" %in% vars_upper) {
    met_TKEN_raster <- raster::brick(file_met_nc, varname = "TKEN")
    tken <-
      array(
        dim = c(length(lon), length(lat), layer_max),
        data = raster::extract(met_TKEN_raster, xxyy)
      )
  }

  # Create a flag for STILT receptors - height must be less than 3x the PBLH
  stilt_flag <- array(dim = c(length(lon), length(lat), layer_max))
  for (layer.tick in 1:layer_max) {
    stilt_flag[,,layer.tick] <- hght[,,layer.tick] < 3 * pblh
  }

  # Find the heights of the interfaces between layers
  hght_interfaces <- abind::abind(
    matrix(nrow = length(lon), ncol = length(lat), data = 0),
    (hght[,,1:(layer_max - 1)] + hght[,,2:layer_max]) / 2,
    along = 3
  )
  hght_lower <- hght_interfaces[,,1:(layer_max - 1)]
  hght_upper <- hght_interfaces[,,2:layer_max]

  # Number density across layer in mol / m^2
  dens <- array(dim = c(length(lon), length(lat), layer_max))
  for (tick in 1:(layer_max - 1)) {
    dens[,,tick] <-
      pres[,,tick] *
      (hght_upper[,,tick] - hght_lower[,,tick]) *
      (1 - wvmr[,,tick]) /
      (100 * 8.3145 * temp[,,tick])
  }
  # Add the top of the atmosphere - assume the air is dry
  dens[,,layer_max] <- pres[,,layer_max] / (100 * 9.81 * 0.028964)

  # Fraction of total air is used for the column footprint weights
  totalair <- apply(dens, c(1,2), sum)
  densfrac <- array(dim = dim(dens), data = 1)
  for (tick in 1:layer_max) {
    densfrac[,,tick] <- dens[,,tick] / totalair
  }

  # If density was requested, then calculate it
  if ("DENS" %in% vars_upper) {
    # Volume number density
    vdens <- array(dim = c(length(lon), length(lat), layer_max))
    for (tick in 1:(layer_max)) {
      vdens[,,tick] <-
        pres[,,tick] *
        (1 - wvmr[,,tick]) /
        (8.3145 * temp[,,tick])
    }
  }

  # The "allflag" is used to count indices
  allflag <- array(dim = c(length(lon), length(lat), layer_max), data = 1)

  # Return the receptor list
  output <- data.frame(
    ymd_hms       = rep(utc, length(stilt_flag[,,1:(layer_max)])),
    lon           = rep(as.vector(lon_mat), layer_max),
    lat           = rep(as.vector(lat_mat), layer_max),
    agl           = as.vector(hght[,,1:(layer_max)]),
    flag          = as.vector(stilt_flag[,,1:(layer_max)]),
    filename      =
      StiltIdFromGeodetic(
        utc = utc,
        lon = rep(as.vector(lon_mat), layer_max),
        lat = rep(as.vector(lat_mat), layer_max),
        agl = hght[,,1:(layer_max)]
      ),
    along         = which(allflag[,,1:(layer_max)] == 1, arr.ind = TRUE)[,1],
    across        = which(allflag[,,1:(layer_max)] == 1, arr.ind = TRUE)[,2],
    layer         = which(allflag[,,1:(layer_max)] == 1, arr.ind = TRUE)[,3],
    weight        = as.vector(densfrac)
  )

  # Add requested variables: surface
  if ("PBLH" %in% vars_surface) {
    output$pblh <- rep(as.vector(pblh), layer_max)
  }
  if ("PRSS" %in% vars_surface) {
    output$prss <- rep(as.vector(prss), layer_max)
  }
  if ("SHGT" %in% vars_surface) {
    output$shgt <- rep(as.vector(shgt), layer_max)
  }
  if ("MSLP" %in% vars_surface) {
    output$mslp <- rep(as.vector(mslp), layer_max)
  }
  if ("TPP1" %in% vars_surface) {
    output$tpp1 <- rep(as.vector(tpp1), layer_max)
  }
  if ("DIFR" %in% vars_surface) {
    output$difr <- rep(as.vector(difr), layer_max)
  }
  if ("T02M" %in% vars_surface) {
    output$t02m <- rep(as.vector(t02m), layer_max)
  }
  if ("RH2M" %in% vars_surface) {
    output$rh2m <- rep(as.vector(rh2m), layer_max)
  }
  if ("U10M" %in% vars_surface) {
    output$u10m <- rep(as.vector(u10m), layer_max)
  }
  if ("V10M" %in% vars_surface) {
    output$v10m <- rep(as.vector(v10m), layer_max)
  }
  if ("LHTF" %in% vars_surface) {
    output$lhtf <- rep(as.vector(lhtf), layer_max)
  }
  if ("SHTF" %in% vars_surface) {
    output$shtf <- rep(as.vector(shtf), layer_max)
  }
  if ("USTR" %in% vars_surface) {
    output$ustr <- rep(as.vector(ustr), layer_max)
  }
  if ("RGHS" %in% vars_surface) {
    output$rghs <- rep(as.vector(rghs), layer_max)
  }
  if ("DSWF" %in% vars_surface) {
    output$dswf <- rep(as.vector(dswf), layer_max)
  }
  if ("TCLD" %in% vars_surface) {
    output$tcld <- rep(as.vector(tcld), layer_max)
  }
  if ("REFC" %in% vars_surface) {
    output$refc <- rep(as.vector(refc), layer_max)
  }
  if ("CAPE" %in% vars_surface) {
    output$cape <- rep(as.vector(cape), layer_max)
  }

  # Add requested variables: upper
  if ("TEMP" %in% vars_upper) {
    output$temp <- as.vector(temp[,,1:(layer_max)])
  }
  if ("UWND" %in% vars_upper) {
    output$uwnd <- as.vector(uwnd[,,1:(layer_max)])
  }
  if ("VWND" %in% vars_upper) {
    output$vwnd <- as.vector(vwnd[,,1:(layer_max)])
  }
  if ("WWND" %in% vars_upper) {
    output$wwnd <- as.vector(wwnd[,,1:(layer_max)])
  }
  if ("SPHU" %in% vars_upper) {
    output$sphu <- as.vector(sphu[,,1:(layer_max)])
  }
  if ("TKEN" %in% vars_upper) {
    output$tken <- as.vector(tken[,,1:(layer_max)])
  }
  if ("PRES" %in% vars_upper) {
    output$pres <- as.vector(pres[,,1:(layer_max)])
  }
  if ("WVMR" %in% vars_upper) {
    output$wvmr <- as.vector(wvmr[,,1:(layer_max)])
  }
  if ("DENS" %in% vars_upper) {
    output$dens <- as.vector(vdens)
  }

  return(output)

}

#' Generate a STILT column receptorlist with footprint weights - HRRR Version
#'
#' When computing a column-averaged STILT trajectory and footprint,
#' receptors need to be distributed through the atmospheric column.
#' A well-chosen distribution of receptors will accurately capture the
#' vertical structure of the atmosphere. Additionally, the receptors should
#' capture the slant of the column since the viewing zenith angle might be
#' large. This function uses the msatR orthorectification code to find the
#' intersection of the instrument pixels with the layers of HRRR
#' (High-Resolution Rapid Refresh) meteorologial model. It then weights the
#' layers according to the total dry air mass density in the slant column.
#'
#' This code is specialized for the HRRR meteorological model because each
#' meteorological model has different variable available for calculating the
#' total dry air mass density in the slant column. There is an another version
#' of this code called \code{OrthorectifyStiltReceptorListFromGfs} that is
#' specialized for the GFS (Global Forecast System) meteorological model.
#'
#' @param spacecraft_state initial spacecraft state object. See documentation
#'   for the function \code{SpacecraftState} for more information. The entire
#'   time series will be orthorectified, so the user should restrict the file
#'   beforehand. The user should supply the spacecraft state at all indices
#'   until the end of the attitude, which likely includes one time step after
#'   the activity is labeled in the spacecraft state.
#' @param spacecraft_configuration a list containing configuration data for the
#'   spacecraft. The default is saved in package data as
#'   \code{ground_configuration} and contains initial information about
#'   MethaneSAT. See the data documentation for \code{ground_configuration}
#'   for more detail.
#' @param dir_nc directory where NetCDF meteorological files are to be stored
#' @param metvar vector of character strings with additional meteorological
#'   variables to extract along the pixel boresights. Must be a subset of the
#'   upper layer variables in the netcdf file.
#' @param framerate imaging frame rate in Hz (default 1 Hz for orthorectifying)
#'   simulated scans.
#' @param aggregate_alongtrack integer number of pixels to aggregate along
#'   track (default 1).
#' @param aggregate_acrosstrack integer number of pixels to aggregate across
#'   track (default 128).
#' @param layer_max integer maximum layer to extract (up to 55). If 0
#'   (default), then the maximum layer will be set to 3x the planetary
#'   boundary layer height.
#' @param dem_raster raster digital elevation map. If NULL (default) then the
#'   dem object in the package data will be used.
#' @param verbose logical, if TRUE (default), then the progress is reported.
#'
#' @return A data.frame representing a STILT receptor list
#'
#' @family stilt functions
#' @export
OrthorectifyStiltReceptorListFromHrrr <- function(
    spacecraft_state,
    spacecraft_configuration,
    dir_nc,
    metvar = c(),
    framerate = 1,
    aggregate_alongtrack = 1,
    aggregate_acrosstrack = 128,
    layer_max = 0,
    dem_raster = NULL,
    verbose = TRUE
) {

  # Prepare the digital elevation map

  # If the dem file was specified, load it as an overwrite to the package dem
  if (!is.null(dem_raster)) {
    dem <- dem_raster
  }

  # Clip the raster to the local DEM
  dem_raster_clipped <-
    ClipDemToSpacecraftState(
      dem = dem,
      spacecraft_state = spacecraft_state,
      spacecraft_configuration = ground_configuration
    )

  # Orthorectify the surface
  orthorectified_surface <-
    OrthorectifyScanCenters(
      spacecraft_state = spacecraft_state,
      spacecraft_configuration = spacecraft_configuration,
      framerate = framerate,
      aggregate_alongtrack = aggregate_alongtrack,
      aggregate_acrosstrack = aggregate_acrosstrack,
      dem_raster = dem_raster_clipped,
      verbose = verbose
    )
  n_alongtrack <- dim(orthorectified_surface$lon)[1]
  n_acrosstrack <- dim(orthorectified_surface$lon)[2]

  # Retrieve met file

  # The met file time is the start of the scan
  utc <- spacecraft_state$utc[1]

  # Retrieve meteorological file
  file_met <-
    ArlFilename(
      model = "hrrr",
      utc   = utc,
      nhrs  = 0,
      archive = FALSE
    )
  hour_sel <-
    ArlHour(
      model = "hrrr",
      utc = utc
    )
  file_met_nc <- paste0(dir_nc, "/", file_met, "_", hour_sel, ".nc")
  stopifnot(file.exists(file_met_nc))

  # Surface variables
  orthorectified_stilt_lons <- orthorectified_surface$lon
  orthorectified_stilt_lats <- orthorectified_surface$lat
  orthorectified_stilt_alts <- orthorectified_surface$alt
  met_PRSS_raster <- raster::brick(file_met_nc, varname = "PRSS")
  orthorectified_stilt_prss <-
    matrix(
      nrow = n_alongtrack,
      ncol = n_acrosstrack,
      data =
        raster::extract(
          met_PRSS_raster,
          cbind(
            as.vector(orthorectified_stilt_lons),
            as.vector(orthorectified_stilt_lats))
        )
    )

  # Get upper layer met files
  met_HGHT_raster <- raster::brick(file_met_nc, varname = "HGHT")
  met_PRES_raster <- raster::brick(file_met_nc, varname = "PRES")
  met_WVMR_raster <- raster::brick(file_met_nc, varname = "WVMR")
  met_TEMP_raster <- raster::brick(file_met_nc, varname = "TEMP")
  if ("UWND" %in% metvar) {
    met_UWND_raster <- raster::brick(file_met_nc, varname = "UWND")
  }
  if ("VWND" %in% metvar) {
    met_VWND_raster <- raster::brick(file_met_nc, varname = "VWND")
  }
  if ("WWND" %in% metvar) {
    met_WWND_raster <- raster::brick(file_met_nc, varname = "WWND")
  }
  if ("RELH" %in% metvar) {
    met_RELH_raster <- raster::brick(file_met_nc, varname = "RELH")
  }
  if ("DIFW" %in% metvar) {
    met_DIFW_raster <- raster::brick(file_met_nc, varname = "DIFW")
  }
  if ("SPHU" %in% metvar) {
    met_SPHU_raster <- raster::brick(file_met_nc, varname = "SPHU")
  }
  if ("TKEN" %in% metvar) {
    met_TKEN_raster <- raster::brick(file_met_nc, varname = "TKEN")
  }

  # Create a digital elevation map of the pblh and the layers
  met_PBLH_raster <-
    raster::raster(file_met_nc, varname = "PBLH")
  met_PBLH_raster_clipped <-
    raster::resample(met_PBLH_raster, dem_raster_clipped)
  met_PBLH_raster_clipped_WGS84 <-
    met_PBLH_raster_clipped + dem_raster_clipped
  met_HGHT_raster_clipped <-
    raster::resample(met_HGHT_raster, dem_raster_clipped)
  met_HGHT_raster_clipped_WGS84 <-
    met_HGHT_raster_clipped + dem_raster_clipped

  # Find the max layer: the highest layer within 3x the PBLH
  if (layer_max == 0) {
    layer_sel <- met_HGHT_raster_clipped < 3 * met_PBLH_raster_clipped
    for (layer.tick in 1:dim(layer_sel)[3]) {
      if (all(raster::values(layer_sel[[layer.tick]]) == 0)) {
        layer_max <- layer.tick
        break()
      }
    }
  }

  # Orthorectify Each Layer
  orthorectified_layers <- list()
  orthorectified_stilt_flag <-
    array(dim = c(dim(orthorectified_surface$lon), layer_max))
  orthorectified_stilt_lon <-
    array(dim = c(dim(orthorectified_surface$lon), layer_max))
  orthorectified_stilt_lat <-
    array(dim = c(dim(orthorectified_surface$lon), layer_max))
  orthorectified_stilt_agl <-
    array(dim = c(dim(orthorectified_surface$lon), layer_max))
  orthorectified_stilt_wvmr <-
    array(dim = c(dim(orthorectified_surface$lon), layer_max))
  orthorectified_stilt_pres <-
    array(dim = c(dim(orthorectified_surface$lon), layer_max))
  orthorectified_stilt_temp <-
    array(dim = c(dim(orthorectified_surface$lon), layer_max))
  if ("UWND" %in% metvar) {
    orthorectified_stilt_uwnd <-
      array(dim = c(dim(orthorectified_surface$lon), layer_max))
  }
  if ("VWND" %in% metvar) {
    orthorectified_stilt_vwnd <-
      array(dim = c(dim(orthorectified_surface$lon), layer_max))
  }
  if ("WWND" %in% metvar) {
    orthorectified_stilt_wwnd <-
      array(dim = c(dim(orthorectified_surface$lon), layer_max))
  }
  if ("DIFW" %in% metvar) {
    orthorectified_stilt_difw <-
      array(dim = c(dim(orthorectified_surface$lon), layer_max))
  }
  if ("SPHU" %in% metvar) {
    orthorectified_stilt_sphu <-
      array(dim = c(dim(orthorectified_surface$lon), layer_max))
  }
  if ("TKEN" %in% metvar) {
    orthorectified_stilt_tken <-
      array(dim = c(dim(orthorectified_surface$lon), layer_max))
  }

  for (layer.tick in 1:layer_max) {

    if (verbose) {
      cat("Orthorectifying Layer ", layer.tick, "\n")
    }

    orthorectified_layer <-
      OrthorectifyScanCenters(
        spacecraft_state = spacecraft_state,
        spacecraft_configuration = spacecraft_configuration,
        framerate = 1,
        aggregate_alongtrack = 1,
        aggregate_acrosstrack = 128,
        dem_raster = met_HGHT_raster_clipped_WGS84[[layer.tick]],
        verbose = verbose
      )

    # Longitude and latitude to extract from rasters
    extract_mat <-
      cbind(
        as.vector(orthorectified_stilt_lons),
        as.vector(orthorectified_stilt_lats)
      )

    # Save variables for this layer
    orthorectified_stilt_flag[,,layer.tick] <-
      orthorectified_stilt_agl[,,layer.tick] <
        (3 * raster::extract(met_PBLH_raster_clipped, extract_mat))
    orthorectified_stilt_lon[,,layer.tick] <- orthorectified_layer$lon
    orthorectified_stilt_lat[,,layer.tick] <- orthorectified_layer$lat
    orthorectified_stilt_agl[,,layer.tick] <-
      raster::extract(met_HGHT_raster[[layer.tick]], extract_mat)
    orthorectified_stilt_wvmr[,,layer.tick] <-
      raster::extract(met_WVMR_raster[[layer.tick]], extract_mat)
    orthorectified_stilt_pres[,,layer.tick] <-
      raster::extract(met_PRES_raster[[layer.tick]], extract_mat)
    orthorectified_stilt_temp[,,layer.tick] <-
      raster::extract(met_TEMP_raster[[layer.tick]], extract_mat)
    if ("UWND" %in% metvar) {
      orthorectified_stilt_uwnd[,,layer.tick] <-
        raster::extract(met_UWND_raster[[layer.tick]], extract_mat)
    }
    if ("VWND" %in% metvar) {
      orthorectified_stilt_vwnd[,,layer.tick] <-
        raster::extract(met_VWND_raster[[layer.tick]], extract_mat)
    }
    if ("WWND" %in% metvar) {
      orthorectified_stilt_wwnd[,,layer.tick] <-
        raster::extract(met_WWND_raster[[layer.tick]], extract_mat)
    }
    if ("DIFW" %in% metvar) {
      orthorectified_stilt_difw[,,layer.tick] <-
        raster::extract(met_DIFW_raster[[layer.tick]], extract_mat)
    }
    if ("SPHU" %in% metvar) {
      orthorectified_stilt_sphu[,,layer.tick] <-
        raster::extract(met_SPHU_raster[[layer.tick]], extract_mat)
    }
    if ("TKEN" %in% metvar) {
      orthorectified_stilt_tken[,,layer.tick] <-
        raster::extract(met_TKEN_raster[[layer.tick]], extract_mat)
    }
  }

  # Calculate number density of air
  orthorectified_stilt_vza <- array(dim = dim(orthorectified_surface$lon))
  for (alongtrack.tick in 1:n_alongtrack) {
    orthorectified_stilt_vza[alongtrack.tick, ] <-
      ZenithAngle(
        lon_observer = orthorectified_stilt_lons[alongtrack.tick, ],
        lat_observer = orthorectified_stilt_lats[alongtrack.tick, ],
        alt_observer = orthorectified_stilt_alts[alongtrack.tick, ],
        object_ecef = spacecraft_state$pos_ecef[alongtrack.tick, ]
      )
  }

  # Height differences
  hght_interfaces <-
    abind::abind(
      matrix(nrow = n_alongtrack, ncol = n_acrosstrack, data = 0),
      (orthorectified_stilt_agl[,,1:(layer_max - 1)] +
        orthorectified_stilt_agl[,,2:layer_max]) / 2,
      along = 3
    )
  hght_lower <- hght_interfaces[,,1:(layer_max - 1)]
  hght_upper <- hght_interfaces[,,2:layer_max]

  # Number density across layer in mol / m^2
  dens <- array(dim = c(n_alongtrack, n_acrosstrack, layer_max))
  for (tick in 1:(layer_max - 1)) {
    dens[,,tick] <-
      orthorectified_stilt_pres[,,tick] *
      (hght_upper[,,tick] - hght_lower[,,tick]) *
      (1 - orthorectified_stilt_wvmr[,,tick]) /
      (100 * 8.3145 * orthorectified_stilt_temp[,,tick] *
        cos(orthorectified_stilt_vza))
  }
  # Add the top of the atmosphere - assume the air is dry
  dens[,,layer_max] <-
    orthorectified_stilt_pres[,,layer_max] /
    (100 * 9.81 * 0.028964 * cos(orthorectified_stilt_vza))

  # Fraction of total air
  totalair <- apply(dens, c(1,2), sum)
  densfrac <- array(dim = dim(dens), data = 1)
  for (tick in 1:layer_max) {
    densfrac[,,tick] <- dens[,,tick] / totalair
  }

  if ("DENS" %in% metvar) {
    # Volume number density
    vdens <- array(dim = c(n_alongtrack, n_acrosstrack, (layer_max)))
    for (tick in 1:(layer_max)) {
      vdens[,,tick] <- orthorectified_stilt_pres[,,tick] *
      (1 - orthorectified_stilt_wvmr[,,tick]) /
      (8.3145 * orthorectified_stilt_temp[,,tick] *
        cos(orthorectified_stilt_vza))
    }
  }
  allflag <- array(dim = dim(orthorectified_stilt_lon), data = 1)

  # Return Receptors
  # Return the receptors
  output <- data.frame(
    ymd_hms  = rep(utc, length(orthorectified_stilt_flag[,,1:(layer_max)])),
    lon      = as.vector(orthorectified_stilt_lon[,,1:(layer_max)]),
    lat      = as.vector(orthorectified_stilt_lat[,,1:(layer_max)]),
    agl      = as.vector(orthorectified_stilt_agl[,,1:(layer_max)]),
    flag     = as.vector(orthorectified_stilt_flag[,,1:(layer_max)]),
    filename =
      StiltIdFromGeodetic(
        utc = utc,
        lon = orthorectified_stilt_lon[,,1:(layer_max)],
        lat = orthorectified_stilt_lat[,,1:(layer_max)],
        agl = orthorectified_stilt_agl[,,1:(layer_max)]
      ),
    along    = which(allflag[,,1:(layer_max)] == 1, arr.ind = TRUE)[,1],
    across   = which(allflag[,,1:(layer_max)] == 1, arr.ind = TRUE)[,2],
    layer    = which(allflag[,,1:(layer_max)] == 1, arr.ind = TRUE)[,3],
    weight   = as.vector(densfrac)
  )

  if ("TEMP" %in% metvar) {
    output$temp <- as.vector(orthorectified_stilt_temp[,,1:(layer_max)])
  }
  if ("UWND" %in% metvar) {
    output$uwnd <- as.vector(orthorectified_stilt_uwnd[,,1:(layer_max)])
  }
  if ("VWND" %in% metvar) {
    output$vwnd <- as.vector(orthorectified_stilt_vwnd[,,1:(layer_max)])
  }
  if ("WWND" %in% metvar) {
    output$wwnd <- as.vector(orthorectified_stilt_wwnd[,,1:(layer_max)])
  }
  if ("DIFW" %in% metvar) {
    output$difw <- as.vector(orthorectified_stilt_difw[,,1:(layer_max)])
  }
  if ("SPHU" %in% metvar) {
    output$sphu <- as.vector(orthorectified_stilt_sphu[,,1:(layer_max)])
  }
  if ("TKEN" %in% metvar) {
    output$tken <- as.vector(orthorectified_stilt_tken[,,1:(layer_max)])
  }
  if ("PRES" %in% metvar) {
    output$pres <- as.vector(orthorectified_stilt_pres[,,1:(layer_max)])
  }
  if ("WVMR" %in% metvar) {
    output$wvmr <- as.vector(orthorectified_stilt_wvmr[,,1:(layer_max)])
  }
  if ("DENS" %in% metvar) {
    output$dens <- as.vector(vdens)
  }

  return(output)

}

