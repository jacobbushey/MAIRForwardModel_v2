# Astronomical Alamanc functions

# These functions generate ephemera of solar system bodies using algorithms
# from the astronomical alamanc. The ephmera give the apparent position of the
# body from an observer at the center of the Earth in Earth-Centered Inertial
# coordinates. The package currently has the sun and moon implemented.

# An alternate source of these ephemera are the NASA JPL ephemera
# DE430 or DE440. The astronomical alamanc are simplified equations
# describing the ephemera that can be conveniently calculated in this
# package.

# Note that the solar ephemeris is producing a significant error with
# respect to the DE440 solar ephemeris, and a kludge is currently
# implemented to find the best match. This is not ideal.

#' Compute the apparent position of the sun in meters Earth-Centered Inertial
#'
#' \code{SolarEphemeris} calculates the apparent position of the sun from the
#' center of the Earth. It accounts for relativistic effects. The algorithm
#' is from the Astronomical Almanac, and is valid until the year 2050.
#'
#' @param utc vector of UTC times in POSIX format
#'
#' @return matrix with 3 columns, where each row is the apparent sun position
#'   in meters ECI (Earth-Centered Inertial)
#'
#' @examples
#' SolarEphemeris("1987-02-22")
#'
#' @family geodesy functions
#' @export
SolarEphemeris <- function(
    utc
) {

  # Constants
  au2m    <- 149597870691  # Meters per astronomical unit

  # Julian date
  jd <- JulianFromUtc(utc)

  # Elements of the solar ephemeris
  n       <- jd - 2451545.0
  #n       <- jd - 2451545.304504 # Kludge to match JPL DE440
  L       <- 280.460 + 0.9856474 * n
  g       <- 357.528 + 0.9856003 * n
  L       <- (L / 360 - floor(L / 360)) * 360
  g       <- (g / 360 - floor(g / 360)) * 360
  lambda  <- L + 1.915 * sin(g * pi / 180) + 0.020 * sin(2 * g * pi / 180)
  epsilon <- 23.439 - 0.0000004 * n
  R       <- 1.00014 - 0.01671 * cos(g * pi / 180) -
              0.00014 * cos(2 * g * pi / 180)

  # Return the eci coordinates
  sun_eci <- data.frame(
    x = au2m * R * cos(lambda * pi / 180),
    y = au2m * R * cos(epsilon * pi / 180) * sin(lambda * pi / 180),
    z = au2m * R * sin(epsilon * pi / 180) * sin(lambda * pi / 180)
  )

  return(sun_eci)

}

#' Compute the apparent position of the moon in meters Earth-Centered Inertial
#'
#' \code{LunarEphemeris} calculates the apparent position of the sun from the
#' center of the Earth. It accounts for relativistic effects. The algorithm
#' is from the Astronomical Almanac, and is valid until the year 2050.
#'
#' @param utc vector of UTC times in POSIX format
#'
#' @return matrix with 3 columns, where each row is the apparent moon position
#'   in meters ECI (Earth-Centered Inertial)
#'
#' @examples
#' LunarEphemeris("1987-02-22")
#'
#' @family geodesy functions
#' @export
LunarEphemeris <- function(
    utc
) {

  # Constants
  au2m    <- 149597870691  # Meters per astronomical unit

  # Julian date
  jd <- JulianFromUtc(utc)

  # Time argument of the harmonics
  t_h <- (jd -2451545.0)/36525

  # Harmonics
  lambda <-
    218.32 + 481267.883 * t_h +
      6.29 * sin((134.9 + 477198.85 * t_h) * pi / 180) +
     -1.27 * sin((259.2 - 413335.38 * t_h) * pi / 180) +
      0.66 * sin((235.7 + 890534.23 * t_h) * pi / 180) +
      0.21 * sin((269.9 + 954397.70 * t_h) * pi / 180) +
     -0.19 * sin((357.5 +  35999.05 * t_h) * pi / 180) +
     -0.11 * sin((186.6 + 966404.05 * t_h) * pi / 180)
  beta <-
    5.13  * sin(( 93.3 + 483202.03 * t_h) * pi / 180) +
    0.28  * sin((228.2 + 960400.87 * t_h) * pi / 180) +
    -0.28 * sin((318.3 +   6003.18 * t_h) * pi / 180) +
    -0.17 * sin((217.6 - 407332.20 * t_h) * pi / 180)
  hppi <-
    0.9508 +
    0.0518 * cos((134.9 + 477198.85 * t_h) * pi / 180) +
    0.0095 * cos((259.2 - 413335.38 * t_h) * pi / 180) +
    0.0078 * cos((235.7 + 890534.23 * t_h) * pi / 180) +
    0.0028 * cos((269.9 + 954397.70 * t_h) * pi / 180)

  SD <- 0.2725 * hppi
  r <- 1 / sin(hppi * pi / 180) # (earth radii)

  l <- cos(beta * pi / 180) * cos(lambda * pi / 180)
  m <-
    0.9175 * cos(beta * pi / 180) * sin(lambda * pi / 180) -
    0.3978 * sin(beta * pi / 180)
  n <-
    0.3978 * cos(beta * pi / 180) * sin(lambda * pi / 180) +
    0.9175 * sin(beta * pi / 180)

  moon_right_ascension_declination <-
    data.frame(
      right_ascension = atan2(m, l),
      declination = asin(n),
      distance = r * 6.378140e6
    )

  moon_eci <-
    EciFromRightAscensionDeclination(
      moon_right_ascension_declination
    )

  return(moon_eci)

}

