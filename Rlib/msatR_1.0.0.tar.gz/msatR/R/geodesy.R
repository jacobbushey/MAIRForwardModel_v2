# Geodesy functions

# These functions are used to describe the shape of the Earth and the geometry
# of views on or around the Earth. These functions are not central to the
# purpose of msatR and are common algorithms that can be found elsewhere,
# so they are kept internal to the package using the "@keywords internal"
# functionality in the Roxygen package documentation.

#' Calculate the radius of the ellipsoid at a latitude
#'
#' \code{RadiusAtLatitude} gives the radius of the ellipsoid at a latitude.
#' The radius is measured from the center of the ellipsoid to a point at the
#' given latitude. The default ellipsoid is the WGS84
#' (Word Geodetic System, 1984) ellipsoid.
#'
#' @param lat latitude
#' @param a semi-major axis in meters (default 6378137.0 for WGS84
#'   (Word Geodetic Survey, 1984) ellipsoid)
#' @param b semi-minor axis in meters (default 6356752.3 for WGS84
#'   (Word Geodetic Survey, 1984) ellipsoid)
#'
#' @return a numeric vector of radius in meters
#'
#' @examples
#' RadiusAtLatitude(0)
#'
#' RadiusAtLatitude(90)
#'
#' @keywords internal
#' @family geodesy functions
#' @export
RadiusAtLatitude <- function(
  lat,
  a = 6378137.0,
  b = 6356752.3
) {

  # Calculate components
  N <- a^2 / sqrt(a^2 * cos(lat * pi / 180)^2 + b^2 * sin(lat * pi / 180)^2)
  zcomp <- (N * (b / a)^2) * sin(lat * pi / 180)
  xycomp <- N * cos(lat * pi / 180)

  # Compute and return the radius
  radius <- sqrt(zcomp^2 + xycomp^2)

  return(radius)

}

#' Calculate the length of the parallel of latitude
#'
#' \code{ParallelOfLatitudeCircumference} calculates the length of a parallel
#' of latitude. A parallel of latitude is a circle of constant latitude
#' centered on the pole.
#'
#' @param lat A numeric vector of latitude
#' @param a semi-major axis in meters (default 6378137.0 for WGS84 ellipsoid)
#' @param b semi-minor axis in meters (default 6356752.3 for WGS84 ellipsoid)
#'
#' @return a numeric vector of circumference in meters
#'
#' @examples
#' ParallelOfLatitudeCircumference(0)
#'
#' ParallelOfLatitudeCircumference(90)
#'
#' @keywords internal
#' @export
ParallelOfLatitudeCircumference <- function(
  lat,
  a = 6378137.0,
  b = 6356752.3
) {

  # Compute and return the circumference
  parallel_of_latitude_length <- 2 * pi * sin(pi * (90 - lat) / 180) *
    sqrt(((a^2 * cos(lat * pi / 180))^2 + (b^2 * sin(lat * pi / 180))^2)  /
           ((a * cos(lat * pi / 180))^2 + (b * sin(lat * pi / 180))^2))

  # Return the output
  return(parallel_of_latitude_length)

}

#' Calculate the local tangent plane to the WGS84 ellipsoid
#'
#' \code{LocalTangentPlane} calculate the basis vectors of the plane tangent to
#' the WGS84 (World Geodetic System, 1984) ellipsoid at a given longitude and
#' latitude. The basis vectors point East (x_hat), North (y_hat), and Up
#' (z_hat).
#'
#' @param lon a numeric vector of longitude of the observer
#' @param lat a numeric vector of latitude of the observer, same length as lon
#'
#' @return a list of the basis vectors of the local tangent plane.
#'   x_hat points East, y_hat points North, z_hat points up
#'
#' @examples
#' LocalTangentPlane(0,0)
#'
#' @export
LocalTangentPlane <- function(lon, lat) {

  # Find two points above geodetic point
  geodetic1 <- data.frame(
    lon = lon,
    lat = lat,
    alt = rep(0, length(lon))
  )
  p1 <- EcefFromGeodetic(geodetic1)

  geodetic2 <- data.frame(
    lon = lon,
    lat = lat,
    alt = rep(1000, length(lon))
  )
  p2 <- EcefFromGeodetic(geodetic2)

  # zhat faces up from tangent plane
  z_hat <- (p2 - p1) %>% NormalizeByRow() %>% 'rownames<-'(NULL)

  # yhat faces north along tangent plane
  y_hat <-
    CrossProductByRow(z_hat, RepeatRows(c(0, 0, 1), nrow(z_hat))) %>%
    CrossProductByRow(z_hat) %>%
    NormalizeByRow() %>%
    as.data.frame() %>%
    'colnames<-'(c("x", "y", "z")) %>%
    'rownames<-'(NULL)

  # xhat faces east along tangent plane
  x_hat  <-
    CrossProductByRow(y_hat, z_hat) %>%
    as.data.frame() %>%
    'colnames<-'(c("x", "y", "z")) %>%
    'rownames<-'(NULL)

  # Return result as a list
  ltp <- list(x_hat = x_hat, y_hat = y_hat, z_hat = z_hat)

  return(ltp)

}

#' Calculate the local-vertical local-horizontal (LVLH) basis
#'
#' \code{LocalVerticalLocalHorizontal} calculates the local-vertical
#' local-horizontal (LVLH) basis from the position and velocity of the
#' spacecraft. The LVLH basis vectors point down from the spacecraft (z_hat),
#' perpendicular to the spacecraft velocity and z_hat (y_hat), and
#' approximately to the velocity vector (x_hat).
#'
#' @param pos vector or matrix with 3 columns of the satellite position
#'   in some Earth-centered Cartesian coordinate system e.g.,
#'   Earth-Centered Earth-Fixed or Earth-Centered Inertial
#' @param vel vector or matrix with 3 columns of the satellite velocity
#'   in some Earth-Centered Cartesian coordinate system e.g.,
#'   Earth-Centered Earth-Fixed or Earth-Centered Inertial
#'
#' @return list of the basis vectors of the local-vertical local-horizontal
#' coordinate
#'
#' | Coordinate | Description |
#' | --- | --- |
#' | z_hat | points down from the spacecraft |
#' | y_hat | points perpendicular to velocity and z_hat |
#' | x_hat | points perpendicular to y_hat and z_hat, approximately velocity |
#'
#' @examples
#' pos = c(6378137, 0, 0)
#' vel = c(0, 0, 6000)
#' LocalVerticalLocalHorizontal(pos, vel)
#'
#' @family geodesy functions
#' @export
LocalVerticalLocalHorizontal <- function(
  pos,
  vel
) {

  # Error handling
  stopifnot(length(pos) == length(vel))

  # Coerce to matrix
  if (is.vector(pos)) {
    pos <- matrix(nrow = 1, ncol = 3, data = pos)
  }

  if (is.vector(vel)) {
    vel <- matrix(nrow = 1, ncol = 3, data = vel)
  }

  # Normalize
  pos_hat <- NormalizeByRow(pos)
  vel_hat <- NormalizeByRow(vel)

  # LVLH unit vectors
  z_hat <-
    -pos_hat %>%
    as.data.frame() %>%
    'colnames<-'(c("x", "y", "z")) %>%
    'rownames<-'(NULL)

  y_hat <-
    CrossProductByRow(z_hat, vel_hat) %>%
    NormalizeByRow() %>%
    as.data.frame() %>%
    'colnames<-'(c("x", "y", "z")) %>%
    'rownames<-'(NULL)

  x_hat <-
    CrossProductByRow(y_hat, z_hat) %>%
    NormalizeByRow() %>%
    as.data.frame() %>%
    'colnames<-'(c("x", "y", "z")) %>%
    'rownames<-'(NULL)

  # Return as a list
  lvlh <-
    list(
      x_hat = x_hat,
      y_hat = y_hat,
      z_hat = z_hat
    )

  return(lvlh)

}

#' Find out when the spacecraft is in eclipse.
#'
#' TODO: calculate the penumbra and umbra rather than the cylendrical eclipse.
#'
#' \code{Eclipse} determines if the spacecraft is in eclipse (hidden from the
#' sun by the Earth). It uses the WGS84 (World Geodetic System, 1984)
#' ellipsoid.
#'
#' @param pos vector, matrix, or data.frame with 3 columns of
#'   spacecraft position in meters Earth-Centered Earth-Fixed
#' @param sun vector, matrix, or data.frame with 3 columns of sun
#'   position in meters, Earth-Centered Earth-Fixed
#'
#' @return Logical vector, TRUE when the spacecraft is in eclipse
#'
#' @examples
#' pos = c(6378137, 0, 0)
#' sun = c(1.496e+11, 0, 0)
#' Eclipse(pos, sun)
#' pos = c(6378137, 0, 0)
#' sun = c(-1.496e+11, 0, 0)
#' Eclipse(pos, sun)
#'
#' @family geodesy functions
#' @export
Eclipse <- function(
  pos,
  sun
) {

  # Is the spacecraft on the backside of the Earth wrt the sun?
  is_backside <- AngleBetweenVectors(sun, pos) > pi / 2

  # Find the radius of the Earth at the latitude of the spacecraft
  radius <-
    pos %>%
    GeodeticFromEcef() %>%
    '$'("lat") %>%
    RadiusAtLatitude()

  # Is the spacecraft within the Earth's radius?
  is_radius <-
    DecomposeVector(
      vec = pos,
      basis = sun
    )[[2]] %>%
    NormByRow() %>%
    "<"(radius)

  # Return the result of both tests
  eclipse <- is_backside & is_radius

  return(eclipse)

}

#' Calculate the zenith angle of an object from the perspective of an observer
#' on the surface of the Earth
#'
#' \code{ZenithAngle} calculates the zenith angle of an object from the
#' perspective of an observer on the surface of the Earth. The zenith angle
#' is defined as the angle between the local vertical at the observer and
#' the line from the observer to the object.
#'
#' @param lon_observer numeric vector of longitude of the observer
#' @param lat_observer numeric vector of latitude of the observer, same length
#'   as lon_observer
#' @param alt_observer numeric vector of altitude above the WGS84 ellipsoid of
#'   the observer in meters, same length as lon_observer
#' @param object_ecef vector, matrix, or data.frame with 3 columns,
#'   each row is the location of the object in meters,
#'   Earth-Centered Earth-Fixed
#'
#' @return numeric vector of the zenith angles in radians
#'
#' @examples
#' ZenithAngle(
#'   lon_observer = 0,
#'   lat_observer = 0,
#'   alt_observer = 0,
#'   object_ecef = c(sqrt(2) * 1.496e+11, sqrt(2) * 1.496e+11, 0)
#' )
#'
#' @keywords internal
#' @family geodesy functions
#' @export
ZenithAngle <- function(
  lon_observer,
  lat_observer,
  alt_observer,
  object_ecef
) {

  # Coerce the object to matrix
  if (is.vector(object_ecef)) {
    object_ecef <-
      data.frame(
        x = object_ecef[1],
        y = object_ecef[2],
        z = object_ecef[3]
      )
  }

  # Determine the observer ecef
  observer_ecef <-
    EcefFromGeodetic(
      data.frame(
        lon = lon_observer,
        lat = lat_observer,
        alt = alt_observer
      )
    ) %>%
    as.matrix()

  # Coerce the observer ecef to same number of rows as the object
  observer_ecef <-
    RepeatRows(
      as.vector(observer_ecef),
      nrow(object_ecef)
    )

  # Determine the object ray
  object_ray <- object_ecef - observer_ecef

  # Find the tangentplane
  tangentplane <-
    LocalTangentPlane(
      lon = rep(lon_observer, nrow(object_ecef)),
      lat = rep(lat_observer, nrow(object_ecef))
    )

  # Return the angle between the object ray and the tangentplane normal
  zenith <- AngleBetweenVectors(object_ray, tangentplane$z_hat)

  return(zenith)

}

#' Calculate the zenith and azimuth angle of a object
#' from the perspective of an observer on the surface of the Earth
#'
#'
#' Calculate the zenith and azimuth angles of an object from the perspective
#' of an observer on the surface of the Earth
#'
#' \code{ZenithAndAzimuthAngles} calculates the zenith and azimuth angles of an
#' object from the perspective of an observer on the surface of the Earth. The
#' zenith angle is defined as the angle between the local vertical at the
#' observer and the line from the observer to the object. the azimuth angle is
#' defined as the angle between the local north vector at the observer and the
#' projection of the vector from the observer to the object onto the local
#' tangent plane about the local vertical.
#'
#' @param lon_observer numeric vector of longitude of the observer
#' @param lat_observer numeric vector of latitude of the observer, same length
#'   as lon_observer
#' @param alt_observer numeric vector of altitude above the WGS84 ellipsoid of
#'   the observer in meters, same length as lon_observer
#' @param object_ecef matrix with 3 columns, each row is the location
#'   of the object in meters, Earth-Centered Earth-Fixed
#'
#' @return a data.frame with columns zenith and azimuth
#'
#' @examples
#' ZenithAndAzimuthAngles(
#'   lon_observer = 0,
#'   lat_observer = 0,
#'   alt_observer = 0,
#'   object_ecef = c(sqrt(2) * 1.496e+11, sqrt(2) * 1.496e+11, 0)
#' )
#'
#' @family geodesy functions
#' @export
ZenithAndAzimuthAngles <- function(
  lon_observer,
  lat_observer,
  alt_observer,
  object_ecef
) {

  # Coerce the object to matrix
  if (is.vector(object_ecef)) {
    object_ecef <- matrix(nrow = 1, ncol = 3, data = object_ecef)
  }

  # Determine the observer ecef
  observer_ecef <-
    EcefFromGeodetic(
      data.frame(
        lon = lon_observer,
        lat = lat_observer,
        alt = alt_observer
      )
    ) %>%
    as.matrix()

  # Coerce the observer ecef to same number of rows as the object
  observer_ecef <-
    RepeatRows(
      as.vector(observer_ecef),
      nrow(object_ecef)
    )

  # Determine the object ray
  object_ray <- object_ecef - observer_ecef

  # Find the tangentplane
  tangentplane <-
    LocalTangentPlane(
      lon = rep(lon_observer, nrow(object_ecef)),
      lat = rep(lat_observer, nrow(object_ecef))
    )

  # Return the angle between the object ray and the tangentplane normal
  zenith <- AngleBetweenVectors(object_ray, tangentplane$z_hat)

  # Decompose the object
  object_pp <-
    DecomposeVector(
      vec = object_ray,
      basis = tangentplane$z_hat
    )

  # Find the azimuth angle
  edot <- (object_pp$perpendicular * tangentplane$x_hat) %>%
    rowSums()
  azimuth <-
    AngleBetweenVectors(
      object_pp$perpendicular,
      tangentplane$y_hat
    )
  azimuth[edot < 0] <- 2 * pi - azimuth[edot < 0]

  # Return a data frame of the zenith and azimuth angles
  zenith_zimuth <-
    data.frame(
      zenith  = zenith,
      azimuth = azimuth
    )

  return(zenith_zimuth)

}

