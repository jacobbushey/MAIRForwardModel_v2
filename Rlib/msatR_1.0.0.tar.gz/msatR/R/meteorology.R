# Meteorology functions

# These are functions for handling met files from the NOAA ARL archive
# https://www.ready.noaa.gov/archives.php

# The meteorological files are used in science planning and level 4 processing.
# In science planning, they provide conditions that are taken into account in
# selecting targets. In level 4 processing, they provide the locations and
# weights for STILT Lagrangian Particle Dispersion Model receptors.

# The main functions in this family identify and download ARL format binary
# files from the NOAA ARL archive, and covnert them to netCDF format for easy
# and efficient reading. There are also a number of helper functions
# that perform simple conversions between quantities that are required for
# the computation of the fraction of the atmospheric column in each layer of
# the atmosphere.

# Helper Functions-------------------------------------------------------------

#' Clear blanks from an open binary connection
#'
#' \code{ClearBlanks} is a helper function useful in reading a NOAA
#' (National Oceanic and Atmospheric Administration) ARL
#' (Air Resources Laboratory) file. NOAA ARL files are binary format and contain
#' long strings of blank characters that must be skipped in reading. There is
#' no indication of how,long these strings are, so this function skims the file
#' until it hits a non-blank string.
#'
#' @param file_arl open binary connection
#'
#' @return NULL. Side effect: the pointer to the open binary connection.
#'   file_arl will be advanced to the next non-blank entry.
#'
#' @keywords internal
#' @family meteorology ARL file processing functions
#' @export
ClearBlanks <- function(file_arl) {

  while (suppressWarnings(readChar(file_arl, 1)) == '') {}
  seek(file_arl, -1, "current")

}

#' Calculate water vapor mixing ratio from temperature, relative humidity,
#' and pressure
#'
#' \code{WvmrFromTempRelhPres} is a helper function for analyzing GFS
#' (Global Forecast System). It calculates the water vapor mixing ratio from
#' quantities available from GFS (temperature, relative humidity, and pressure).
#' All inputs must have the same length.
#'
#' @param temp numeric vector of temperatures in degrees Kelvin
#' @param relh numeric vector of relative humidity in percent
#' @param pres numeric vector of press in hPa
#'
#' @return numeric vector of water vapor mixing ratios in kg/kg,
#'   same length as inputs
#'
#' @examples
#' WvmrFromTempRelhPres(273, 0.3, 1000)
#'
#' @keywords internal
#' @family meteorology helper functions
#' @export
WvmrFromTempRelhPres <- function(temp, relh, pres) {

  wvmr <-
    (relh * 6.108 * exp(17.27 * (temp - 273.15) / (temp - 273.15 + 237.3))) /
    (100 * pres)

  return(wvmr)

}

#' Calculates layer height in a GFS file
#'
#' \code{GfsLayerHeights} is a helper function that calculates the height
#' at the center of a GFS (Global Forecast System) model.
#' All inputs must have the same length.
#'
#' @param temp numeric vector of temperatures in degrees Kelvin
#' @param relh numeric vector of relative humidity in percent
#' @param pres numeric vector of press in hPa
#' @param prss numeric surface pressure in hPa
#'
#' @return numeric vector of layer heights in meters
#'
#' @examples
#' GfsLayerHeights(
#'   temp = c(273, 271, 270),
#'   relh = c(1, 1, 1),
#'   pres = c(1000, 900, 800),
#'   prss = 1100
#'  )
#'
#' @keywords internal
#' @family meteorology helper functions
#' @export
GfsLayerHeights <- function(temp, relh, pres, prss) {

  # Constants
  k     <- 1.380649e-23                       # Boltzmann constant
  g     <- 9.81                               # Acceleration due to gravity
  m_dry <- 28.9647 /  (1000 * 6.0221409e+23)  # Molar Mass dry air [kg/molec]
  m_h2o <- 18.01528 / (1000 * 6.0221409e+23)  # Molar Mass water   [kg/molec]

  # Water vapor mixing ratio
  wvmr <- WvmrFromTempRelhPres(temp, relh, pres)

  # Molar mass of wet air [kg / molecule]
  m_air <- m_dry * (1 - wvmr) + wvmr * m_h2o

  # Scale Height
  h <- k * temp / (m_air * g)

  # Layer height
  hght <- rep(NA, length(pres))
  hght[1] <- -h[1] * log(pres[1] / prss)
  for (tick in 2:length(pres)) {
    hght[tick] <- hght[tick - 1] - h[tick] * log(pres[tick] / pres[tick - 1])
  }

  return(hght)

}

#' Calculate water vapor mixing ratio from specific humidity
#'
#' \code{WvmrFromTempRelhPres} is a helper function for analyzing HRRR
#' (High Resolution Rapid Refresh). It calculates the water vapor mixing ratio
#' from quantities available from HRRR (specific humidity).
#'
#' @param sphu numeric vector of specific humidity in mass of water vapor
#'   per mass of moist air
#'
#' @return numeric vector of water vapor mixing ratios in kg/kg
#'
#' @examples
#' WvmrFromSphu(0.01)
#'
#' @keywords internal
#' @family meteorology helper functions
#' @export
WvmrFromSphu <- function(sphu) {

  wvmr <- (sphu / (1 - sphu))

  return(wvmr)

}

#' Calculate layer heights in a HRR meteorological file
#'
#' #' \code{HrrrLayerHeights} is a helper function that calculates the height
#' at the center of a HRRR (High Resolution Rapid Refresh) model.
#' All inputs must have the same length.
#'
#' @param temp numeric vector of temperatures in degrees Kelvin
#' @param sphu numeric vector of specific humidity in mass of water vapor
#'   per mass of moist air
#' @param pres numeric vector of press in hPa
#' @param prss numeric surface pressure in hPa
#'
#' @return A vector of layer heights in meters
#'
#' @examples
#' HrrrLayerHeight(
#'   temp = c(273, 271, 270),
#'   sphu = c(0.01, 0.011, 0.012),
#'   pres = c(1000, 900, 800),
#'   prss = 1100
#' )
#'
#' @keywords internal
#' @family meteorology helper functions
#' @export
HrrrLayerHeight <- function(temp, sphu, pres, prss) {

  # Constants
  k     <- 1.380649e-23                       # Boltzmann constant
  g     <- 9.81                               # Acceleration due to gravity
  m_dry <- 28.9647 /  (1000 * 6.0221409e+23)  # Molar Mass dry air [kg/molec]
  m_h2o <- 18.01528 / (1000 * 6.0221409e+23)  # Molar Mass water   [kg/molec]

  # Water vapor mixing ratio
  wvmr <- WvmrFromSphu(sphu)

  # Molar mass of wet air [kg / molecule]
  m_air <- m_dry * (1 - wvmr) + wvmr * m_h2o

  # Scale Height
  h <- k * temp / (m_air * g)

  # Layer height
  hght <- rep(NA, length(pres))
  hght[1] <- -h[1] * log(pres[1] / prss)
  for (tick in 2:length(pres)) {
    hght[tick]  <- hght[tick - 1] - h[tick] * log(pres[tick] / pres[tick - 1])
  }

  return(hght)

}

# ARL File Processing  -------------------------------------------------------

#' Generate the file name for a meteorological file in ARL format
#'
#' \code{ArlFilename} generates an a NOAA (National Oceanic and Atmospheric
#' Administration) ARL (Air Resources Laboratory) meteorological file name.
#' This is the name of the file on the NOAA ARL meteorological archives
#' (https://www.ready.noaa.gov/archives.php). This can be the name of the file
#' only, or can include the directory path on the NOAA ARL ftp server
#' (if archive = TRUE).
#'
#'#' The following metoeorological models are available
#'
#' | Model | Long Name | Extent | Dates | Latency |
#' | --- | --- | --- | --- | --- |
#' | gdas0p5 | Global Data Assimilation System at 0.5 degrees | Global | September 2007 to June 2019 | NA |
#' | gdas1 | Global Data Assimilation System at 1 degree | Global | December 2004 to present | Lags by 1 day |
#' | gfs0p25 | Global Forecast System at 0.25 degrees | Global | June 2019 - present | Forecast available up to 6 days in the future |
#' | hrrr v1 | High-Resolution Rapid Refresh Version 1 | Continental USA | June 15, 2015 - July 23, 2019 | NA |
#' | hrrr v2 | High-Resolution Rapid Refresh Version 2 | Continental USA | July 23, 2019 - October 27, 2020 | NA |
#' | hrrr v3 | High-Resolution Rapid Refresh Version 3 | Continental USA | October 27, 2020 - present | Lags by 1 day |
#' | nam12 | North American Mesoscale Model at 12 km | North America ~20N to ~60N | May 2007 to present | Lags by 1 day |
#' | nams | North American Mesoscale Model on Hybrid Sigma-Pressure | North America ~20N to ~60N | 2010 to present | Lags by 1 day |
#' | narr | North American Regional Reanalysis | North America | 1979 - 2019 | NA |
#'
#' The appropriate version of hrrr is automatically detected by the code.
#' Note that only hrrr and gfs0p25 can be used in arl2nc and arl_header
#' functions.
#'
#' @param model character string specifying the meteorological model
#'   to download. One of: "gdas0p5", "gdas1", "gfs0p25", "hrrr", "nam12",
#'   "nams", or "narr".
#' @param utc vector of UTC (Universal Coordinated Time) dates in POSIX
#'   (Portable Operating System Interface) format
#' @param nhrs numeric specifying the number of hours
#'   (positive for forward-time, negative for backward time) needed to cover
#'   the period of interest. If the period extends over multiple files, a
#'   vector of file names will be returned.
#' @param archive logical - if TRUE (default is FALSE), then the path to the
#'   NOAA ARL ftp archive will be included
#'
#' @return character vector of meteorological file names
#'
#' @examples
#' ArlFilename(
#'   model = "gdas0p5",
#'   utc = lubridate::ymd_hms("2022-01-01 00:00:00"),
#'   nhrs = 0
#'  )
#' # [1] "20220101_gdas0p5"
#'
#' @family meteorology ARL file processing functions
#' @export
ArlFilename <- function(model, utc, nhrs, archive = FALSE) {

  # Available models
  models <- c("gdas0p5", "gdas1", "gfs0p25", "hrrr", "nam12", "nams", "narr")

  # Error handling
  stopifnot(
    # "model" must be a length-1 character identical to one of the options
    length(model) == 1,
    model %in% models,
    # "utc" must be a length-1 POSIX
    length(utc)  == 1,
    inherits(utc, "POSIXct"),
    # "nhrs" must be a length 1 numeric
    length(nhrs) == 1,
    is.numeric(nhrs),
    # "archive" must be a length-1 logical
    length(archive) == 1,
    is.logical(archive)
  )

  # Apply the nhrs to extend the utc
  # Add a sequence of hours since no model has resolution greater than 1 hour
  utc <- utc + lubridate::hours(0:nhrs)

  # Initialize the path to NULL
  ftp_path <- rep(NULL, length(utc))

  # Create name for each met model
  if (model == "gdas0p5") {
    if (archive) {
      ftp_path <-
        rep("ftp://arlftp.arlhq.noaa.gov/archives/gdas0p5/", length(utc))
    }
    files   <-
      paste0(
        ftp_path,
        lubridate::year(utc),
        stringr::str_pad(lubridate::month(utc), width = 2, pad = 0),
        stringr::str_pad(lubridate::day(utc),   width = 2, pad = 0),
        "_gdas0p5"
      )
  }
  if (model == "gdas1") {
    if (archive) {
      ftp_path <-
        rep("ftp://arlftp.arlhq.noaa.gov/archives/gdas1/", length(utc))
    }
    # gdas1 is dated by the week, 1:1-7, 2:8-14, 3:15-21, 4:22-28, 5:29-31
    wk <- c(1, 2, 3, 4, 5)[cut(lubridate::day(utc), c(-1, 7, 14, 21, 29))]
    # month and year part of name
    files <-
      paste0(
        ftp_path,
        "gdas1.",
        format(utc, "%b%y") %>% tolower,
        ".w", wk
      )
  }
  if (model == "gfs0p25") {
    if (archive) {
      ftp_path <-
        rep("ftp://arlftp.arlhq.noaa.gov/archives/gfs0p25/", length(utc))
    }
    files <-
      paste0(
        ftp_path,
        lubridate::year(utc),
        stringr::str_pad(lubridate::month(utc), width = 2, pad = 0),
        stringr::str_pad(lubridate::day(utc),   width = 2, pad = 0),
        "_gfs0p25"
      )
  }
  if (model == "hrrr") {
    # There are three versions of hrrr.
    # v1: June 15, 2015 - July 23, 2019
    # v2: July 23, 2019 - October 27, 2020
    # v3: October 27, 2020 - present
    if (archive) {
      ftp_path <-
        rep("ftp://arlftp.arlhq.noaa.gov/archives/hrrr/", length(utc))
      # Path to v2, which ended on 2020-10-27 11:00:00
      ftp_path[utc < lubridate::ymd_hms("2020-10-23 11:00:00")] <-
        "ftp://arlftp.arlhq.noaa.gov/archives/hrrr.v2/"
      # Path to v1, which ended on 2019-07-23 11:00:00
      ftp_path[utc < lubridate::ymd_hms("2019-07-23 11:00:00")] <-
        "ftp://arlftp.arlhq.noaa.gov/archives/hrrr.v1/"
    }
    # hrrr is dated by the hour, 0:0-5, 6:6-11, 12:12-17, 18:18-23
    hr_adj <- c(0, 6, 12, 18)[cut(lubridate::hour(utc), c(-1, 5, 11, 17, 23))]
    # Filename for current version
    files <-
      paste0(
        ftp_path,
        lubridate::year(utc),
        stringr::str_pad(lubridate::month(utc), width = 2, pad = 0),
        stringr::str_pad(lubridate::day(utc),   width = 2, pad = 0), "_",
        stringr::str_pad(hr_adj,                width = 2, pad = 0), "-",
        stringr::str_pad(hr_adj + 5,            width = 2, pad = 0), "_hrrr"
      )
    # Filename for v1 or v2
    files[utc < lubridate::ymd_hms("2020-10-27 11:00:00")] <-
      paste0(
        ftp_path[utc < lubridate::ymd_hms("2020-10-27 11:00:00")],
        "hysplit.",
        lubridate::year(utc),
        stringr::str_pad(lubridate::month(utc), width = 2, pad = 0),
        stringr::str_pad(lubridate::day(utc),   width = 2, pad = 0), ".",
        stringr::str_pad(hr_adj,                width = 2, pad = 0), "z.hrrra"
      )
  }
  if (model == "nam12") {
    if (archive) {
      ftp_path <-
        rep("ftp://arlftp.arlhq.noaa.gov/archives/gfs0p25/", length(utc))
    }
    files   <-
      paste0(
        ftp_path,
        lubridate::year(utc),
        stringr::str_pad(lubridate::month(utc), width = 2, pad = 0),
        stringr::str_pad(lubridate::day(utc),   width = 2, pad = 0),
        "_nam12"
      )
  }
  if (model == "nams") {
    if (archive) {
      ftp_path <-
        rep("ftp://arlftp.arlhq.noaa.gov/archives/gfs0p25/", length(utc))
    }
    files <-
      paste0(
        ftp_path,
        lubridate::year(utc),
        stringr::str_pad(lubridate::month(utc), width = 2, pad = 0),
        stringr::str_pad(lubridate::day(utc),   width = 2, pad = 0),
        "_hysplit.t00z.namsa"
      )
  }
  if (model == "narr") {
    if (archive) {
      ftp_path <-
        rep("ftp://arlftp.arlhq.noaa.gov/archives/gfs0p25/", length(utc))
    }
    files <-
      paste0(
        ftp_path,
        "NARR",
        lubridate::year(utc),
        stringr::str_pad(lubridate::month(utc), width = 2, pad = 0)
      )
  }

  # Return the unique files
  files <- unique(files)

  return(files)

}

#' Download a meteorological file in ARL format from the NOAA ARL Archive
#'
#' \code{DownloadARL} downloads meteorological data from the NOAA
#' (National Oceanic and Atmospheric Administration) ARL
#' (Air Resources Laboratory) Archives ftp site
#' (https://www.ready.noaa.gov/archives.php).
#'
#' The following metoeorological models are available
#'
#' | Model | Long Name | Extent | Dates | Latency |
#' | --- | --- | --- | --- | --- |
#' | gdas0p5 | Global Data Assimilation System at 0.5 degrees | Global | September 2007 to June 2019 | NA |
#' | gdas1 | Global Data Assimilation System at 1 degree | Global | December 2004 to present | Lags by 1 day |
#' | gfs0p25 | Global Forecast System at 0.25 degrees | Global | June 2019 - present | Forecast available up to 6 days in the future |
#' | hrrr v1 | High-Resolution Rapid Refresh Version 1 | Continental USA | June 15, 2015 - July 23, 2019 | NA |
#' | hrrr v2 | High-Resolution Rapid Refresh Version 2 | Continental USA | July 23, 2019 - October 27, 2020 | NA |
#' | hrrr v3 | High-Resolution Rapid Refresh Version 3 | Continental USA | October 27, 2020 - present | Lags by 1 day |
#' | nam12 | North American Mesoscale Model at 12 km | North America ~20N to ~60N | May 2007 to present | Lags by 1 day |
#' | nams | North American Mesoscale Model on Hybrid Sigma-Pressure | North America ~20N to ~60N | 2010 to present | Lags by 1 day |
#' | narr | North American Regional Reanalysis | North America | 1979 - 2019 | NA |
#'
#' The appropriate version of hrrr is automatically detected by the code.
#' Note that only hrrr and gfs0p25 can be used in arl2nc and arl_header
#' functions.
#'
#' @param model character string specifying the meteorological model
#'   to download. One of: "gdas0p5", "gdas1", "gfs0p25", "hrrr", "nam12",
#'   "nams", or "narr".
#' @param utc vector of UTC (Universal Coordinated Time) dates in POSIX
#'   (Portable Operating System Interface) format
#' @param nhrs numeric specifying the number of hours
#'   (positive for forward-time, negative for backward time) needed to cover
#'   the period of interest. If the period extends over multiple files, a
#'   vector of file names will be returned.
#' @param metdir character string where to download and save the file
#' @param overwrite logical, if TRUE (default), then an existing met
#'   file is overwritten. If FALSE, then an existing met file is not
#'   overwritten. Use with caution since a corrupt (e.g., partially downloaded)
#'   met file will be left there.
#' @param verbose logical, if TRUE (defaut) the status will be printed
#'
#' @return A data.frame with columns:
#'  | Column | Description |
#'  | --- | --- |
#'  | dir | character, the directory where the met file is stored |
#'  | file | character, the directory where the met file is stored |
#'  | status | character, One of "exists", downloaded", "download failed" |
#'  Side effect: downloads the file to the directory specified by "metdir".
#'
#' @examples
#' DownloadARL(
#'   model = "gfs0p25",
#'   utc = lubridate::ymd_hms("2020-01-01 00:00:00"),
#'   nhrs = 0,
#'   metdir = "/tmp/",
#'   overwrite = TRUE,
#'   verbose = TRUE
#' )
#'
#' @family meteorology ARL file processing functions
#' @export
DownloadARL <- function(
    model,
    utc,
    nhrs,
    metdir,
    overwrite,
    verbose = TRUE
) {

  # Available models
  models <- c("gdas0p5", "gdas1", "gfs0p25", "hrrr", "nam12", "nams", "narr")

  # Error handling
  stopifnot(
    # "model" must be a length-1 character identical to one of the options
    length(model) == 1,
    model %in% models,
    # "utc" must be a length-1 POSIX
    length(utc)  == 1,
    inherits(utc, "POSIXct"),
    # "nhrs" must be a length-1 numeric
    length(nhrs) == 1,
    is.numeric(nhrs),
    # "dir" must be a length-1 character that points to an existing directory
    # with write permission
    length(metdir) == 1,
    is.character(metdir),
    dir.exists(metdir),
    file.access(metdir, 2) == 0,
    # Overwrite must be a length-1 logical
    length(overwrite) == 1,
    is.logical(overwrite)
  )

  # Define the files we are looking for
  files <- ArlFilename(model, utc, nhrs, archive = FALSE)

  # Initialize the status - we will update this as we learn about it
  status <- rep(NA, length(files))

  # Find local files
  files_l <- paste0(metdir, files)

  # Test if the local files already exist
  files_l_ex <- file.exists(files_l)
  if (verbose & any(files_l_ex)) {
    cat(paste0("\n", files_l[files_l_ex], " exists"))
  }
  if (!overwrite) {
    status[files_l_ex] <- "exists"
  }

  # Find the arl archive files
  files_a <- ArlFilename(model, utc, nhrs, archive = TRUE)

  # Download the files
  for (tick in which(is.na(status))) {
    res <-
      try(
        expr = {
          paste0("wget ", files_a[tick]) %>% system()
          paste0("mv ", files[tick], " ", metdir) %>% system()
        },
        silent = TRUE
      )
    if (class(res) == "try-error") {
      status[tick] <- "download failed"
      if (verbose) {
        cat(paste0("\n", files[tick], " failed to download"))
      }
    } else {
      status[tick] <- "downloaded"
    }
  }

  # Return the data.frame of the results
  fileinfo <-
    data.frame(
      dir    = metdir,
      file   = files,
      status = status
    )

  return(fileinfo)

}

#' Find the time index in a NOAA ARL meteorological file
#'
#' \code{ArlHour} determines the time index of a NOAA
#' (National Oceanic and Atmospheric Administration) ARL
#' (Air Resources Laboratory) meteorological file that corresponds to a time.
#' These indexes are used in the file names of NetCDF extractions.
#'
#' @param utc vector of UTC (Universal Coordinated Time) dates in POSIX
#'   (Portable Operating System Interface) format
#' @param model character string specifying the meteorological model
#'   One of: "gdas0p5", "gdas1", "gfs0p25", "hrrr", "nam12", "nams", or "narr".
#'
#' @return integer time index in the meteorological file
#'
#' @examples
#' ArlHour(
#'   utc = lubridate::ymd_hms("2022-01-01 00:00:00"),
#'   model = "gdas0p5"
#' )
#'
#' @family meteorology ARL file processing functions
#' @export
ArlHour <- function(utc, model) {

  if (model %in% c("gdas1")) {
    hr <-
      ((lubridate::day(utc) - 1) %% 7) * 24 +
        cut(lubridate::hour(utc), seq(from = -1, to = 24, by = 3)) %>%
      as.numeric()
  }
  if (model %in% c("gfs0p25", "gdas0p5", "nam12")) {
    hr <-
      cut(lubridate::hour(utc), seq(from = -1, to = 24, by = 3)) %>%
      as.numeric()
  }
  if (model %in% c("hrrr")) {
    model_hrs <- lubridate::hour(utc) - c(-1,5,11,17)
    hr <- min(model_hrs[model_hrs > 0])
  }
  if (model %in% c("nams")) {
    hr <- lubridate::hour(utc) + 1
  }
  if (model %in% c("narr")) {
    hr <-
      (lubridate::day(utc) - 1)* 24 +
        cut(lubridate::hour(utc), seq(from = -1, to = 24, by = 3)) %>%
      as.numeric()
  }

  # Return the hour
  return(hr)

}

#' Read the header of an NOAA ARL file
#'
#' \code{ArlHeader} reads the header information from a NOAA
#' (National Oceanic and Atmospheric Administration) ARL
#' (Air Resources Laboratory) meteorological file. The header includes metadata
#' about the date, grid, and projection.
#'
#' @param arl character name of the file. Must be a HRRR or GFS0p25 file.
#'   See ArlFilename.
#'
#' @return list of metadata
#'
#' @examples
#' # Not run because it is too computationally expesive to test every time
#' # the package builds
#' \dontrun{
#' metfile_gfs0p25 <- DownloadARL(
#'   model = "gfs0p25",
#'   utc = lubridate::ymd_hms("2020-01-01 00:00:00"),
#'   nhrs = 0,
#'   metdir = "/tmp/",
#'   overwrite = TRUE,
#'   verbose = TRUE
#' )
#' ArlHeader(
#'   arl = metfile_gfs0p25$file
#' )
#' metfile_hrrr <- DownloadARL(
#'   model = "hrrr",
#'   utc = lubridate::ymd_hms("2022-01-01 00:00:00"),
#'   nhrs = 0,
#'   metdir = "/tmp/",
#'   overwrite = TRUE,
#'   verbose = TRUE
#' )
#' ArlHeader(
#'   arl = metfile_hrrr$file
#' )
#' }
#'
#' @family meteorology ARL file processing functions
#' @export
ArlHeader <- function(arl) {

  # Error handling
  stopifnot(
    length(arl) == 1,
    is.character(arl)
  )

  # Detect the model
  if (stringr::str_detect(arl, "gfs0p25")) {
    model <- "gfs0p25"
  }
  if (stringr::str_detect(arl, "hrrr")) {
    model <- "hrrr"
  }

  # Open the arl file as a connection
  f_arl <- file(arl, 'rb')

  # Initialize output
  out <- NULL

  # Greenwich date for which data valid
  out$year                  <- readChar(f_arl, 2)  %>% as.integer() + 2000
  out$month                 <- readChar(f_arl, 2)  %>% as.integer()
  out$day                   <- readChar(f_arl, 2)  %>% as.integer()
  out$hour                  <- readChar(f_arl, 2)  %>% as.integer()
  # Hours forecast, zero for analysis
  out$forecast              <- readChar(f_arl, 2)  %>% as.integer()
  # Level from the surface up
  out$layer                 <- readChar(f_arl, 2)  %>% as.integer()
  # Grid Identification
  out$grid                  <- readChar(f_arl, 2)
  # Variable Label
  out$variable              <- readChar(f_arl, 4)
  # Scaling exponent needed for unpacking
  out$exponent              <- readChar(f_arl, 4)  %>% as.integer()
  # Precision of unpacked data
  out$precision             <- readChar(f_arl, 14) %>% as.numeric()
  # Unpacked data value at grid point 1, 1
  out$value11               <- readChar(f_arl, 14) %>% as.numeric()
  # The data source - i.e., the name of the met model
  out$data_source           <- readChar(f_arl, 4)
  # Forecast time
  out$forecast_hour         <- readChar(f_arl, 3)  %>% as.integer()
  out$forecast_minute       <- readChar(f_arl, 2)  %>% as.integer()
  # Projection parameters
  # Pole Latitude
  out$pole_latitude         <- readChar(f_arl, 7)  %>% as.numeric()
  # Pole Longitude
  out$pole_longitude        <- readChar(f_arl, 7)  %>% as.numeric()
  # Tangent Latitude
  out$tangent_latitude      <- readChar(f_arl, 7)  %>% as.numeric()
  # Tangent Longitude
  out$tangent_longitude     <- readChar(f_arl, 7)  %>% as.numeric()
  # Grid size
  out$grid_size             <- readChar(f_arl, 7)  %>% as.numeric()
  # Orientation
  out$orientation           <- readChar(f_arl, 7)  %>% as.numeric()
  # Cone angle
  out$cone_angle            <- readChar(f_arl, 7)  %>% as.numeric()
  # X Synch Point
  out$xsynch_point          <- readChar(f_arl, 7)  %>% as.numeric()
  # Y Synch Point
  out$ysynch_point          <- readChar(f_arl, 7)  %>% as.numeric()
  # Synch Point Latitude
  out$synch_point_latitude  <- readChar(f_arl, 7)  %>% as.numeric()
  # Synch Point Longitude
  out$synch_point_longitude <- readChar(f_arl, 7)  %>% as.numeric()
  # Reserved should be 0
  out$reserved              <- readChar(f_arl, 7)  %>% as.numeric()
  # !! There are only 3 characters reserved for this.
  #    It will give 440 for GFS0p25. 1000 must be added. !!
  if (model == "gfs0p25") {
    out$nx                  <- readChar(f_arl, 3) %>% as.integer() + 1000
  }
  if (model == "hrrr") {
    out$nx                  <- readChar(f_arl, 3) %>% as.integer()
  }
  # !! There are only 3 characters reserved for this.
  #    It will give 059 for HRRR. 1000 must be added. !!
  if (model == "gfs0p25") {
    out$ny                  <- readChar(f_arl, 3) %>% as.integer()
  }
  if (model == "hrrr") {
    out$ny                  <- readChar(f_arl, 3) %>% as.integer() + 1000
  }
  # nlayers
  out$nlayers               <- readChar(f_arl, 3) %>% as.integer()
  # V coordinate decodes as:
  # 1-sigma (fraction)
  # 2-pressure (mb)
  # 3-terrain (fraction)
  # 4-hybrid (mb: offset.fraction)
  # The V coordinate should be 1 for HRRR. The hybrid coefficients and
  # equation are contained in this code.
  out$v_coordinate          <- readChar(f_arl, 2)  %>% as.numeric()
  # The index length is the length of the rest of the index record.
  # For HRRR, this should be 2780.
  out$index_length          <- readChar(f_arl, 4)  %>% as.integer()

  # Read out the variables at each level
  # Variables stored as a list of vars in each level

  # Vars for HRRR
  vars     <- NULL
  if (model == "hrrr") {
    # Sigma grid A and B values
    sigma_A <- rep(NA, out$nlayers)
    sigma_B <- rep(NA, out$nlayers)
    # Loop through layers
    for (tick in 1:out$nlayers) {
      # Read sigma sigma pressures
      sigma_A.B <- readChar(f_arl, 6)
      sigma_A[tick] <- strsplit(sigma_A.B, "\\.")[[1]][1] %>%
        as.numeric()
      if (is.na(sigma_A[tick])) {
        sigma_A[tick] <- 0
      }
      sigma_B[tick] <- paste0("0.", strsplit(sigma_A.B, "\\.")[[1]][2]) %>%
        as.numeric()
      # Read variables
      nvars <- readChar(f_arl, 2) %>% as.integer()
      vars_now <- NULL
      # Loop through variables and record their names
      for (variable.tick in 1:nvars){
        vars_now <- c(vars_now, readChar(f_arl, 4))
        # Cut through the checksum (next 3 chars) and the reserved (next 1 char)
        readChar(f_arl, 4)
      }
      vars[[tick]] <- vars_now
    }
    # Save to header info
    out$vars <- vars
    out$sigma_A <- sigma_A
    out$sigma_B <- sigma_B
    # Create a projection
    lat_1 <- acos(out$cone_angle / 360.0) * (180 / pi)
    out$proj  <-
      paste0(
        "+proj=lcc +lat_1=",  out$cone_angle,
        " +lat_2=",           out$cone_angle,
        " +lat_0=",           out$tangent_latitude,
        " +lon_0=",           out$tangent_longitude,
        ' +units=m +e=0 +a=6371229'
      )
    out$xx <-
      seq(
        from = -1 * ((out$nx * out$grid_size * 1000) - 1) / 2,
        to = ((out$nx * out$grid_size * 1000) - 1) / 2,
        by = out$grid_size * 1000
      ) - 520.143
    out$yy <-
      seq(
        from = -1 * ((out$ny * out$grid_size * 1000) - 1) / 2,
        to = ((out$ny * out$grid_size * 1000) - 1) / 2,
        by = out$grid_size * 1000
      ) - 306.153
  }

  # Vars for GFS0p25
  if (model == "gfs0p25") {
    # Hybrid grid A and B values
    hybrid_A  <- rep(NA, out$nlayers)
    hybrid_B  <- rep(NA, out$nlayers)
    # Loop through layers
    for (tick in 1:out$nlayers){
      # Read hybrid sigma pressures
      hybrid_A.B <- readChar(f_arl, 6)
      hybrid_A[tick] <- strsplit(hybrid_A.B, "\\.")[[1]][1] %>%
        as.numeric()
      if (is.na(hybrid_A[tick])) {
        hybrid_A[tick] <- 0
      }
      hybrid_B[tick] <-
        paste0("0.", strsplit(hybrid_A.B, "\\.")[[1]][2]) %>%
        as.numeric()
      # Read variables
      nvars          <- readChar(f_arl, 2) %>% as.integer()
      vars_now       <- NULL
      # Loop through variables and record their names
      for (variable.tick in 1:nvars){
        vars_now     <- c(vars_now, readChar(f_arl, 4))
        # Cut through the checksum (next 3 chars) and the reserved (next 1 char)
        readChar(f_arl, 4)
      }
      vars[[tick]] <- vars_now
    }
    # Save to header info
    out$vars      <- vars
    out$hybrid_A  <- hybrid_A
    out$hybrid_B  <- hybrid_B
  }

  # Return the output
  return(out)

}

# NetCDFs  -------------------------------------------------------------------

#' Convert a GFS0p25 NOAA ARL file to NetCDF
#'
#' \code{NcdfFromArl_GFS0p25} extracts data from a
#' GFS0p25 (Global Forcast System at 0.25 degree resolution)
#' NOAA (National Oceanic and Atmospheric Administration)
#' ARL (Air Resources Laboratory) meteorological file into a
#' NetCDF (Network Common Data Form) file. A NetCDF file can be read using
#' R's raster or ncdf4 packages. It is a more compact and readable format than
#' NOAA ARL and by selecting only the required data to extract, it offers
#' significant disk space savings. NetCDFs are the required input for
#' mission planning and some Level 4 products.
#' Refer to the output file itself for information on its contents.
#'
#' @param dir_arl character, directory where the NOAA ARL file is stored.
#' @param file_arl character, name of the NOAA ARL file.
#' @param dir_out character, directory where to store the NetCDF file.
#' @param vars_surface character vector. Surface variable to extract.
#'   Subset of: "PRSS", "MSLP", "UMOF", "VMOF", "TPP6", "SHTF", "DSWF", "SPH2",
#'   "U10M", "V10M", "T02M", "TCLD", "PBLH", "LHTF", "USTR", "RGHS", "PTRO",
#'   "SHGT", and the additional parameters calculated in this code, external to
#'   the met product from ARL, "WNDS" (wind speed in ms^-1), "WNDA" (wind
#'   direction as an azimuth degrees from north), "WNDD" (wind divergence in
#'   s^-1), and "WNDV" (wind vorticity in s^-1). Defaults to "PRSS", "U10M",
#'   "V10M", "TCLD", "PBLH", "SHGT", which is the minimum needed for STILT
#'   receptor list generation and analysis.
#' @param vars_upper character vector. Upper layer variable to extract.
#'   Subset of: "TEMP", "UWND", "VWND", "WWND", "RELH", "PRES", and the
#'   additional parameters calculated in this code, external to the met product
#'   from ARL, "WVMR" (water vapor mixing ratio), "HGHT" (layer height in m).
#'   Defaults to "TEMP", "RELH", "PRES", "WVMR", "HGHT", which is the minimum
#'   needed for STILT receptor list generation and analysis.
#' @param lon_out_range numeric vector length 2. Range of longitudes to output.
#'   (min longitude, max longitude), -180 to 180 convention.
#' @param lat_out_range numeric vector length 2. Range of latitudes to output.
#'   (min latitude, max latitude).
#' @param layers_sel layers to output. Defaults to 1:55 - all the layers.
#' @param hours_sel hours in file to output. Defaults to 1:8 - all the hours.
#' @param verbose logical. If TRUE, print progress.
#'
#' @return A NetCDF containing the met data. The file is self-documenting.
#'
#' @examples
#' # Not run because it is too computationally expesive to test every time
#' # the package builds
#' \dontrun{
#' NcdfFromArl_GFS0p25(
#'   dir_arl = "/tmp/",
#'   file_arl = "20200101_gfs0p25",
#'   dir_out = "/tmp/"
#' )
#' }
#'
#' @family meteorology NetCDF functions
#' @export
NcdfFromArl_GFS0p25 <- function(
  dir_arl,
  file_arl,
  dir_out,
  vars_surface  = c("PRSS", "U10M", "V10M", "TCLD", "PBLH", "SHGT"),
  vars_upper    = c("TEMP", "RELH", "PRES", "WVMR", "HGHT"),
  lon_out_range = c(-180, 180),
  lat_out_range = c(-90, 90),
  layers_sel    = 1:55,
  hours_sel     = 1:8,
  verbose       = TRUE
) {

  # Open the connection
  f_arl       <-  file(paste0(dir_arl, file_arl), 'rb')

  # Initialize NetCDF

  # Hard coded dimensions
  index_length  <- 3340
  lons          <- seq(from = -179.875,  to = 179.875,  by = 0.25)
  lats          <- seq(from = -90,       to = 90,       by = 0.25)
  hours         <- seq(from = 0, to = 21, by = 3)
  layers        <- 1:55

  # Dimension lengths
  nlon          <- length(lons)
  nlat          <- length(lats)
  nhours        <- length(hours)
  nlayer        <- length(layers)

  # Selected dimensions
  lons_out      <- lons[lons >= lon_out_range[1] & lons <= lon_out_range[2]]
  lats_out      <- lats[lats >= lat_out_range[1] & lats <= lat_out_range[2]]
  hours_out     <- hours[hours_sel]
  layers_out    <- layers[layers_sel]

  # Selected dimensions lengths
  nlon_out      <- length(lons_out)
  nlat_out      <- length(lats_out)
  nhours_out    <- length(hours_out)
  nlayers_out   <- length(layers_out)

  # NetCDF dimensions
  londim    <- ncdf4::ncdim_def('longitude', 'degrees lowerleft',  lons_out)
  latdim    <- ncdf4::ncdim_def('latitude',  'degrees lowerleft',  lats_out)
  layerdim  <- ncdf4::ncdim_def('layer',     'hybrid sigma layer', layers_out)

  # Make var
  mv <- 99999 # missing value

  # Initialize variable list
  vars_nc <- list(
    # Surface Variables
    PRSS =
      ncdf4::ncvar_def(
        name = 'PRSS',
        units = 'degrees',
        longname = "surface pressure",
        dim = list(londim, latdim),
        missval = mv
      ),
    MSLP =
      ncdf4::ncvar_def(
        name = 'MSLP',
        units = 'hPa',
        longname = 'mean sea level pressure',
        dim = list(londim, latdim),
        missval = mv
      ),
    UMOF =
      ncdf4::ncvar_def(
        name = 'UMOF',
        units = 'N/m2',
        longname = ' u-component of momentum flux',
        dim = list(londim, latdim),
        missval = mv
      ),
    VMOF =
      ncdf4::ncvar_def(
        name = 'VMOF',
        units = 'N/m2',
        longname = 'v-component of momentum flux',
        dim = list(londim, latdim),
        missval = mv
      ),
    TPP6 =
      ncdf4::ncvar_def(
        name = 'TPP6',
        units = 'm',
        longname = 'precipitation, 6 hr accumulation',
        dim = list(londim, latdim),
        missval = mv
      ),
    SHTF =
      ncdf4::ncvar_def(
        name = 'SHTF',
        units = 'W/m2',
        longname = 'sensible heat net flux',
        dim = list(londim, latdim),
        missval = mv
      ),
    DSWF =
      ncdf4::ncvar_def(
        name = 'DSWF',
        units = 'W/m2',
        longname = 'downward short wave radiation flux',
        dim = list(londim, latdim),
        missval = mv
      ),
    SPH2 =
      ncdf4::ncvar_def(
        name = 'SPH2',
        units = 'kg/kg',
        longname = 'specific humidity at 2 meters AGL',
        dim = list(londim, latdim),
        missval = mv
      ),
    U10M =
      ncdf4::ncvar_def(
        name = 'U10M',
        units = 'm/s',
        longname = 'u wind component at 10 meters AGL',
        dim = list(londim, latdim),
        missval = mv
      ),
    V10M =
      ncdf4::ncvar_def(
        name = 'V10M',
        units = 'm/s',
        longname = 'v wind conponent at 10 meters AGL',
        dim = list(londim, latdim),
        missval = mv
      ),
    WNDS =
      ncdf4::ncvar_def(
        name = 'WNDS',
        units = 'm/s',
        longname = 'wind speed',
        dim = list(londim, latdim),
        missval = mv
      ),
    WNDA =
      ncdf4::ncvar_def(
        name = 'WNDA',
        units = 'degrees from north',
        longname = 'wind direction',
        dim = list(londim, latdim),
        missval = mv
      ),
    WNDD =
      ncdf4::ncvar_def(
        name = 'WNDD',
        units = '1/s',
        longname = 'wind divergence',
        dim = list(londim, latdim),
        missval = mv
      ),
    WNDV =
      ncdf4::ncvar_def(
        name = 'WNDV',
        units = '1/s',
        longname = 'wind vorticity',
        dim = list(londim, latdim),
        missval = mv
      ),
    T02M =
      ncdf4::ncvar_def(
        name = 'T02M',
        units = 'K',
        longname = 'temperature at 2 meters AGL',
        dim = list(londim, latdim),
        missval = mv
      ),
    TCLD =
      ncdf4::ncvar_def(
        name = 'TCLD',
        units = '%',
        longname = 'total cloud cover',
        dim = list(londim, latdim),
        missval = mv
      ),
    PBLH =
      ncdf4::ncvar_def(
        name = 'PBLH',
        units = 'm',
        longname = 'planetary boundary layer height',
        dim = list(londim, latdim),
        missval = mv
      ),
    LHTF =
      ncdf4::ncvar_def(
        name = 'LHTF',
        units = 'W/m2',
        longname = 'latent heat net flux',
        dim = list(londim, latdim),
        missval = mv
      ),
    USTR =
      ncdf4::ncvar_def(
        name = 'USTR',
        units = 'm/s',
        longname = 'friction velocity',
        dim = list(londim, latdim),
        missval = mv
      ),
    RGHS =
      ncdf4::ncvar_def(
        name = 'RGHS',
        units = 'm',
        longname = 'surface roughness',
        dim = list(londim, latdim),
        missval = mv
      ),
    PTRO =
      ncdf4::ncvar_def(
        name = 'PTRO',
        units = 'hPa',
        longname = 'pressure at the tropopause',
        dim = list(londim, latdim),
        missval = mv
      ),
    SHGT =
      ncdf4::ncvar_def(
        name = 'SHGT',
        units = 'm',
        longname = 'surface height',
        dim = list(londim, latdim),
        missval = mv
      ),
    # Upper Layer Variables
    TEMP =
      ncdf4::ncvar_def(
        name = 'TEMP',
        units = 'K',
        longname = 'temperature',
        dim = list(londim, latdim, layerdim),
        missval = mv
      ),
    UWND =
      ncdf4::ncvar_def(
        name = 'UWND',
        units = 'm/s',
        longname = 'u wind component',
        dim = list(londim, latdim, layerdim),
        missval = mv
      ),
    VWND =
      ncdf4::ncvar_def(
        name = 'VWND',
        units = 'm/s',
        longname = 'v wind component',
        dim = list(londim, latdim, layerdim),
        missval = mv
      ),
    WWND =
      ncdf4::ncvar_def(
        name = 'WWND',
        units = 'm/s',
        longname = 'w wind component',
        dim = list(londim, latdim, layerdim),
        missval = mv
      ),
    RELH =
      ncdf4::ncvar_def(
        name = 'RELH',
        units = '%',
        longname = 'relative humidity',
        dim = list(londim, latdim, layerdim),
        missval = mv
      ),
    PRES =
      ncdf4::ncvar_def(
        name = 'PRES',
        units = 'hPa',
        longname = 'pressure',
        dim = list(londim, latdim, layerdim),
        missval = mv
      ),
    # Special calculated fields
    WVMR =
      ncdf4::ncvar_def(
        name = 'WVMR',
        units = 'mol/mol',
        longname = 'water vapor mixing ratio',
        dim = list(londim, latdim, layerdim),
        missval = mv
      ),
    HGHT =
      ncdf4::ncvar_def(
        name = 'HGHT',
        units = 'm',
        longname = 'height above ground',
        dim = list(londim, latdim, layerdim),
        missval = mv
      )
  )

  # Restrict to the variables that were chosen
  vars_nc <- vars_nc[c(vars_surface, vars_upper)]

  # Test for required inputs
  if (("WVMR" %in% vars_upper) &
      any(!(c("TEMP", "RELH", "PRES") %in% vars_upper))) {
    stop("WVMR requires TEMP, RELH and PRES")
  }
  if (("HGHT" %in% vars_upper) &
      any(!(c("TEMP", "RELH", "PRES", "PRSS") %in%
            c(vars_upper, vars_surface)))) {
    stop("HGHT requires TEMP, RELH, PRES, and PRSS")
  }

  # Loop through times
  for (hour.tick in 1:8) {

    # Seek through the header
    seek(f_arl, nlon * nlat - index_length, "current")

    # Clear the blanks
    ClearBlanks(f_arl)

    # If this is not an hour of interest, then skip ahead
    if (!(hour.tick %in% hours_sel)) {
      seek(f_arl, 348 * (nlon * nlat + 50), "current")
      next()
    }

    # Make new output file
    ncid_new <-
      ncdf4::nc_create(
        paste0(dir_out, file_arl, "_", hour.tick, ".nc"),
        vars_nc,
        force_v4 = TRUE
      )

    # Read the variables and save them

    # Loop through the variables
    for (var.tick in 1:348) {

      # * Block header

      # Read the block header
      block_header              <- NULL
      block_header$year         <- readChar(f_arl, 2) %>%
                                   as.integer() %>%
                                   '+'(2000)
      block_header$month        <- readChar(f_arl, 2) %>%
                                   as.integer()
      block_header$day          <- readChar(f_arl, 2) %>%
                                   as.integer()
      block_header$hour         <- readChar(f_arl, 2) %>%
                                   as.integer()
      block_header$forecast     <- readChar(f_arl, 2) %>%
                                   as.integer()
      block_header$layer        <- readChar(f_arl, 2) %>%
                                   as.numeric()
      block_header$AA           <- readChar(f_arl, 2)
      block_header$var_name     <- readChar(f_arl, 4)
      block_header$scale        <- readChar(f_arl, 4) %>%
                                   as.numeric()
      block_header$precision    <- readChar(f_arl, 14) %>%
                                   as.numeric()
      block_header$first_value  <- readChar(f_arl, 14) %>%
                                   as.numeric()

      # If this is not one of the variables we want, then skip ahead
      if (!(block_header$var_name %in% c(vars_surface, vars_upper))) {
        seek(f_arl, nlon * nlat, "current")
        next()
      }

      # If this is not one of the layers we want, then skip ahead
      if (!(block_header$layer %in% c(0, layers_sel))) {
        seek(f_arl, nlon * nlat, "current")
        next()
      }

      # Report the status of the extraction
      if (verbose) {
        cat(
          paste0(
            "\nhour.tick: ", hour.tick, " of 8",
            " var.tick: ",   var.tick, " of 348",
            " Varible: ",    block_header$var_name,
            " Layer: ",      block_header$layer,
            " Hour: ",       block_header$hour
          )
        )
      }

      # Block data

      # Read the block data
      dat <-
        readBin(
          f_arl,
          what   = "int",
          n      = nlon * nlat,
          size   = 1,
          signed = F
        )

      # Arrange the block data into an array
      datmat <- matrix(nrow = nlon, ncol = nlat, data = dat)

      # * Fill the variable array

      # Initialize the variable array
      varmat <- matrix(nrow = nlon, ncol = nlat, data = NA)

      # Initialize the previous value
      prev_value  <- block_header$first_value

      # Walk through columns and set first values
      for (column.tick in 1:nlat) {
        # Decode the first value of this column
        varmat[1, column.tick]  <- (datmat[1, column.tick] - 127) /
          (2^(7 - block_header$scale)) + prev_value
        # Update the prev value
        prev_value              <- varmat[1, column.tick]
      }

      # Walk through the columns, start the prev value,
      # then fill each row along that column
      for (column.tick in 1:nlat) {
        prev_value      <- varmat[1, column.tick]
        for (row.tick in 2:nlon) {
          value_now     <- (datmat[row.tick, column.tick] - 127) /
            (2^(7 - block_header$scale)) +
            prev_value
          prev_value    <- value_now
          if (abs(value_now) < block_header$precision) {
            value_now   <- 0
          }
          varmat[row.tick, column.tick]   <- value_now
        }
      }

      # Change the longitude convention from 0:360 to -180:180
      varmat <- varmat[c(721:1440, 1:720), ]

      # Restrict to the lon and lat we want
      varmat <- varmat[lons %in% lons_out, lats %in% lats_out]

      # Save the variable to the netcdf

      # If this is a surface variable
      if (block_header$layer == 0) {
        ncdf4::ncvar_put(
          nc    = ncid_new,
          varid = vars_nc[[block_header$var_name]],
          vals  = varmat,
          start = c(1, 1),
          count = c(nlon_out, nlat_out)
        )

        # If this is an upper layer variable
      } else {
        ncdf4::ncvar_put(
          nc    = ncid_new,
          varid = vars_nc[[block_header$var_name]],
          vals  = varmat,
          start = c(1, 1, which(layers_sel == block_header$layer)),
          count = c(nlon_out, nlat_out, 1)
        )
      }
    }

    # If special calculated fields are selected, calculate and save them
    # Water vapor mixing ratio
    if ("WVMR" %in% vars_upper) {
      TEMP <- ncdf4::ncvar_get(ncid_new, "TEMP", collapse_degen = FALSE)
      RELH <- ncdf4::ncvar_get(ncid_new, "RELH", collapse_degen = FALSE)
      PRES <- ncdf4::ncvar_get(ncid_new, "PRES", collapse_degen = FALSE)
      WVMR <- array(dim = dim(PRES))
      for (layer.tick in 1:length(layers_sel)) {
        WVMR[,, layer.tick] <-
          WvmrFromTempRelhPres(
            TEMP[,,layer.tick],
            RELH[,,layer.tick],
            PRES[,,layer.tick]
          )
      }
      ncdf4::ncvar_put(
        nc    = ncid_new,
        varid = vars_nc[["WVMR"]],
        vals  = WVMR,
        start = c(1, 1, 1),
        count = c(nlon_out, nlat_out, nlayers_out)
      )
    }

    # heights in meters
    if ("HGHT" %in% vars_upper) {
      TEMP <- ncdf4::ncvar_get(ncid_new, "TEMP", collapse_degen = FALSE)
      RELH <- ncdf4::ncvar_get(ncid_new, "RELH", collapse_degen = FALSE)
      PRES <- ncdf4::ncvar_get(ncid_new, "PRES", collapse_degen = FALSE)
      PRSS <- ncdf4::ncvar_get(ncid_new, "PRSS", collapse_degen = FALSE)
      HGHT <- array(dim = dim(PRES))
      if (verbose) {pb <- utils::txtProgressBar()}
      for (lon.tick in 1:(dim(PRES)[1])) {
        if (verbose) {utils::setTxtProgressBar(pb, lon.tick / (dim(PRES)[1]))}
        for (lat.tick in 1:(dim(PRES)[2])) {
          HGHT[lon.tick, lat.tick, ]  <-
            GfsLayerHeights(TEMP[lon.tick,lat.tick,],
                             RELH[lon.tick,lat.tick,],
                             PRES[lon.tick,lat.tick,],
                             PRSS[lon.tick,lat.tick])
        }
      }

      # Save to netCDF
      ncdf4::ncvar_put(
        nc = ncid_new,
        varid = vars_nc[["HGHT"]],
        vals  = HGHT,
        start = c(1, 1, 1),
        count = c(nlon_out, nlat_out, nlayers_out)
      )

    }

    # Wind speed in m/s
    if ("WNDS" %in% vars_surface) {
      U10M <- ncdf4::ncvar_get(ncid_new, "U10M", collapse_degen = FALSE)
      V10M <- ncdf4::ncvar_get(ncid_new, "V10M", collapse_degen = FALSE)
      WNDS <- sqrt(U10M^2 + V10M^2)
      # Save netCDF
      ncdf4::ncvar_put(
        nc = ncid_new,
        varid = vars_nc[["WNDS"]],
        vals  = WNDS,
        start = c(1, 1),
        count = c(nlon_out, nlat_out)
      )
    }

    # Wind direction in azimuth degrees from north
    if ("WNDA" %in% vars_surface) {
      U10M <- ncdf4::ncvar_get(ncid_new, "U10M", collapse_degen = FALSE)
      V10M <- ncdf4::ncvar_get(ncid_new, "V10M", collapse_degen = FALSE)
      WNDA <- atan2(V10M, U10M)
      # Save netCDF
      ncdf4::ncvar_put(
        nc = ncid_new,
        varid = vars_nc[["WNDA"]],
        vals  = WNDA,
        start = c(1, 1),
        count = c(nlon_out, nlat_out)
      )
    }

    # Wind Divergence
    if ("WNDD" %in% vars_surface) {
      # U winds
      U10M <- ncdf4::ncvar_get(ncid_new, "U10M", collapse_degen = FALSE)
      # North-South U10M Gradient
      U10M_delta_y <- matrix(nrow = nrow(U10M), ncol = ncol(U10M))
      U10M_delta_y[, 2:(ncol(U10M_delta_y) - 1)] <-
        0.5 * (U10M[, 3:ncol(U10M_delta_y)] - U10M[, 1:(ncol(U10M_delta_y) - 2)])
      # East-West U10M Gradient
      U10M_delta_x <- matrix(nrow = nrow(U10M), ncol = ncol(U10M))
      U10M_delta_x[2:(nrow(U10M_delta_x) - 1), ] <-
        0.5 * (U10M[3:nrow(U10M_delta_x), ] - U10M[1:(nrow(U10M_delta_x) - 2), ])

      # V winds
      V10M <- ncdf4::ncvar_get(ncid_new, "U10M", collapse_degen = FALSE)
      # North-South U10M Gradient
      V10M_delta_y <- matrix(nrow = nrow(V10M), ncol = ncol(V10M))
      V10M_delta_y[, 2:(ncol(V10M_delta_y) - 1)] <-
        0.5 * (U10M[, 3:ncol(V10M_delta_y)] - U10M[, 1:(ncol(V10M_delta_y) - 2)])
      # East-West U10M Gradient
      V10M_delta_x <- matrix(nrow = nrow(V10M), ncol = ncol(V10M))
      V10M_delta_x[2:(nrow(V10M_delta_x) - 1), ] <-
        0.5 * (V10M[3:nrow(V10M_delta_x), ] - U10M[1:(nrow(V10M_delta_x) - 2), ])

      # Length along longitudes and latitude
      delta_x <-
        matrix(
          nrow = nrow(U10M),
          ncol = ncol(U10M),
          data = ParallelOfLatitudeCircumference(lats_out) *
            (diff(lons_out)[1] / 360),
          byrow = TRUE
        )
      delta_y <-
        matrix(
          nrow = nrow(U10M),
          ncol = ncol(U10M),
          data = diff(lats_out)[1] * 6378137 * pi / 180
        )

      # Compute divergence
      WNDD <- U10M_delta_x / delta_x + V10M_delta_y / delta_y

      # Save netCDF
      ncdf4::ncvar_put(
        nc = ncid_new,
        varid = vars_nc[["WNDD"]],
        vals  = WNDD,
        start = c(1, 1),
        count = c(nlon_out, nlat_out)
      )

    }

    # Wind Vorticity
    if ("WNDV" %in% vars_surface) {
      # U winds
      U10M <- ncdf4::ncvar_get(ncid_new, "U10M", collapse_degen = FALSE)
      # North-South U10M Gradient
      U10M_delta_y <- matrix(nrow = nrow(U10M), ncol = ncol(U10M))
      U10M_delta_y[, 2:(ncol(U10M_delta_y) - 1)] <-
        0.5 * (U10M[, 3:ncol(U10M_delta_y)] - U10M[, 1:(ncol(U10M_delta_y) - 2)])
      # East-West U10M Gradient
      U10M_delta_x <- matrix(nrow = nrow(U10M), ncol = ncol(U10M))
      U10M_delta_x[2:(nrow(U10M_delta_x) - 1), ] <-
        0.5 * (U10M[3:nrow(U10M_delta_x), ] - U10M[1:(nrow(U10M_delta_x) - 2), ])

      # V winds
      V10M <- ncdf4::ncvar_get(ncid_new, "U10M", collapse_degen = FALSE)
      # North-South U10M Gradient
      V10M_delta_y <- matrix(nrow = nrow(V10M), ncol = ncol(V10M))
      V10M_delta_y[, 2:(ncol(V10M_delta_y) - 1)] <-
        0.5 * (U10M[, 3:ncol(V10M_delta_y)] - U10M[, 1:(ncol(V10M_delta_y) - 2)])
      # East-West U10M Gradient
      V10M_delta_x <- matrix(nrow = nrow(V10M), ncol = ncol(V10M))
      V10M_delta_x[2:(nrow(V10M_delta_x) - 1), ] <-
        0.5 * (V10M[3:nrow(V10M_delta_x), ] - U10M[1:(nrow(V10M_delta_x) - 2), ])

      # Length along longitudes and latitude
      delta_x <-
        matrix(
          nrow = nrow(U10M),
          ncol = ncol(U10M),
          data = ParallelOfLatitudeCircumference(lats_out) *
            (diff(lons_out)[1] / 360),
          byrow = TRUE
        )
      delta_y <-
        matrix(
          nrow = nrow(U10M),
          ncol = ncol(U10M),
          data = diff(lats_out)[1] * 6378137 * pi / 180
        )

      # Compute divergence
      WNDV <- V10M_delta_y / delta_x - U10M_delta_x / delta_y

      # Save netCDF
      ncdf4::ncvar_put(
        nc = ncid_new,
        varid = vars_nc[["WNDV"]],
        vals  = WNDV,
        start = c(1, 1),
        count = c(nlon_out, nlat_out)
      )

    }

    # Close out netCDF to finalize file
    ncdf4::nc_close(ncid_new)

  }

}

#' Convert a HRRR NOAA ARL file to NetCDF
#'
#' #' \code{NcdfFromArl_GFS0p25} extracts data from a
#' GFS0p25 (Global Forcast System at 0.25 degree resolution)
#' NOAA (National Oceanic and Atmospheric Administration)
#' ARL (Air Resources Laboratory) meteorological file into a
#' NetCDF (Network Common Data Form) file. A NetCDF file can be read using
#' R's raster or ncdf4 packages. It is a more compact and readable format than
#' NOAA ARL and by selecting only the required data to extract, it offers
#' significant disk space savings. NetCDFs are the required input for
#' mission planning and some Level 4 products.
#' Refer to the output file itself for information on its contents.
#'
#' @param dir_arl character directory where the NOAA ARL file is stored
#' @param file_arl character name of the NOAA ARL file
#' @param dir_out character directory where to store the NetCDF file
#' @param vars_surface character vector. Surface variable to extract.
#'   Subset of:
#'   "SHGT", "MSLP", "TPP1", "DIFR", "T02M", "RH2M", "U10M", "V10M", "PRSS",
#'   "LHTF", "SHTF", "USTR", "RGHS", "DSWF", "PBLH", "TCLD", "REFC", "CAPE"
#'   Defaults to "SHGT", "T02M", "U10M", "V10M", "PRSS", "PBLH", "TCLD",
#'   which is the minimum needed for STILT receptor list generation and
#'   analysis.
#' @param vars_upper character vector. Upper layer variable to extract.
#'   Subset of: "TEMP", "UWND", "VWND", "WWND", "DIFW", "SPHU", "TKEN", "PRES",
#'   "WVMR", "HGHT".
#'   Defaults to "TEMP", "SPHU", "PRES", "WVMR", "HGHT" which is the minimum
#'   needed for STILT receptor list generation and analysis.
#' @param lon_out_range Numeric vector length 2. Range of longitudes to output.
#'   (min longitude, max longitude), -180 to 180 convention.
#' @param lat_out_range Numeric vector length 2. Range of latitudes to output.
#'   (min latitude, max latitude).
#' @param layers_sel layers to output. Defaults to 1:35 - all the layers.
#' @param hours_sel hours in file to output. Defaults to 1:6 - all the hours.
#' @param verbose logical. If TRUE, print progress.
#'
#' @return NetCDF containing the meteorological data.
#'   The file is self-documenting.
#'
#' @examples
#' # Not run because it is too computationally expesive to test every time
#' # the package builds
#' \dontrun{
#' NcdfFromArl_HRRR(
#'   dir_arl = "/tmp/",
#'   file_arl = "20220101_00-05_hrrr",
#'   dir_out = "/tmp/"
#' )
#' }
#'
#' @family meteorology NetCDF functions
#' @export
NcdfFromArl_HRRR <- function(
  dir_arl       = "/tmp/",
  file_arl      = "20210806_12-17_hrrr",
  dir_out       = "/tmp/",
  vars_surface  = c("SHGT", "T02M", "U10M", "V10M", "PRSS", "PBLH", "TCLD"),
  vars_upper    = c("TEMP", "SPHU", "PRES", "WVMR", "HGHT"),
  lon_out_range = c(-180, 180),
  lat_out_range = c(-90, 90),
  layers_sel    = 1:35,
  hours_sel     = 1:6,
  verbose       = TRUE
) {

  # Open thee connection
  f_arl       <-  file(paste0(dir_arl, file_arl), 'rb')

  # Initialize NetCDF

  # Hard coded dimensions
  index_length  <- 2780
  x             <- 1:1799
  y             <- 1:1059
  hours         <- 1:6
  layers        <- 1:35
  projection    <-
    "+proj=lcc +lat_1=38.5 +lat_2=38.5 +lat_0=38.5 +lon_0=262.5 +units=m +e=0 +a=6371229"
  grid_size     <- 3

  # Dimension lengths
  nx            <- length(x)
  ny            <- length(y)
  nhours        <- length(hours)
  nlayer        <- length(layers)

  # Find longitudes and latitudes
  xy        <- expand.grid(x, y)
  # 0.5 added since these lon lats are lower left and we would like cell centers
  xx <-
    seq(
      from = -1 * ((nx * grid_size * 1000) - 1) / 2,
      to = ((nx * grid_size * 1000) - 1) / 2,
      by = grid_size * 1000
    ) - 520.143 + 0.5
  # 0.5 added since these lon lats are lower left and we would like cell centers
  yy <-
    seq(
      from = -1 * ((ny * grid_size * 1000) - 1) / 2,
      to = ((ny * grid_size * 1000) - 1) / 2,
      by = grid_size * 1000
    ) - 306.153 + 0.5
  xxyy <- expand.grid(xx, yy)
  lonlat <-
    proj4::project(xxyy, projection, inverse = TRUE) %>%
    as.data.frame() %>%
    'colnames<-'(c("lon", "lat"))
  lonlat$x  <- xy$Var1
  lonlat$y  <- xy$Var2

  # Selected dimensions
  lonlat_sel    <-
    dplyr::filter(
      lonlat,
      lonlat$lon >= lon_out_range[1],
      lonlat$lon <= lon_out_range[2],
      lonlat$lat >= lat_out_range[1],
      lonlat$lat <= lat_out_range[2]
    )
  x_out         <- min(lonlat_sel$x):max(lonlat_sel$x)
  y_out         <- min(lonlat_sel$y):max(lonlat_sel$y)
  xx_out        <- xx[x_out]
  yy_out        <- yy[y_out]
  hours_out     <- hours[hours_sel]
  layers_out    <- layers[layers_sel]

  # Create matrices of the output longitude and latitude
  lonlat_out <-
    dplyr::filter(
      lonlat,
      lonlat$x %in% x_out,
      lonlat$y %in% y_out
    )
  lon_out <-
    matrix(nrow = length(x_out), ncol = length(y_out), data = lonlat_out$lon)
  lat_out <-
    matrix(nrow = length(x_out), ncol = length(y_out), data = lonlat_out$lat)

  # Selected dimensions lengths
  nx_out        <- length(xx_out)
  ny_out        <- length(yy_out)
  nhours_out    <- length(hours_out)
  nlayers_out   <- length(layers_out)

  # NetCDF dimensions
  xdim      <- ncdf4::ncdim_def('x',         'x index',            xx_out)
  ydim      <- ncdf4::ncdim_def('y',         'y index',            yy_out)
  hourdim   <- ncdf4::ncdim_def('hour',      'hour of day UTC',    hours_out)
  layerdim  <- ncdf4::ncdim_def('layer',     'hybrid sigma layer', layers_out)

  # Make var
  mv <- 99999 # missing value

  # Initialize variable list
  vars_nc <- list(

    # Longitude and Latitude
    LON =
      ncdf4::ncvar_def(
        name = 'LON',
        units = 'degreess',
        longname = "longitude",
        dim = list(xdim, ydim),
        missval = mv
      ),
    LAT =
      ncdf4::ncvar_def(
        name = 'LAT',
        units = 'degrees',
        longname = "latitude",
        dim = list(xdim, ydim),
        missval = mv
      ),

    # Surface Variables
    SHGT =
      ncdf4::ncvar_def(
        name = 'SHGT',
        units = 'm',
        longname = "surface height",
        dim = list(xdim, ydim),
        missval = mv
      ),
    MSLP =
      ncdf4::ncvar_def(
        name = 'MSLP',
        units = 'hPa',
        longname = "mean sea level pressure",
        dim = list(xdim, ydim),
        missval = mv
      ),
    TPP1 =
      ncdf4::ncvar_def(
        name = 'TPP1',
        units = 'm',
        longname = "precipitation, 1 hr accumulation",
        dim = list(xdim, ydim),
        missval = mv
      ),
    DIFR =
      ncdf4::ncvar_def(
        name = 'DIFR',
        units = 'm',
        longname = "writing difference for TPP1",
        dim = list(xdim, ydim),
        missval = mv
      ),
    T02M =
      ncdf4::ncvar_def(
        name = 'T02M',
        units = 'C',
        longname = "temperature at 2 meters AGL",
        dim = list(xdim, ydim),
        missval = mv
      ),
    RH2M =
      ncdf4::ncvar_def(
        name = 'RH2M',
        units = '%',
        longname = "relative humidity at 2 meters AGL",
        dim = list(xdim, ydim),
        missval = mv
      ),
    U10M =
      ncdf4::ncvar_def(
        name = 'U10M',
        units = 'm/s',
        longname = "u wind component at 10 meters AGL",
        dim = list(xdim, ydim),
        missval = mv
      ),
    V10M =
      ncdf4::ncvar_def(
        name = 'V10M',
        units = 'm/s',
        longname = "v wind component at 10 meters AGL",
        dim = list(xdim, ydim),
        missval = mv
      ),
    PRSS =
      ncdf4::ncvar_def(
        name = 'PRSS',
        units = 'hPa',
        longname = "surface pressure",
        dim = list(xdim, ydim),
        missval = mv
      ),
    LHTF =
      ncdf4::ncvar_def(
        name = 'LHTF',
        units = 'W/m2',
        longname = "latent heat net flux",
        dim = list(xdim, ydim),
        missval = mv
      ),
    SHTF =
      ncdf4::ncvar_def(
        name = 'SHTF',
        units = 'W/m2',
        longname = "sensible heat net flux",
        dim = list(xdim, ydim),
        missval = mv
      ),
    USTR =
      ncdf4::ncvar_def(
        name = 'USTR',
        units = 'm/s',
        longname = "friction velocity",
        dim = list(xdim, ydim),
        missval = mv
      ),
    RGHS =
      ncdf4::ncvar_def(
        name = 'RGHS',
        units = 'm',
        longname = "surface roughness",
        dim = list(xdim, ydim),
        missval = mv
      ),
    DSWF =
      ncdf4::ncvar_def(
        name = 'DSWF',
        units = 'W/m2',
        longname = "downward short wave radiation flux",
        dim = list(xdim, ydim),
        missval = mv
      ),
    PBLH =
      ncdf4::ncvar_def(
        name = 'PBLH',
        units = 'm',
        longname = "planetary boundary layer height",
        dim = list(xdim, ydim),
        missval = mv
      ),
    TCLD =
      ncdf4::ncvar_def(
        name = 'TCLD',
        units = '%',
        longname = "total cloud cover",
        dim = list(xdim, ydim),
        missval = mv
      ),
    REFC =
      ncdf4::ncvar_def(
        name = 'REFC',
        units = 'dBZ',
        longname = "composite reflectivity",
        dim = list(xdim, ydim),
        missval = mv
      ),
    CAPE =
      ncdf4::ncvar_def(
        name = 'CAPE',
        units = 'J/Kg',
        longname = "convective available potential energy",
        dim = list(xdim, ydim),
        missval = mv
      ),

    # Upper Layer Variables
    TEMP =
      ncdf4::ncvar_def(
        name = 'TEMP',
        units = 'C',
        longname = 'temperature',
        dim = list(xdim, ydim, layerdim),
        missval = mv
      ),
    UWND =
      ncdf4::ncvar_def(
        name = 'UWND',
        units = 'm/s',
        longname = 'u wind component',
        dim = list(xdim, ydim, layerdim),
        missval = mv
      ),
    VWND =
      ncdf4::ncvar_def(
        name = 'VWND',
        units = 'm/s',
        longname = 'v wind component',
        dim = list(xdim, ydim, layerdim),
        missval = mv
      ),
    WWND =
      ncdf4::ncvar_def(
        name = 'WWND',
        units = 'mb/hr',
        longname = 'w wind component',
        dim = list(xdim, ydim, layerdim),
        missval = mv
      ),
    DIFW =
      ncdf4::ncvar_def(
        name = 'DIFW',
        units = 'mb/hr',
        longname = 'writing difference for WWND',
        dim = list(xdim, ydim, layerdim),
        missval = mv
      ),
    SPHU =
      ncdf4::ncvar_def(
        name = 'SPHU',
        units = 'g/kg',
        longname = 'specific humidity',
        dim = list(xdim, ydim, layerdim),
        missval = mv
      ),
    TKEN =
      ncdf4::ncvar_def(
        name = 'TKEN',
        units = 'joul',
        longname = 'turbulent kinetic energy',
        dim = list(xdim, ydim, layerdim),
        missval = mv
      ),
    PRES =
      ncdf4::ncvar_def(
        name = 'PRES',
        units = 'hPa',
        longname = 'pressure',
        dim = list(xdim, ydim, layerdim),
        missval = mv
      ),


    # Special calculated fields
    WVMR =
      ncdf4::ncvar_def(
        name = 'WVMR',
        units = 'mol/mol',
        longname = 'water vapor mixing ratio',
        dim = list(xdim, ydim, layerdim),
        missval = mv
      ),
    HGHT =
      ncdf4::ncvar_def(
        name = 'HGHT',
        units = 'm',
        longname = 'height above ground',
        dim = list(xdim, ydim, layerdim),
        missval = mv
      )
  )

  # Restrict to the variables that were chosen
  vars_nc <- vars_nc[c("LON", "LAT", vars_surface, vars_upper)]

  # Test for required inputs
  if (("WVMR" %in% vars_upper) &
     any(!(c("SPHU") %in% vars_upper))) {
    stop("WVMR requires SPHU")
  }
  if (("HGHT" %in% vars_upper) &
     any(!(c("TEMP", "SPHU", "PRES", "PRSS") %in%
           c(vars_upper, vars_surface)))) {
    stop("HGHT requires TEMP, SPHU, PRES, and PRSS")
  }

  # Loop through times
  for (hour.tick in 1:6) {

    # Seek through the header
    seek(f_arl, nx * ny - index_length, "current")

    # Clear the blanks
    ClearBlanks(f_arl)

    # If this is not an hour of interest, then skip ahead
    if (!(hour.tick %in% hours_sel)) {
      seek(f_arl, 298 * (nx * ny + 50), "current")
      next()
    }

    # Make new output file
    ncid_new <-
      ncdf4::nc_create(
        paste0(dir_out, file_arl, "_", hour.tick, ".nc"),
        vars_nc,
        force_v4 = TRUE
      )

    # Put the longitude and latitude into the netcdf file
    ncdf4::ncvar_put(
      nc    = ncid_new,
      varid = vars_nc[["LON"]],
      vals  = lon_out,
      start = c(1, 1),
      count = c(nx_out, ny_out)
    )
    ncdf4::ncvar_put(
      nc    = ncid_new,
      varid = vars_nc[["LAT"]],
      vals  = lat_out,
      start = c(1, 1),
      count = c(nx_out, ny_out)
    )

    # Read the variables and save them

    # Loop through the variables
    for (var.tick in 1:298) {

      # * Block header

      # Read the block header
      block_header              <- NULL
      block_header$year         <- readChar(f_arl, 2) %>%
                                    as.integer() %>%
                                    '+'(2000)
      block_header$month        <- readChar(f_arl, 2) %>% as.integer()
      block_header$day          <- readChar(f_arl, 2) %>% as.integer()
      block_header$hour         <- readChar(f_arl, 2) %>% as.integer()
      block_header$forecast     <- readChar(f_arl, 2) %>% as.integer()
      block_header$layer        <- readChar(f_arl, 2) %>% as.numeric()
      block_header$AA           <- readChar(f_arl, 2)
      block_header$var_name     <- readChar(f_arl, 4)
      block_header$scale        <- readChar(f_arl, 4) %>% as.numeric()
      block_header$precision    <- readChar(f_arl, 14) %>% as.numeric()
      block_header$first_value  <- readChar(f_arl, 14) %>% as.numeric()

      # If this is not one of the variables we want, then skip ahead
      if (!(block_header$var_name %in% c(vars_surface, vars_upper))) {
        seek(f_arl, nx * ny, "current")
        next()
      }

      # If this is not one of the layers we want, then skip ahead
      if (!(block_header$layer %in% c(0, layers_sel))) {
        seek(f_arl, nx * ny, "current")
        next()
      }


      # Report the status of the extraction
      if (verbose) {
        cat(
          paste0(
            "\nhour.tick: ", hour.tick, " of 6",
            " var.tick: ",   var.tick, " of 298",
            " Varible: ",    block_header$var_name,
            " Layer: ",      block_header$layer,
            " Hour: ",       block_header$hour
          )
        )
      }

      # Block data

      # Read the block data
      dat <-
        readBin(
          f_arl,
          what   = "int",
          n      = nx * ny,
          size   = 1,
          signed = F
        )

      # Arrange the block data into an array
      datmat <-  matrix(nrow = nx, ncol = ny, data = dat)

      # * Fill the variable array

      # Initialize the variable array
      varmat <- matrix(nrow = nx, ncol   = ny, data   = NA)

      # Initialize the previous value
      prev_value  <- block_header$first_value

      # Walk through columns and set first values
      for (column.tick in 1:ny) {
        # Decode the first value of this column
        varmat[1, column.tick]  <- (datmat[1, column.tick] - 127) /
          (2^(7 - block_header$scale)) + prev_value
        # Update the prev value
        prev_value <- varmat[1, column.tick]
      }

      # Walk through the columns, start the prev value,
      # then fill each row along that column
      for (column.tick in 1:ny) {
        prev_value  <- varmat[1, column.tick]
        for (row.tick in 2:nx) {
          value_now <- (datmat[row.tick, column.tick] - 127) /
            (2^(7 - block_header$scale)) + prev_value
          prev_value <- value_now
          if (abs(value_now) < block_header$precision) {
            value_now <- 0
          }
          varmat[row.tick, column.tick]   <- value_now
        }
      }

      # Restrict to the x and y values we want
      varmat <- varmat[x %in% x_out, y %in% y_out]

      # Save the variable to the NetCDF

      # If this is a surface variable
      if (block_header$layer == 0) {
        ncdf4::ncvar_put(
          nc    = ncid_new,
          varid = vars_nc[[block_header$var_name]],
          vals  = varmat,
          start = c(1, 1),
          count = c(nx_out, ny_out)
        )

        # If this is an upper layer variable
      } else {
        ncdf4::ncvar_put(
          nc    = ncid_new,
          varid = vars_nc[[block_header$var_name]],
          vals  = varmat,
          start = c(1, 1, which(layers_sel == block_header$layer)),
          count = c(nx_out, ny_out, 1)
        )
      }
    }


    # Water vapor mixing ratio
    if ("WVMR" %in% vars_upper) {
      SPHU <- ncdf4::ncvar_get(ncid_new, "SPHU", collapse_degen = FALSE)
      WVMR <- array(dim = dim(SPHU))
      for (layer.tick in 1:length(layers_sel)) {
        WVMR[,, layer.tick] <-
          WvmrFromSphu(SPHU[,, layer.tick])
      }
      ncdf4::ncvar_put(
        nc    = ncid_new,
        varid = vars_nc[["WVMR"]],
        vals  = WVMR,
        start = c(1, 1, 1),
        count = c(nx_out, ny_out, nlayers_out)
      )
    }

    # heights in meters
    if ("HGHT" %in% vars_upper) {
      TEMP <- ncdf4::ncvar_get(ncid_new, "TEMP", collapse_degen = FALSE)
      SPHU <- ncdf4::ncvar_get(ncid_new, "SPHU", collapse_degen = FALSE)
      PRES <- ncdf4::ncvar_get(ncid_new, "PRES", collapse_degen = FALSE)
      PRSS <- ncdf4::ncvar_get(ncid_new, "PRSS", collapse_degen = FALSE)
      HGHT <- array(dim = dim(PRES))
      if (verbose) {
        pb <- utils::txtProgressBar()
      }
      for (x.tick in 1:(dim(PRES)[1])) {
        if (verbose) {utils::setTxtProgressBar(pb, x.tick / (dim(PRES)[1]))}
        for (lat.tick in 1:(dim(PRES)[2])) {
          HGHT[x.tick, lat.tick, ]  <-
            HrrrLayerHeight(
              TEMP[x.tick,lat.tick,],
              SPHU[x.tick,lat.tick,],
              PRES[x.tick,lat.tick,],
              PRSS[x.tick,lat.tick]
            )
        }
      }
      ncdf4::ncvar_put(
        nc    = ncid_new,
        varid = vars_nc[["HGHT"]],
        vals  = HGHT,
        start = c(1, 1, 1),
        count = c(nx_out, ny_out, nlayers_out)
      )
    }

    # Close out the NetCDF
    ncdf4::nc_close(ncid_new)

  }

}
