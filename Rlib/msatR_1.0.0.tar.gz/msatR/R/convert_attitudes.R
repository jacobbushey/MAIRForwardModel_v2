# Convert Attitude Functions

# These functions convert between different representations of attitudes.
# This is an important capability for science planning because activities
# and slews between them are derived using whatever representation is most
# convenient then converted to quaternions for output.

# Attitudes are represented as:
# - Rotation Matrices
#   3x3 matrix (or a list of them) operator applying the active rotation.
#   Used to convert between different attitude representations because
#   conversion equations are convenient.
# - Basis Vectors
#   List of 3 vectors, matrices, or data.frames, each holding unit vectors
#   in the direction of a axis of the body frame in some other frame.
#   Used to derive many activities since individual vectors can be driven to
#   references.
# - Rotation Vectors
#   Vector, matrix, or data.frame, with direction pointing along
#   the rotation axis and magnitude giving the rotation angle in degrees.
#   Used to compute slews since they can be used in differential equations.
# - Pitch, Roll, Yaw
#   Vector, matrix, or data.frame of Tait-Bryan Angles (roll, then pitch,
#   then yaw).
#   Used to describe some spacecraft constraints (e.g., do not scan witha roll
#   greater than 40 degrees).
# - Quaternions
#   Vector, matrix, or data.frame of unit quaternions for rotation,
#   using Hamilton's order convention (r, i1, i2, i3). It is important to
#   note that some output needs to be in the NASA JPL order convention
#   (i1, i2, i3, r). These cases are handled at the point of the output.

# These functions use the rotation matrix as the main pivot point to calculate
# all other conversions. The first 8 functions below calculate the conversion
# of each representation with rotation matrices. All following functions use
# a conversion to and from rotation matrices to perform the conversion.

# Note that the rotation matrices are ACTIVE rotations.
# A directed cosine matrix is often used to describe an attitude,
# and that is a PASSIVE rotation. Take the transpose.

# Examples and unit tests are provided for all these functions.

#' Convert an attitude described in basis vectors to rotation matrices
#'
#' @param basis_vectors length-3 list of data.frames with an equal number of
#'   rows and 3 columns: x_hat, y_hat, and z_hat, forming a basis
#'
#' @return list of rotation matrices
#'
#' @examples
#' basis_vectors <- list()
#' basis_vectors$x_hat <- data.frame(x = 1, y = 0, z = 0)
#' basis_vectors$y_hat <- data.frame(x = 0, y = 1, z = 0)
#' basis_vectors$z_hat <- data.frame(x = 0, y = 0, z = 1)
#' RotationMatricesFromBasisVectors(basis_vectors)
#'
#' @family convert attitude functions
#' @export
RotationMatricesFromBasisVectors <- function(basis_vectors) {

  # Coerce to matrices
  if (is.null(nrow(basis_vectors[[1]]))) {
    basis_vectors[[1]] <- matrix(nrow = 1, data = basis_vectors[[1]])
  }
  if (is.null(nrow(basis_vectors[[2]]))) {
    basis_vectors[[2]] <- matrix(nrow = 1, data = basis_vectors[[2]])
  }
  if (is.null(nrow(basis_vectors[[3]]))) {
    basis_vectors[[3]] <- matrix(nrow = 1, data = basis_vectors[[3]])
  }

  # Test for orthogonality, report error
  if (
    any(rowSums(basis_vectors[[1]] * basis_vectors[[2]]) > 10^-8) |
    any(rowSums(basis_vectors[[1]] * basis_vectors[[3]]) > 10^-8) |
    any(rowSums(basis_vectors[[2]] * basis_vectors[[3]]) > 10^-8)
  ) {
    stop("The input basis vectors are not orthogonal")
  }

  # Coerce to unit vectors
  basis_vectors[[1]] <- NormalizeByRow(basis_vectors[[1]])
  basis_vectors[[2]] <- NormalizeByRow(basis_vectors[[2]])
  basis_vectors[[3]] <- NormalizeByRow(basis_vectors[[3]])

  # Convert to rotation matrix
  rotation_matrices <-
    lapply(
      1:nrow(basis_vectors[[1]]),
      function(x) {
        mat <- cbind(
          unlist(basis_vectors[[1]][x, ]),
          unlist(basis_vectors[[2]][x, ]),
          unlist(basis_vectors[[3]][x, ])
        )
        dimnames(mat) <- NULL
        return(mat)
      }
    )

  if (length(rotation_matrices) == 1) {
    rotation_matrices <- rotation_matrices[[1]]
  }

  return(rotation_matrices)

}

#' Convert an attitude described in rotation matrices to basis vectors
#'
#' @param rotation_matrices list of rotation matrices
#'
#' @return length-3 list of data.frames with an equal number of
#'   rows and 3 columns: x_hat, y_hat, and z_hat, forming a basis
#'
#' @examples
#' BasisVectorsFromRotationMatrices(diag(3))
#'
#' @family convert attitude functions
#' @export
BasisVectorsFromRotationMatrices <- function(rotation_matrices) {

  # Coerce to list
  if (!("list" %in% class(rotation_matrices))) {
    rotation_matrices <- list(rotation_matrices)
  }

  # Convert to basis vectors
  basis_vectors <-
    list(
      x_hat =
        stapply(
          1:length(rotation_matrices),
          function(x) {unlist(rotation_matrices[[x]][,1])}
        ) %>%
        as.data.frame() %>%
        'colnames<-'(c("x", "y", "z")),
      y_hat =
        stapply(
          1:length(rotation_matrices),
          function(x) {unlist(rotation_matrices[[x]][,2])}
        ) %>%
        as.data.frame() %>%
        'colnames<-'(c("x", "y", "z")),
      z_hat =
        stapply(
          1:length(rotation_matrices),
          function(x) {unlist(rotation_matrices[[x]][,3])}
        ) %>%
        as.data.frame() %>%
        'colnames<-'(c("x", "y", "z"))
    )

  return(basis_vectors)

}

#' Convert an attitude described in rotation vectors to rotation matrices
#'
#' @param rotation_vectors data.frame of rotation vectors
#'   (direction is the rotation axis, magnitude is the angle in radians)
#'
#' @return list of rotation matrices
#'
#' @examples
#' RotationMatricesFromRotationVectors(c(1,0,0))
#'
#' @family convert attitude functions
#' @export
RotationMatricesFromRotationVectors <- function(rotation_vectors) {

  # Coerce to matrix
  if (is.data.frame(rotation_vectors)) {
    rotation_vectors <- as.matrix(rotation_vectors)
  }
  if (is.vector(rotation_vectors)) {
    rotation_vectors <- matrix(ncol = 3, data = rotation_vectors)
  }
  rotation_vectors <- as.matrix(rotation_vectors)

  vnorm <- NormByRow(rotation_vectors)

  rotation_matrices <- list()
  for (tick in 1:nrow(rotation_vectors)) {

    # Null rotation
    if (vnorm[tick] < 1e-8) {
      rotation_matrices[[tick]] <- diag(3)
    } else {
      # Any other rotation
      rotation_matrices[[tick]] <-
        t(
          diag(3) * cos(vnorm[tick]) +
          (1 - cos(vnorm[tick])) *
          ((rotation_vectors[tick, ] / vnorm[tick]) %*%
            t(rotation_vectors[tick, ] / vnorm[tick])) -
          sin(vnorm[tick]) *
          CrossProductMatrix(rotation_vectors[tick, ] / vnorm[tick])
       )
    }
  }

  if (length(rotation_matrices) == 1) {
    rotation_matrices <- rotation_matrices[[1]]
  }

  return(rotation_matrices)

}

#' Convert an attitude described in rotation matrices to rotation vectors
#'
#' @param rotation_matrices list of rotation matrices
#'
#' @return data.frame of rotation vectors
#'   (direction is the rotation axis, magnitude is the angle in radians)
#'
#' @examples
#' RotationVectorsFromRotationMatrices(diag(3))
#'
#' @family convert attitude functions
#' @export
RotationVectorsFromRotationMatrices <- function(rotation_matrices) {

  # Coerce to list
  if (!"list" %in% class(rotation_matrices)) {
    rotation_matrices <- list(rotation_matrices)
  }

  # Apply the conversion to rotation vectors to each rotation matrix
  rotation_vectors <- lapply(
    rotation_matrices,
    function(rotation_matrices) {

      # Compute the rotation angle
      arg <- (sum(diag(rotation_matrices)) - 1) / 2
      if (abs(arg) > 1) {
        arg <- sign(arg)
      }
      theta <- acos(arg)

      # Compute the rotation axis and return the rotation vector
      if (theta %% pi != 0) {
        euleraxis <-
          c(
            (rotation_matrices[3,2] - rotation_matrices[2,3]) /
              (2 * sin(theta)),
            (rotation_matrices[1,3] - rotation_matrices[3,1]) /
              (2 * sin(theta)),
            (rotation_matrices[2,1] - rotation_matrices[1,2]) /
              (2 * sin(theta))
           )
        return(theta * euleraxis)
      } else {
        return(c(0, 0, 0))
      }
    }
  )

  # Coerce to a data.frame
  rotation_vectors_df <-
    data.frame(
      x = unlist(lapply(rotation_vectors, function(x) {x[1]})),
      y = unlist(lapply(rotation_vectors, function(x) {x[2]})),
      z = unlist(lapply(rotation_vectors, function(x) {x[3]}))
    )
  rownames(rotation_vectors_df) <- NULL

  return(rotation_vectors_df)

}

#' Convert an attitude described in Tait-Bryan angles
#' (pitch, then roll, then yaw) into rotation matrices
#'
#' @param pitch_roll_yaw data.frame with columns pitch, roll, and yaw, in
#'   radians, in order pitch, then roll, then yaw.
#'
#' @return list of rotation matrices
#'
#' @examples
#' pitch_roll_yaw <-
#'   data.frame(
#'     pitch = c(0, pi/36),
#'     roll = c(0, pi/8),
#'     yaw = c(0, pi/72)
#'   )
#' RotationMatricesFromPitchRollYaw(pitch_roll_yaw)
#'
#' @family convert attitude functions
#' @export
RotationMatricesFromPitchRollYaw <- function(pitch_roll_yaw) {

  # Coerce to data.frame and error handling
  # vector input
  if (is.vector(pitch_roll_yaw)) {
    if (length(pitch_roll_yaw) != 3) {
      stop("The pitch, roll, yaw vector must have length 3")
    }
    pitch_roll_yaw <-
      data.frame(
        pitch = pitch_roll_yaw[1],
        roll = pitch_roll_yaw[2],
        yaw = pitch_roll_yaw[3]
      )
  }
  # matrix Input
  if (is.matrix(pitch_roll_yaw)) {
    if (ncol(pitch_roll_yaw) != 3) {
      stop("The pitch, roll, yaw vector must have length 3")
    }
    pitch_roll_yaw <-
      data.frame(
        pitch = pitch_roll_yaw[, 1],
        roll = pitch_roll_yaw[, 2],
        yaw = pitch_roll_yaw[, 3]
      )
  }
  # data.frame input
  if (is.data.frame(pitch_roll_yaw)) {
    if (!all(colnames(pitch_roll_yaw) == c("pitch", "roll", "yaw"))) {
      stop("The columns of pitch_roll_yaw must be pitch, roll, and yaw")
    }
  }

  # Apply rotations
  if (nrow(pitch_roll_yaw) == 1) {
    rotation_matrices <-
      R_y(pitch_roll_yaw$pitch) %*%
      R_x(pitch_roll_yaw$roll) %*%
      R_z(pitch_roll_yaw$yaw)
  } else {
    rotation_matrices <-
      R_y(pitch_roll_yaw$pitch) %>%
      MultiplyMatrixLists(R_x(pitch_roll_yaw$roll)) %>%
      MultiplyMatrixLists(R_z(pitch_roll_yaw$yaw))
  }

  return(rotation_matrices)

}

#' Convert an attitude described in rotation matrices to Tait-Bryan angles
#' (pitch, then roll, then yaw)
#'
#' @param rotation_matrices list of rotation matrices
#'
#' @return data.frame with columns pitch, roll, and yaw, in
#'   radians, in order pitch, then roll, then yaw.
#'
#' @examples
#' PitchRollYawFromRotationMatrices(diag(3))
#'
#' @family convert attitude functions
#' @export
PitchRollYawFromRotationMatrices <- function(rotation_matrices) {

  # Coerce to list
  if (!is.list(rotation_matrices)) {
    rotation_matrices <- list(rotation_matrices)
  }

  # Decompose the rotations matrix into roll, then pitch, then yaw
  pitch_roll_yaw <-
    stapply(
      1:length(rotation_matrices),
      function(x) {
        # Determine roll
        roll_restricted <- asin(-rotation_matrices[[x]][2,3])
        # Possibilities for roll on [-pi, pi]
        if (roll_restricted > 0) {
          roll <- c(roll_restricted, pi - roll_restricted)
        }
        if (roll_restricted == 0) {
          roll <- roll_restricted
        }
        if (roll_restricted < 0) {
          roll <- c(roll_restricted, roll_restricted - pi)
        }
        # We are left with two options for roll that we must constrain later


        # Determine pitch
        pitch_restricted <-
          atan2(
            rotation_matrices[[x]][1,3],
            rotation_matrices[[x]][3,3]
          )
        # Possibilities for pitch on [-pi, pi]
        if (pitch_restricted > 0) {
          pitch <- c(pitch_restricted, pitch_restricted - pi)
        }
        if (pitch_restricted == 0) {
          pitch <- pitch_restricted
        }
        if (pitch_restricted < 0) {
          pitch <- c(pitch_restricted, pitch_restricted + pi)
        }

        # Determine pitch
        yaw_restricted <-
          atan2(
            rotation_matrices[[x]][2,1],
            rotation_matrices[[x]][2,2]
          )
        # Possibilities for pitch on [-pi, pi]
        if (yaw_restricted > 0) {
          yaw <- c(yaw_restricted, yaw_restricted - pi)
        }
        if (yaw_restricted == 0) {
          yaw <- yaw_restricted
        }
        if (yaw_restricted < 0) {
          yaw <- c(yaw_restricted, yaw_restricted + pi)
        }

        # We are left with 8 possible combinations
        # Find the combination that yields the correct rotation matrix
        pitch_roll_yaw_candidates <-
          expand.grid(
            pitch,
            roll,
            yaw
          ) %>%
          "colnames<-"(c("pitch", "roll", "yaw"))
        rotation_matrix_candidates <-
          RotationMatricesFromPitchRollYaw(pitch_roll_yaw_candidates)
        # Coerce to list
        if (!is.list(rotation_matrix_candidates)) {
          rotation_matrix_candidates <- list(rotation_matrix_candidates)
        }
        rotation_matrix_match <-
          lapply(
            rotation_matrix_candidates,
            function(y) {
              all.equal(y, rotation_matrices[[x]], tolerance = 1e-6)
            }
          )
        # Quietly return the selected pitch, roll, and yaw
        # Note that the pitch, roll, and yaw are not necessarily unique,
        # so we return the first set.
        pitch_roll_yaw_allowed <-
          pitch_roll_yaw_candidates[
            which(unlist(rotation_matrix_match) == "TRUE"),
          ]
        pitch_roll_yaw_allowed <-
          dplyr::arrange(
            pitch_roll_yaw_allowed,
            abs(pitch),
            abs(roll),
            abs(yaw)
            )
        pitch_roll_yaw_allowed[1,]
      }
    ) %>%
    apply(2, unlist)

  # Convert the shape to rows for data frame conversion
  if (is.vector(pitch_roll_yaw)) {
    pitch_roll_yaw <- t(pitch_roll_yaw)
  }
  pitch_roll_yaw <- as.data.frame(pitch_roll_yaw, optional = TRUE)

  return(pitch_roll_yaw)

}

#' Convert an attitude described in quaternions to rotation matrices
#'
#' @param q vector, matrix, or data.frame of quaternions, with columns
#'   r, i1, i2, i3
#'
#' @return list of rotation matrices
#'
#' @examples
#' RotationMatricesFromQuaternions(c(1,0,0,0))
#'
#' RotationMatricesFromQuaternions(rbind(c(1,0,0,0), c(0,1,0,0)))
#'
#' @family convert attitude functions
#' @export
RotationMatricesFromQuaternions <- function(q) {

  # Coerce to data.frame
  if (is.vector(q)) {
    q <- data.frame(
      r = q[1],
      i1 = q[2],
      i2 = q[3],
      i3 = q[4]
    )
  }

  # Compute rotation matrices as a list
  rotation_matrices <-
    lapply(1:nrow(q),
           function(x) {
             rbind(c(2 * (q[x, 1] * q[x, 1] + q[x, 2] * q[x, 2]) - 1,
                     2 * (q[x, 2] * q[x, 3] - q[x, 1] * q[x, 4]),
                     2 * (q[x, 2] * q[x, 4] + q[x, 1] * q[x, 3])),
                   c(2 * (q[x, 2] * q[x, 3] + q[x, 1] * q[x, 4]),
                     2 * (q[x, 1] * q[x, 1] + q[x, 3] * q[x, 3]) - 1,
                     2 * (q[x, 3] * q[x, 4] - q[x, 1] * q[x, 2])),
                   c(2 * (q[x, 2] * q[x, 4] - q[x, 1] * q[x, 3]),
                     2 * (q[x, 3] * q[x, 4] + q[x, 1] * q[x, 2]),
                     2 * (q[x, 1] * q[x, 1] + q[x, 4] * q[x, 4]) - 1)
            )
           }
    )

  # Coerce to matrix if length 1
  if (length(rotation_matrices) == 1) {
    rotation_matrices <- rotation_matrices[[1]]
  }

  return(rotation_matrices)

}

#' Convert an attitude described in rotation matrices to quaternions
#'
#' @param rotation_matrices list of rotation matrices
#'
#' @return data.frame of quaternions, with columns r, i1, i2, i3
#'
#' @examples
#' QuaternionsFromRotationMatrices(diag(3))
#'
#' @family convert attitude functions
#' @export
QuaternionsFromRotationMatrices <- function(rotation_matrices) {

  # Coerce to list
  if (!is.list(rotation_matrices)) {
    rotation_matrices <- list(rotation_matrices)
  }

  # Abbreviate rotation_matrices for easier reading
  mat <- rotation_matrices

  quaternions <-
    stapply(
      1:length(mat),
      function(x) {
        tr <- sum(diag(mat[[x]]))
        if (tr > 0) {
          S = sqrt(tr + 1) * 2
          q_r = 0.25 * S
          q_i1 = (mat[[x]][3, 2] - mat[[x]][2, 3]) / S
          q_i2 = (mat[[x]][1, 3] - mat[[x]][3, 1]) / S
          q_i3 = (mat[[x]][2, 1] - mat[[x]][1, 2]) / S
        } else if (
            (mat[[x]][1, 1] > mat[[x]][2, 2]) &
            (mat[[x]][1, 1] > mat[[x]][3, 3])
          ) {
          S = sqrt(1 + mat[[x]][1, 1] - mat[[x]][2, 2] - mat[[x]][3, 3]) * 2
          q_r = (mat[[x]][3, 2] - mat[[x]][2, 3]) / S
          q_i1 = 0.25 * S
          q_i2 = (mat[[x]][1, 2] + mat[[x]][2, 1]) / S
          q_i3 = (mat[[x]][1, 3] + mat[[x]][3, 1]) / S
        } else if (mat[[x]][2, 2] > mat[[x]][3, 3]) {
          S = sqrt(1 + mat[[x]][2, 2] - mat[[x]][1, 1] - mat[[x]][3, 3]) * 2
          q_r = (mat[[x]][1, 3] - mat[[x]][3, 1]) / S
          q_i1 = (mat[[x]][1, 2] + mat[[x]][2, 1]) / S
          q_i2 = 0.25 * S
          q_i3 = (mat[[x]][2, 3] + mat[[x]][3, 2]) / S
        } else {
          S = sqrt(1 + mat[[x]][3, 3] - mat[[x]][1, 1] - mat[[x]][2, 2]) * 2
          q_r = (mat[[x]][2, 1] - mat[[x]][1, 2]) / S
          q_i1 = (mat[[x]][1, 3] + mat[[x]][3, 1]) / S
          q_i2 = (mat[[x]][2, 3] + mat[[x]][3, 2]) / S
          q_i3 = 0.25 * S
        }
        return(c(q_r, q_i1, q_i2, q_i3))
      }
    ) %>%
    'colnames<-'(c("r", "i1", "i2", "i3"))

  # Coerce to data.frame
  quaternions <- as.data.frame(quaternions)

  return(quaternions)

}


#' Convert an attitude described in Tait-Bryan angles
#' (pitch, then roll, then yaw) into quaternions
#'
#' @param pitch_roll_yaw data.frame with columns pitch, roll, and yaw, in
#'   radians, in order pitch, then roll, then yaw.
#'
#' @return data.frame of quaternions with columns r, i1, i2, i3
#'
#' @examples
#' pitch_roll_yaw <-
#'   data.frame(
#'     pitch = c(0, pi/36),
#'     roll = c(0, pi/8),
#'     yaw = c(0, pi/72)
#'   )
#' QuaternionsFromPitchRollYaw(pitch_roll_yaw)
#'
#' @family convert attitude functions
#' @export
QuaternionsFromPitchRollYaw <- function(pitch_roll_yaw) {
  pitch_roll_yaw %>%
  RotationMatricesFromPitchRollYaw() %>%
  QuaternionsFromRotationMatrices()
}

#' Convert an attitude described in quaternions to rotation matrices
#'
#' @param q vector, matrix, or data.frame of quaternions, with columns
#'   r, i1, i2, i3
#'
#' @return list of rotation matrices
#'
#' @examples
#' PitchRollYawFromQuaternions(c(1,0,0,0))
#'
#' @family convert attitude functions
#' @export
PitchRollYawFromQuaternions <- function(q) {
  q %>%
  RotationMatricesFromQuaternions() %>%
  PitchRollYawFromRotationMatrices()
}

#' Convert an attitude described in basis vectors to quaternions
#' @param basis_vectors length-3 list of data.frames with an equal number of
#'   rows and 3 columns: x_hat, y_hat, and z_hat, forming a basis
#'
#' @return data.frame of quaternions with columns r, i1, i2, i3
#'
#' @examples
#' basis_vectors <- list()
#' basis_vectors$x_hat <- data.frame(x = 1, y = 0, z = 0)
#' basis_vectors$y_hat <- data.frame(x = 0, y = 1, z = 0)
#' basis_vectors$z_hat <- data.frame(x = 0, y = 0, z = 1)
#' QuaternionsFromBasisVectors(basis_vectors)
#'
#' @family convert attitude functions
#' @export
QuaternionsFromBasisVectors <- function(basis_vectors) {

  basis_vectors %>%
  RotationMatricesFromBasisVectors() %>%
  QuaternionsFromRotationMatrices()

}

#' Convert an attitude described in quaternions to rotation matrices
#'
#' @param q vector, matrix, or data.frame of quaternions, with columns
#'   r, i1, i2, i3
#'
#' @return list of rotation matrices
#'
#' @examples
#' BasisVectorsFromQuaternions(c(1,0,0,0))
#'
#' @family convert attitude functions
#' @export
BasisVectorsFromQuaternions <- function(q) {

  q %>%
  RotationMatricesFromQuaternions() %>%
  BasisVectorsFromRotationMatrices()

}

#' Convert an attitude described in rotation vectors to rotation matrices
#'
#' @param rotation_vectors data.frame of rotation vectors
#'   (direction is the rotation axis, magnitude is the angle in radians)
#'
#' @return data.frame of quaternions with columns r, i1, i2, i3
#'
#' @examples
#' QuaternionsFromRotationVectors(c(1,0,0))
#'
#' @family convert attitude functions
#' @export
QuaternionsFromRotationVectors <- function(rotation_vectors) {

  rotation_vectors %>%
  RotationMatricesFromRotationVectors() %>%
  QuaternionsFromRotationMatrices()

}

#' Convert an attitude described in quaternions to rotation vectors
#'
#' @param q vector, matrix, or data.frame of quaternions, with columns
#'   r, i1, i2, i3
#'
#' @return data.frame of rotation vectors
#'   (direction is the rotation axis, magnitude is the angle in radians)
#'
#' @examples
#' RotationVectorsFromQuaternions(c(1,0,0,0))
#'
#' @family convert attitude functions
#' @export
RotationVectorsFromQuaternions <- function(q) {

    q %>%
    RotationMatricesFromQuaternions() %>%
    RotationVectorsFromRotationMatrices()

}

#' Convert an attitude described in rotation vectors to Tait-Bryan angles
#' (pitch, then roll, then yaw)
#'
#' @param rotation_vectors data.frame of rotation vectors
#'   (direction is the rotation axis, magnitude is the angle in radians)
#'
#' @return data.frame with columns pitch, roll, and yaw, in
#'   radians, in order pitch, then roll, then yaw.
#'
#' @examples
#' PitchRollYawFromRotationVectors(c(1,0,0))
#'
#' @family convert attitude functions
#' @export
PitchRollYawFromRotationVectors <- function(rotation_vectors) {

  rotation_vectors %>%
  RotationMatricesFromRotationVectors() %>%
  PitchRollYawFromRotationMatrices()

}

#' Convert an attitude described in Tait-Bryan angles
#' (pitch, then roll, then yaw) to rotation vectors
#'
#' @param pitch_roll_yaw data.frame with columns pitch, roll, and yaw, in
#'   radians, in order pitch, then roll, then yaw.
#'
#' @return a data.frame of rotation vectors
#'   (direction is the rotation axis, magnitude is the angle in radians)
#'
#' @examples
#' pitch_roll_yaw <-
#'   data.frame(
#'     pitch = c(0, pi/36),
#'     roll = c(0, pi/8),
#'     yaw = c(0, pi/72)
#'   )
#' RotationVectorsFromPitchRollYaw(pitch_roll_yaw)
#'
#' @family convert attitude functions
#' @export
RotationVectorsFromPitchRollYaw <- function(pitch_roll_yaw) {

  pitch_roll_yaw %>%
    RotationMatricesFromPitchRollYaw() %>%
    RotationVectorsFromRotationMatrices()

}

#' Convert an attitude described in Tait-Bryan angles
#' (pitch, then roll, then yaw) to basis vectors
#'
#' @param pitch_roll_yaw data.frame with columns pitch, roll, and yaw, in
#'   radians, in order pitch, then roll, then yaw.
#'
#' @return list with elements x_hat, y_hat, and z_hat, where each row of
#'   x_hat, y_hat, and z_hat is a basis vector resulting from the rotation of
#'   the identity basis by the associated rotation matrix
#'
#' @examples
#' pitch_roll_yaw <-
#'   data.frame(
#'     pitch = c(0, pi/36),
#'     roll = c(0, pi/8),
#'     yaw = c(0, pi/72)
#'   )
#' BasisVectorsFromPitchRollYaw(pitch_roll_yaw)
#'
#' @family convert attitude functions
#' @export
BasisVectorsFromPitchRollYaw <- function(pitch_roll_yaw) {

  pitch_roll_yaw %>%
    RotationMatricesFromPitchRollYaw() %>%
    BasisVectorsFromRotationMatrices()

}

#' Convert an attitude described in basis vectors to Tait-Bryan angles
#' (pitch, then roll, then yaw)
#'
#' @param basis_vectors length-3 list of data.frames with an equal number of
#'   rows and 3 columns: x_hat, y_hat, and z_hat, forming a basis
#'
#' @return data.frame with columns pitch, roll, and yaw, in
#'   radians, in order pitch, then roll, then yaw.
#'
#' @examples
#' basis_vectors <- list()
#' basis_vectors$x_hat <- data.frame(x = 1, y = 0, z = 0)
#' basis_vectors$y_hat <- data.frame(x = 0, y = 1, z = 0)
#' basis_vectors$z_hat <- data.frame(x = 0, y = 0, z = 1)
#' PitchRollYawFromBasisVectors(basis_vectors)
#'
#' @family convert attitude functions
#' @export
PitchRollYawFromBasisVectors <- function(basis_vectors) {

  basis_vectors %>%
  RotationMatricesFromBasisVectors() %>%
  PitchRollYawFromRotationMatrices() %>%
  "colnames<-"(c("pitch", "roll", "yaw"))

}

#' Convert an attitude described in basis vectors to rotation vectors
#'
#' @param basis_vectors length-3 list of data.frames with an equal number of
#'   rows and 3 columns: x_hat, y_hat, and z_hat, forming a basis
#'
#' @return data.frame with columns pitch, roll, and yaw, in
#'   radians, in order pitch, then roll, then yaw.
#'
#' @examples
#' basis_vectors <- list()
#' basis_vectors$x_hat <- data.frame(x = 1, y = 0, z = 0)
#' basis_vectors$y_hat <- data.frame(x = 0, y = 1, z = 0)
#' basis_vectors$z_hat <- data.frame(x = 0, y = 0, z = 1)
#' RotationVectorsFromBasisVectors(basis_vectors)
#'
#' @family convert attitude functions
#' @export
RotationVectorsFromBasisVectors <- function(basis_vectors) {

  basis_vectors %>%
  RotationMatricesFromBasisVectors() %>%
  RotationVectorsFromRotationMatrices()

}

#' Convert an attitude described in rotation vectors to basis vectors
#'
#' @param rotation_vectors data.frame of rotation vectors
#'   (direction is the rotation axis, magnitude is the angle in radians)
#'
#' @return list with elements x_hat, y_hat, and z_hat, where each row of
#'   x_hat, y_hat, and z_hat is a basis vector resulting from the rotation of
#'   the identity basis by the associated rotation matrix
#'
#' @examples
#' BasisVectorsFromRotationVectors(c(1,0,0))
#'
#' @family convert attitude functions
#' @export
BasisVectorsFromRotationVectors <- function(rotation_vectors) {

  rotation_vectors %>%
  RotationMatricesFromRotationVectors() %>%
  BasisVectorsFromRotationMatrices()

}
