# Quaternion functions

# These functions facilitate quaternion math. They are much faster than
# R's normal quaternion functions because they allow calculations on the entire
# time series in a single operation. They also include functions
# for analyzing the angular velocity and acceleration for the assessment of
# spacecraft constraints and a function that will rectify quaternions to a
# consistent sign convention.

#' Multiply quaternions by the row of a matrix or data.frame
#'
#' \code{QuaternionMultiply} is an efficient method of computing the product
#' of quaternions by row. Quaternions can be arranged as rows of a matrix or
#' data.frame, and each row multiplied using binary operations, producing the
#' result fast and returning a data.frame. This is necessary for MethaneSAT
#' mission planning when angles between long time series of attitudes in
#' quaternions are required.
#'
#' @param q1 vector, matrix, or data frame with 4 columns of the first
#'   quaternions to multiply with 4 columns r, i1, i2, i3
#' @param q2 vector, matrix, or data frame with 4 columns of the second
#'   quaternions to multiply with columns r, i1, i2, i3
#'
#' @return a data.frame of the quaternions resulting from the multiplication
#'   with columns r, i1, i2, i3
#'
#' @examples
#' QuaternionMultiply(c(1,0,0,0), c(0,1,0,0))
#'
#' @family quaternion functions
#' @export
QuaternionMultiply <- function(q1, q2) {

  # Coerce to matrix
  if (is.vector(q1)) {
    q1 <- matrix(nrow = 1, ncol = 4, data = q1)
  }
  if (is.vector(q2)) {
    q2 <- matrix(nrow = 1, ncol = 4, data = q2)
  }

  # Compute and return the quaternion multiplication
  quaternions <-
    data.frame(
      r  = q1[,1] * q2[,1] - q1[,2] * q2[,2] -
          q1[,3] * q2[,3] - q1[,4] * q2[,4],
      i1 = q1[,1] * q2[,2] + q1[,2] * q2[,1] -
          q1[,3] * q2[,4] + q1[,4] * q2[,3],
      i2 = q1[,1] * q2[,3] + q1[,2] * q2[,4] +
          q1[,3] * q2[,1] - q1[,4] * q2[,2],
      i3 = q1[,1] * q2[,4] - q1[,2] * q2[,3] +
          q1[,3] * q2[,2] + q1[,4] * q2[,1]
    )

  return(quaternions)

}

#' Apply a quaternion rotation to a vector in 3-space
#'
#' \code{QuaternionRotateVector} will rotate a vector by a quaternion in a
#' consistent reference frame. The rotation is carried out by the
#' Hamilton product (q-1pq) where q is the rotation quaternion and
#' p is the quaternion formed by the vector to be rotated, with imaginary
#' parts formed by the vector elements and real paart zero.
#'
#' @param vec vector, matrix, or data frame with 3 columns of the vectors to be
#'   rotated.
#' @param rotation_quaternion vector, matrix, or data frame with 4 columns of
#'    the second quaternions to multiply with columns r, i1, i2, i3
#'
#' @return a data.frame of the vectors resulting from the rotation of
#'   vec by rotation_quaternion with columns x, y, z
#'
#' @examples
#' QuaternionRotateVector(c(1,2,3), c(0,1,0,0))
#'
#' @family quaternion functions
#' @export
QuaternionRotateVector <-
  function(
    vec,
    rotation_quaternion
  ) {

    # Coerce to matrix with the first columnm 0
    if (is.matrix(vec)) {
      vec <- cbind(0, vec)
    }
    if (is.data.frame(vec)) {
      vec <- cbind(0, as.matrix(vec))
    }
    if (is.vector(vec)) {
      vec <- matrix(nrow = 1, ncol = 4, data = c(0, vec))
    }

  rotated_vectors <-
    rotation_quaternion %>%
    QuaternionMultiply(vec) %>%
    QuaternionMultiply(QuaternionInvert(rotation_quaternion))

  rotated_vectors <-
    rotated_vectors[, 2:4] %>%
    "colnames<-"(c("x", "y", "z"))

  return(rotated_vectors)

}

#' Invert quaternions by the row of a matrix or data.frame
#'
#' \code{QuaternionInvert} is an efficient method of computing the inverse
#' of quaternions by row. Quaternions can be arranged as rows of a matrix or
#' data.frame, and each row inverted using binary operations, producing the
#' result fast and returning a data.frame. This is necessary for MethaneSAT
#' mission planning when angles between long time series of attitudes in
#' quaternions are required.
#'
#' @param q matrix, or data frame with 4 columns of the quaternions to invert
#'   with columns r, i1, i2, i3
#'
#' @return a data.frame of the quaternions resulting from the inversion
#'   with columns r, i1, i2, i3
#'
#' @examples
#' q <- c(1,1,-3,1)
#' q_inv <- QuaternionInvert(q)
#' QuaternionMultiply(q, q_inv)
#'
#' @family quaternion functions
#' @export
QuaternionInvert <- function(q) {

  # Coerce vector to matrix
  if (is.vector(q)) {
    q <- matrix(nrow = 1, ncol = 4, data = q)
  }

  # Compute the quaternion conjugate
  q_conj <- cbind(q[,1], -q[,2], -q[,3], -q[,4])

  # Compute the normalization factor for the inverse
  q_norm <- QuaternionMultiply(q, q_conj) %>% NormByRow()

  # Invert the quaternion
  q_inv <- q_conj / RepeatColumns(vec = q_norm, n = 4)

  q_inv <- as.data.frame(q_inv)
  colnames(q_inv) <- c("r", "i1", "i2", "i3")

  return(q_inv)

}

#' Calculate the angle between two quaternions along the shortest axis
#'
#' \code{AngleBetweenQuaternions} calculates shortest angle of rotation
#' from one attitude to another, where the attitudes are coded as quaternions.
#'
#' @param q1 vector, matrix, or data frame with 4 columns of the first
#'   quaternions to compare Must lead with the real component r.
#' @param q2 vector, matrix, or data frame with 4 columns of the second
#'   quaternions to compare Must lead with the real component r.
#'
#' @return numeric vector of angles between the quaternions in radians
#'
#' @examples
#' AngleBetweenQuaternions(c(1,0,0,0), c(1,1,0,0))
#'
#' @family quaternion functions
#' @export
AngleBetweenQuaternions <- function(q1, q2) {

  # Coerce vector to matrix
  if (is.vector(q1)) {
    q1 <- matrix(nrow = 1, ncol = 4, data = q1)
  }
  if (is.vector(q2)) {
    q2 <- matrix(nrow = 1, ncol = 4, data = q2)
  }

  # Coerce to unit quaternions
  q1 <- NormalizeByRow(q1)
  q2 <- NormalizeByRow(q2)

  # To get the angle between quaternions you need to check if the
  # multiplication is greater than 1.
  # It can be greater than 1 due to numerical error. It will only be ~O(10^-16)
  q12                  <- QuaternionMultiply(q2, QuaternionInvert(q1))
  angle                <- rep(NA, nrow(q1))
  q12norms             <- NormByRow(q12[,2:4])
  angle[q12norms <= 1] <- 2 * asin(q12norms[q12norms <= 1])
  angle[q12norms >  1] <- 2 * asin(1)

  return(angle)

}


#' Calculate the axis of rotation between two quaternions
#'
#' \code{AxisBetweenQuaternions} calculates axis of rotation
#' from one attitude to another, where the attitudes are coded as quaternions.
#'
#' @param q1 vector, matrix, or data frame with 4 columns of the first
#'   quaternions to compare Must lead with the real component r.
#' @param q2 vector, matrix, or data frame with 4 columns of the second
#'   quaternions to compare Must lead with the real component r.
#'
#' @return data.frame with four columns: the angles between the quaternions
#'   in radians and the axes of the rotation
#'
#' @examples
#' AxisBetweenQuaternions(c(1,0,0,0), c(1,1,0,0))
#'
#' @family quaternion functions
#' @export
AxisBetweenQuaternions <- function(q1, q2) {

  # Coerce vector to matrix
  if (is.vector(q1)) {
    q1 <- matrix(nrow = 1, ncol = 4, data = q1)
  }
  if (is.vector(q2)) {
    q2 <- matrix(nrow = 1, ncol = 4, data = q2)
  }

  # Coerce to unit quaternions
  q1 <- NormalizeByRow(q1)
  q2 <- NormalizeByRow(q2)

  # To get the angle between quaternions you need to check if the
  # multiplication is greater than 1.
  # It can be greater than 1 due to numerical error. It will only be ~O(10^-16)
  q12 <- QuaternionMultiply(q2, QuaternionInvert(q1))
  angle <- 2 * atan2(NormByRow(q12[,2:4]), q12[,1])

  # To get the axis between quaternions. normalize the axis part
  axis <- NormalizeByRow(q12[,2:4])

  # Return the output as a data.frame
  output <-
    data.frame(
      angle = angle,
      x = axis[,1],
      y = axis[,2],
      z = axis[,3]
    )

  return(output)

}

#' Ensure that a time series of quaternions has a consistent convention
#'
#' \code{QuaternionRectify} rectifies a time series of quaternions. Quaternions
#' are not unique. If q is a quaternion, then q = -q. This is causes problems
#' for analyzing time series of quaternions. Conversion of other attitude
#' descriptions to quaternions produce a random sign convention. This function
#' will re-sign the quaternions so that they have a consistent convention and
#' plot smoothly.
#'
#' @param q vector, matrix, or data frame with 4 columns of the
#'   quaternions. 4 columns: r, i1, i2, i3.
#'
#' @return A data.frame of quaternions
#'
#' @examples
#' q <- rbind(
#'  c(1,   0,   0, 0),
#'  c(0.9, 0.1, 0, 0),
#'  c(-0.9, -0.1, 0, 0)
#' )
#' QuaternionRectify(q)
#'
#' @family quaternion functions
#' @export
QuaternionRectify <- function(q) {

  # Error handling
  stopifnot(
    is.matrix(q) | is.data.frame(q),
    ncol(q) == 4
    )

  # Coerce to matrix
  q <- as.matrix(q)

  # Compare each quaternion to the one before it
  for (tick in 2:nrow(q)) {
    # A negative vector dot product means the quaternion convention flips
    if (sum(q[tick - 1, ] * q[tick, ]) < 0) {
      # Flip all future quaternions
      q[tick:nrow(q), ] <- -q[tick:nrow(q), ]
    }
  }

  # Coerce to data.frame for output
  q <- as.data.frame(q)
  colnames(q) <- c("r", "i1", "i2", "i3")

  return(q)

}

#' Calculate the angular velocity of a time series of quaternions
#'
#' \code{AngularVelocityFromQuaternions} calculates the angular velocity
#' vectors from a time series of quaternions. This function uses forward finite
#' differences, and so the last element is NA.
#'
#' @param q Vector, matrix, or data frame with 4 columns of the
#'  quaternions. 4 columns: q_r, q_i1, q_i2, q_i3.
#' @param delt_sec The time step between elements of the sequence (default 1)
#'
#' @return a numeric matrix of the angular velocities, the last element is NA
#'
#' @examples
#' q <- rbind(
#'  c(1,   0,   0, 0),
#'  c(0.9, 0.1, 0, 0),
#'  c(-0.9, -0.1, 0, 0)
#' )
#' AngularVelocityFromQuaternions(q)
#'
#' @family quaternion functions
#' @export
AngularVelocityFromQuaternions <- function(q, delt_sec = 1) {

  # Error handling
  stopifnot(
    nrow(q) >= 2,
    ncol(q) == 4
  )

  # Prep dot product and inverse for quaternion angle formula
  qdot    <- (q[2:nrow(q), ] - q[1:(nrow(q) - 1), ]) / delt_sec
  qinv    <- QuaternionInvert(q[1:(nrow(q) - 1), ])

  # Compute and return the angular velocity
  angular_velocity <-
    rbind(
      2 * QuaternionMultiply(qdot, qinv)[,2:4],
      c(NA,NA,NA)
    )
  colnames(angular_velocity) <- c("x", "y", "z")

  return(angular_velocity)

}

#' Calculate the angular acceleration of a time series of quaternions
#'
#' \code{AngularAccelerationFromQuaternions} calculates the angular
#' acceleration vectors from a time series of quaternions. This function uses
#' centered finite differences, and so the first and last elements are NA.
#'
#' @param q vector, matrix, or data frame with 4 columns of the
#'   quaternions. 4 columns: q_r, q_i1, q_i2, q_i3.
#' @param delt_sec The time step between elements of the sequence
#'
#' @return A numeric matrix of the angular accelerations,
#'   the first and last elements are NA
#'
#' @examples
#' q <- rbind(
#'  c(1,   0,   0, 0),
#'  c(0.9, 0.1, 0, 0),
#'  c(-0.9, -0.1, 0, 0)
#' )
#' AngularAccelerationFromQuaternions(q)
#'
#' @family quaternion functions
#' @export
AngularAccelerationFromQuaternions <- function(q, delt_sec = 1) {

  # Error handling
  stopifnot(
    nrow(q) >= 3,
    ncol(q) == 4
  )

  # Prep dot product and inverse for quaternion angle formula
  qdotdot <- (q[3:nrow(q), ] -
                2 * q[2:(nrow(q) - 1), ] +
                q[1:(nrow(q) - 2), ]) / delt_sec
  qdot    <- (q[3:nrow(q), ] -
                q[2:(nrow(q) - 1), ]) / delt_sec
  qinv    <- QuaternionInvert(q[2:(nrow(q) - 1), ])

  # Calculate and return the angular acceleration
  angular_acceleration <-
    rbind(
      c(NA,NA,NA),
      (2 * (QuaternionMultiply(qdotdot, qinv) -
            QuaternionMultiply(QuaternionMultiply(qdot, qinv),
                              QuaternionMultiply(qdot, qinv))))[, 2:4],
          c(NA,NA,NA)
    )
  colnames(angular_acceleration) <- c("x", "y", "z")

  return(angular_acceleration)

}
