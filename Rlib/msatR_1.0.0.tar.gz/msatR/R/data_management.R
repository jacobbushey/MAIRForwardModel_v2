# Data management functions

# These functions generate outputs for data management activities. These
# includes names of files and data budgets for scan and downlink activities.
# Note that the data unit conventions follow ISO an IEC standards as per the
# MethaneSAT Payload Target Data Size description and the MethaneSAT Mission
# Systems Spatial, Temporal, and Unit Standards document (No. MSYS-210526).

#' Generate a collection ID
#'
#' @param observation_type character string specifying the observation type.
#'   Options follow the activity names: "Scan", "DarkScan",
#'   "LedMeasurementScan", "LunarSweepScan", "VicariousScan", "GlintScan",
#'   "AirglowLimbScan"
#' @param contiguous_scan logical if the scan is contiguous
#'   (i.e. multiple targets taken in a single scan)
#' @param target_id integer target id scanned. If the scan is contiguous, then
#'   this is the first target in the contiguous scan.
#' @param sequential_collection_number integer sequential collection number
#'
#' @return a character string in hexadecimal format for the collection ID
#'
#' @family data management functions
#' @export
WriteCollectionId <- function(
    observation_type,
    contiguous_scan = FALSE,
    target_id,
    sequential_collection_number
  ) {

  # Bits 28 to 31 (4 bits): Type of observation
  observation_type_bits <-
    c("Scan" = "0000",
      "DarkScan" = "0001",
      "LedMeasurementScan" = "0010",
      "LunarSweepScan" = "0011",
      "VicariousScan" = "0100",
      "GlintScan" = "0101",
      "AirglowLimbScan"= "0110"
    )[observation_type]

  # Bit 27 (1 bit): Contiguous scan flag
  contiguous_scan_bits <-
    contiguous_scan %>%
    as.numeric() %>%
    as.character()

  # Bits 26-17 (10 bits): target_id
  target_id_bits <- BinaryStringFromInteger(target_id, width = 10)

  # Bits 16 - 0 (17 bits): Sequential Collection Number
  sequential_collection_number_bits <-
    BinaryStringFromInteger(sequential_collection_number, width = 17)

  # Assemble the collection ID
  collection_id <-
    paste0(
      observation_type_bits,
      contiguous_scan_bits,
      target_id_bits,
      sequential_collection_number_bits
    )

  # The Mission Planning to Mission Operation Center ICD requires that
  # collection_ids be in hexadecimal form
  collection_id <- HexFromBinary(collection_id)

  return(collection_id)

}

#' Read a collection ID
#'
#' @param collection_id hexadecimal string collection ID, 8 characters long
#'
#' @return data.frame of collection data, with rows:
#'   observation_type, contiguous_scan, target_id, sequential_collection_number.
#'   See the arguments of WriteCollectionId for details.
#'
#' @family data management functions
#' @export
ReadCollectionId <- function(
    collection_id
) {

  # Convert collection ID to binary so that we can disect the bits
  collection_id <- BinaryFromHex(collection_id)

  # Bits 28 to 31 (4 bits): Type of observation
  observation_type <-
    c("0000" = "Scan",
      "0001" = "DarkScan",
      "0010" = "LedMeasurementScan",
      "0011" = "LunarSweepScan",
      "0100" = "VicariousScan",
      "0101" = "GlintScan",
      "0110" = "AirglowLimbScan",
      "1111" = "Test"
    )[substr(collection_id, 1, 4)]

  # Bit 27 (1 bit): Contiguous scan flag
  contiguous_scan <-
    collection_id %>%
    substr(5, 5) %>%
    as.numeric() %>%
    as.logical()

  # Bits 26-17 (10 bits): target_id
  target_id <-
    collection_id %>%
    substr(6, 15) %>%
    IntegerFromBinaryString()

  # Bits 16 - 0 (17 bits): Sequential Collection Number
  sequential_collection_number <-
    collection_id %>%
    substr(16, 32) %>%
    IntegerFromBinaryString()

  # Assemble the output
  output <-
    data.frame(
      observation_type = observation_type,
      contiguous_scan = contiguous_scan,
      target_id = target_id,
      sequential_collection_number = sequential_collection_number
    )

  return(output)

}

#' Calculate the data budgeting for a scan activity
#'
#' MethaneSAT scan data
#'
#' @param duration length of scan in seconds
#' @param frame_rate frame rate for image acquisition in Hz
#' @param spacecraft_configuration a list containing configuration data for the
#'   spacecraft. The default is saved in package data as
#'   \code{ground_configuration} and contains initial information about
#'   MethaneSAT. See the data documentation for \code{ground_configuration}
#'   for more detail.
#'
#' @return a data.frame with columns image_bytes, superpages, ccsds_bytes,
#'   peb_to_hsdr_time, dvb_s2_bytes, downlink_time
#'
#' @family data management functions
#' @export
CalculateScanData <- function(
    duration = 32,
    frame_rate = 17.5,
    spacecraft_configuration = ground_configuration
  ) {

  # Payload scan collection size
  # Image
  image_size <-
    2 *
    spacecraft_configuration$data_management$image$rows *
    spacecraft_configuration$data_management$image$columns +
    spacecraft_configuration$data_management$image$frame_header_bytes +
    spacecraft_configuration$data_management$image$frame_header_bytes
  frames <-
    ceiling(duration * frame_rate)
  image_bytes <-
    sum(
      image_size * frames +
        spacecraft_configuration$data_management$image$collect_header_bytes
    )

  # Superpages
  # Data lives on the PEB as Superpages
  superpages <-
    ceiling(
      image_bytes /
      spacecraft_configuration$data_management$superpages$each_bytes
    )
  # # You can't have a fractional superpage. Recalculate image bytes to fill.
  # image_bytes <-
  #   superpages *
  #   spacecraft_configuration$data_management$superpages$each_bytes

  # CCSDS Segments
  # Data is transferred from the PEB to the HSDR as CCSDS Segments
  # Data lives on the HSDR as CCSDS Segments
  ccsds_segments <-
    ceiling(
      image_bytes /
        spacecraft_configuration$data_management$ccsds_segments$data_bytes
    )
  ccsds_primary_header_bytes <-
    ccsds_segments *
    spacecraft_configuration$data_management$ccsds_segments$primary_header_size_bytes
  ccsds_secondary_header_bytes <-
    ccsds_segments *
    spacecraft_configuration$data_management$ccsds_segments$secondary_header_size_bytes
  ccsds_bytes <-
    image_bytes +
    ccsds_primary_header_bytes +
    ccsds_secondary_header_bytes

  # Data transfer from PEB to HSDR
  peb_to_hsdr_time <-
    ccsds_bytes /
    spacecraft_configuration$data_management$hsdr_storage$peb_to_hsdr_rate_Bps

  # Payload Data Packetization by Bus Avionics for Encrypted Downlink
  tm_space_packets <-
    ceiling(
      ccsds_bytes /
      spacecraft_configuration$data_management$tm_space_packets$data_bytes
    )
  tm_space_packet_primary_header_bytes <-
    tm_space_packets *
    spacecraft_configuration$data_management$tm_space_packets$primary_header_bytes
  tm_space_packet_secondary_header_bytes <-
    tm_space_packets *
    spacecraft_configuration$data_management$tm_space_packets$secondary_header_bytes
  tm_space_packet_authentication_bytes <-
    tm_space_packets *
    spacecraft_configuration$data_management$tm_space_packets$authentication_bytes
  tm_space_packets_bytes <-
    tm_space_packet_primary_header_bytes +
    tm_space_packet_secondary_header_bytes +
    tm_space_packet_authentication_bytes +
    ccsds_bytes

  # TM Transfer Frames
  tm_transfer_frames <-
    ceiling(
      tm_space_packets_bytes /
      spacecraft_configuration$data_management$tm_transfer_frames$tm_transfer_frame_size
    )
  tm_transfer_frame_primary_header_bytes <-
    tm_transfer_frames *
    spacecraft_configuration$data_management$tm_transfer_frames$tm_transfer_primary_header_size
  tm_transfer_frame_sync_marker_bytes <-
    tm_transfer_frames *
    spacecraft_configuration$data_management$tm_transfer_frames$tm_transfer_frame_sync_marker_size
  tm_transfer_frame_bytes <-
    tm_transfer_frame_primary_header_bytes +
    tm_transfer_frame_sync_marker_bytes +
    tm_space_packets_bytes

  # DVB-S2 Packetization
  # Data is downlinked as DVB-S2 Packets
  dvb_s2_frames <-
    ceiling(
      tm_transfer_frame_bytes /
      spacecraft_configuration$data_management$dvb_s2_packets$data_bytes
    )
  dvb_s2_header_bytes <-
    dvb_s2_frames *
    spacecraft_configuration$data_management$dvb_s2_packets$header_bytes
  dvb_s2_bytes <-
    dvb_s2_header_bytes +
    tm_transfer_frame_bytes

  # Downlink
  downlink_time <-
    dvb_s2_bytes /
    (1000 * 1000 * ground_configuration$downlink$downlink_rate_MBps)

  # Select the output for budgeting
  output <- data.frame(
    image_bytes,
    superpages,
    ccsds_bytes,
    peb_to_hsdr_time,
    dvb_s2_bytes,
    downlink_time
  )

  return(output)

}

#' Calculate the data budgeting for a downlink activity
#'
#' MethaneSAT downlink data
#'
#' @param downlink_time length of downlink in seconds
#'   (be sure to remove commlink delay)
#' @param spacecraft_configuration a list containing configuration data for the
#'   spacecraft. The default is saved in package data as
#'   \code{ground_configuration} and contains initial information about
#'   MethaneSAT. See the data documentation for \code{ground_configuration}
#'   for more detail.
#'
#' @return a data.frame with columns image_bytes, superpages, ccsds_bytes,
#'   peb_to_hsdr_time, dvb_s2_bytes, downlink_time
#'
#' @family data management functions
#' @export
CalculateDownlinkData <- function(
    downlink_time,
    spacecraft_configuration = ground_configuration
) {

  # DVB-S2 Packetization
  # Data is downlinked in this format
  dvb_s2_bytes <-
    downlink_time *
    (1000 * 1000 * ground_configuration$downlink$downlink_rate_MBps)
  dvb_s2_frames <-
    dvb_s2_bytes /
    (spacecraft_configuration$data_management$dvb_s2_packets$data_bytes +
     spacecraft_configuration$data_management$dvb_s2_packets$header_bytes)
  dvb_s2_header_bytes <-
    dvb_s2_frames *
    spacecraft_configuration$data_management$dvb_s2_packets$header_bytes

  # TM Transfer Frames
  tm_transfer_frame_bytes <-
    dvb_s2_frames *
    spacecraft_configuration$data_management$dvb_s2_packets$data_bytes
  tm_transfer_frames <-
    tm_transfer_frame_bytes /
    (spacecraft_configuration$data_management$tm_transfer_frames$tm_transfer_primary_header_size +
     spacecraft_configuration$data_management$tm_transfer_frames$tm_transfer_frame_sync_marker_size +
     spacecraft_configuration$data_management$tm_transfer_frames$tm_transfer_frame_size)

  # Payload Data Packetization by Bus Avionics for Encrypted Downlink
  tm_space_packets_bytes <-
    tm_transfer_frames *
    spacecraft_configuration$data_management$tm_transfer_frames$tm_transfer_frame_size
  tm_space_packets <-
    tm_space_packets_bytes /
    (spacecraft_configuration$data_management$tm_space_packets$primary_header_bytes +
     spacecraft_configuration$data_management$tm_space_packets$secondary_header_bytes +
     spacecraft_configuration$data_management$tm_space_packets$authentication_bytes +
     spacecraft_configuration$data_management$tm_space_packets$data_bytes)

  # CCSDS Segments
  # Data is transferred from the PEB to the HSDR in this format
  # Data lives on the HSDR in this format
  ccsds_bytes <-
    tm_space_packets *
    spacecraft_configuration$data_management$tm_space_packets$data_bytes
  ccsds_segments <-
    ccsds_bytes /
    (spacecraft_configuration$data_management$ccsds_segments$primary_header_size_bytes +
       spacecraft_configuration$data_management$ccsds_segments$secondary_header_size_bytes +
       spacecraft_configuration$data_management$ccsds_segments$data_bytes)

  # Data transfer from PEB to HSDR
  peb_to_hsdr_time <-
    ccsds_bytes /
    spacecraft_configuration$data_management$hsdr_storage$peb_to_hsdr_rate_Bps

  # Image
  image_bytes <-
    ccsds_segments *
    spacecraft_configuration$data_management$ccsds_segments$data_bytes

  # Superpages
  # Data lives on the PEB in this format
  superpages <-
    ceiling(
      image_bytes /
        spacecraft_configuration$data_management$superpages$each_bytes
    )

  # Select the output for budgeting
  output <- data.frame(
    image_bytes,
    superpages,
    ccsds_bytes,
    peb_to_hsdr_time,
    dvb_s2_bytes,
    downlink_time
  )

  return(output)

}

