# Activity Functions

# These functions facilitate the addition of activities to the MethaneSAT
# science plan. There are functions that assess the feasibility and simulate
# the attitude of Cruise, Scan, Downlink, Dark Scan, Vicarious Scan,
# Airglow Limb Scan, and Thrust activities. There are also functions that
# translate the description of the attitude between the Blue Canyon
# Technologies XACT command structure and the attitude as a quaternion
# rotation from Earth-Centered Inertial (ECI) Coordinates.

# The functions that assess the feasibility and simulate the attitude of
# activities usually output a list with elements "feasible",
# "activity_schedule", and "attitude_quaternion_eci". The element "feasible"
# gives the rows of the spacecraft_state input object correspond to times when
# the activity is feasible. The element "attitude_quaternion_eci" gives the
# attitude of the spacecraft at each feasible time (each time corresponds to an
# element of a list). The element "activity_schedule" gives the columns of the
# spacecraft_state object that are used to implement the activity schedule
# (see the "ActivitySchedule") function in the "spacecraft_State.R" file.

# There are a couple special cases of activity functions with unique output.
# The ActivityCruise function outputs only an attitude since it is the default
# activity and integrates into an activity schedule in the background. The
# downlink activity doesn't contain a "feasible" object because all feasible
# times are taken for downlinks. However, it includes the extra object
# "groundstation_views", which is used for the ground station views product in
# the mission planning workflow.

# The attiudes computed by these functions have been extensively tested
# with support by Bill Preetz of Ubiquity Robotics and many engineers from
# Ball Aerospace.

# Examples and unit tests are left out of the package for these functions
# because of the complexity of their inputs.

# TODO:
# - A new plan for dark scan calibrations has been discussed where a
#   dark calibration can take place during a thrust with no alteration of the
#   attitude.

#' Determine the spacecraft attitude from a BCT XACT command
#'
#' The MethaneSAT activity schedule uses Blue Canyon Technologies (BCT) XACT
#' commands to request activities for the spacecraft. Attitudes are commanded
#' by setting a "reference frame" that relates to the inertial frame, a
#' "command frame" that relates to the body frame, and a quaternion rotation
#' "qTARGETwrtREF" that applies a rotation of the command frame off the
#' reference frame. For details on the BCT XACT commands, see the Blue Canyon
#' Technologies XACT User Guide (Drawing Number 3PR1006) from Blue Canyon
#' Technologies.
#'
#' This function decodes a BCT XACT command into a the spacecraft attitude
#' as a quaternion with respect to Earth-Centered Inertial (ECI) coordinates.
#'
#' @param qTARGETwrtREF a single quaternion with elements r, i1, i2, i3 that
#'   rotates the command frame with respect to the reference frame.
#'   Taken directly from the BCT XACT command.
#' @param primary_command a single vector with elements x, y, and z that
#'   points in the primary command direction in body frame coordinates.
#'   Taken directly from the BCT XACT command.
#' @param secondary_command a single vector with elements x, y, and z that
#'   points in the secondary command direction in body frame coordinates.
#'   Taken directly from the BCT XACT command.
#' @param primary_reference vector or data.frame of vectors pointing in the
#'   direction of the primary reference in Earth-Centered Inertial (ECI)
#'   coordinates
#' @param secondary_reference vector or data.frame of vectors pointing in the
#'   direction of the secondary reference in Earth-Centered Inertial (ECI)
#'   coordinates
#'
#' @return a data.frame with of the spacecraft attitude relative to
#'   Earth-Centered Inertial (ECI), with columns r, i1, i2, i3
#'
#' @family activity functions
#' @export
AttitudeFromXactCommand <-
  function(
    qTARGETwrtREF,
    primary_reference,
    secondary_reference,
    primary_command,
    secondary_command
  ) {

  # Preparing inputs

  # Ensure that the inputs are perfectly normalized and not in lists
  primary_reference <- primary_reference %>%  NormalizeByRow()
  secondary_reference <- secondary_reference %>% NormalizeByRow()
  primary_command <- primary_command %>% NormalizeByRow() %>% unlist()
  secondary_command <- secondary_command %>% NormalizeByRow() %>% unlist()

  # Define the reference frame

  # Reference frame z_hat points along the primary reference
  z_hat_reference <- NormalizeByRow(primary_reference)
  # Reference frame x_hat minimizes the distance to the secondary reference.
  # This is done by first calculating y_hat perpendicular to z_hat and
  # the secondary reference, then completing the coordinate system.
  y_hat_reference <-
    z_hat_reference %>%
    CrossProductByRow(secondary_reference) %>%
    NormalizeByRow()
  x_hat_reference <-
    y_hat_reference %>%
    CrossProductByRow(z_hat_reference) %>%
    NormalizeByRow()
  basis_vectors_reference <-
    list(
      x_hat = x_hat_reference,
      y_hat = y_hat_reference,
      z_hat = z_hat_reference
    )

  # The quaternion version of this is a rotation from body to reference
  q_body_reference <-
    QuaternionsFromBasisVectors(basis_vectors_reference)

  # Define the command frame

  # Command frame z_hat points along the primary command
  z_hat_command <- NormalizeByRow(primary_command)
  # Command frame x_hat points as close as possible the secondary command.
  # This is done by first calculating y_hat perpendicular to z_hat and
  # the secondary command, then completing the coordinate system.
  y_hat_command <-
    z_hat_command %>%
    CrossProductByRow(secondary_command) %>%
    NormalizeByRow()
  x_hat_command <-
    y_hat_command %>%
    CrossProductByRow(z_hat_command) %>%
    NormalizeByRow()
  basis_vectors_command <-
    list(
      x_hat = x_hat_command,
      y_hat = y_hat_command,
      z_hat = z_hat_command
    )

  # The quaternion version of this is a rotation from body to command
  q_body_command <-
    QuaternionsFromBasisVectors(basis_vectors_command)

  # Compute the attitude of the spacecraft with respect to ECI.
  # This is the output quaternion.
  q_out <-
    QuaternionInvert(q_body_command) %>%
    QuaternionMultiply(qTARGETwrtREF) %>%
    QuaternionMultiply(q_body_reference)

  return(q_out)

}

#' Determine the qTARGETwrtREF component of a BCT XACT command
#'
#' The MethaneSAT activity schedule uses Blue Canyon Technologies Xact
#' commands to request activities for the spacecraft. Attitudes are commanded
#' by setting a "reference frame" that relates to the inertial frame, a
#' "command frame" that relates to the body frame, and a quaternion rotation
#' "qTARGETwrtREF" that applies a rotation of the command frame off the
#' reference frame.
#'
#' This function calculates the qTARGETwrtREF required to command the
#' spacecraft to a given attitude.
#'
#' @param attitude_quaternion_eci data.frame with of the spacecraft attitude
#'   relative to Earth-Centered Inertial (ECI), with columns r, i1, i2, i3
#' @param primary_command a single vector with elements x, y, and z that
#'   points in the primary command direction in body frame coordinates.
#'   Taken directly from the BCT XACT command.
#' @param secondary_command a single vector with elements x, y, and z that
#'   points in the secondary command direction in body frame coordinates.
#'   Taken directly from the BCT XACT command.
#' @param primary_reference vector or data.frame of vectors pointing in the
#'   direction of the primary reference in Earth-Centered Inertial (ECI)
#'   coordinates
#' @param secondary_reference vector or data.frame of vectors pointing in the
#'   direction of the secondary reference in Earth-Centered Inertial (ECI)
#'   coordinates
#'
#' @return a single quaternion with elements r, i1, i2, i3 that
#'   rotates the command frame with respect to the reference frame
#'
#' @family activity functions
#' @export
XactCommandFromAttitude <-
  function(
    attitude_quaternion_eci,
    primary_reference,
    secondary_reference,
    primary_command,
    secondary_command
  ) {

  # Preparing inputs

  # Ensure that the inputs are perfectly normalized and not in lists
  primary_reference <- primary_reference %>%  NormalizeByRow()
  secondary_reference <- secondary_reference %>% NormalizeByRow()
  primary_command <- primary_command %>% NormalizeByRow() %>% unlist()
  secondary_command <- secondary_command %>% NormalizeByRow() %>% unlist()

  # Define the reference frame

  # Reference frame z_hat points along the primary reference
  z_hat_reference <- NormalizeByRow(primary_reference)
  # Reference frame x_hat minimizes the distance to the secondary reference.
  # This is done by first calculating y_hat perpendicular to z_hat and
  # the secondary reference, then completing the coordinate system.
  y_hat_reference <-
    z_hat_reference %>%
    CrossProductByRow(secondary_reference) %>%
    NormalizeByRow()
  x_hat_reference <-
    y_hat_reference %>%
    CrossProductByRow(z_hat_reference) %>%
    NormalizeByRow()
  basis_vectors_reference <-
    list(
      x_hat = x_hat_reference,
      y_hat = y_hat_reference, z_hat = z_hat_reference)

  # The quaternion version of this is a rotation from body to reference
  q_body_reference <-
    QuaternionsFromBasisVectors(basis_vectors_reference)

  # Define the command frame

  # Command frame z_hat points along the primary command
  z_hat_command <- NormalizeByRow(primary_command)
  # Command frame x_hat points as close as possible the secondary command.
  # This is done by first calculating y_hat perpendicular to z_hat and
  # the secondary command, then completing the coordinate system.
  y_hat_command <-
    z_hat_command %>%
    CrossProductByRow(secondary_command) %>%
    NormalizeByRow()
  x_hat_command <-
    y_hat_command %>%
    CrossProductByRow(z_hat_command) %>%
    NormalizeByRow()
  basis_vectors_command <-
    list(
      x_hat = x_hat_command,
      y_hat = y_hat_command,
      z_hat = z_hat_command
    )

  # The quaternion version of this is a rotation from body to command
  q_body_command <-
    QuaternionsFromBasisVectors(basis_vectors_command)

  # Compute the command frame with respect to the reference frame.
  # This is the output quaternion.
  q_out <-
    q_body_command %>%
    QuaternionMultiply(attitude_quaternion_eci) %>%
    QuaternionMultiply(QuaternionInvert(q_body_reference))

  return(q_out)
}

#' Calculate the MethaneSAT cruise attitude
#'
#' The MethaneSAT cruise attitude points the body frame z_hat to nadir then
#' minimizes the angle between body frame x_hat and anti-sun. This function is
#' called to initialize the attitude in the \code{SpacecraftState} function.
#'
#' @param pos_eci a vector, matrix, or data.frame with 3 columns giving
#'   the position of the spacecraft in meters Earth-Centered Inertial (ECI)
#' @param sun_eci a vector, matrix, or data.frame with 3 columns giving
#'   the position of the sun in meters Earth-Centered Inertial (ECI)
#' @return a data.frame with of the spacecraft attitude relative to
#'   Earth-Centered Inertial (ECI), with columns r, i1, i2, i3.
#' @family activity functions
#' @export
ActivityCruise  <- function(
  pos_eci,
  sun_eci
) {

  # Unit vectors
  pos_eci_hat <- NormalizeByRow(pos_eci)
  sun_eci_hat <- NormalizeByRow(sun_eci)

  # z_hat points towards nadir
  z_cruise_eci_hat <-
    -pos_eci_hat %>%
    "colnames<-"(c("x", "y", "z"))

  # y_hat is perpendicular to nadir and the sun
  y_cruise_eci_hat <-
    -CrossProductByRow(-pos_eci_hat, sun_eci_hat) %>%
    NormalizeByRow() %>%
    "colnames<-"(c("x", "y", "z"))

  # x_hat follows
  x_cruise_eci_hat <-
    CrossProductByRow(y_cruise_eci_hat, z_cruise_eci_hat) %>%
    NormalizeByRow() %>%
    "colnames<-"(c("x", "y", "z"))

  # Transform to rectified quaternions
  quaternion_cruise_eci <-
    list(x_cruise_eci_hat, y_cruise_eci_hat, z_cruise_eci_hat) %>%
    QuaternionsFromBasisVectors() %>%
    QuaternionRectify()

  # Return quaternions in eci for initializing the spacecraft state
  return(quaternion_cruise_eci)

}

#' Calculate the MethaneSAT scan attitude
#'
#' \code{ActivityScan} calculates the MethaneSAT scan attitude based on the
#' spacecraft state and a set of target aim points
#' (\code{target_left_ecef} and \code{target_right_ecef}). The target
#' aim points orient the instrument array across the target. There are two
#' possible attitudes that will align with the aim points, but only one of
#' will protect the radiator from the sun. This function automatically selects
#' the correct attitude.
#'
#' The time parameter (\code{utc}) defaults to NULL. If it is left NULL,
#' then the function will detect the times when a scan is feasible and
#' return all feasible scan activities. If \code{utc} is set, then the
#' function will return all feasible scan activities within \code{utc}.
#'
#' @param spacecraft_state initial spacecraft state object. See documentation
#'   for the function \code{SpacecraftState} for more information.
#' @param spacecraft_configuration a list containing configuration data for the
#'   spacecraft. The default is saved in package data as
#'   \code{ground_configuration} and contains initial information about
#'   MethaneSAT. The data can be loaded from a configuration file using the
#'   function \code{ReadGroundConfiguration} See the data documentation for
#'   \code{ground_configuration} for more detail on the object.
#' @param utc vector of UTC (Universal Coordinated Time) dates in POSIX
#'   (Portable Operating System Interface) format to select times to return
#'   scan activities. Only feasible activities will be returned. If there are
#'   no feasible activities, then NULL will be returned.
#' @param aimpoints data.frame of aimpoints
#' @param glint logical. If TRUE (default is FALSE) then the framerate will
#'   be set to the glint frame rate (35 Hz).
#' @param test_slews logical (default FALSE) if TRUE then each feasible
#'   will be testedto see if the spacecraft can slew back to cruise or onto
#'   the next activity
#' @param collection_id optional collection ID - see WriteCollectionId
#'   to generate this
#' @param verbose logical (default FALSE) if TRUE, then the progress of the
#'   function is printed to screen
#'
#' @return a list, with elements "feasible" (a vector of numeric rows of
#'   spacecraft_state when the activity is feasible), "attitude_quaternion"
#'   (a list of data.frames of quaternions in Earth-Centered Inertial
#'   describing the attitude of the spacecraft), and "activity_schedule"
#'   (a list of data.frames giving information for generating the
#'   activity schedule).
#'
#' @family activity functions
#' @export
ActivityScan <- function(
    spacecraft_state,
    utc = NULL,
    spacecraft_configuration,
    aimpoints,
    glint = FALSE,
    test_slews = FALSE,
    collection_id = "NA",
    verbose = FALSE
) {

  # Configuration

  # The activity name and framerate need to be set for glint vs regular scan
  frame_rate <- spacecraft_configuration$scanning$framerate_1_hz
  activity_name <- "Scan"
  if (glint) {
    frame_rate = spacecraft_configuration$scanning$framerate_2_hz
    activity_name <- "GlintScan"
  }

  # Initialize a progress bar if verbose has been selected.
  # This function can be just a little computationally expensive, so the
  # progress can be hlpful.
  if (verbose) {
    pb <- utils::txtProgressBar(style = 3)
  }

  # The code proceeds in the following steps:
  # 1) Determine geometric and solar zenith angle feasibility in ECEF.
  #    This is done in ECEF for computational efficiency.
  # 2) Calculate attitude in ECI.
  # 3) Apply further feasibility restrictions.
  #    There are some restrictions to feasibility that can only be calculated
  #    in ECI. These are cheap and done here.
  # 4) Generate the activities
  #    These are the outputs.

  # Step 1) Determine feasibility in ECEF

  if (verbose) {
    cat("Determine Feasability \n")
  }

  # Isolate the geodetic point at the center of the target for testing
  target_geodetic <-
    aimpoints %>%
    dplyr::filter(point == "center") %>%
    "$"(geodetic)

  # The elevation and solar zenith angles
  # are measured with resperct to the local tangent plane
  target_local_tangent_plane_ecef <-
    LocalTangentPlane(
      lon = target_geodetic$lon,
      lat = target_geodetic$lat
    )

  # The line of sight is used to get the elevation angle
  line_of_site_ecef <-
    aimpoints %>%
    dplyr::filter(point == "center") %>%
    "$"(ecef) %>%
    RepeatRows(nrow(spacecraft_state)) %>%
    "-"(spacecraft_state$pos_ecef)

  # Calculate the elevation angle
  # If this is less than pi/2 then the spacecraft is above the target.
  elevation_angle <-
    AngleBetweenVectors(
      target_local_tangent_plane_ecef$z_hat,
      - line_of_site_ecef
    )

  # Calculate the solar zenith angle.
  # This must be within the spacecraft_configuration spec
  solar_zenith_angle <-
    AngleBetweenVectors(
      target_local_tangent_plane_ecef$z_hat,
      spacecraft_state$sun_ecef
    )

  # Restrict to feasible times
  feasible <-
    which(
      ((elevation_angle * 180 / pi) < 90)  &
      ((solar_zenith_angle * 180 / pi) <
          spacecraft_configuration$scan$sza_max_deg) &
      (spacecraft_state$activity %in% c("Cruise", "Slew"))
    )

  # If the user has specified a utc time, restrict the feasible period
  if (!is.null(utc)) {
    feasible <- feasible[spacecraft_state$utc[feasible] %in% utc]
  }

  # From here on, we only want to look at the spacecraft state in feasible time
  spacecraft_state_feasible <- spacecraft_state[feasible, ]

  # If there are no feasible times, return NULL
  if (length(feasible) < 2) {
    return(NULL)
  }

  # 2) Calculate attitude in ECI

  if (verbose) {
    cat("Calculating Scan Attitudes \n")
  }

  # Convert the aimpoints to ECI
  target_left_eci <-
    aimpoints %>%
    dplyr::filter(point == "left") %>%
    "$"(ecef) %>%
    RepeatRows(nrow(spacecraft_state)) %>%
    EciFromEcef(q_ei = spacecraft_state_feasible$q_ei)
  target_right_eci <-
    aimpoints %>%
    dplyr::filter(point == "right") %>%
    "$"(ecef) %>%
    RepeatRows(nrow(spacecraft_state)) %>%
    EciFromEcef(q_ei = spacecraft_state_feasible$q_ei)

  # Get line of sight vectors at the aim points
  line_of_sight_left_eci <-
    target_left_eci - spacecraft_state_feasible$pos_eci
  line_of_sight_right_eci <-
    target_right_eci - spacecraft_state_feasible$pos_eci

  # x_hat is perpendicular to the plane formed by the reference vectors,
  # this gives two options - which we select based on the position of the sun
  middle_x_hat_eci <-
    CrossProductByRow(line_of_sight_left_eci, line_of_sight_right_eci) %>%
    NormalizeByRow()

  # Detect the yaw flip - if the spacecraft velocity points towards the sun
  # then the non-flipped attitude will point the radiator at the sun.
  # Note that the yaw flip is a slice and not an if statement.
  # This allows us to appropriately handle targets near the sub-solar point.
  yaw_flip <-
    AngleBetweenVectors(
      spacecraft_state_feasible$vel_eci,
      spacecraft_state_feasible$sun_eci
    ) > pi / 2

  # Apply the yaw flip to x_hat
  middle_x_hat_eci[yaw_flip] <- - middle_x_hat_eci[yaw_flip]

  # Set z_hat to the bisector of the lines of sight to the aim points.
  # This is the direction that will maximize the tolerance to pointing and
  # ephemeris error.
  middle_z_hat_eci <-
    (NormByRow(line_of_sight_right_eci) * line_of_sight_left_eci +
       NormByRow(line_of_sight_left_eci) * line_of_sight_right_eci) %>%
    NormalizeByRow()

  # Set y_hat to complete the right-handed coordinate system
  middle_y_hat_eci <-
    CrossProductByRow(middle_z_hat_eci, middle_x_hat_eci) %>%
    NormalizeByRow()

  # Set up the basis vectors as a list for conversion to other attitude types
  middle_basis_vectors_eci <-
    list(middle_x_hat_eci, middle_y_hat_eci, middle_z_hat_eci)

  # Convert to quaternions in ECEF.
  # We want quaternions because the spacecraft state includes q_ei
  # that can be used to convert to ECI.
  middle_attitude_quaternion_eci <-
    QuaternionsFromBasisVectors(middle_basis_vectors_eci)

  # Generate qTARGETwrtREF
  attitude_scan <-
    XactCommandFromAttitude(
      attitude_quaternion_eci = middle_attitude_quaternion_eci,
      primary_reference = spacecraft_state_feasible$pos_eci,
      secondary_reference = spacecraft_state_feasible$vel_eci,
      primary_command = c(0, 0, -1),
      secondary_command = c(1, 0, 0)
    )

  # 3) Apply further feasibility restrictions

  # The pitch and roll must be within spec.
  pitch_roll_yaw <- PitchRollYawFromQuaternions(attitude_scan)
  feasible2 <-
      (abs(pitch_roll_yaw$pitch * 180 / pi) <
        spacecraft_configuration$scan$pitch_max_deg) &
      (abs(pitch_roll_yaw$roll * 180 / pi) <
        spacecraft_configuration$scan$roll_max_deg)
  feasible <- feasible[feasible2]

  # Apply the restriction
  attitude_scan <- attitude_scan[feasible2, ]

  # If there are no feasible times, return NULL
  if (length(feasible) == 0) {
    return(NULL)
  }

  # 4) Generate the activities

  if (verbose) {
    cat("Generating Activities \n")
  }

  # Initialize the attitude and activity schedule objects
  attitude_quaternion_eci <- list()
  activity_schedule <- list()
  activity <-
    c(
      rep("Settle", spacecraft_configuration$scan$settle_s),
      rep(activity_name, 2 * spacecraft_configuration$scan$buffer_s +
            spacecraft_configuration$scan$standard_scan_s)
    )

  # For each feasible time, calculate and assess the scan attitude
  counter <- 1
  slew_test <- rep(TRUE, length(feasible))
  for (tick in 1:length(feasible)) {

    if (verbose) {
      utils::setTxtProgressBar(pb, tick / length(feasible))
    }

    # The scan indices are centered on "feasible"
    # with half the scan plus the buffer on either side,
    # and the settle before that.
    scan_indices <-
      feasible[tick] +
      seq(
        from =
          - spacecraft_configuration$scan$standard_scan_s / 2 -
          spacecraft_configuration$scan$buffer_s -
          spacecraft_configuration$scan$settle_s,
        to =
          spacecraft_configuration$scan$standard_scan_s / 2 +
          spacecraft_configuration$scan$buffer_s - 1
      )

    # Get the attitude
    attitude_quaternion_eci_now <-
      AttitudeFromXactCommand(
        primary_command = c(0, 0, -1),
        secondary_command = c(1, 0, 0),
        qTARGETwrtREF = attitude_scan[tick, ],
        primary_reference = spacecraft_state$pos_eci[scan_indices, ],
        secondary_reference = spacecraft_state$vel_eci[scan_indices, ]
      )
    attitude_quaternion_eci_now$utc <- spacecraft_state$utc[scan_indices]
    attitude_quaternion_eci_now$row <- scan_indices

    # If test_slews is set, then test the slew and only return feasible
    if (test_slews) {
      # Now, can we slew to and from to this activity?
      spacecraft_state_with_slew <-
        SpacecraftStateAddActivity(
          spacecraft_state = spacecraft_state,
          spacecraft_configuration = spacecraft_configuration,
          attitude_quaternion_eci = attitude_quaternion_eci_now,
          activity_schedule = NULL,
          verbose = FALSE
        )
      if (is.null(spacecraft_state_with_slew)) {
        slew_test[feasible.tick] <- FALSE
        next()
      }
      if (
        any(spacecraft_state_with_slew$constraints$sun_violation) |
        any(spacecraft_state_with_slew$constraints$earth_violation)
      ) {
        next()
      }
    }

    # Calculate the data requirement
    scan_data <-
      CalculateScanData(
        duration =
          spacecraft_configuration$scan$standard_scan_s +
          2 * spacecraft_configuration$scan$buffer_s,
        frame_rate = frame_rate,
        spacecraft_configuration = spacecraft_configuration
      )

    # Add the attitude and activity schedule to the list
    attitude_quaternion_eci[[counter]] <- attitude_quaternion_eci_now
    activity_schedule[[counter]] <-
      data.frame(
        utc = spacecraft_state$utc[scan_indices],
        activity = activity,
        TargX = 0,
        TargY = 0,
        TargZ = 0,
        PriRefDir = 6,
        SecRefDir = 7,
        PriCmdDir = 6,
        SecCmdDir = 1,
        AttInterp = "Quaternion",
        qTARGETwrtREF1 = attitude_scan[tick, 2],
        qTARGETwrtREF2 = attitude_scan[tick, 3],
        qTARGETwrtREF3 = attitude_scan[tick, 4],
        qTARGETwrtREF4 = attitude_scan[tick, 1],
        RateInterp = 1,
        CmdRateX = 0,
        CmdRateY = 0,
        CmdRateZ = 0,
        collectionID = collection_id,
        frameRate = frame_rate,
        window = "Science",
        LedDriveCurrent810nmCh4 = 0,
        LedDriveCurrent1550nmCh4 = 0,
        LedDriveCurrent810nmO2 = 0,
        LedDriveCurrent1550nmO2 = 0,
        stationName =  "NA",
        antennaID = "NA",
        xBand = FALSE,
        sBand = FALSE,
        thruster1 = NA,
        thruster2 = NA,
        thruster3 = NA,
        SPCount = scan_data$superpages,
        CCSDSBytes = scan_data$ccsds_bytes,
        PEBtoHSDR = scan_data$peb_to_hsdr_time,
        DVBS2Bytes = scan_data$dvb_s2_bytes,
        DownlinkTime = scan_data$downlink_time
      )

    counter <- counter + 1

  }

  feasible <- feasible[slew_test]

  # Return a list of objects that will be needed to generate
  # the activity schedule, the 1-hz time series and orthorectification
  output <-
    list(
      feasible = feasible,
      attitude_quaternion_eci = attitude_quaternion_eci,
      activity_schedule = activity_schedule
    )

  return(output)

}

#' Calculate the MethaneSAT downlink attitude and ground station views.
#'
#' \code{ActivityDownlink} calculates the MethaneSAT downlink time and attitude
#' based on the spacecraft state and a ground station antenna. The downlink
#' time is calculated to give the longest continuous contact that satisfies
#' spacecraft constraints, the constraints of the Blue Canyon Technologies
#' XACT command structure, and the ability to slew to the activity.
#'
#' The downlink attitude points the x-band antenna at the ground station
#' antenna and then finds the rotation rates from the sun or orbit
#' normal that result in feasible attitudes. S-Band contacts do not require
#' the antenna pointing, but the data rate is reduced without antenna pointing.
#'
#' @param utc vector of Universal Coordinated Time (UTC) dates in
#'   Portable Operating System Interface (POSIX) format for overriding the
#'   automatically selected activity time. Defaults to NULL, which allows the
#'   function to detect the longest continuous downlink attitude. If not NULL,
#'   then the feasible time will be subset to within the provided times.
#' @param rev ascending ops revolution number for restricting the allowed
#'   feasible times. Defaults to NULL, which allows the function to use all
#'   revs in the spacecraft state.
#' @param spacecraft_state initial spacecraft state object. See documentation
#'   for the function \code{SpacecraftState} for more information.
#' @param spacecraft_configuration a list containing configuration data for the
#'   spacecraft. The default is saved in package data as
#'   \code{ground_configuration} and contains initial information about
#'   MethaneSAT. The data can be loaded from a configuration file using the
#'   function \code{ReadGroundConfiguration} See the data documentation for
#'   \code{ground_configuration} for more detail on the object.
#' @param station the ground station. One of "SVALSAT", "PUNTA_ARENAS",
#'   "AWARUA", "HARTEBEESTHOEK", "PUERTOLLANO".
#' @param antenna the ground station antenna (optional). The antenna codes
#'   can be found in the groundstation_antennas data set, along with other
#'   information. This will override the station input.
#' @param secondary_reference the secondary reference direction for determining
#'   the command frame. One of "sun" or "orbit normal". The command frame is
#'   the frame from which the spacecraft is rotated with a linear rate to
#'   determine the attitude.
#' @param tiebreaker character string telling what to use to break ties in
#'   selecting the contacts. One of "power" (default) or "buffer". If set to
#'   power, the potential power production is used. If set to buffer, the min
#'   distance from a violation at the beginning or end of the contact
#'   is used.
#' @param command_angle_resolution the resolution of the command angles to
#'   be check in degrees (default 1).
#' @param command_rate_min the minimum command rate in degrees per second
#'   (default 0 for static rotations).
#' @param command_rate_max the maximum command rate in degrees per second
#'   (default 0 for static rotations).
#' @param command_rate_resolution the resolution of the command rate in
#'   degrees per second (default 1).
#' @param verbose if TRUE (default is FALSE) then the status will be printed to
#'   the screen
#'
#' @return a list, with elements "ground_station_views"
#'   (a data.frame containing the information needed for the ground station
#'   views product in the mission planning workflow, as defined in the
#'   MOS-MP ICD - Document 2642516, Revision C),
#'   "attitude_quaternion_eci", (a data.frame of quaternions in
#'   Earth-Centered Inertial describing the attitude of the spacecraft)
#'   and "activity_schedule" (a list of data.frames giving information for
#'   generating the activity schedule)
#'
#' @family activity functions
#' @export
ActivityDownlink <- function(
    utc = NULL,
    rev = NULL,
    spacecraft_state,
    spacecraft_configuration,
    station,
    antenna = NULL,
    secondary_reference = "sun",
    tiebreaker = "power",
    command_angle_resolution = 1,
    command_rate_min = -1,
    command_rate_max = 1,
    command_rate_resolution = 0.1,
    verbose = FALSE
) {

  # The code proceeds in the following steps:
  # 1) Determine geometric feasibility in ECEF.
  #    This is done in ECEF for computational efficiency.
  # 2) Calculate attitudes and restrictions in ECI.
  # 3) Select the best attitude.
  # 4) Generate the activities.
  #    These are the outputs.

  # Configuration

  # If verbose is set, initialize a progress bar.
  # This code can be wall time intensive so this can be helpful to a user.
  if (verbose) {
    pb <- utils::txtProgressBar()
  }

  # For ground station views, we use generic ground station locations.
  # This line will set the ground station. If the antenna is specified, the
  # next block of code will override it.
  groundstation <-
    spacecraft_configuration$ground_stations[
      spacecraft_configuration$ground_stations$name == station,
    ]
  groundstation$id <- groundstation$name

  # For downlink planning, we use specific antenna locations
  # This block of code will override the ground station with the specific
  # antenna if it is selected.
  if (!is.null(antenna)) {
    if (!(antenna %in% spacecraft_configuration$ground_station_antennas$id)) {
      stop("antenna should be one of the KSAT id's. See help.")
    } else {
      groundstation <-
        dplyr::filter(
          spacecraft_configuration$ground_station_antennas,
          id == antenna
        )
    }
  }

  # Step 1) Determine feasibility in ECEF

  # Find when a connection to the ground station is geometrically feasible.
  # This occurs when the elevation angle of the line of sight is less than the
  # minimum defined in the spacecraft configuration

  # Get the local tangent plane at the ground station.
  # The elevation angle is measured against the z-axis.
  groundstation_local_tangent_plane_ecef <-
    LocalTangentPlane(
      lon = groundstation$geodetic$lon,
      lat = groundstation$geodetic$lat
    )

  # Get the bore sight vector from spacecraft to ground station.
  # The elevation angle is the angle between this and the ground station
  # local tangent plane z-axis.
  spacecraft_to_station_ecef <-
    NormalizeByRow(
      RepeatRows(unlist(groundstation$ecef), length(spacecraft_state$utc)) -
      spacecraft_state$pos_ecef
    )

  # Measure the elevation angle.
  elevation_angle <-
    AngleBetweenVectors(
      - spacecraft_to_station_ecef,
      RepeatRows(
        unlist(groundstation_local_tangent_plane_ecef$z_hat),
        length(spacecraft_state$utc))
    )

  # Get the feasible geometry for the s band, which has 0 angle
  feasible_s <- which((elevation_angle * 180/pi) < 90)
  feasible_tc <- which((elevation_angle * 180/pi) < (90 - 5))

  # The contact is feasible when the elevation angle is less than
  # the minimum elevation angle in the spacecraft configuration.
  feasible <-
    which(
      ((elevation_angle * 180/pi) <
        (90 - spacecraft_configuration$downlink$elevation_min_deg)) &
      (spacecraft_state$activity %in% c("Cruise", "Slew"))
    )

  # If the user has specified a rev, restrict the feasible period
  if (!is.null(rev)) {
    feasible <- feasible[spacecraft_state$rev$rev_ascending[feasible] %in% rev]
    feasible_s <- feasible_s[spacecraft_state$rev$rev_ascending[feasible_s] %in% rev]
    feasible_tc <- feasible_tc[spacecraft_state$rev$rev_ascending[feasible_tc] %in% rev]
  }

  # Initialize the output if there is no feasible downlink.
  ground_station_views <-
    data.frame(
      station = groundstation$name,
      slewtimeStart = NA,
      sBandTimeStart =
        Iso8601FromUtc(spacecraft_state$utc[min(feasible_s)]),
      tcTimeStart =
        Iso8601FromUtc(spacecraft_state$utc[min(feasible_tc)]),
      xBandTimeStart = NA,
      xBandTimeEnd = NA,
      tcTimeEnd =
        Iso8601FromUtc(spacecraft_state$utc[max(feasible_tc)]),
      sBandTimeEnd =
        Iso8601FromUtc(spacecraft_state$utc[max(feasible_s)]),
      slewtimeEnd = NA,
      estDataDownlink = 0
    )
  output <-
    list(
      downlink_max = 0,
      ground_station_views = ground_station_views,
      attitude_quaternion_eci = NA,
      activity_schedule = NA
    )

  # If the user has specified a utc time, restrict the feasible period
  if (!is.null(utc)) {
    feasible <- feasible[spacecraft_state$utc[feasible] %in% utc]
  }

  # This situation should never exist in reality but could cause an error
  if (any(c(1, nrow(spacecraft_state)) %in% feasible)) {
    if (verbose) {
      cat("\nFeasible pass on the edge")
    }
    return(output)
  }

  # If there is no feasible pass, output the ground station views
  # (which is potentially enpty)
  if (length(feasible) == 0) {
    if (verbose) {
      cat("\nNo Feasible Pass")
    }
    return(output)
  }

  # If there is a feasible pass, find the best possible pass
  if (verbose) {
    cat("\nFeasible Pass Identified\n")
  }

  # Step 2) Determine the attitude and restrictions in ECI

  # Restrict the spacecraft state to the feasible period
  spacecraft_state_feasible <- spacecraft_state[feasible, ]
  spacecraft_to_station_ecef <- spacecraft_to_station_ecef[feasible, ]
  spacecraft_to_station_eci <-
    EciFromEcef(
      spacecraft_to_station_ecef,
      q_ei = spacecraft_state_feasible$q_ei
    )

  # Set up the reference frame and the command frame
  primary_reference_vec <-
    spacecraft_to_station_eci
  if (secondary_reference == "orbit normal") {
    secondary_reference_vec <-
      CrossProductByRow(
        spacecraft_state_feasible$vel_eci,
        spacecraft_state_feasible$pos_eci
      ) %>%
      NormalizeByRow() %>%
      as.matrix()
  }
  if (secondary_reference == "sun") {
    secondary_reference_vec <-
      spacecraft_state_feasible$sun_eci - spacecraft_state_feasible$pos_eci
  }
  primary_command <- spacecraft_configuration$bus$xband_antenna
  secondary_command <- c(0, -1, 0)

  # Set up the angles and rate to rotate the spacecraft
  # about the reference frame to avoid keepout angles.
  # These angles are used to calculate qTARGETwrtREFERENCE
  command_angles <-
    seq(
      from = 0,
      to = 359.999,
      by = command_angle_resolution
    )
  command_rates <-
    seq(
      from = command_rate_min,
      to = command_rate_max,
      by = command_rate_resolution
    )

  # Create some shape objects to make later code more readable
  n_angles <- length(command_angles)
  n_rates <- length(command_rates)
  n_utc <- length(feasible)

  # An array of command angles for each rate
  command_angle_array <- array(dim = c(n_angles, n_rates, n_utc))
  for (angle.tick in 1:n_angles) {
    for (rate.tick in 1:n_rates) {
      command_angle_array[angle.tick, rate.tick, ] <-
        (command_angles[angle.tick] +
           (1:n_utc - 1) * command_rates[rate.tick]) %% 360
    }
  }

  # Calculate possible command frames by rotating the reference frame
  # about the antenna (z)
  attitude_quaternion_eci_mat <- array(dim = c(n_angles, n_rates, n_utc, 4))
  sun_to_radiator <- array(dim = c(n_angles, n_rates, n_utc))
  sun_to_reubensplane <- array(dim = c(n_angles, n_rates, n_utc))
  earth_to_radiator <- array(dim = c(n_angles, n_rates, n_utc))
  earth_to_reubensplane <- array(dim = c(n_angles, n_rates, n_utc))
  agility_violation <- array(dim = c(n_angles, n_rates, n_utc))
  power_factor <- array(dim = c(n_angles, n_rates, n_utc))
  for (angle.tick in 1:n_angles) {
    if (verbose) {
      utils::setTxtProgressBar(pb, angle.tick / n_angles)
    }
    for (rate.tick in 1:n_rates) {

      # Set up qTARGETwrtREF
      qTARGETwrtREF <-
        data.frame(
          r = cos(command_angle_array[angle.tick, rate.tick, ] * pi / 360),
          i1 = 0,
          i2 = 0,
          i3 = sin(command_angle_array[angle.tick, rate.tick, ] * pi / 360)
        )

      # Transform to ECI
      attitude_quaternion_eci_mat[angle.tick, rate.tick, , ] <-
        as.matrix(
        AttitudeFromXactCommand(
          qTARGETwrtREF = qTARGETwrtREF,
          primary_reference = primary_reference_vec,
          secondary_reference = secondary_reference_vec,
          primary_command = primary_command,
          secondary_command = secondary_command
        )
      )

      # Check the constraints
      spacecraft_state_test <- spacecraft_state_feasible
      spacecraft_state_test$attitude_quaternion_eci <-
        attitude_quaternion_eci_mat[angle.tick, rate.tick, , ]
      constraint_checks <-
        CheckConstraints(
          spacecraft_state = spacecraft_state_test,
          spacecraft_configuration = spacecraft_configuration,
          verbose = FALSE
        )
      agility_violation[angle.tick, rate.tick, ] <-
        constraint_checks$agility_violation
      power_factor[angle.tick, rate.tick, ] <-
        constraint_checks$power_factor
      sun_to_radiator[angle.tick, rate.tick, ] <-
        constraint_checks$sun_to_radiator
      sun_to_reubensplane[angle.tick, rate.tick, ] <-
        constraint_checks$sun_to_reubensplane
      earth_to_radiator[angle.tick, rate.tick, ] <-
        constraint_checks$earth_to_radiator
      earth_to_reubensplane[angle.tick, rate.tick, ] <-
        constraint_checks$earth_to_reubensplane
    }
  }

  # Step 3) Select the best attitude

  # We want to find the longest contact
  # subject to our ability to slew to the contact.
  # However, calculating and checking slews is expensive.
  # So, we first try the best contact regardless of slew and try to slew to it.
  # If that fails, then we make the thermal constraints stricter and repeat.

  # We use a while loop and exit when we either find a good contact or
  # run out of allowed states

  # Initialize the constraints to the spacecraft configuration constraints
  sun_to_radiator_deg_min <-
    spacecraft_configuration$constraints$sun_to_radiator_deg
  sun_to_reubensplane_deg_min <-
    spacecraft_configuration$constraints$sun_to_reubensplane_deg
  earth_to_radiator_deg_min <-
    spacecraft_configuration$constraints$earth_to_radiator_deg
  earth_to_reubensplane_deg_min <-
    spacecraft_configuration$constraints$earth_to_reubensplane_deg

  flag <- TRUE
  while (flag) {

    # Calculate the allowed states
    allowed <-
      (((sun_to_radiator * 180 / pi) > sun_to_radiator_deg_min) |
       ((sun_to_reubensplane * 180 / pi) > sun_to_reubensplane_deg_min)) &
      (((earth_to_radiator * 180 / pi) > earth_to_radiator_deg_min) |
       ((earth_to_reubensplane * 180 / pi) > earth_to_reubensplane_deg_min)) &
      ! agility_violation

    # If there is no feasible pass, output an empty activity
    if (sum(allowed) == 0) {
      if (verbose) {
        cat("\nNo Feasible Pass")
      }
      return(output)
    }

    # Select the best segment, with
    # 1) the longest time, and then
    # 2) the highest power factor or the distance from a violation

    # Measure the length of each ground station contact.
    # For this we use the run length encoding (rle) algorithm to find
    # the length of the longest continuous segment of each
    # combination of command angles and rates.
    contact_length <- array(dim = c(n_angles, n_rates))
    for (angle.tick in 1:n_angles) {
      for (rate.tick in 1:n_rates) {
        if (all(!allowed[angle.tick, rate.tick, ])) {next()}
        contact_length[angle.tick, rate.tick] <-
          # Isolate the allowed times for this angle and rate combination
          allowed[angle.tick, rate.tick, ] %>%
          # Take the rle to find the length of continuous allowed segments
          rle() %>%
          # Convert to a data.frame with the start and end indices
          RleToDataFrame() %>%
          # Filter out the not allowed segments
          dplyr::filter(value) %>%
          # Find the length by taking the difference between the start and end
          dplyr::select(start, end) %>%
          apply(1, diff) %>%
          # The max length is our contact length
          max() %>%
          "+"(1)
      }
    }

    # If there is no feasible pass, output an empty activity
    if (max(contact_length, na.rm = TRUE) < 5) {
      if (verbose) {
        cat("\nNo Feasible Pass")
      }
      return(output)
    }

    # Find the longest possible secondary angle and rate
    downlink_max <-
      which(
        contact_length == max(contact_length, na.rm = TRUE),
        arr.ind = TRUE
      )

    # Maximize the angular distance (buffer) to violations at the start or end
    if (tiebreaker == "buffer") {

      # "buffer" is the measure of the buffer for each yaw angle
      buffer <- rep(NA, nrow(downlink_max))
      for (downlink_max.tick in 1:nrow(downlink_max)) {

        # Retrieve the indices of the longest segment
        contact_indices <-
          # Isolate the allowed times for this angle and rate combination
          allowed[
            downlink_max[downlink_max.tick, 1],
            downlink_max[downlink_max.tick, 2],
          ] %>%
          # Take the rle to find the length of continuous allowed segments
          rle() %>%
          # Convert to a data.frame with the start and end indices
          RleToDataFrame() %>%
          # Filter out the not allowed segments
          dplyr::filter(value) %>%
          # Pull the longest segment
          dplyr::filter(length == max(length))

        # Measure the buffer
        buffer[downlink_max.tick] <-
          min(
            # Sun violations
            max(
              # Sun to radiator at the start of the activity
              sun_to_radiator[
                downlink_max[downlink_max.tick, 1],
                downlink_max[downlink_max.tick, 2],
                contact_indices$start
              ],
              # Sun to Reuben's plane at the start of the activity
              sun_to_reubensplane[
                downlink_max[downlink_max.tick, 1],
                downlink_max[downlink_max.tick, 2],
                contact_indices$start
              ]
            ) *
              (180 / pi) -
              spacecraft_configuration$constraints$sun_to_radiator_deg,
            max(
              # Sun to radiator at the end of the activity
              sun_to_radiator[
                downlink_max[downlink_max.tick, 1],
                downlink_max[downlink_max.tick, 2],
                contact_indices$end
              ],
              # Sun to Reuben's plane at the end of the activity
              sun_to_reubensplane[
                downlink_max[downlink_max.tick, 1],
                downlink_max[downlink_max.tick, 2],
                contact_indices$end
              ]
            )
              * (180 / pi) -
              spacecraft_configuration$constraints$sun_to_reubensplane_deg,
            # Earth violations
            max(
              # Earth to radiator at the start of the activity
              earth_to_radiator[
                downlink_max[downlink_max.tick, 1],
                downlink_max[downlink_max.tick, 2],
                contact_indices$start
              ],
              # Earth to Reuben's plane at the start of the activity
              earth_to_reubensplane[
                downlink_max[downlink_max.tick, 1],
                downlink_max[downlink_max.tick, 2],
                contact_indices$start
              ]
            ) *
              (180 / pi) -
              spacecraft_configuration$constraints$earth_to_radiator_deg,
            max(
              # Earth to radiator at the end of the activity
              earth_to_radiator[
                downlink_max[downlink_max.tick, 1],
                downlink_max[downlink_max.tick, 2],
                contact_indices$end
              ],
              # Earth to Reuben's plane at the end of the activity
              earth_to_reubensplane[
                downlink_max[downlink_max.tick, 1],
                downlink_max[downlink_max.tick, 2],
                contact_indices$end
              ]
            ) *
              (180 / pi) -
              spacecraft_configuration$constraints$earth_to_reubensplane_deg
          )
      }

    }

    # Select the best yaw angle as the highest power production
    if (tiebreaker == "power") {
      power_factor_sum <- apply(power_factor * allowed, c(1,2), sum)
      if (nrow(downlink_max) > 1) {
        downlink_max <-
          downlink_max[which.max(power_factor_sum[downlink_max]), ]
      }
    }

    # If there is still a tie then it doesn't matter which we choose.
    # Just pick the first one.
    if (length(downlink_max) > 2) {
      downlink_max <- downlink_max[1,]
    }

    # Retrieve the indices of the longest segment
    contact_indices <-
      # Isolate the allowed times for this angle and rate combination
      allowed[downlink_max[1], downlink_max[2], ] %>%
      # Take the rle to find the length of continuous allowed segments
      rle() %>%
      # Convert to a data.frame with the start and end indices
      RleToDataFrame() %>%
      # Filter out the not allowed segments
      dplyr::filter(value) %>%
      # Pull the longest segment
      dplyr::filter(length == max(length)) %>%
      # Take a sequence from start to end
      (function(x) {x$start:x$end})

    # Quaternion in ECI
    attitude_quaternion_eci_now <-
      data.frame(
        row = feasible[contact_indices],
        utc = spacecraft_state$utc[feasible[contact_indices]],
        attitude_quaternion_eci_mat[
            downlink_max[1],
            downlink_max[2],
            contact_indices,
          ] %>%
          as.data.frame() %>%
          "colnames<-"(c("r", "i1", "i2", "i3"))
      )

    if (verbose) {
      cat("\nchecking slews")
    }

    # Input the activity to the spacecraft state
    spacecraft_state_with_slew <-
      SpacecraftStateAddActivity(
        spacecraft_state = spacecraft_state,
        spacecraft_configuration = spacecraft_configuration,
        attitude_quaternion_eci = attitude_quaternion_eci_now,
        activity_schedule = NULL,
        verbose = FALSE
      )

    # Test for any violations along the slew and tighten the tolerances
    violation <-
      any(
        spacecraft_state_with_slew$constraints$sun_violation |
        spacecraft_state_with_slew$constraints$earth_violation |
        spacecraft_state_with_slew$constraints$agility_violation
      )
    if (violation) {
      cat("\nviolation - restricting and trying again")
      sun_to_radiator_deg_min <- sun_to_radiator_deg_min + 5
      sun_to_reubensplane_deg_min <- sun_to_reubensplane_deg_min + 5
      earth_to_radiator_deg_min <- earth_to_radiator_deg_min + 5
      earth_to_reubensplane_deg_min <- earth_to_reubensplane_deg_min + 5
      next()
    }
    else {
      flag <- FALSE
    }

    flag <- FALSE

  }

  # Step 4) Generate the activities

  # The S-Band connection uses the entire overpass (all times in "feasible")
  # while the X-Band connection uses only the part of the overpass when the
  # antenna can feasibly connect to the ground station ("contact_indices"
  # in "feasible").
  ground_station_views <-
    data.frame(
      station = groundstation$name,
      slewtimeStart =
        Iso8601FromUtc(min(
          spacecraft_state_with_slew$utc[
            spacecraft_state_with_slew$activity == "Slew"
          ]
        )),
      sBandTimeStart =
        Iso8601FromUtc(spacecraft_state$utc[min(feasible_s)]),
      tcTimeStart =
        Iso8601FromUtc(spacecraft_state$utc[min(feasible_tc)]),
      xBandTimeStart =
        Iso8601FromUtc(spacecraft_state$utc[feasible[min(contact_indices)]]),
      xBandTimeEnd =
        Iso8601FromUtc(spacecraft_state$utc[feasible[max(contact_indices)]]),
      tcTimeEnd =
        Iso8601FromUtc(spacecraft_state$utc[max(feasible_tc)]),
      sBandTimeEnd =
        Iso8601FromUtc(spacecraft_state$utc[max(feasible_s)]),
      slewtimeEnd =
        Iso8601FromUtc(max(
          spacecraft_state_with_slew$utc[
            spacecraft_state_with_slew$activity == "Slew"
          ]
        )),
      estDataDownlink =
        length(contact_indices) *
        spacecraft_configuration$downlink$downlink_rate_MBps
    )

  # Quaternion in ECI
  attitude_quaternion_eci <-
    data.frame(
      row = feasible[contact_indices],
      utc = spacecraft_state$utc[feasible[contact_indices]],
        attitude_quaternion_eci_mat[
          downlink_max[1],
          downlink_max[2],
          contact_indices,
        ] %>%
        as.data.frame() %>%
        "colnames<-"(c("r", "i1", "i2", "i3"))
    )

  # Calculate data budget for the downlink
  downlink_data <-
    CalculateDownlinkData(
      length(contact_indices) -
        spacecraft_configuration$downlink$commlink_delay_s,
      spacecraft_configuration = spacecraft_configuration
    )

  # Add the attitude and activity schedule to the list
  activity_schedule <-
    data.frame(
      utc = spacecraft_state$utc[contact_indices],
      activity = "Downlink",
      TargX = groundstation$ecef$x,
      TargY = groundstation$ecef$y,
      TargZ = groundstation$ecef$z,
      PriRefDir = 9,
      SecRefDir = 3,
      PriCmdDir = 12,
      SecCmdDir = 5,
      AttInterp = "Quaternion",
      qTARGETwrtREF1 = 0,
      qTARGETwrtREF2 = 0,
      qTARGETwrtREF3 =
        sin(
          command_angle_array[
            downlink_max[1],
            downlink_max[2],
            contact_indices[1]
          ] * pi / 360
        ),
      qTARGETwrtREF4 =
        cos(
          command_angle_array[
            downlink_max[1],
            downlink_max[2],
            contact_indices[1]
          ] * pi / 360
        ),
      RateInterp = 1,
      CmdRateX = 0,
      CmdRateY = 0,
      CmdRateZ = command_rates[downlink_max[2]],
      collectionID = "NA",
      frameRate = 0,
      window = "NA",
      LedDriveCurrent810nmCh4 = 0,
      LedDriveCurrent1550nmCh4 = 0,
      LedDriveCurrent810nmO2 = 0,
      LedDriveCurrent1550nmO2 = 0,
      stationName = groundstation$name,
      antennaID = groundstation$id,
      xBand = TRUE,
      sBand = TRUE,
      thruster1 = NA,
      thruster2 = NA,
      thruster3 = NA,
      SPCount = downlink_data$superpages,
      CCSDSBytes = downlink_data$ccsds_bytes,
      PEBtoHSDR = downlink_data$peb_to_hsdr_time,
      DVBS2Bytes = downlink_data$dvb_s2_bytes,
      DownlinkTime = downlink_data$downlink_time
  )

  # Return a list of objects that will be needed to generate
  # ground station views, the activity schedule, the 1-hz time series and
  # orthorectification
  output <-
    list(
      downlink_max = downlink_max,
      ground_station_views = ground_station_views,
      attitude_quaternion_eci = attitude_quaternion_eci,
      activity_schedule = activity_schedule
    )

  return(output)

}

#' Calculate the MethaneSAT dark calibration attitude
#'
#' \code{ActivityDark} calculates the MethaneSAT dark, LED, or LED sweep
#' calibration (i.e., any calibration that requires a look to deep space)
#' attitude based on the position of the spacecraft. The attitude is the
#' lowest pure pitch from cruise that passes the Kaman line and does not
#' cause a thermal violation. We take the pitch relative to cruise rather than
#' Local Vertical - Local Horizontal because it is more likely to pass thermal
#' constraints.
#'
#' @param utc UTC times in POSIX format when to perform the calibration
#' @param spacecraft_state initial spacecraft state object. See documentation
#'   for the function \code{SpacecraftState} for more information.
#' @param spacecraft_configuration a list containing configuration data for the
#'   spacecraft. The default is saved in package data as
#'   \code{ground_configuration} and contains initial information about
#'   MethaneSAT. The data can be loaded from a configuration file using the
#'   function \code{ReadGroundConfiguration} See the data documentation for
#'   \code{ground_configuration} for more detail on the object.
#' @param pitch angle to pitch up from cruise attitude in radians
#'   (default 73 * pi / 180). Must be at least 70.5 to clear the
#'   Kaman airglow line.
#' @param led logical (default FALSE). If TRUE, then the LED drive currents
#'   will be turned on.
#' @param collection_id optional collection ID - see WriteCollectionId
#'   to generate this
#'
#' @return a list, with elements attitude_quaternion
#'
#' @family activity functions
#' @export
ActivityDarkScan <- function(
    utc,
    spacecraft_state,
    spacecraft_configuration,
    pitch = 73 * pi / 180,
    led = FALSE,
    collection_id = "NA"
  ) {

  # Set the LED Drive Currents
  LedDriveCurrent810nmCh4 <- 0
  LedDriveCurrent1550nmCh4 <- 0
  LedDriveCurrent810nmO2 <- 0
  LedDriveCurrent1550nmO2 <- 0
  activity <- "DarkScan"
  if (led) {
    LedDriveCurrent810nmCh4 <- 1.55
    LedDriveCurrent1550nmCh4 <- 2.5
    LedDriveCurrent810nmO2 <- 1.5
    LedDriveCurrent1550nmO2 <- 2.5
    activity <- "LedMeasurementScan"
  }

  # Pitch and yaw angles to search
  attitude_pitch_roll_yaw <- c(pitch = pitch, roll = 0, yaw = 0)

  # Get the attitude with respect to cruise
  attitude_quaternion_cruise <-
    QuaternionsFromPitchRollYaw(attitude_pitch_roll_yaw)

  # Find feasible indices

  # Calculate the attitude of the dark scan by rotating lvlh
  attitude_quaternion_eci <-
    QuaternionMultiply(
      attitude_quaternion_cruise,
      spacecraft_state$attitude_quaternion_eci
    )

  # Check the constraints to find the feasible periods
  spacecraft_state_test <- spacecraft_state
  spacecraft_state_test$attitude_quaternion_eci <- attitude_quaternion_eci
  constraint_checks <-
    CheckConstraints(
      spacecraft_state = spacecraft_state_test,
      spacecraft_configuration = spacecraft_configuration,
      verbose = FALSE
    )

  # Need to be able to stack with DarkScan
  feasible <-
    which(
      !(
        constraint_checks$sun_violation |
        constraint_checks$earth_violation |
        ((constraint_checks$sun_to_instrument * 180 / pi) < 20)
      ) &
      (spacecraft_state$activity %in% c("Cruise", "Slew"))
    )

  # If utc is set, then narrow down to the selected utc
  if (!is.null(utc)) {
    feasible <- feasible[spacecraft_state$utc[feasible] %in% utc]
  }

  if (length(feasible) == 0) {
    print("No feasible dark attitude")
    return(NULL)
  }

  # Restrict the attitude_quaternion_eci to the feasible points
  attitude_quaternion_eci <-
    data.frame(
      row = feasible,
      utc = spacecraft_state$utc[feasible],
      attitude_quaternion_eci[feasible, ]
    )

  # Calculate the data requirement
  scan_data <-
    CalculateScanData(
      duration = length(feasible),
      frame_rate = spacecraft_configuration$scan$framerate_1_hz,
      spacecraft_configuration = spacecraft_configuration
    )

  if (led) {
    scan_data <-
      CalculateScanData(
        duration = length(feasible) * 0.4,
        frame_rate = spacecraft_configuration$scan$framerate_1_hz,
        spacecraft_configuration = spacecraft_configuration
      )
  }

  activity_schedule <-
    data.frame(
      utc = spacecraft_state$utc[feasible],
      activity = activity,
      TargX = 0,
      TargY = 0,
      TargZ = 0,
      PriRefDir = 6,
      SecRefDir = 3,
      PriCmdDir = 6,
      SecCmdDir = 4,
      AttInterp = "Quaternion",
      qTARGETwrtREF1 = attitude_quaternion_cruise$i1,
      qTARGETwrtREF2 = attitude_quaternion_cruise$i2,
      qTARGETwrtREF3 = attitude_quaternion_cruise$i3,
      qTARGETwrtREF4 = attitude_quaternion_cruise$r,
      RateInterp = 1,
      CmdRateX = 0,
      CmdRateY = 0,
      CmdRateZ = 0,
      collectionID = collection_id,
      frameRate = spacecraft_configuration$scan$framerate_1_hz,
      window = "Calibration",
      LedDriveCurrent810nmCh4 = LedDriveCurrent810nmCh4,
      LedDriveCurrent1550nmCh4 = LedDriveCurrent1550nmCh4,
      LedDriveCurrent810nmO2 = LedDriveCurrent810nmO2,
      LedDriveCurrent1550nmO2 = LedDriveCurrent1550nmO2,
      stationName =  "NA",
      antennaID = "NA",
      xBand = FALSE,
      sBand = FALSE,
      thruster1 = NA,
      thruster2 = NA,
      thruster3 = NA,
      SPCount = scan_data$superpages,
      CCSDSBytes = scan_data$ccsds_bytes,
      PEBtoHSDR = scan_data$peb_to_hsdr_time,
      DVBS2Bytes = scan_data$dvb_s2_bytes,
      DownlinkTime = scan_data$downlink_time
    )

  # Return the output
  # Return a list of objects that will be needed to generate
  # the activity schedule, the 1-hz time series and orthorectification
  output <-
    list(
      feasible = feasible,
      attitude_quaternion_eci = attitude_quaternion_eci,
      activity_schedule = activity_schedule
    )

  return(output)

}

#' Calculate the MethaneSAT vicarious calibration attitude
#'
#' A vicarious calibration is a sweep of every pixel of the instrument across
#' the site of a calibrated instrument or flat field.
#'
#' The vicarious calibration attitude points the instrument bore sight at the
#' target and rotates the spacecraft so that the instrument array aligns with
#' the bore sight travel. This is accomplished by first finding the attitude
#' that points the instrument bore sight at the target, then finding points
#' along the sweep above and below the target, and using these points as
#' aim points to fix the attitude of the array.
#'
#' @param utc vector of UTC (Universal Coordinated Time) dates in POSIX
#'   (Portable Operating System Interface) format to select times to return
#'   scan activities. Only feasible activities will be returned. If there are
#'   no feasible activities, then NULL will be returned.
#' @param duration numeric length of the scan in seconds
#' @param spacecraft_state initial spacecraft state object. See documentation
#'   for the function \code{SpacecraftState} for more information.
#' @param spacecraft_configuration a list containing configuration data for the
#'   spacecraft. The default is saved in package data as
#'   \code{ground_configuration} and contains initial information about
#'   MethaneSAT. The data can be loaded from a configuration file using the
#'   function \code{ReadGroundConfiguration} See the data documentation for
#'   \code{ground_configuration} for more detail on the object.
#' @param target_geodetic location of the target centroid in lon and lat
#' @param test_slews logical (default FALSE) if TRUE then each feasible
#'   will be tested
#' @param collection_id optional collection ID - see WriteCollectionId
#'   to generate this
#' @param verbose logical (default FALSE) if TRUE, then the progress of the
#'   function is printed to screen
#'
#' @return a list, with elements activity_schedule,
#'   attitude_quaternion_eci and attitude_quaternion_ecef.
#'
#' @family activity functions
#' @export
ActivityVicariousScan <- function(
    utc = NULL,
    duration = 30,
    spacecraft_state,
    spacecraft_configuration,
    target_geodetic,
    test_slews = FALSE,
    collection_id = "NA",
    verbose = FALSE
) {

  # Initialize a progress bar if verbose has been selected.
  # This function can just a little computationally expensive.
  if (verbose) {
    pb <- utils::txtProgressBar(style = 3)
  }

  # 1) Find z_hat by pointing the instrument bore sight at the site
  # 2) Generate an example orbit by dragging z_hat along the spacecraft state
  # 3) Uee the example orbit points to find xhat and yhat just like a scan

  # Determine feasibility

  target_ecef <- EcefFromGeodetic(target_geodetic)

  # z_hat points from the spacecraft to the target at the middle of the scan
  middle_z_hat_ecef <-
    (RepeatRows(target_ecef, nrow(spacecraft_state)) -
      spacecraft_state$pos_ecef) %>%
    NormalizeByRow()

  # Cut it down to feasible times

  # Get the local tangent plane at the target
  # z_hat from this is used to measure elevation and zenith angles
  target_local_tangent_plane_ecef <-
    LocalTangentPlane(
      lon = target_geodetic$lon,
      lat = target_geodetic$lat
    )

  # Calculate the elevation angle. If this is less than pi/2
  # then the spacecraft is above the target.
  elevation_angle <-
    AngleBetweenVectors(
      target_local_tangent_plane_ecef$z_hat,
      - middle_z_hat_ecef
    )

  # 3) The solar zenith angle
  solar_zenith_angle <-
    AngleBetweenVectors(
      target_local_tangent_plane_ecef$z_hat,
      spacecraft_state$sun_ecef
    )

  # Use the conditions to determine feasibility
  # The max pitch and roll should not be hard coded.
  # They should be moved to the spacecraft configuration
  feasible <-
    which(
      ((elevation_angle * 180 / pi) < 90) &
      ((solar_zenith_angle * 180 / pi) <
        spacecraft_configuration$scan$sza_max_deg) &
      (spacecraft_state$activity %in% c("Cruise", "Slew"))
    )

  # If the user has specified a utc time, restrict the feasible period
  if (!is.null(utc)) {
    feasible <- feasible[spacecraft_state$utc[feasible] %in% utc]
  }

  # Apply the restriction

  # Restrict middle_z_hat to the feasible times
  middle_z_hat_ecef <- middle_z_hat_ecef[feasible, ]
  spacecraft_state_feasible <- spacecraft_state[feasible, ]

  # To get x_hat and y_hat, we need the intersection of the boresight with the
  # earth before and after the middle of the scan
  top_eci <-
    IntersectEllipsoid(
      pos_ecef = spacecraft_state$pos_ecef[feasible + 1, ],
      ray_ecef = middle_z_hat_ecef,
      elevation = target_geodetic$alt
    ) %>%
    EcefFromGeodetic() %>%
    EciFromEcef(q_ei = spacecraft_state$q_ei[feasible + 1, ])

  bottom_eci <-
    IntersectEllipsoid(
      pos_ecef = spacecraft_state$pos_ecef[feasible - 1, ],
      ray_ecef = middle_z_hat_ecef,
      elevation = target_geodetic$alt
    ) %>%
    EcefFromGeodetic() %>%
    EciFromEcef(q_ei = spacecraft_state$q_ei[feasible - 1, ])

  # Get reference vectors at the left and right side of the target
  line_of_sight_top_eci <- top_eci - spacecraft_state_feasible$pos_eci
  line_of_sight_bottom_eci <- bottom_eci - spacecraft_state_feasible$pos_eci

  # To ensure perfect orthogonality, reset z_hat to the
  # bisector of the lines of sight to bottom and top_ecef
  # the difference is on the order of thousanths of a degree
  middle_z_hat_eci <-
    (NormByRow(line_of_sight_top_eci) * line_of_sight_bottom_eci +
       NormByRow(line_of_sight_bottom_eci) * line_of_sight_top_eci) %>%
    NormalizeByRow()

  # x_hat is perpendicular to the plane formed by the reference vectors,
  # this gives two options - which we select based on the position of the sun.
  middle_x_hat_eci <-
    CrossProductByRow(line_of_sight_top_eci, line_of_sight_bottom_eci) %>%
    NormalizeByRow()

  # Detect the yaw flip - if the radiator is pointed towards the sun
  # then flip the spacecraft so that the radiator points away
  yaw_flip <-
    AngleBetweenVectors(
      middle_x_hat_eci,
      spacecraft_state_feasible$sun_eci
    ) < pi / 2

  # Apply the yaw flip
  middle_x_hat_eci[yaw_flip] <- - middle_x_hat_eci[yaw_flip]

  # Set y_hat to complete the right-handed coordinate system
  middle_y_hat_eci <-
    CrossProductByRow(middle_z_hat_eci, middle_x_hat_eci) %>%
    NormalizeByRow()

  # Set up the basis vectors as a list for conversion to other attitude types
  middle_basis_vectors_eci <-
    list(middle_x_hat_eci, middle_y_hat_eci, middle_z_hat_eci)

  # Convert to quaternions in ECI.
  middle_attitude_quaternion_eci <-
    QuaternionsFromBasisVectors(middle_basis_vectors_eci)

  # Generate qTARGETwrtREF
  attitude_scan <-
    XactCommandFromAttitude(
      attitude_quaternion_eci = middle_attitude_quaternion_eci,
      primary_reference = spacecraft_state_feasible$pos_eci,
      secondary_reference = spacecraft_state_feasible$vel_eci,
      primary_command = c(0, 0, -1),
      secondary_command = c(1, 0, 0)
    )

  # Initialize the attitude and activity schedule objects
  attitude_quaternion_eci <- list()
  activity_schedule <- list()
  activity <-
    c(
      rep("Settle", spacecraft_configuration$scan$settle_s),
      rep("VicariousScan", spacecraft_configuration$scan$standard_scan_s)
    )

  # For each feasible time, calculate and assess the scan attitude
  counter <- 1
  for (tick in 1:length(feasible)) {

    if (verbose) {
      utils::setTxtProgressBar(pb, tick / length(feasible))
    }

    # Get the times to scan
    scan_indices <-
      feasible[tick] +
      seq(
        from = - duration / 2 - spacecraft_configuration$scan$settle_s,
        to = duration / 2 - 1
      )

    # Get the attitude
    attitude_quaternion_eci_now <-
      AttitudeFromXactCommand(
        primary_command = c(0, 0, -1),
        secondary_command = c(1, 0, 0),
        qTARGETwrtREF = attitude_scan[tick, ],
        primary_reference = spacecraft_state$pos_eci[scan_indices, ],
        secondary_reference = spacecraft_state$vel_eci[scan_indices, ]
      )
    attitude_quaternion_eci_now$utc <- spacecraft_state$utc[scan_indices]
    attitude_quaternion_eci_now$row <- scan_indices

    # If test_slews is set, then test the slew and only
    if (test_slews) {
      # Now, can we slew to and from to this activity?
      spacecraft_state_with_slew <-
        SpacecraftStateAddActivity(
          spacecraft_state = spacecraft_state,
          spacecraft_configuration = spacecraft_configuration,
          attitude_quaternion_eci = attitude_quaternion_eci_now,
          activity_schedule = NULL,
          verbose = FALSE
        )
      if (is.null(spacecraft_state_with_slew)) {
        next
      }
      if (
        any(spacecraft_state_with_slew$sun_violation) |
        any(spacecraft_state_with_slew$earth_violation)
      ) {
        next()
      }
    }

    attitude_quaternion_eci[[counter]] <- attitude_quaternion_eci_now

    # Calculate the data requirement
    scan_data <-
      CalculateScanData(
        duration = length(scan_indices),
        frame_rate = spacecraft_configuration$scan$framerate_1_hz,
        spacecraft_configuration = spacecraft_configuration
      )

    # If we made it past the slew test,
    # then add the attitude and activity schedule to the list
    activity_schedule[[counter]] <-
      data.frame(
        utc = spacecraft_state$utc[scan_indices],
        activity = activity,
        TargX = 0,
        TargY = 0,
        TargZ = 0,
        PriRefDir = 6,
        SecRefDir = 7,
        PriCmdDir = 6,
        SecCmdDir = 1,,
        AttInterp = "Quaternion",
        qTARGETwrtREF1 = attitude_scan[tick, 2],
        qTARGETwrtREF2 = attitude_scan[tick, 3],
        qTARGETwrtREF3 = attitude_scan[tick, 4],
        qTARGETwrtREF4 = attitude_scan[tick, 1],
        RateInterp = 1,
        CmdRateX = 0,
        CmdRateY = 0,
        CmdRateZ = 0,
        collectionID = collection_id,
        frameRate = spacecraft_configuration$scan$framerate_1_hz,
        window = "Science",
        LedDriveCurrent810nmCh4 = 0,
        LedDriveCurrent1550nmCh4 = 0,
        LedDriveCurrent810nmO2 = 0,
        LedDriveCurrent1550nmO2 = 0,
        stationName =  "NA",
        antennaID = "NA",
        xBand = FALSE,
        sBand = FALSE,
        thruster1 = NA,
        thruster2 = NA,
        thruster3 = NA,
        SPCount = scan_data$superpages,
        CCSDSBytes = scan_data$ccsds_bytes,
        PEBtoHSDR = scan_data$peb_to_hsdr_time,
        DVBS2Bytes = scan_data$dvb_s2_bytes,
        DownlinkTime = scan_data$downlink_time
      )

    counter <- counter + 1

  }

  # Return the output
  output <-
    list(
      feasible = feasible,
      activity_schedule = activity_schedule,
      attitude_quaternion_eci = attitude_quaternion_eci
    )

  return(output)

}

#' Calculate the MethaneSAT limb scan attitude
#'
#' The limb scan attitude is the pure pitch from cruise that aims the
#' instrument at a specific altitude above the surface of the Earth.
#' This function allows the user to set the altitude with reference to the
#' spherical Earth approximation or the WGS84 ellipsoid. The spherical Earth
#' approximation will give more consistent results, especially if the altitude
#' is not set to vary. The WGS84 ellipsoid will give more accurate results.
#' The altitude can vary in order to scan across the limb. This is achieved by
#' implementing a command rate.
#'
#' @param spacecraft_state initial spacecraft state object. See documentation
#'   for the function \code{SpacecraftState} for more information.
#' @param spacecraft_configuration a list containing configuration data for the
#'   spacecraft. The default is saved in package data as
#'   \code{ground_configuration} and contains initial information about
#'   MethaneSAT. The data can be loaded from a configuration file using the
#'   function \code{ReadGroundConfiguration} See the data documentation for
#'   \code{ground_configuration} for more detail on the object.
#' @param utc_start vector of UTC (Universal Coordinated Time) dates in POSIX
#'   (Portable Operating System Interface) format when to start the scan
#' @param utc_end vector of UTC (Universal Coordinated Time) dates in POSIX
#'   (Portable Operating System Interface) format when to end the scan
#' @param altitude_start altitude in meters above the Earth's surface
#'   to point the instrument array at the start of the scan
#' @param altitude_end altitude in meters above the Earth's surface to point
#'   the instrument array at the end of the scan
#' @param earth_model character string specifying the model of the Earth
#'   elevation to use. One of "sphere" (default) or "WGS84".
#' @param collection_id optional collection ID - see WriteCollectionId
#'   to generate this
#'
#' @return a list, with elements activity_schedule,
#'   attitude_quaternion_eci and attitude_quaternion_ecef.
#'
#' @family activity functions
#' @export
ActivityAirglowLimbScan <- function(
    spacecraft_state,
    spacecraft_configuration,
    utc_start,
    utc_end,
    altitude_start,
    altitude_end,
    earth_model = "sphere",
    collection_id = "NA"
) {

  # The limb scan attitude is found by a line search across pitches
  # We start by analytically calculating the pitch that would intersect the
  # limb on a circular earth. We then search the pitches +/- 1 degree on
  # either side of the first guess, and find the minimum pitch that fails to
  # intersect the elevated ellipsoid.

  # This requires an initial attitude and a rate.
  # The rate is about the y axis, and so is described by the pitch rate alone.

  # Constants
  R_Earth <- 6371000 # Radius of the Earth in meters
  n_pitch <- 1000

  # Find the pitch for the start and end of the scan
  utc <- c(utc_start, utc_end)
  altitude <- c(altitude_start, altitude_end)
  pitch <- rep(NA, 2)
  pitch_index <- spacecraft_state$utc %in% utc[1]
  for (tick in 1:2) {
    # Find the starting  pitch
    index <- which(spacecraft_state$utc %in% utc[tick])
    pitch_first_guess <-
      asin(
        (R_Earth + altitude[tick]) /
        NormByRow(spacecraft_state$pos_eci[pitch_index, ])
      )
    if (earth_model == "sphere") {
      pitch[tick] <- pitch_first_guess
      next()
    }

    pitch_candidates <-
      pitch_first_guess +
      seq(
        from = -pi / 180,
        to = pi / 180,
        length = n_pitch,
      )

    # Pitch and yaw angles to search
    attitude_pitch_roll_yaw <-
      data.frame(
        pitch = pitch_candidates,
        roll = 0,
        yaw = 0
      )

    # Get the attitude with respect to cruise
    attitude_quaternion_cruise <-
      QuaternionsFromPitchRollYaw(attitude_pitch_roll_yaw)

    # Calculate the attitude of the dark scan by rotating lvlh
    attitude_quaternion_eci <-
      QuaternionMultiply(
        attitude_quaternion_cruise,
        spacecraft_state$attitude_quaternion_eci[index, ]
      )

    attitude_basis_eci <- BasisVectorsFromQuaternions(attitude_quaternion_eci)

    # Find attitudes
    intersections <-
      data.frame(
        lon = rep(NA, n_pitch),
        lat = rep(NA, n_pitch),
        alt = rep(NA, n_pitch)
      )
    for (pitch.tick in 1:n_pitch) {
      intersections[pitch.tick, ] <-
        suppressWarnings(
          IntersectEllipsoid(
            pos_ecef = spacecraft_state$pos_eci[index, ],
            ray_ecef = attitude_basis_eci$z_hat[pitch.tick, ],
            elevation = altitude_start
          )
        )
    }
    pitch[tick] <- pitch_candidates[min(which(is.na(intersections$alt)))]
  }

  # Isolate
  feasible <-
    which(
      spacecraft_state$utc >= utc[1] & spacecraft_state$utc <= utc[2] &
      (spacecraft_state$activity %in% c("Cruise", "Slew"))
    )

  # Create a settle and scan sequence
  activity <-
    c(
      rep("Settle", spacecraft_configuration$scan$settle_s),
      rep("AirglowLimbScan", length(feasible))
    )

  # A sequence of pitch values across the limb scan
  # to find the attitude of the spacecraft
  pitch_indices <- c(-spacecraft_configuration$scan$settle_s:-1, 0:(length(feasible) - 1))
  pitch_rate <- (pitch[2] - pitch[1]) / (length(feasible) - 1)
  pitches <- pitch[1] + pitch_rate * pitch_indices
  scan_indices <- feasible[1] + pitch_indices

  # Pitch and yaw angles to search
  attitude_pitch_roll_yaw <-
    data.frame(
      pitch = pitches,
      roll = 0,
      yaw = 0
    )

  # Get the attitude with respect to cruise
  attitude_quaternion_cruise <-
    QuaternionsFromPitchRollYaw(attitude_pitch_roll_yaw)

  # Calculate the attitude of the dark scan by rotating lvlh
  attitude_quaternion_eci <-
    data.frame(
      row = scan_indices,
      utc = spacecraft_state$utc[scan_indices],
      QuaternionMultiply(
        attitude_quaternion_cruise,
        spacecraft_state$attitude_quaternion_eci[scan_indices, ]
      )
    )

  # # Now, can we slew to and from to this activity?
  spacecraft_state_with_slew <-
    SpacecraftStateAddActivity(
      spacecraft_state = spacecraft_state,
      spacecraft_configuration = spacecraft_configuration,
      attitude_quaternion_eci = attitude_quaternion_eci,
      activity_schedule = NULL,
      verbose = FALSE
    )
  # Check Constraints
  if (
    any(spacecraft_state_with_slew$constraints$sun_violation) |
    any(spacecraft_state_with_slew$constraints$earth_violation) |
    #any(spacecraft_state_with_slew$constraints$agility_violation) |
    any((spacecraft_state_with_slew$constraints$sun_to_instrument[scan_indices] *
          180 / pi) < 20)
  ) {
    warning("Limb unfeasbible at this time/attitude")
    return(NULL)
  }

  # Get the command rate
  command_rate <- mean(diff(pitches) * 180 / pi)

  # Calculate the data requirement
  scan_data <-
    CalculateScanData(
      duration = length(feasible),
      frame_rate = spacecraft_configuration$scan$framerate_1_hz,
      spacecraft_configuration = spacecraft_configuration
    )

  # Write the activity schedule
  activity_schedule <-
    data.frame(
      utc = spacecraft_state$utc[scan_indices],
      activity = activity,
      TargX = 0,
      TargY = 0,
      TargZ = 0,
      PriRefDir = 6,
      SecRefDir = 3,
      PriCmdDir = 6,
      SecCmdDir = 4,
      AttInterp = "Quaternion",
      qTARGETwrtREF1 = attitude_quaternion_cruise$i1[which.min(pitch_indices)],
      qTARGETwrtREF2 = attitude_quaternion_cruise$i2[which.min(pitch_indices)],
      qTARGETwrtREF3 = attitude_quaternion_cruise$i3[which.min(pitch_indices)],
      qTARGETwrtREF4 = attitude_quaternion_cruise$r[which.min(pitch_indices)],
      RateInterp = 1,
      CmdRateX = 0,
      CmdRateY = command_rate,
      CmdRateZ = 0,
      collectionID = collection_id,
      frameRate = spacecraft_configuration$scan$framerate_1_hz,
      window = "Science",
      LedDriveCurrent810nmCh4 = 0,
      LedDriveCurrent1550nmCh4 = 0,
      LedDriveCurrent810nmO2 = 0,
      LedDriveCurrent1550nmO2 = 0,
      stationName =  "NA",
      antennaID = "NA",
      xBand = FALSE,
      sBand = FALSE,
      thruster1 = NA,
      thruster2 = NA,
      thruster3 = NA,
      SPCount = scan_data$superpages,
      CCSDSBytes = scan_data$ccsds_bytes,
      PEBtoHSDR = scan_data$peb_to_hsdr_time,
      DVBS2Bytes = scan_data$dvb_s2_bytes,
      DownlinkTime = scan_data$downlink_time
    )

  # Return the output
  output <-
    list(
      feasible = feasible,
      attitude_quaternion_eci = attitude_quaternion_eci,
      activity_schedule = activity_schedule
    )

  return(output)

}

#' Calculate the MethaneSAT thrust attitude
#'
#' The thrust attitude points z_hat in the anti-velocity direction,
#' then points x_hat as close as possible to anti-nadir. The thrust should
#' occur in eclipse. The first 3 minutes of eclipse is reserved for calibration
#' activities.
#'
#' @param spacecraft_state initial spacecraft state object. See documentation
#'   for the function \code{SpacecraftState} for more information.
#' @param spacecraft_configuration a list containing configuration data for the
#'   spacecraft. The default is saved in package data as
#'   \code{ground_configuration} and contains initial information about
#'   MethaneSAT. The data can be loaded from a configuration file using the
#'   function \code{ReadGroundConfiguration} See the data documentation for
#'   \code{ground_configuration} for more detail on the object.
#' @param utc_start vector of UTC (Universal Coordinated Time) dates in POSIX
#'   (Portable Operating System Interface) format when to start the thrust.
#'   If NA (default) then the thrust is automatically calculated using the
#'   duration_max, buffer_before, and buffer_end arguments. If not NA, then
#'   utc_end must also be supplied and these override duration_max.
#' @param utc_end vector of UTC (Universal Coordinated Time) dates in POSIX
#'   (Portable Operating System Interface) format when to end the scan.
#'   If NA (default) then the thrust is automatically calculated using the
#'   duration_max, buffer_before, and buffer_end arguments. If not NA, then
#'   utc_start must also be supplied and these override duration_max.
#' @param duration_max numeric length of the required thrust in seconds.
#'   The thrust activity will first be placed in the indices in eclipse that
#'   avoid existing activities, then it will be restricted to the required
#'   amount of time. This can be overridden by the utc_start and utc_end
#'   arguments.
#' @param buffer_before numeric length to stay in cruise before activity in
#'   seconds
#' @param buffer_after numeric length to stay in cruise before activity in
#'   seconds
#' @param activity_type character string activity type to describe the type of
#'.  thrusting. One of "SKM" (default) for "Station Keeping Maneuver", "ORM"
#'.  for "Orbit Raising Maneuver", or "CAM" for collision avoidance maneuver.
#' @param thrusters numeric vector of 0 or 1 (default c(1,1,0)) for on/off state
#'   of thrusters 1, 2, and 3.
#' @param qTARGETwrtREF a single quaternion with elements r, i1, i2, i3 that
#'   rotates the command frame with respect to the thrust frame of:
#'   1) body Z to primary reference velocity then
#'   2) body X to secondary reference nadir.
#'
#' @return a list, with elements activity_schedule,
#'   attitude_quaternion_eci and attitude_quaternion_ecef.
#'
#' @family activity functions
#' @export
ActivityThrust <- function(
    spacecraft_state,
    spacecraft_configuration,
    utc_start = NA,
    utc_end = NA,
    duration_max = 1080,
    buffer_before = 0,
    buffer_after = 0,
    activity_type = "SKM",
    thrusters = c(1,1,0),
    qTARGETwrtREF = c(1,0,0,0)
  ) {

  # If the start and end times of the scan were not supplied,
  # then find the longest contiguous unoccupied period in eclipse.
  if (is.na(utc_start) | is.na(utc_end)) {

    # The feasible period is the eclipse, minus blackouts for other activities
    feasible <- which(spacecraft_state$eclipse)
    feasible <- feasible[spacecraft_state$activity[feasible] == "Cruise"]

    # It must be continuous
    if (length(unique(diff(feasible))) > 1) {
      feasible_rle_df <- RleToDataFrame(rle_x = rle(diff(feasible)))
      sel <- which.max(feasible_rle_df$length)
      feasible <- feasible[feasible_rle_df$start[sel]:feasible_rle_df$end[sel]]
    }

    # If there are no feasible times, return NULL
    if (length(feasible) == 0) {
      return(NULL)
    }

    # Determine the attitude of the spacecraft
    attitude_quaternion_eci <-
      cbind(
        row = feasible,
        utc = spacecraft_state$utc[feasible],
        AttitudeFromXactCommand(
          qTARGETwrtREF = qTARGETwrtREF,
          primary_reference = spacecraft_state$vel_eci[feasible, ],
          secondary_reference = spacecraft_state$pos_eci[feasible, ],
          primary_command = c(0,0,1),
          secondary_command = c(1,0,0)
        )
      )

    # Find the activity slewed into
    attitude_quaternion_eci <-
      SlewIntoAttitude(
        spacecraft_state = spacecraft_state,
        spacecraft_configuration = spacecraft_configuration,
        attitude_quaternion_eci = attitude_quaternion_eci,
        buffer_before = buffer_before,
        buffer_after = buffer_after,
        verbose = FALSE
      )

    # The feasible indices are all the indices that are feasible,
    # So these are measured before filtering down to the max duration
    feasible <- attitude_quaternion_eci$row

    # Restrict down the the max duration. This is done after all of the other
    # restrictions to ensure that the activity maintins the full length.
    attitude_quaternion_eci <- attitude_quaternion_eci[1:duration_max, ]

  }

  # If the utc_start and utc_end times were supplied, then override feasible.
  if (!is.na(utc_start) & !is.na(utc_start)) {
    feasible <-
      which(
        spacecraft_state$utc >= utc_start &
        spacecraft_state$utc <= utc_end
      )

    # Determine the attitude of the spacecraft
    attitude_quaternion_eci <-
      AttitudeFromXactCommand(
        qTARGETwrtREF = qTARGETwrtREF,
        primary_reference = spacecraft_state$vel_eci[feasible, ],
        secondary_reference = spacecraft_state$pos_eci[feasible, ],
        primary_command = c(0,0,1),
        secondary_command = c(1,0,0)
      )
    attitude_quaternion_eci$row <- feasible
    attitude_quaternion_eci$utc <- spacecraft_state$utc[feasible]

  }

  # Depricated direct calculation
  # # z_hat points at the anti-velocity vector
  # z_hat_eci <- NormalizeByRow(spacecraft_state$vel_eci[feasible, ])
  #
  # # x_hat points as close as possible at the anti-nadir vector
  # y_hat_eci <-
  #   z_hat_eci %>%
  #   CrossProductByRow(spacecraft_state$pos_eci[feasible, ]) %>%
  #   NormalizeByRow()
  # x_hat_eci <-
  #   y_hat_eci %>%
  #   CrossProductByRow(z_hat_eci) %>%
  #   NormalizeByRow()
  #
  # # Convert to quaternions ECI
  # attitude_quaternion_eci <-
  #   data.frame(
  #     row = feasible,
  #     utc = spacecraft_state$utc[feasible],
  #     list(x_hat = x_hat_eci, y_hat = y_hat_eci, z_hat = z_hat_eci) %>%
  #     QuaternionsFromBasisVectors()
  #   )

  # Now, can we slew to and from to this activity?
  spacecraft_state_with_slew <-
    SpacecraftStateAddActivity(
      spacecraft_state = spacecraft_state,
      spacecraft_configuration = spacecraft_configuration,
      attitude_quaternion_eci = attitude_quaternion_eci,#_restricted,
      activity_schedule = NULL,
      verbose = FALSE
    )

  # Check Constraints
  if (
    any(spacecraft_state_with_slew$constraints$sun_violation) |
    any(spacecraft_state_with_slew$constraints$earth_violation) #|
    #any(spacecraft_state_with_slew$constraints$agility_violation)
  ) {
    warning("Thrust unfeasbible at this time/attitude")
    return(NULL)
  }

  # Write the activity schedule
  activity_schedule <-
    data.frame(
      utc = attitude_quaternion_eci$utc,
      activity = activity_type,
      TargX = 0,
      TargY = 0,
      TargZ = 0,
      PriRefDir = 7,
      SecRefDir = 6,
      PriCmdDir = 3,
      SecCmdDir = 1,
      AttInterp = "Quaternion",
      qTARGETwrtREF1 = qTARGETwrtREF[2],
      qTARGETwrtREF2 = qTARGETwrtREF[3],
      qTARGETwrtREF3 = qTARGETwrtREF[4],
      qTARGETwrtREF4 = qTARGETwrtREF[1],
      RateInterp = 1,
      CmdRateX = 0,
      CmdRateY = 0,
      CmdRateZ = 0,
      collectionID = "NA",
      frameRate = 0,
      window = "NA",
      LedDriveCurrent810nmCh4 = 0,
      LedDriveCurrent1550nmCh4 = 0,
      LedDriveCurrent810nmO2 = 0,
      LedDriveCurrent1550nmO2 = 0,
      stationName =  "NA",
      antennaID = "NA",
      xBand = FALSE,
      sBand = FALSE,
      thruster1 = thrusters[1],
      thruster2 = thrusters[2],
      thruster3 = thrusters[3],
      SPCount = 0,
      CCSDSBytes = 0,
      PEBtoHSDR = 0,
      DVBS2Bytes = 0,
      DownlinkTime = 0
    )

  # Return the output
  output <-
    list(
      feasible = feasible,
      attitude_quaternion_eci = attitude_quaternion_eci,
      activity_schedule = activity_schedule
    )

  return(output)

}

