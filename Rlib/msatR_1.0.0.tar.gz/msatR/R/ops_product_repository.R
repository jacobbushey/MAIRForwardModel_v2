# Ops product repository functions

# These are functions for generating file names for files on the MethaneSAT
# Operations Product Repository.

# Files on the Operations Product Repository (OPR) have a specific file naming
# convention that is defined in the MethaneSAT Mission Operations System to
# Missions Planning (MOS-MP) ICD. The file names have fields for the version,
# the year, and the day of year, possibly with an end day of year. Given a
# file name format, these scripts will find the latest version of the correct
# input file or generate a new version of an output file.

#' Find the latest version input files on the ops product repository
#'
#' Files on the Operations Product Repository (OPR) have a specific file naming
#' convention that is defined in the MethaneSAT Mission Operations System to
#' Missions Planning (MOS-MP) ICD. The file names have fields for the version,
#' the year, and the day of year, possibly with an end day of year. Given a
#' file name format, these scripts will find the latest version of the correct
#' input file
#'
#' @param path directory where the input file is held
#' @param pattern RegEx pattern to search for files. Example
#'  "Ephemeris_v\\d{2}_\\d{4}_\\d{3}_\\d{3}.oem".
#' @param digits Interpretation of each of the digits in "pattern".
#'  Must include "version", "year", and "doy_start".
#'  These are all standard digits in the MethaneSAT file naming conventions.
#' @param yyyy 4-digit numeric year for the start of the file
#' @param doy numeric day of the year for the start of the file
#'
#' @return character string file name
#'
#' @family ops product repository functions
#' @export
FindInputFile <-
  function(
    path,       # Directory to search for the files.
    pattern,    # RegEx pattern to search for files.
    # Example "Ephemeris_v\\d{2}_\\d{4}_\\d{3}_\\d{3}.oem"
    digits,     # Interpretation of each of the digits in "pattern".
    # Must include "version", "year", and "doy_start".
    # These are all standard digits in the MethaneSAT file naming
    # conventions.
    yyyy,       # 4-digit numeric year for the start of the file.
    doy         # numeric day of the year for the start of the file.
  ) {

    # List all of the files in the directory that match the pattern.
    all_files <- list.files(path, pattern)

    if (length(all_files) == 0) {
      return(NULL)
    }

    # For data that must be timely, the year and doy are used.
    # Narrow down to the latest version fo the file on the required date.
    if (!is.na(yyyy) & !is.na(doy)) {
      input_file <-
        # Extract digits from the file names.
        gsub("[^[:digit:]]+", "-", all_files) %>% strsplit("-") %>%
        # The previous line of code produces a list with NA values in element 1.
        # Convert this to a data.frame with the column names from the config file.
        # so that we can use dplyr to filter and arrange.
        unlist() %>% as.numeric() %>% na.omit() %>% as.vector() %>%
        matrix(nrow = length(all_files), byrow = TRUE) %>%
        as.data.frame() %>% "colnames<-"(digits) %>%
        # Attach the ephemeris file names for the final result.
        cbind(all_files) %>%
        # Filter to make sure that the start day is correct.
        dplyr::filter(year == yyyy, doy_start == doy) %>%
        # Select the latest version.
        dplyr::arrange(rev(version)) %>% "["(1,"all_files")
    }

    # For configuration type files, the year and doy are only a guide
    # to find the newest file. They are NA in the arguments.
    if (is.na(yyyy) & is.na(doy)) {
      input_file <-
        # Extract digits from the file names.
        gsub("[^[:digit:]]+", "-", all_files) %>% strsplit("-") %>%
        # The previous line of code produces a list with NA values in element 1.
        # Convert this to a data.frame with the column names from the config file.
        # so that we can use dplyr to filter and arrange.
        unlist() %>% as.numeric() %>% na.omit() %>% as.vector() %>%
        matrix(nrow = length(all_files), byrow = TRUE) %>%
        as.data.frame() %>% "colnames<-"(digits) %>%
        # Attach the ephemeris file names for the final result.
        cbind(all_files) %>%
        # Select the latest version.
        dplyr::arrange(rev(year), rev(doy), rev(version)) %>% "["(1,"all_files")
    }

    # Return the input file
    return(input_file)

  }

#' Generate a new version of output file on the ops product repository
#'
#' Files on the Operations Product Repository (OPR) have a specific file naming
#' convention that is defined in the MethaneSAT Mission Operations System to
#' Missions Planning (MOS-MP) ICD. The file names have fields for the version,
#' the year, and the day of year, possibly with an end day of year. Given a
#' file name format, these scripts will generate a new version of an output
#' file.
#'
#' @param path directory where the input file is held
#' @param pattern RegEx pattern to search for files. Example
#'  "Ephemeris_v\\d{2}_\\d{4}_\\d{3}_\\d{3}.oem".
#' @param digits Interpretation of each of the digits in "pattern".
#'  Must include "version", "year", and "doy_start".
#'  These are all standard digits in the MethaneSAT file naming conventions.
#' @param yyyy 4-digit numeric year for the start of the file
#' @param doy numeric day of the year for the start of the file
#'
#' @return character string file name
#'
#' @family ops product repository functions
#' @export

FindOutputFile <-
  function(
    path,       # Directory to search for the files.
    pattern,    # RegEx pattern to search for files.
    # Example "Ephemeris_v\\d{2}_\\d{4}_\\d{3}_\\d{3}.oem"
    digits,     # Interpretation of each of the digits in "pattern".
    # Must include "version", "year", and "doy_start".
    # These are all standard digits in the MethaneSAT file naming
    # conventions.
    yyyy,       # 4-digit numeric year for the start of the file.
    doy         # numeric day of the year for the start of the file.
  ) {

    # List all of the files in the directory that match the pattern.
    all_files <- list.files(path, pattern)

    # If there are no existing output files, generate one with version number 1
    if (length(all_files) == 0) {
      output_digits <- digits
      output_digits[output_digits == "version"] <- 1
      output_digits[output_digits == "year"] <- yyyy
      output_digits[output_digits == "doy_start"] <- doy
      output_digits[output_digits == "doy_end"] <- doy + 7
      # Convert the regex to a format string for sprintf
      pattern_fmt <-
        pattern %>%
        stringr::str_replace_all(stringr::fixed("\\d{"), "%0") %>%
        stringr::str_replace_all(stringr::fixed("}"), "d")
      # Generate the output file
      output_file <- do.call(sprintf, c(fmt = pattern_fmt, output_digits))
      return(output_file)
    }

    # Check to see if there are any files with the current date
    # Extract digits from the file names.
    num_files <-
      gsub("[^[:digit:]]+", "-", all_files) %>% strsplit("-") %>%
      # The previous line of code produces a list with NA values in element 1.
      # Convert this to a data.frame with the column names from the config file.
      # so that we can use dplyr to filter and arrange.
      unlist() %>% as.numeric() %>% na.omit() %>% as.vector() %>%
      matrix(nrow = length(all_files), byrow = TRUE) %>%
      as.data.frame() %>% "colnames<-"(digits) %>%
      # Filter to make sure that the start day is correct.
      dplyr::filter(year == yyyy, doy_start == doy) %>%
      nrow()

    if (num_files == 0) {
      output_digits <- digits
      output_digits[output_digits == "version"] <- 1
      output_digits[output_digits == "year"] <- yyyy
      output_digits[output_digits == "doy_start"] <- doy
      output_digits[output_digits == "doy_end"] <- doy + 7
      # Convert the regex to a format string for sprintf
      pattern_fmt <-
        pattern %>%
        stringr::str_replace_all(stringr::fixed("\\d{"), "%0") %>%
        stringr::str_replace_all(stringr::fixed("}"), "d")
      # Generate the output file
      output_file <- do.call(sprintf, c(fmt = pattern_fmt, output_digits))
      return(output_file)
    }

    # Get the digits to sub into the file
    output_digits <-
      # Extract digits from the file names.
      gsub("[^[:digit:]]+", "-", all_files) %>% strsplit("-") %>%
      # The previous line of code produces a list with NA values in element 1.
      # Convert this to a data.frame with the column names from the config file.
      # so that we can use dplyr to filter and arrange.
      unlist() %>% as.numeric() %>% na.omit() %>% as.vector() %>%
      matrix(nrow = length(all_files), byrow = TRUE) %>%
      as.data.frame() %>% "colnames<-"(digits) %>%
      # Filter to make sure that the start day is correct.
      dplyr::filter(year == yyyy, doy_start == doy) %>%
      # Select the latest version.
      dplyr::arrange(rev(version)) %>% "["(1,)

    # Increment the version
    output_digits$version <- output_digits$version + 1

    # Convert the regex to a format string for sprintf
    pattern_fmt <-
      pattern %>%
      stringr::str_replace_all(stringr::fixed("\\d{"), "%0") %>%
      stringr::str_replace_all(stringr::fixed("}"), "d")

    # Generate the output file
    output_file <- do.call(sprintf, c(fmt = pattern_fmt, output_digits))

    # Return the selected file
    return(output_file)

  }
