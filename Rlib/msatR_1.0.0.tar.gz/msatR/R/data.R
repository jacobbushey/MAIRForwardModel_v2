# Data products that can be loaded into then environment using msatR:::
# or can be used directly by the package.

# These include:
# - dem: A global digital elevation map
# - groundstation_antennas: The standard set of ground station antennas
# - groundstations: The standard set of ground stations
# - orbit_examples: Example orbits for the expected T9 and T10 launches
#   for use in target generation and analysis.
# - ground_configuration: standard spacecraft configuration for methanesat

# This file is a description of the data that is required by the package format.
# It also includes the code that is used to generate the data
# (all commented out).

#' Glint look-up table
#' A table of glint glint irradiance (sr-1) values as a function of wind speed
#' (m/s), relative azimuth angle (degrees), viewing zenith angle (degrees), and
#' solar zenith angle (degrees).
#' @format An array of dimension 20x90x15x15
#' @source Christopher Chan-Miller personal communication (from Cox-Munk 1950).
"glint_lut"

#' Orbit Examples
#' Typical orbits for finding the scan azimuth as a function of latitude.
#' Includes versions for transporter 8 and transporter 9 potential launches.
#' Spans latitudes on the sun-side only.
#' @format A list of 2 data.frames (Transporter_8 and Transporter_9),
#'   each with 2857 rows and 6 variables:
#' \describe{
#'   \item{pos_ecef}{data.frame of spacecraft location in meters ECEF}
#'   \item{vel_ecef}{data.frame of spacecraft velocity in meters/sec ECEF}
#'   \item{pos_geodetic}{data.frame of the spacecraft location in geodetic (lon, lat, and alt (m above WGS84 ellipsoid))}
#'   \item{boresight_center_ecef}{center of the array unit vector in ECEF}
#'   \item{boresight_left_ecef}{left side of the array unit vector in ECEF}
#'   \item{boresight_right_ecef}{right side of the array unit vector in ECEF}
#'  }
"orbit_examples"

# # Code to generate ground_configuration
# # Python Code to Run ephemeris - example with Transporter 10:
# # Dependencies
# import json
# import numpy as np
# import math
# from datetime import timedelta, date
# from dateutil import parser
# from sgp4.api import Satrec
# from decimal import *
#
# # User functions
# def daterange(date1, date2):
#   for n in range(int ((date2 - date1).days)+1):
#     yield date1 + timedelta(n)
#
# def convertTuple(tup):
#   str =  ', '.join(tup)
#   return str
#
# def juliandate(time):
#   if isinstance(time, (tuple, list)):
#     return list(map(juliandate, time))
#   if time.month < 3:
#     year = time.year - 1
#     month = time.month + 12
#   else:
#     year = time.year
#     month = time.month
#   A = int(year / 100.0)
#   B = 2 - A + int(A / 4.0)
#   C = ((time.second / 60.0 + time.minute) / 60.0 + time.hour) / 24.0
#   jd = int(365.25 * (year + 4716)) + int(30.6001 * (month + 1)) + time.day + B - 1524.5 + C
#   return jd
#
# # Determine start and end dates
# utc_start = parser.parse("2020-01-01T00:00:00.000Z")
# utc_end = parser.parse("2020-01-01T00:00:00.000Z")
#
# # Determine ephemeris at each date
# for utc in daterange(utc_start, utc_end):
#   print(utc)
#   # Satellite ephemeris using the sgp4 package
#   # Transporter_9
#   #satellite = Satrec.twoline2rv(
#   #  "1 88888U  20001A  20001.50000000  .00000000  00000-0  00000-0 0  9991",
#   #  "2 88888  97.5055 273.4960 0000000  00.0000  00.0000 15.1339254 1    2"
#   #)
#   # Transporter_10
#   satellite = Satrec.twoline2rv(
#     "1 88888U  20001A  20001.50000000  .00000000  00000-0  00000-0 0  9991",
#     "2 88888  97.5055  78.4960 0000000  00.0000  00.0000 15.1339254 1    1"
#   )
#   f = open(
#     "/tmp/MethaneSAT_PosVel_T10_" +
#     utc.strftime('%Y') +
#     "_" +
#     utc.strftime('%j') +
#     ".csv",
#     "w+")
#   f.write(
#     convertTuple(
#       (
#         "UTC",
#         "pos_eci_x",
#         "pos_eci_y",
#         "pos_eci_z",
#         "vel_eci_x",
#         "vel_eci_y",
#         "vel_eci_z"
#       )
#     )
#   )
#   f.write("\n")
#   for tick in range(0, 86400):
#     t = utc + timedelta(seconds = tick)
#     t_j = juliandate(utc + timedelta(seconds = tick))
#     jd = int(t_j)
#     fr = t_j - int(t_j)
#     e, r, v = satellite.sgp4(jd, fr)
#     f.write(
#       convertTuple(
#         (
#           t.strftime('%Y-%m-%dT%H:%M:%S.000Z'),
#           str(round(1000 * r[0], 2)),
#           str(round(1000 * r[1], 2)),
#           str(round(1000 * r[2], 2)),
#           str(round(1000 * v[0], 2)),
#           str(round(1000 * v[1], 2)),
#           str(round(1000 * v[2], 2))
#         )
#       )
#     )
#     f.write("\n")
#   f.close()
#
# # R Code to process the orbits
# orbit_examples <- list()
# orbit_example <- read.csv("/tmp/MethaneSAT_PosVel_T10_2020_001.csv")
# pos_eci <- data.frame(
#   x = orbit_example$pos_eci_x,
#   y = orbit_example$pos_eci_y,
#   z = orbit_example$pos_eci_z
# )
# vel_eci <- data.frame(
#   x = orbit_example$vel_eci_x,
#   y = orbit_example$vel_eci_y,
#   z = orbit_example$vel_eci_z
# )
# rev_number <-
#   RevNumber(
#     utc = orbit_example$UTC,
#     pos_eci = pos_eci,
#     vel_eci = vel_eci,
#     tle = ground_configuration$tle$transporter_10
#   )
# # Filter to the sun side of one rev
# rev_filter <-
#   rev_number$rev_ascending == unique(rev_number$rev_ascending)[7] &
#   vel_eci[, 3] < 0 # If it's an ascending orbit (i.e., T9), make this > 0
# orbit_example <- orbit_example[rev_filter, ]
# pos_eci <- pos_eci[rev_filter, ]
# vel_eci <- vel_eci[rev_filter, ]
# eop <- GetEopIERS(utc = lubridate::ymd_hms(orbit_example$UTC))
# orbit_examples$transporter_10 <-
#   data.frame(row = 1:nrow(pos_eci))
# orbit_examples$transporter_10$pos_ecef <-
#   EcefFromEci(pos_eci, eop = eop)
# orbit_examples$transporter_10$vel_ecef <-
#   EcefFromEci(vel_eci, eop = eop)
# orbit_examples$transporter_10$pos_geodetic <-
#   GeodeticFromEci(pos_eci, eop = eop)
# plot(
#   x = orbit_examples$transporter_10$pos_geodetic$lon,
#   y = orbit_examples$transporter_10$pos_geodetic$lat
# )
# # Find the orbit directions
# basis_vectors <-
#   LocalVerticalLocalHorizontal(
#     orbit_examples$transporter_10$pos_ecef,
#     orbit_examples$transporter_10$vel_ecef
#   )
# orbit_examples$transporter_10$boresight_center_ecef <- basis_vectors$z_hat
# orbit_examples$transporter_10$boresight_left_ecef <-
#   RotateVectorR3(
#     basis_vectors$z_hat,
#     basis_vectors$x_hat,
#     (ground_configuration$instrument$fov_deg - 1) * pi / 180 / 2
#   )
# orbit_examples$transporter_10$boresight_right_ecef <-
#   RotateVectorR3(
#     basis_vectors$z_hat,
#     basis_vectors$x_hat,
#     - (ground_configuration$instrument$fov_deg - 1) * pi / 180 / 2
#   )
# orbit_examples$transporter_10 <-
#   dplyr::select(
#     orbit_examples$transporter_10,
#     pos_ecef,
#     vel_ecef,
#     pos_geodetic,
#     boresight_center_ecef,
#     boresight_left_ecef,
#     boresight_right_ecef
#   )
#
# orbit_example <- read.csv("/tmp/MethaneSAT_PosVel_T9_2020_001.csv")
# pos_eci <- data.frame(
#   x = orbit_example$pos_eci_x,
#   y = orbit_example$pos_eci_y,
#   z = orbit_example$pos_eci_z
# )
# vel_eci <- data.frame(
#   x = orbit_example$vel_eci_x,
#   y = orbit_example$vel_eci_y,
#   z = orbit_example$vel_eci_z
# )
# rev_number <-
#   RevNumber(
#     utc = orbit_example$UTC,
#     pos_eci = pos_eci,
#     vel_eci = vel_eci,
#     tle = ground_configuration$tle$transporter_9
#   )
# # Filter to the sun side of one rev
# rev_filter <-
#   rev_number$rev_descending == unique(rev_number$rev_ascending)[7] &
#   vel_eci[, 3] > 0 # If it's an ascending orbit (i.e., T9), make this > 0
# orbit_example <- orbit_example[rev_filter, ]
# pos_eci <- pos_eci[rev_filter, ]
# vel_eci <- vel_eci[rev_filter, ]
# eop <- GetEopIERS(utc = lubridate::ymd_hms(orbit_example$UTC))
# orbit_examples$transporter_9 <-
#   data.frame(row = 1:nrow(pos_eci))
# orbit_examples$transporter_9$pos_ecef <-
#   EcefFromEci(pos_eci, eop = eop)
# orbit_examples$transporter_9$vel_ecef <-
#   EcefFromEci(vel_eci, eop = eop)
# orbit_examples$transporter_9$pos_geodetic <-
#   GeodeticFromEci(pos_eci, eop = eop)
# plot(
#   x = orbit_examples$transporter_9$pos_geodetic$lon,
#   y = orbit_examples$transporter_9$pos_geodetic$lat
# )
# # Find the orbit directions
# basis_vectors <-
#   LocalVerticalLocalHorizontal(
#     orbit_examples$transporter_9$pos_ecef,
#     orbit_examples$transporter_9$vel_ecef
#   )
# orbit_examples$transporter_9$boresight_center_ecef <- basis_vectors$z_hat
# orbit_examples$transporter_9$boresight_left_ecef <-
#   RotateVectorR3(
#     basis_vectors$z_hat,
#     basis_vectors$x_hat,
#     (ground_configuration$instrument$fov_deg - 1) * pi / 180 / 2
#   )
# orbit_examples$transporter_9$boresight_right_ecef <-
#   RotateVectorR3(
#     basis_vectors$z_hat,
#     basis_vectors$x_hat,
#     - (ground_configuration$instrument$fov_deg - 1) * pi / 180 / 2
#   )
# orbit_examples$transporter_9 <-
#   dplyr::select(
#     orbit_examples$transporter_9,
#     pos_ecef,
#     vel_ecef,
#     pos_geodetic,
#     boresight_center_ecef,
#     boresight_left_ecef,
#     boresight_right_ecef
#   )
# save(orbit_examples, file = "./data/orbit_examples.rda")

#' Ground Configuration
#' The ground configuration stored as package data. This data is stored in a
#' json file that is shared on the MethaneSAT Ops Product Repository.
#' It contains information about the ground stations, the location of bus
#' components, thermal and agility constraints, scanning parameters, instrument
#' parameters, data management parameters, and downlink parameters.
#' @format A list of 5 elements: bus, constraints, scan, and downlink
#' \describe{
#'   \item{filename}{Character string of ground configuration file name}
#'   \item{groundstation_antennas}{list of 21, the number of ground stations.
#'   Each item contains a list of 6:
#'     id (KSAT antenna id code),
#'     name (Station name),
#'     dishsize (Size of dish in meters),
#'     band (Downlink bands),
#'     geodetic (data.frame of geodetic coordinates (lon, lat, and alt ( in mabove WGS84)),
#'     ecef (data.frame of Earth-Centered Earth-Fixed coordinates)
#'   }
#'   \item{groundstations}{
#'     name (Station name),
#'     geodetic (data.frame of geodetic coordinates (lon, lat, and alt ( in mabove WGS84)),
#'     ecef (data.frame of Earth-Centered Earth-Fixed coordinates)
#'   }
#'   \item{bus}{list of 6:
#'     instrument (instrument boresight vector in body frame),
#'     thruster (thruster vector in body frame),
#'     solarpanel_driveaxis (solar panel drive axis in body frame - the solar panel is always normal to this),
#'     radiator (radiator normal in body frame),
#'     reubensplane (Reuben's plane (plane unprotected by the radiator shield) normal in body frame),
#'     xband_antenna (X-Band antenna vector in body frame)
#'  }
#'  \item{constraints}{list of 8:
#'    angular_velocity_max_degps (length-3 vector of maximum bus angular velocity in degrees per second),
#'    angular_acceleration_max_degps2 (length-3 vector of maximum bus angular acceleration in degrees per squared second),
#'    sun_to_instrument_deg (minimum sun to instrument angle in degrees),
#'    sun_to_radiator_deg (minimum sun to radiator angle in degrees),
#'    sun_to_reubensplane_deg (minimum sun to Reuben's plane angle in degrees),
#'    earth_to_radiator_deg (minimum Earth to radiator angle in degrees),
#'    earth_to_reubensplane_deg (minimum Earth to Reuben's plane angle in degrees),
#'    angle_buffer_deg (minimum sun to instrument angle in degrees)
#'  }
#'  \item{scanning}{list of 12:
#'    settle_s (time to settle at scan attitude before scan in seconds),
#'    standard_scan_s (standard time to scan in seconds),
#'    buffer_s (buffer time to extend scan before and after targets to prevent corner clips in seconds),
#'    framerate_1_hz (standard frame rate in Hz),
#'    framerate_2_hz (enhanced scan frame rate in Hz),
#'    sza_max_deg (maximum allowed solar zenith angle in degrees),
#'    pitch_max_deg (maximum allowed pitch angle in degrees),
#'    roll_max_deg (maximum allowed roll angle in degrees),
#'    stereo (maximum number of stereo collections per target),
#'    aggregate_alongtrack (number of pixels to aggregate along-track),
#'    aggregate_acrosstrack (number of pixels to aggregate across-track),
#'    optimization_interval_s (interval over which to optimize target selection on seconds)
#'  }
#'  \item{instrument}{list of 6:
#'    fov_deg (camera angular field of view in degrees),
#'    f_number (camera f number),
#'    focal_length_mm (focal length of the camera in mm),
#'    optical_efficiency (instrument optical efficiency),
#'    quantum_efficiency (instrument quantum efficiency),
#'    dispersion (instrument optical dispersion)
#'  }
#'  \item{data_management}{list of 7:
#'    image,
#'    superpages,
#'    ccsds segments,
#'    tm_space_packets,
#'    tm_transfer_frames,
#'    dvb_s2_packets,
#'    hsdr_storage
#'  }
#'}
"ground_configuration"

# # Code to generate ground_configuration
# ground_configuration <- ReadGroundConfiguration("./data/GroundConfiguration_v01_2023_001.json")
# save(ground_configuration, file = "./data/ground_configuration.rda")

# Save all in sysdata.rda
# save(
#   dem,
#   glint_lut,
#   orbit_examples,
#   ground_configuration,
#   file = "./R/sysdata.rda"
#   )

