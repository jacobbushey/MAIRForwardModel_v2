# Convert Coordinate Functions

# These functions facilitate the conversion of position, velocity, and attitude
# between coordinate systems:
# - Geocentric: longitude, latitude, meters above the spherical Earth
# - Geodetic: longitude, latitude, meters above the WGS84 ellipsoid
# - Earth-Centered-Earth_Fixed (ECEF)
# - Earth-Centered-Inertial (ECI)
# - Right Ascension and Declination

# The conversion between Earth-Fixed coordinates (geocentric, geodetic, ECEF)
# and Inertial (ECI, Right Ascension and Declination) require the calculation
# of Precession, Nutation, Earth Rotation, and Polar Motion, which uses
# Earth Orientation Parameters that are downloaded from IERS (preferred) or
# Celestrak.

# Earth Orientation Parameters -----------------------------------------------

#' Download and process Earth Orientation Parameters (EOP) from IERS
#'
#' The International Earth Rotation and Reference Systems Service (IERS)
#' Earth Orientation Parameters (EOP) are text files containing data required
#' to calculate precession, nutation, rotation, and polar motion for
#' converting between the Earth-Centered-Inertial and
#' Earth-Centered-Earth-Fixed reference frames. The files are downloaded from
#' the IERS server at
#' https://datacenter.iers.org/products/eop/rapid/standard/finals2000A.data
#' There are two versions of the data in these files,
#' bulletin A and bulletin B.
#' Bulletin A includes additional predicted values, beyond what should
#' be used for planning MethaneSAT. We therefore prefer bulletin B and it is
#' default.
#'
#' versions of the files. The "short" file gives data one year back in time and
#' projects forward 84 days. The "long" file gives data back to 1962-01-20 and
#' projects forward 84 days. In this function, a local EOP file can be
#' specified, or the appropriate file is downloaded from the JPL server.
#'
#' @param utc vector of UTC (Universal Coordinated Time) dates in
#'   POSIX (Portable Operating System Interface) format
#' @param output_dir directory to save Earth orientation parameters
#'   (default /tmp/)
#' @param bulletin character, either "A" for IERS bulletin A (default) or
#'   "B" for IERS bulletin B (default)
#' @param iers_file optional local IERS file. If NULL (default), then the file
#'   will be downloaded.
#' @param leap_seconds_file optional local IERS file. If NULL (default), then the file
#'   will be downloaded.
#'
#' @return a list of two data.frames of Earth Orientation Parameters:
#'   | Column | Description |
#'   | --- | --- |
#'   | utc | UTC dates in POSIX format |
#'   | mjd | Modified Julian Date: days since 1 January 4713 BCE - 2400000.5 |
#'   | x_pole | X component of polar motion (arc-seconds) |
#'   | y_pole | Y component of polar motion (arc-seconds) |
#'   | UT1_UTC | Universal Time 1 minus UTC (seconds) |
#'   | TAI_UTC | International Atomic Time minus UTC (seconds) |
#'
#'  Where UTC is Universal Coordinated Time, POSIX is Portable Operating
#'  System Interface
#'
#' @examples
#' GetEopIERS(lubridate::ymd_hms("2022-01-01 00:00:00"), bulletin = "A")
#'
#' @family convert coordinates function
#' @export
GetEopIERS <- function(
    utc,
    output_dir = "/tmp/",
    bulletin = "B",
    iers_file = NULL,
    leap_seconds_file = NULL
) {

  # Arc-seconds to radians
  k_arcs  <- 3600 * 180 / pi

  if (is.null(iers_file)) {

    iers_file <- "https://datacenter.iers.org/data/csv/finals.data.csv"

    # Download the raw file
    utils::download.file(
      url = iers_file,
      destfile = paste0(output_dir, "/", basename(iers_file))
    )

  }

  if (is.null(leap_seconds_file)) {

    leap_seconds_file <-
      "https://www.ietf.org/timezones/data/leap-seconds.list"

    # Download the raw file
    utils::download.file(
      url = leap_seconds_file,
      destfile = paste0(output_dir, "/", basename(leap_seconds_file))
    )
  }

  # Read the IERS file.
  eop <-
    utils::read.csv(
      file = paste0(output_dir, "/", basename(iers_file)),
      sep = ";"
    )

  # Read the leap seconds file.
  leap_seconds_scan <-
    scan(
      file = paste0(output_dir, "/", basename(leap_seconds_file)),
      what = "character",
      sep = "\n"
    )
  leap_seconds_data_lines <-
    leap_seconds_scan %>%
    substr(1, 1) %>%
    stringr::str_detect("[1234567890]")
  leap_seconds <-
    data.frame(
    utc =
      leap_seconds_scan[leap_seconds_data_lines] %>%
      substr(17, 26) %>%
      lubridate::dmy(),
    TAI_UTC =
      leap_seconds_scan[leap_seconds_data_lines] %>%
      substr(12, 13) %>%
      as.numeric()
    )
  leap_seconds$mjd <- ModifiedJulianFromUtc(leap_seconds$utc)

  # Add leap seconds to eop
  eop$TAI_UTC <- rep(9, nrow(eop))
  for (leap_second.tick in 1:nrow(leap_seconds)) {
    eop$TAI_UTC[eop$MJD >= leap_seconds$mjd[leap_second.tick]] <-
      leap_seconds$TAI_UTC[leap_second.tick]
  }

  # Convert the utc time to mjd
  mjd <- ModifiedJulianFromUtc(utc)

  ## A data.frame of interpolated EOP
  ## This block uses the spline interpolation for
  ## x_pole, y_pole, UT1_UTC, and TAI_UTC. This is tecchnically more accurate,
  ## has been commented out since most other implementations simply ingests
  ## values.
  #if (bulletin == "A") {
  #  eop_interpolated <- data.frame(
  #    utc     = utc,
  #    mjd     = mjd,
  #    x_pole  = stats::splinefun(x = eop$MJD, y = eop$x_pole / k_arcs)(mjd),
  #    y_pole  = stats::splinefun(x = eop$MJD, y = eop$y_pole / k_arcs)(mjd),
  #    UT1_UTC = stats::splinefun(x = eop$MJD, y = eop$UT1.UTC)(mjd),
  #    TAI_UTC = stats::splinefun(x = eop$MJD, y = eop$TAI_UTC)(mjd)
  #  )
  #} else if (bulletin == "B") {
  #  eop_interpolated <- data.frame(
  #    utc     = utc,
  #    mjd     = mjd,
  #    x_pole  = stats::splinefun(
  #               x = eop$MJD,
  #               y = eop$bulB.x_pole / k_arcs)(mjd),
  #    y_pole  = stats::splinefun(
  #               x = eop$MJD,
  #               y = eop$bulB.y_pole / k_arcs)(mjd),
  #    UT1_UTC = stats::splinefun(x = eop$MJD, y = eop$bulB.UT.UTC)(mjd),
  #    TAI_UTC = stats::splinefun(x = eop$MJD, y = eop$TAI_UTC)(mjd)
  #  )
  #}

  # A data.frame of interpolated EOP
  # This implementation is a constant interpolation
  if (bulletin == "A") {
    eop_interpolated <- data.frame(
      utc     = utc,
      mjd     = mjd,
      x_pole  =
        stats::approx(
          x = eop$MJD,
          y = eop$x_pole / k_arcs,
          xout = mjd,
          method = "constant"
        )$y,
      y_pole  =
        stats::approx(
          x = eop$MJD,
          y = eop$y_pole / k_arcs,
          xout = mjd,
          method = "constant"
        )$y,
      UT1_UTC =
        stats::approx(
          x = eop$MJD,
          y = eop$UT1.UTC,
          xout = mjd,
          method = "constant"
        )$y,
      TAI_UTC =
        stats::approx(
          x = eop$MJD,
          y = eop$TAI_UTC,
          xout = mjd,
          method = "constant"
        )$y
    )
  } else if (bulletin == "B") {
    eop_interpolated <- data.frame(
      utc     = utc,
      mjd     = mjd,
      x_pole  =
        stats::approx(
          x = eop$MJD,
          y = eop$bulB.x_pole / k_arcs,
          xout = mjd,
          method = "constant"
        )$y,
      y_pole  =
        stats::approx(
          x = eop$MJD,
          y = eop$bulB.y_pole / k_arcs,
          xout = mjd,
          method = "constant"
        )$y,
      UT1_UTC =
        stats::approx(
          x = eop$MJD,
          y = eop$bulB.UT.UTC,
          xout = mjd,
          method = "constant"
        )$y,
      TAI_UTC =
        stats::approx(
          x = eop$MJD,
          y = eop$TAI_UTC,
          xout = mjd,
          method = "constant"
        )$y
    )
  }

  return(eop_interpolated)

}

#' Download and process Earth Orientation Parameters (EOP) from Celestrak
#'
#' @param utc vector of UTC (Universal Coordinated Time) dates in
#'   POSIX (Portable Operating System Interface) format
#' @param output_dir directory to save Earth orientation parameters
#'   (default /tmp/)
#' @param celestrak_file optional local Celestrak File. If NULL (default),
#'   then the file will be downloaded.
#'
#' @return data.frame of Earth Orientation Parameters:
#'   | Column | Description |
#'   | --- | --- |
#'   | utc | UTC dates in POSIX format |
#'   | mjd | Modified Julian Date: days since 1 January 4713 BCE - 2400000.5 |
#'   | x_pole | X component of polar motion (arc-seconds) |
#'   | y_pole | Y component of polar motion (arc-seconds) |
#'   | UT1_UTC | Universal Time 1 minus UTC (seconds) |
#'   | TAI_UTC | International Atomic Time minus UTC (seconds) |
#'
#'  Where UTC is Universal Coordinated Time, POSIX is Portable Operating
#'  System Interface
#'
#' @examples
#' GetEopCelestrak(lubridate::ymd_hms("2022-01-01 00:00:00"))
#'
#' @family convert coordinates function
#' @export
GetEopCelestrak <- function(
    utc,
    output_dir = "/tmp/",
    celestrak_file = NULL
) {

  # Arc-seconds to radians
  k_arcs  <- 3600 * 180 / pi

  if (is.null(celestrak_file)) {

    # Select the appropriate file. The "Last5Years.txt" file
    if (min(lubridate::year(utc)) < (lubridate::year(Sys.time()) - 5)) {
      celestrak_file = "https://celestrak.com/SpaceData/EOP-All.txt"
    } else {
      celestrak_file = "https://celestrak.com/SpaceData/EOP-Last5Years.txt"
    }

    # Download the raw Celestrak file
    utils::download.file(
      url = celestrak_file,
      destfile = paste0(output_dir, "/", basename(celestrak_file))
    )

  }

  # Read the raw Celestrak file.
  eop_scan <- scan(
    file = paste0(output_dir, "/", basename(celestrak_file)),
    skip = 34,
    what = "character",
    sep  = "\n"
  )

  # Some metadata is written directly into the file. This code filters it out
  # by selecting lines that start with a 4-digit year.
  data_lines <-
    eop_scan %>%
    substr(1, 4) %>%
    stringr::str_detect("[1234567890]")
  eop_scan <- eop_scan[data_lines]

  # Convert to a data.frame
  eop  <-
    eop_scan %>%
    strsplit("\\s+") %>%
    unlist() %>%
    as.numeric() %>%
    matrix(ncol = 13, byrow = TRUE) %>%
    data.frame(stringsAsFactors = FALSE) %>%
    'colnames<-'(
      c("year", "month", "mday", "mjd", "x", "y", "UT1_UTC", "LOD", "dPsi",
        "dEpsilon", "dX", "dY", "TAI_UTC")
    )

  # Convert the utc time to mjd
  mjd <- ModifiedJulianFromUtc(utc)

  ## A data.frame of interpolated EOP
  #eop_interpolated <- data.frame(
  #  utc     = utc,
  #  mjd     = mjd,
  #  x_pole  = stats::splinefun(x = eop$mjd, y = eop$x / k_arcs)(mjd),
  #  y_pole  = stats::splinefun(x = eop$mjd, y = eop$y / k_arcs)(mjd),
  #  UT1_UTC = stats::splinefun(x = eop$mjd, y = eop$UT1_UTC)(mjd),
  #  TAI_UTC = stats::splinefun(x = eop$mjd, y = eop$TAI_UTC)(mjd)
  #)

  # A data.frame of interpolated EOP
  # This implementation is a constant interpolation
  eop_interpolated <- data.frame(
    utc     = utc,
    mjd     = mjd,
    x_pole  =
      stats::approx(
        x = eop$mjd,
        y = eop$x / k_arcs,
        xout = mjd,
        method = "constant"
      )$y,
    y_pole  =
      stats::approx(
        x = eop$mjd,
        y = eop$y / k_arcs,
        xout = mjd,
        method = "constant"
      )$y,
    UT1_UTC =
      stats::approx(
        x = eop$mjd,
        y = eop$UT1_UTC,
        xout = mjd,
        method = "constant"
      )$y,
    TAI_UTC =
      stats::approx(
        x = eop$mjd,
        y = eop$TAI_UTC,
        xout = mjd,
        method = "constant"
      )$y
  )

  return(eop_interpolated)

}

# Earth Orientation Model ----------------------------------------------------

#' Generate time transformations used in geodesy functions
#'
#' @param ut1_utc numeric vector of UT1 (Universal Time 1) minus
#'   UTC (Coordinated Universal Time) in seconds
#' @param tai_utc numeric vector of TAI (International Atomic Time) minus
#'   UTC (Coordinated Universal Time) in seconds
#'
#' @return data frame of time differences needed for converting
#'   Earth-Centered Inertial to Earth-Centered Earth-Fixed coordinates.
#'   | Column | Description |
#'   | --- | --- |
#'   | ut1_tai | Universal Time 1 minus International Atomic Time (seconds) |
#'   | utc_gps | UTC minus GPS (seconds) |
#'   | ut1_gps | Universal Time 1 minus GPS Time (seconds) |
#'   | tt_utc | Terrestrial Time minus UTC (seconds) |
#'   | gps_utc | GPS Time minus UTC (seconds) |
#'
#'  Where UTC is Universal Coordinated Time, POSIX is Portable Operating
#'  System Interface, GPS is Global Positioning System
#'
#' @examples
#' TimeConversions(1,1)
#'
#' @keywords internal
#' @family convert coordinates function
#' @export
TimeConversions <- function(ut1_utc, tai_utc) {

  # Calculate time objects
  tt_tai  <- 32.184
  gps_tai <- -19.0
  tt_gps  <-  tt_tai - gps_tai
  tai_gps <- -gps_tai
  ut1_tai <- ut1_utc - tai_utc
  utc_tai <- -tai_utc
  utc_gps <- utc_tai - gps_tai
  ut1_gps <- ut1_tai - gps_tai
  tt_utc  <- tt_tai - utc_tai
  gps_utc <- gps_tai - utc_tai

  # Return the data frame of the time objects that are used
  time_conversions <-
    data.frame(
      ut1_tai = ut1_tai,
      utc_gps = utc_gps,
      ut1_gps = ut1_gps,
      tt_utc  = tt_utc,
      gps_utc = gps_utc
    )

  return(time_conversions)

}

#' Calculate the precession matrix
#'
#' @param mjd_ref numeric reference time as modified Julian dates
#'   (days since 1 January 4713 BCE - 2400000.5, default: 51544.5 for J2000)
#' @param mjd_tt numeric vector of Terrestrial Time as modified Julian dates
#'   (days since 1 January 4713 BCE - 2400000.5)
#'
#' @return list of rotation matrices
#'
#' @examples
#' PrecessionMatrix(c(0,1))
#'
#' @keywords internal
#' @family convert coordinates function
#' @export
PrecessionMatrix <- function(
    mjd_tt,
    mjd_ref = 51544.5
) {

  # Constants
  k_arcs      <- 3600 * 180 / pi  # arc seconds per radian
  k_mjd_ref <- 51544.5            # Modified Julian Date of J2000

  # Time parameters
  t1 <- (mjd_ref  - k_mjd_ref) / 36525
  dt <- (mjd_tt  - mjd_ref) / 36525

  # Precession angles
  zeta <- ((2306.2181 + (1.39656 - 0.000139 * t1) * t1) +
             ((0.30188-0.000344 * t1) + 0.017998 * dt) * dt) * dt / k_arcs
  z <- zeta + ((0.79280 + 0.000411 * T) + 0.000205 * dt) * dt * dt / k_arcs
  theta <- ((2004.3109 - (0.85330 + 0.000217 * t1) * t1) -
              ((0.42665 + 0.000217 * t1) + 0.041833 * dt) * dt) * dt / k_arcs

  # Precession matrix
  if (length(mjd_tt) > 1) {
    precession_matrix <-
      R_z(-z) %>%
      MultiplyMatrixLists(R_y(theta)) %>%
      MultiplyMatrixLists(R_z(-zeta)) %>%
      lapply("t")
  }
  if (length(mjd_tt) == 1) {
    precession_matrix <-
      R_z(-z) %*% R_y(theta) %*% R_z(-zeta) %>% t()
  }

  return(precession_matrix)

}

#' Calculate mean obliquity
#'
#' @param mjd numeric vector of modified Julian dates
#'   (days since 1 January 4713 BCE - 2400000.5)
#'
#' @return numeric vector of mean obliquity in radians
#'
#' @examples
#' MeanObliquity(46848)
#'
#' MeanObliquity(c(46848, 46849))
#'
#' @keywords internal
#' @family convert coordinates function
#' @export
MeanObliquity <- function(mjd) {

  # Time relative to J2000
  t_j     = (mjd - 51544.5) / 36525

  # Calculate Mean Obliquity
  mean_obliquity <-
    (pi/90) *
    (23.43929111 - (46.8150 + (0.00059 - 0.001813 * t_j) * t_j) * t_j / 3600)

  return(mean_obliquity)

}

#' Calculate nutation angles
#'
#' @param mjd numeric vector of modified Julian dates
#'   (days since 1 January 4713 BCE - 2400000.5)
#'
#' @return data.frame with columns:
#'   | Column | Description |
#'   | --- | --- |
#'   | dpsi | Nutation in longitude (arc-seconds) |
#'   | deps | Nutation in obliquity (arc-seconds) |
#'
#' @examples
#' NutationAngles(46848)
#'
#' NutationAngles(c(46848, 46849))
#'
#' @keywords internal
#' @family convert coordinates function
#' @export
NutationAngles <- function(mjd) {

  # Constants
  k_arcs <- 3600 * 180 / pi          # arcseconds per radian
  t_j2000 <- (mjd - 51544.5) / 36525 # J2000 modified julian time
  rev <- 360 * 3600                  # arcsec per revolution

  # Nutation coefficients
  nut_coefficients <- rbind(
    #   l  l' F  D Om    dpsi    *T     deps     *T
    c(  0, 0, 0, 0, 1,-1719960,-1742,  920250,   89),    #   1
    c(  0, 0, 0, 0, 2,   20620,    2,   -8950,    5),    #   2
    c( -2, 0, 2, 0, 1,     460,    0,    -240,    0),    #   3
    c(  2, 0,-2, 0, 0,     110,    0,       0,    0),    #   4
    c( -2, 0, 2, 0, 2,     -30,    0,      10,    0),    #   5
    c(  1,-1, 0,-1, 0,     -30,    0,       0,    0),    #   6
    c(  0,-2, 2,-2, 1,     -20,    0,      10,    0),    #   7
    c(  2, 0,-2, 0, 1,      10,    0,       0,    0),    #   8
    c(  0, 0, 2,-2, 2, -131870,  -16,   57360,  -31),    #   9
    c(  0, 1, 0, 0, 0,   14260,  -34,     540,   -1),    #  10
    c(  0, 1, 2,-2, 2,   -5170,   12,    2240,   -6),    #  11
    c(  0,-1, 2,-2, 2,    2170,   -5,    -950,    3),    #  12
    c(  0, 0, 2,-2, 1,    1290,    1,    -700,    0),    #  13
    c(  2, 0, 0,-2, 0,     480,    0,      10,    0),    #  14
    c(  0, 0, 2,-2, 0,    -220,    0,       0,    0),    #  15
    c(  0, 2, 0, 0, 0,     170,   -1,       0,    0),    #  16
    c(  0, 1, 0, 0, 1,    -150,    0,      90,    0),    #  17
    c(  0, 2, 2,-2, 2,    -160,    1,      70,    0),    #  18
    c(  0,-1, 0, 0, 1,    -120,    0,      60,    0),    #  19
    c( -2, 0, 0, 2, 1,     -60,    0,      30,    0),    #  20
    c(  0,-1, 2,-2, 1,     -50,    0,      30,    0),    #  21
    c(  2, 0, 0,-2, 1,      40,    0,     -20,    0),    #  22
    c(  0, 1, 2,-2, 1,      40,    0,     -20,    0),    #  23
    c(  1, 0, 0,-1, 0,     -40,    0,       0,    0),    #  24
    c(  2, 1, 0,-2, 0,      10,    0,       0,    0),    #  25
    c(  0, 0,-2, 2, 1,      10,    0,       0,    0),    #  26
    c(  0, 1,-2, 2, 0,     -10,    0,       0,    0),    #  27
    c(  0, 1, 0, 0, 2,      10,    0,       0,    0),    #  28
    c( -1, 0, 0, 1, 1,      10,    0,       0,    0),    #  29
    c(  0, 1, 2,-2, 0,     -10,    0,       0,    0),    #  30
    c(  0, 0, 2, 0, 2,  -22740,   -2,    9770,   -5),    #  31
    c(  1, 0, 0, 0, 0,    7120,    1,     -70,    0),    #  32
    c(  0, 0, 2, 0, 1,   -3860,   -4,    2000,    0),    #  33
    c(  1, 0, 2, 0, 2,   -3010,    0,    1290,   -1),    #  34
    c(  1, 0, 0,-2, 0,   -1580,    0,     -10,    0),    #  35
    c( -1, 0, 2, 0, 2,    1230,    0,    -530,    0),    #  36
    c(  0, 0, 0, 2, 0,     630,    0,     -20,    0),    #  37
    c(  1, 0, 0, 0, 1,     630,    1,    -330,    0),    #  38
    c( -1, 0, 0, 0, 1,    -580,   -1,     320,    0),    #  39
    c( -1, 0, 2, 2, 2,    -590,    0,     260,    0),    #  40
    c(  1, 0, 2, 0, 1,    -510,    0,     270,    0),    #  41
    c(  0, 0, 2, 2, 2,    -380,    0,     160,    0),    #  42
    c(  2, 0, 0, 0, 0,     290,    0,     -10,    0),    #  43
    c(  1, 0, 2,-2, 2,     290,    0,    -120,    0),    #  44
    c(  2, 0, 2, 0, 2,    -310,    0,     130,    0),    #  45
    c(  0, 0, 2, 0, 0,     260,    0,     -10,    0),    #  46
    c( -1, 0, 2, 0, 1,     210,    0,    -100,    0),    #  47
    c( -1, 0, 0, 2, 1,     160,    0,     -80,    0),    #  48
    c(  1, 0, 0,-2, 1,    -130,    0,      70,    0),    #  49
    c( -1, 0, 2, 2, 1,    -100,    0,      50,    0),    #  50
    c(  1, 1, 0,-2, 0,     -70,    0,       0,    0),    #  51
    c(  0, 1, 2, 0, 2,      70,    0,     -30,    0),    #  52
    c(  0,-1, 2, 0, 2,     -70,    0,      30,    0),    #  53
    c(  1, 0, 2, 2, 2,     -80,    0,      30,    0),    #  54
    c(  1, 0, 0, 2, 0,      60,    0,       0,    0),    #  55
    c(  2, 0, 2,-2, 2,      60,    0,     -30,    0),    #  56
    c(  0, 0, 0, 2, 1,     -60,    0,      30,    0),    #  57
    c(  0, 0, 2, 2, 1,     -70,    0,      30,    0),    #  58
    c(  1, 0, 2,-2, 1,      60,    0,     -30,    0),    #  59
    c(  0, 0, 0,-2, 1,     -50,    0,      30,    0),    #  60
    c(  1,-1, 0, 0, 0,      50,    0,       0,    0),    #  61
    c(  2, 0, 2, 0, 1,     -50,    0,      30,    0),    #  62
    c(  0, 1, 0,-2, 0,     -40,    0,       0,    0),    #  63
    c(  1, 0,-2, 0, 0,      40,    0,       0,    0),    #  64
    c(  0, 0, 0, 1, 0,     -40,    0,       0,    0),    #  65
    c(  1, 1, 0, 0, 0,     -30,    0,       0,    0),    #  66
    c(  1, 0, 2, 0, 0,      30,    0,       0,    0),    #  67
    c(  1,-1, 2, 0, 2,     -30,    0,      10,    0),    #  68
    c( -1,-1, 2, 2, 2,     -30,    0,      10,    0),    #  69
    c( -2, 0, 0, 0, 1,     -20,    0,      10,    0),    #  70
    c(  3, 0, 2, 0, 2,     -30,    0,      10,    0),    #  71
    c(  0,-1, 2, 2, 2,     -30,    0,      10,    0),    #  72
    c(  1, 1, 2, 0, 2,      20,    0,     -10,    0),    #  73
    c( -1, 0, 2,-2, 1,     -20,    0,      10,    0),    #  74
    c(  2, 0, 0, 0, 1,      20,    0,     -10,    0),    #  75
    c(  1, 0, 0, 0, 2,     -20,    0,      10,    0),    #  76
    c(  3, 0, 0, 0, 0,      20,    0,       0,    0),    #  77
    c(  0, 0, 2, 1, 2,      20,    0,     -10,    0),    #  78
    c( -1, 0, 0, 0, 2,      10,    0,     -10,    0),    #  79
    c(  1, 0, 0,-4, 0,     -10,    0,       0,    0),    #  80
    c( -2, 0, 2, 2, 2,      10,    0,     -10,    0),    #  81
    c( -1, 0, 2, 4, 2,     -20,    0,      10,    0),    #  82
    c(  2, 0, 0,-4, 0,     -10,    0,       0,    0),    #  83
    c(  1, 1, 2,-2, 2,      10,    0,     -10,    0),    #  84
    c(  1, 0, 2, 2, 1,     -10,    0,      10,    0),    #  85
    c( -2, 0, 2, 4, 2,     -10,    0,      10,    0),    #  86
    c( -1, 0, 4, 0, 2,      10,    0,       0,    0),    #  87
    c(  1,-1, 0,-2, 0,      10,    0,       0,    0),    #  88
    c(  2, 0, 2,-2, 1,      10,    0,     -10,    0),    #  89
    c(  2, 0, 2, 2, 2,     -10,    0,       0,    0),    #  90
    c(  1, 0, 0, 2, 1,     -10,    0,       0,    0),    #  91
    c(  0, 0, 4,-2, 2,      10,    0,       0,    0),    #  92
    c(  3, 0, 2,-2, 2,      10,    0,       0,    0),    #  93
    c(  1, 0, 2,-2, 0,     -10,    0,       0,    0),    #  94
    c(  0, 1, 2, 0, 1,      10,    0,       0,    0),    #  95
    c( -1,-1, 0, 2, 1,      10,    0,       0,    0),    #  96
    c(  0, 0,-2, 0, 1,     -10,    0,       0,    0),    #  97
    c(  0, 0, 2,-1, 2,     -10,    0,       0,    0),    #  98
    c(  0, 1, 0, 2, 0,     -10,    0,       0,    0),    #  99
    c(  1, 0,-2,-2, 0,     -10,    0,       0,    0),    # 100
    c(  0,-1, 2, 0, 1,     -10,    0,       0,    0),    # 101
    c(  1, 1, 0,-2, 1,     -10,    0,       0,    0),    # 102
    c(  1, 0,-2, 2, 0,     -10,    0,       0,    0),    # 103
    c(  2, 0, 0, 2, 0,      10,    0,       0,    0),    # 104
    c(  0, 0, 2, 4, 2,     -10,    0,       0,    0),    # 105
    c(  0, 1, 0, 1, 0,      10,    0,       0,    0)     # 106
  )

  # Mean arguments of luni-solar motion
  #   l   mean anomaly of the Moon
  l  = (485866.733 +
          (1325.0 * rev +  715922.633) * t_j2000 +
          31.310 * t_j2000^2 + 0.064 * t_j2000^3) %% rev
  #   l'  mean anomaly of the Sun
  lp = (1287099.804 +
          (99.0 * rev + 1292581.224) * t_j2000 -
          0.577 * t_j2000^2 - 0.012 * t_j2000^3) %% rev
  #   F   mean argument of latitude
  f  = (335778.877 +
          (1342.0 * rev +  295263.137) * t_j2000 -
          13.257 * t_j2000^2 + 0.011 * t_j2000^3) %% rev
  #   D   mean longitude elongation of the Moon from the Sun
  D  = (1072261.307 +
          (1236.0 * rev + 1105601.328) * t_j2000 -
          6.891 * t_j2000^2 + 0.019 * t_j2000^3) %% rev
  #   Om  mean longitude of the ascending node
  Om = (450160.280 -
          (5.0 * rev +  482890.539) * t_j2000 +
          7.455 * t_j2000^2 + 0.008 * t_j2000^3) %% rev

  # Nutation in longitude and obliquity [rad]
  nutation_angles <- stapply(1:length(mjd), function(x) {
    arg <- (nut_coefficients[,1] * l[x]   +
              nut_coefficients[,2] * lp[x]  +
              nut_coefficients[,3] * f[x]   +
              nut_coefficients[,4] * D[x]   +
              nut_coefficients[,5] * Om[x]  ) / k_arcs
    dpsi <- 1e-5 * sum((nut_coefficients[,6] +
              nut_coefficients[,7] * t_j2000[x]) * sin(arg)) / k_arcs
    deps <- 1e-5 * sum((nut_coefficients[,8] +
              nut_coefficients[,9] * t_j2000[x]) * cos(arg)) / k_arcs
    return(c(dpsi = dpsi, deps = deps))
  }) %>% as.data.frame()

  return(nutation_angles)

}

#' Calculate nutation matrix
#'
#' @param mjd numeric vector of modified Julian dates
#'   (days since 1 January 4713 BCE - 2400000.5)
#'
#' @return list of rotation matrices
#'
#' @examples
#' NutationMatrix(46848)
#'
#' NutationMatrix(c(46848, 46849))
#'
#' @keywords internal
#' @family convert coordinates function
#' @export
NutationMatrix <- function(mjd) {

  # Mean obliquity of the ecliptic
  ep  <-  MeanObliquity(mjd)

  # Nutation in longitude and obliquity
  nutangles_data <- NutationAngles(mjd)

  # Nutation matrix
  if (length(mjd) > 1) {
    nutation_matrix <-
      R_x(-ep - nutangles_data$deps) %>%
      MultiplyMatrixLists(R_z(-nutangles_data$dpsi)) %>%
      MultiplyMatrixLists(R_x(ep)) %>%
      lapply("t")
  }
  if (length(mjd) == 1) {
    nutation_matrix <-
      R_x(-ep - nutangles_data$deps) %*%
      R_z(-nutangles_data$dpsi) %*%
      R_x(ep) %>%
      t()
  }

  return(nutation_matrix)

}

#' Calculate GMST (Greenwich Mean Sidereal Time)
#'
#' @param mjd numeric vector of modified Julian dates
#'   (days since 1 January 4713 BCE - 2400000.5)
#'
#' @return numeric vector of GMST (Greenwich Mean Sidereal Time) in radians
#'
#' @examples
#' GMST(46848)
#'
#' GMST(c(46848, 46849))
#'
#' @keywords internal
#' @family convert coordinates function
#' @export
GMST <- function(mjd) {

  mjd_0    <- floor(mjd)
  ut1      <- 86400 * (mjd - mjd_0)       # [s]
  t0_j2000 <- (mjd_0 - 51544.5) / 36525
  t_j2000  <- (mjd   - 51544.5) / 36525
  gmst     <- 24110.54841 +
    8640184.812866 * t0_j2000 +
    1.002737909350795 * ut1 +
    (0.093104-6.2e-6*t_j2000) * t_j2000 * t_j2000  # [s]
  gmst_rad <- 2 * pi * (gmst/86400 - floor(gmst/86400)) # [rad]

  return(gmst_rad)

}

#' Calculate the equation of the equinox
#'
#' @param mjd a numeric vector of modified Julian dates
#'   (days since 1 January 4713 BCE - 2400000.5)
#'
#' @return numeric vector of the equation of equinox
#'
#' @examples
#' EquationOfEquinox(46848)
#'
#' EquationOfEquinox(c(46848, 46849))
#'
#' @keywords internal
#' @family convert coordinates function
#' @export
EquationOfEquinox <- function(mjd) {

  eqnequinox <- NutationAngles(mjd)$dpsi * cos(MeanObliquity(mjd))

  return(eqnequinox)

}

#' Calculate GAST (Greenwich Apparent Sidereal Time)
#'
#' @param mjd numeric vector of modified Julian dates
#'   (days since 1 January 4713 BCE - 2400000.5)
#'
#' @return numeric vector of GAST (Greenwich Apparent Sidereal Time) in radians
#'
#' @examples
#' GAST(46848)
#'
#' GAST(c(46848, 46849))
#'
#' @keywords internal
#' @family convert coordinates function
#' @export
GAST <- function(mjd) {

  # Calculate gast
  gast <- (GMST(mjd) + EquationOfEquinox(mjd)) %% (2 * pi)

  return(gast)

}

#' Calculate the GHA (Greenwich hour angle) matrix
#'
#' @param mjd numeric vector of modified Julian dates
#'   (days since 1 January 4713 BCE - 2400000.5)
#'
#' @return list of GHA (Greenwich hour angle) matrices
#'
#' @examples
#' GHAMatrix(46848)
#'
#' GHAMatrix(c(46848, 46849))
#'
#' @keywords internal
#' @family convert coordinates function
#' @export
GHAMatrix <- function(mjd) {

  if (length(mjd) > 1) {
    gha <-
      mjd %>%
      GAST() %>%
      R_z() %>%
      lapply("t")
  }
  if (length(mjd) == 1) {
    gha <- mjd %>% GAST() %>% R_z() %>% t()
  }

  return(gha)

}

#' Calculate the Polar Motion matrix
#'
#' @param xp numeric vector of x component of polar motion (arc-seconds)
#' @param yp numeric vector of y component of polar motion (arc-seconds)
#'
#' @return list of rotation matrices
#'
#' @examples
#' PoleMatrix(xp = 2.645822e-07, yp = 1.342851e-06)
#'
#' PoleMatrix(
#'   xp = c(2.645822e-07, 2.645822e-07),
#'   yp = c(1.342851e-06, 1.342851e-06)
#' )
#'
#' @keywords internal
#' @family convert coordinates function
#' @export
PoleMatrix <- function(xp, yp) {

  if (length(xp) > 1) {
    polematrix <-
      R_y(-xp) %>%
      MultiplyMatrixLists(R_x(-yp)) %>%
      lapply("t")
  }
  if (length(xp) == 1) {
    polematrix <- R_y(-xp) %*% R_x(-yp) %>% t()
  }

  return(polematrix)

}

# Coordinate Transformations -------------------------------------------------

#' Transform geodetic coordinates to Earth-Centered Earth-Fixed
#'
#' @param geodetic a data.frame with columns:
#'   | Column | Description |
#'   | --- | --- |
#'   | lon | Longitude |
#'   | lat | Latitude |
#'   | alt | Altitude in m above WGS84 ellipsoid |
#' @param a semimajor axis in meters (default 6378137.0m for WGS84 ellipsoid)
#' @param b semiminor axis in meters (default 6356752.3m for WGS84 ellipsoid)
#'
#' @return data.frame of meters Earth-Centered Earth-Fixed
#'
#' @examples
#' # ECEF coordinates of Null Island
#' geodetic <-
#'   data.frame(
#'   lon = 0,
#'   lat = 0,
#'   alt = 0
#'   )
#'
#' EcefFromGeodetic(geodetic)
#'
#' @family convert coordinate functions
#' @export
EcefFromGeodetic <- function(
  geodetic,
  a = 6378137.0,
  b = 6356752.3
) {

  # Convert longitude and latitude to radians.
  lonrad <- pi * geodetic$lon / 180
  latrad <- pi * geodetic$lat / 180

  # Radius of curvature of the prime vertical section.
  N <- a^2 / sqrt(a^2 * cos(latrad)^2 + b^2 * sin(latrad)^2)

  # Return ECEF coordinates
  ecef <-
    data.frame(
      x = (N + geodetic$alt) * cos(latrad) * cos(lonrad),
      y = (N + geodetic$alt) * cos(latrad) * sin(lonrad),
      z = (N * (b / a)^2 + geodetic$alt) * sin(latrad)
    )

  return(ecef)

}

#' Transform Earth-Centered Earth-Fixed coordinates to
#' geocentric coordinates on the sphere
#'
#' @param ecef vector, matrix, or data.frame with 3 columns of the
#'   position in meters Earth-Centered Earth-Fixed
#' @param r radius of the sphere in meters. Defaults to the mean radius
#'   of the Earth (6371009 m).
#'
#' @return a data.frame of lon, lat, and alt above the sphere in meters
#'
#' @examples
#' # Geocentric coordinates of Null Island
#' GeocentricFromEcef(ecef = c(6372000, 0, 0))
#'
#' @family convert coordinate functions
#' @export
GeocentricFromEcef <- function(
  ecef,
  r = 6371000
) {

  # Coerce to matrix
  if (is.vector(ecef)) {
    ecef <- matrix(nrow = 1, ncol = 3, data = ecef)
  }

  # Return geocentric coordinates
  geocentric <-
    data.frame(
      lon = atan2(ecef[,2], ecef[,1]) * (180 / pi),
      lat = atan2(ecef[,3], sqrt(ecef[,1]^2 + ecef[,2]^2)) * (180/pi),
      alt = sqrt(ecef[,1]^2 + ecef[,2]^2 + ecef[,3]^2) - r
    )

  return(geocentric)

}

#' Transform Earth-Centered Earth-Fixed coordinates to geodetic coordinates
#'
#' @param ecef a vector, matrix, or data.frame with 3 columns of the
#'   position in meters Earth-Centered Earth-Fixed
#' @param a semimajor axis in meters (default 6378137.0m for WGS84 ellipsoid)
#' @param b semiminor axis in meters (default 6356752.3m for WGS84 ellipsoid)
#'
#' @return a data.frame with columns:
#'   | Column | Description |
#'   | --- | --- |
#'   | lon | Longitude |
#'   | lat | Latitude |
#'   | alt | Altitude in m above WGS84 ellipsoid |
#'
#' @examples
#' # Geodetic coordinates of Null Island
#' GeodeticFromEcef(ecef = c(6378137, 0, 0))
#'
#' @family convert coordinate functions
#' @export
GeodeticFromEcef <- function(
  ecef,
  a = 6378137.0,
  b = 6356752.3
) {

  # Coerce to matrix
  if (is.vector(ecef)) {
    ecef <- matrix(nrow = 1, ncol = 3, data = ecef)
  }

  # Length of ecef vector.
  r               <- NormByRow(ecef)

  # Distance from the center to the focus of the ellipsoid (along the pole)
  E               <- sqrt(a^2 - b^2)

  # Discriminant of the quadratic
  u               <- sqrt(0.5 * (r^2 - E^2) +
                          0.5 * sqrt((r^2 - E^2)^2 + 4 * E^2 * ecef[,3]^2))

  # Distance from the pole
  Q               <- sqrt(ecef[,1]^2 + ecef[,2]^2)

  # Hypotenuse from the focus to the point
  huE             <- sqrt(u^2 + E^2)

  # Attenuation of the hypotenuse due to eccentricity
  Beta            <- rep(NA, nrow(ecef))
  Betaflag1       <- (u != 0) & (sqrt(ecef[, 1]^2 + ecef[, 2]^2) != 0)
  Beta[Betaflag1] <- atan((huE / u) *
                          (ecef[, 3] / sqrt(ecef[, 1]^2 + ecef[, 2]^2)))
  Betaflag2       <- !Betaflag1 & ecef[, 3] >= 0
  Beta[Betaflag2] <- pi / 2
  Betaflag3       <- !Betaflag1 & !Betaflag2
  Beta[Betaflag3] <- - pi / 2
  eps             <- ((b * u - a * huE + E^2) * sin(Beta)) /
                     (a * huE * 1 / cos(Beta) - E^2 * cos(Beta))
  Beta            <- Beta + eps

  # Geodetic lon and lat
  lon             <- atan2(ecef[,2], ecef[,1])
  lat             <- atan(a / b * tan(Beta))

  # Altitude above ellipsoid
  alt             <- sqrt((ecef[,3] - b * sin(Beta))^2 + (Q - a * cos(Beta))^2)

  # A correction for if the point is inside the ellipsoid
  inside          <- (ecef[,1]^2 / a^2 +
                      ecef[,2]^2 / a^2 +
                      ecef[,3]^2 / b^2) < 1
  alt[inside]     <- -alt[inside]

  # Return result
  geodetic <- data.frame(
    lon = 180 * lon / pi,
    lat = 180 * lat / pi,
    alt = alt
  )
  rownames(geodetic) <- NULL

  return(geodetic)

}

#' Calculate rotation matrices that transform vectors from
#' Earth-Centered Inertial to Earth-Centered Earth-Fixed
#'
#' @param eop Earth orientation parameters - a data.frame containing at least:
#'   | Column | Description |
#'   | --- | --- |
#'   | utc | POSIX of UTC |
#'   | x_pole | X component of polar motion (arc-seconds) |
#'   | y_pole | Y component of polar motion (arc-seconds) |
#'   | UT1_UTC | Universal Time 1 minus UTC (seconds) |
#'   | TAI_UTC | International Atomic Time minus UTC (seconds) |
#'
#'  Where UTC is Universal Coordinated Time, POSIX is Portable Operating
#'  System Interface
#'
#' @return list of rotation matrices such that ecef = eci2ecef_mat %*% eci
#'
#' @examples
#' utc <- "2000-01-01 00:00:00"
#' eop <- GetEopCelestrak(utc = utc)
#' ecef2eci_mat <- RotationMatrices_EcefFromEci(eop = eop)
#'
#' utc <- c("2000-01-01 00:00:00", "2000-01-02 00:00:00")
#' eop <- GetEopCelestrak(utc = utc)
#' ecef2eci_mat <- RotationMatrices_EcefFromEci(eop = eop)
#'
#' @family convert coordinate functions
#' @export
RotationMatrices_EcefFromEci <- function(eop) {

  # Constants
  mjd_j2000 <- 51544.5  # Modified Julian Date of J2000

  # Convert the utc time to a modified julian date
  mjd           <- ModifiedJulianFromUtc(eop$utc)
  timediff_data <- TimeConversions(eop$UT1_UTC,eop$TAI_UTC)
  mjd_ut1       <- mjd + eop$UT1_UTC/ 86400
  mjd_tt        <- mjd + timediff_data$tt_utc / 86400

  # Component matrices of the transformation
  P     <- PrecessionMatrix(mjd_tt, mjd_j2000)    # IAU 1976 Precession
  N     <- NutationMatrix(mjd_tt)                 # IAU 1980 Nutation
  Theta <- GHAMatrix(mjd_ut1)                     # Earth rotation
  Pi    <- PoleMatrix(eop$x_pole,eop$y_pole)      # Polar motion

  # Return the componenets multiplied as a list
  if (nrow(eop) == 1) {
    eci2ecef_mat <- Pi %*% Theta %*% N %*% P
  }
  if (nrow(eop) > 1) {
    eci2ecef_mat <-
      Pi %>%
      MultiplyMatrixLists(Theta) %>%
      MultiplyMatrixLists(N) %>%
      MultiplyMatrixLists(P)
  }

  return(eci2ecef_mat)

}

#' Calculate rotation matrices that transform vectors from
#' Earth-Centered Earth-Fixed to Earth-Centered Inertial
#'
#' @param eop Earth orientation parameters - a data.frame containing at least:
#'   | Column | Description |
#'   | --- | --- |
#'   | utc | POSIX of UTC |
#'   | x_pole | X component of polar motion (arc-seconds) |
#'   | y_pole | Y component of polar motion (arc-seconds) |
#'   | UT1_UTC | Universal Time 1 minus UTC (seconds) |
#'   | TAI_UTC | International Atomic Time minus UTC (seconds) |
#'
#'  Where UTC is Universal Coordinated Time, POSIX is Portable Operating
#'  System Interface
#'
#' @return A list of rotation matrices such that eci = eci2ecef_mat %*% ecef
#'
#' @examples
#' utc <- "2000-01-01 00:00:00"
#' eop <- GetEopCelestrak(utc = utc)
#' eci2ecef_mat <- RotationMatrices_EciFromEcef(eop = eop)
#'
#' utc <- c("2000-01-01 00:00:00", "2000-01-02 00:00:00")
#' eop <- GetEopCelestrak(utc = utc)
#' eci2ecef_mat <- RotationMatrices_EciFromEcef(eop = eop)
#'
#' @family convert coordinate functions
#' @export
RotationMatrices_EciFromEcef <- function(eop) {

  # Retreive eci2eccef matrices
  eci2ecef_mat <- RotationMatrices_EcefFromEci(eop)

  # Transpose to get ecef2eci matrices
  if (nrow(eop) == 1) {
    ecef2eci_mat <- t(eci2ecef_mat)
  }
  if (nrow(eop) > 1) {
    ecef2eci_mat <- lapply(eci2ecef_mat, "t")
  }

  return(ecef2eci_mat)

}

#' Transform Earth-Centered Inertial coordinates to Earth-Centered Earth-Fixed
#'
#' \code{EcefFromEci} transforms coordinates in Earth-Centered Inertial to
#' Earth-Centered Earth-Fixed. It can compute the transformation matrices on its
#' own, or it can take in pre-computed transformation matrices. If you are
#' transforming many objects at many times, consider pre-computing the
#' transformation matrices with \code{RotationMatrices_EcefFromEci}.
#'
#' @param eci vector, matrix, or data.frame with 3 columns of the
#'   position in meters Earth-Centered Inertial
#' @param eop optional data.frame of Earth orientation parameters
#'   containing at least:
#'   | Column | Description |
#'   | --- | --- |
#'   | utc | POSIX of UTC |
#'   | x_pole | X component of polar motion (arc-seconds) |
#'   | y_pole | Y component of polar motion (arc-seconds) |
#'   | UT1_UTC | Universal Time 1 minus UTC (seconds) |
#'   | TAI_UTC | International Atomic Time minus UTC (seconds) |
#'
#'  Where UTC is Universal Coordinated Time, POSIX is Portable Operating
#'  System Interface
#'
#' @param ecef_from_eci_matrices an optional transformation matrix from
#'   Earth-Centered Inertial to Earth-Centered Earth-Fixed
#' @param q_ei quaternion transforming ECEF (Earth-Centered Earth-Fixed) to
#'   ECI (Earth-Centered Inertial)
#'
#' @return a data.frame of vectors in Earth-Centered Earth-Fixed
#'
#' @examples
#' eci <- data.frame(
#'   x = c(6378137, 0),
#'   y = c(0, 6378137),
#'   z = c(0, 0)
#' )
#' utc <- c("2000-01-01 00:00:00", "2000-01-02 00:00:00")
#' eop <- GetEopCelestrak(utc = utc)
#' EcefFromEci(eci = eci, eop = eop)
#'
#' # Pre-computed transformations
#' ecef_from_eci_matrices <- RotationMatrices_EcefFromEci(eop)
#' EcefFromEci(eci = eci, ecef_from_eci_matrices = ecef_from_eci_matrices)
#'
#' @family convert coordinate functions
#' @export
EcefFromEci <- function(
  eci,
  eop = NULL,
  ecef_from_eci_matrices = NULL,
  q_ei = NULL
) {

  # Coerce to matrix
  if (is.vector(eci)) {
    eci <- matrix(nrow = 1, ncol = 3, data = eci)
  }
  if (is.data.frame(eci)) {
    eci <- as.matrix(eci)
  }

  if (!is.null(eop)) {
    # Retrieve ecef_from_eci_matrices matrices
    ecef_from_eci_matrices <-
      RotationMatrices_EcefFromEci(eop)
  } else if (!is.null(q_ei)) {
    ecef_from_eci_matrices <-
      q_ei %>%
      QuaternionInvert() %>%
      RotationMatricesFromQuaternions()
  } else if (is.null(ecef_from_eci_matrices) & is.null(q_ei)) {
    stop("Either ecef_from_eci_matrices, q_ei or eop must be supplied")
  }

  # Transformation from ICRS to WGS
  if (nrow(eci) == 1) {
    ecef <- ecef_from_eci_matrices %*% as.vector(eci) %>% t()
  }
  if (nrow(eci) > 1) {
  ecef <-
    stapply(
      1:length(ecef_from_eci_matrices),
      function(x) {
        ecef_from_eci_matrices[[x]] %*% eci[x,]
      }
    )
  }

  # Coerce to data.frame
  ecef <-
    data.frame(
      x = ecef[, 1],
      y = ecef[, 2],
      z = ecef[, 3]
    )

  return(ecef)

}

#' Transform Earth-Centered Earth-Fixed coordinates to Earth-Centered Inertial
#'
#' \code{EciFromEcef} transforms coordinates in Earth-Centered Earth-Fixed to
#' Earth-Centered Inertial. It can compute the transformation matrices on its
#' own, or it can take in pre-computed transformation matrices. If you are
#' transforming many objects at many times, consider pre-computing the
#' transformation matrices with \code{RotationMatrices_EciFromEcef}.
#'
#' @param ecef A vector, matrix, or data.frame with 3 columns of the
#'   position in meters Earth-Centered Earth-Fixed
#' @param eop an optional data.frame of Earth orientation parameters
#'   containing at least:
#'   | Column | Description |
#'   | --- | --- |
#'   | utc | POSIX of UTC |
#'   | x_pole | X component of polar motion (arc-seconds) |
#'   | y_pole | Y component of polar motion (arc-seconds) |
#'   | UT1_UTC | Universal Time 1 minus UTC (seconds) |
#'   | TAI_UTC | International Atomic Time minus UTC (seconds) |
#'
#'  Where UTC is Universal Coordinated Time, POSIX is Portable Operating
#'  System Interface
#
#' @param eci_from_ecef_matrices an optional transformation matrix
#' @param q_ei quaternion transforming ECEF (Earth-Centered Earth-Fixed) to
#'   ECI (Earth-Centered Inertial)
#'
#' @return A matrix of vectors in Earth-Centered Inertial
#'
#' @examples
#' ecef <- data.frame(
#'   x = c(6378137, 0),
#'   y = c(0, 6378137),
#'   z = c(0, 0)
#' )
#' utc <- c("2000-01-01 00:00:00", "2000-01-02 00:00:00")
#' eop <- GetEopCelestrak(utc = utc)
#' EciFromEcef(ecef = ecef, eop = eop)
#'
#' # Pre-computed transformations
#' eci_from_ecef_matrices <- RotationMatrices_EciFromEcef(eop)
#' EciFromEcef(ecef = ecef, eci_from_ecef_matrices = eci_from_ecef_matrices)
#'
#' @family convert coordinate functions
#' @export
EciFromEcef <- function(
    ecef,
    eop = NULL,
    eci_from_ecef_matrices = NULL,
    q_ei = NULL
) {

  # Coerce to matrix
  if (is.vector(ecef)) {
    ecef <- matrix(nrow = 1, ncol = 3, data = ecef)
  }
  if (is.data.frame(ecef)) {
    ecef <- as.matrix(ecef)
  }

  if (!is.null(eop)) {
    # Retrieve eci_from_ecef_matrices matrices
    eci_from_ecef_matrices <-
      RotationMatrices_EciFromEcef(eop)
  } else if (!is.null(q_ei)) {
    eci_from_ecef_matrices <-
      q_ei %>%
      RotationMatricesFromQuaternions()
  } else if (is.null(eci_from_ecef_matrices) & is.null(q_ei)) {
    stop("Either ecef_from_eci_matrices, q_ei or eop must be supplied")
  }

  # Transformation from ICRS to WGS
  if (nrow(ecef) == 1) {
    eci <- eci_from_ecef_matrices %*% as.vector(ecef) %>% t()
  }
  if (nrow(ecef) > 1) {
    eci <-
      stapply(
        1:length(eci_from_ecef_matrices),
        function(x) {
          eci_from_ecef_matrices[[x]] %*% ecef[x,]
        }
      )
  }

  # Coerce to data.frame
  eci <-
    data.frame(
      x = eci[, 1],
      y = eci[, 2],
      z = eci[, 3]
    )

  return(eci)

}


#' Transform Earth-Centered Inertial coordinates to Geodetic
#'
#' \code{GeodeticFromEci} transforms coordinates in Earth-Centered Inertial to
#' Geodetic. It can compute the transformation matrices on its
#' own, or it can take in pre-computed transformation matrices. If you are
#' transforming many objects at many times, consider pre-computing the
#' transformation matrices with \code{RotationMatrices_EcefFromEci}.
#'
#' @param eci A vector, matrix, or data.frame with 3 columns of the
#'   position in meters Earth-Centered Inertial
#' @param eop an optional data.frame of Earth orientation parameters
#'   containing at least:
#'   | Column | Description |
#'   | --- | --- |
#'   | utc | POSIX of UTC |
#'   | x_pole | X component of polar motion (arc-seconds) |
#'   | y_pole | Y component of polar motion (arc-seconds) |
#'   | UT1_UTC | Universal Time 1 minus UTC (seconds) |
#'   | TAI_UTC | International Atomic Time minus UTC (seconds) |
#'
#'  Where UTC is Universal Coordinated Time, POSIX is Portable Operating
#'  System Interface
#'
#' @param ecef_from_eci_matrices an optional transformation matrix
#'
#' @return A data.frame with columns:
#'   | Column | Description |
#'   | --- | --- |
#'   | lon | Longitude |
#'   | lat | Latitude |
#'   | alt | Altitude in m above WGS84 ellipsoid |
#'
#' @examples
#' eci <- data.frame(
#'   x = c(6378137, 0),
#'   y = c(0, 6378137),
#'   z = c(0, 0)
#' )
#' utc <- c("2000-01-01 00:00:00", "2000-01-02 00:00:00")
#' eop <- GetEopCelestrak(utc = utc)
#' GeodeticFromEci(eci = eci, eop = eop)
#'
#' # Pre-computed transformations
#' ecef_from_eci_matrices <- RotationMatrices_EcefFromEci(eop)
#' GeodeticFromEci(eci = eci, ecef_from_eci_matrices = ecef_from_eci_matrices)
#'
#' @family convert coordinate functions
#' @export
GeodeticFromEci <- function(
    eci,
    eop = NULL,
    ecef_from_eci_matrices = NULL
) {

  # Compute ECEF
  ecef <-
    EcefFromEci(
      eci = eci,
      eop = eop,
      ecef_from_eci_matrices = ecef_from_eci_matrices
    )
  geodetic <- GeodeticFromEcef(ecef)

  # Compute Geodetic
  return(geodetic)

}

#' Transform Geodetic coordinates to Earth-Centered Inertial
#'
#' \code{EciFromGeodetic} transforms coordinates in Geodetic to
#' Earth-Centered Inertial. It can compute the transformation matrices on its
#' own, or it can take in pre-computed transformation matrices. If you are
#' transforming many objects at many times, consider pre-computing the
#' transformation matrices with \code{RotationMatrices_EcefFromEci}.
#'
#' @param geodetic a data.frame with columns lon (longitude in degrees),
#'   lat (latitude in degrees), and alt
#'   (altitude in meters above WGS84 Ellipsoid).
#' @param eop an optional data.frame of Earth orientation parameters
#'   containing at least:
#'   | Column | Description |
#'   | --- | --- |
#'   | utc | POSIX of UTC |
#'   | x_pole | X component of polar motion (arc-seconds) |
#'   | y_pole | Y component of polar motion (arc-seconds) |
#'   | UT1_UTC | Universal Time 1 minus UTC (seconds) |
#'   | TAI_UTC | International Atomic Time minus UTC (seconds) |
#'
#'  Where UTC is Universal Coordinated Time, POSIX is Portable Operating
#'  System Interface
#'
#' @param eci_from_ecef_matrices an optional transformation matrix
#' @param a semimajor axis in meters (default 6378137.0m for WGS84 ellipsoid)
#' @param b semiminor axis in meters (default 6356752.3m for WGS84 ellipsoid)
#'
#' @return A matrix of vectors in Earth-Centered Inertial
#'
#' @examples
#' geodetic <-
#'   data.frame(
#'     lon = c(0, 45),
#'     lat = c(0, 45),
#'     alt = c(0, 0)
#'   )
#' utc <- c("2000-01-01 00:00:00", "2000-01-02 00:00:00")
#' eop <- GetEopCelestrak(utc = utc)
#' EciFromGeodetic(
#'   geodetic = geodetic,
#'   eop = eop
#'  )
#'
#' # Pre-computed transformations
#' eci_from_ecef_matrices <- RotationMatrices_EciFromEcef(eop)
#' geodetic <-
#'   data.frame(
#'     lon = c(0, 45),
#'     lat = c(0, 45),
#'     alt = c(0, 0)
#'   )
#' EciFromGeodetic(
#'   geodetic = geodetic,
#'   eci_from_ecef_matrices = eci_from_ecef_matrices
#'  )
#'
#' @family convert coordinate functions
#' @export
EciFromGeodetic <- function(
    geodetic,
    eop = NULL,
    eci_from_ecef_matrices = NULL,
    a = 6378137.0,
    b = 6356752.3
) {

  # Compute ECEF
  ecef <- EcefFromGeodetic(geodetic)

  # Compute Eci
  eci <- EciFromEcef(
    ecef = ecef,
    eop = eop,
    eci_from_ecef_matrices = eci_from_ecef_matrices
  )

  return(eci)

}

#' Rotate a quaternion to ECI from ECEF using q_ei (saved in spacecraft state)
#'
#' @param q_ecef vector, matrix, or data frame with
#'   4 columns of the attitude as quaternions in ECEF with 4 columns
#'   r, i1, i2, i3
#' @param q_ei Quaternion rotation from ECI to ECEF
#'
#' @return a data.frame of the quaternions resulting from the rotation of
#'   q_ecef to ECI with columns r, i1, i2, i3
#'
#' @family quaternion functions
#' @export
QuaternionEciFromEcef <- function(q_ecef, q_ei) {

  # Rotate to ECI
  attitude_quaternion_eci <-
    QuaternionMultiply(
      q_ecef,
      q_ei
    )

  return(attitude_quaternion_eci)

}

#' Rotate a quaternion to ECEF from ECI using q_ei (saved in spacecraft state)
#'
#' @param q_eci vector, matrix, or data frame with
#'   4 columns of the attitude as quaternions in ECI with 4 columns
#'   r, i1, i2, i3
#' @param q_ei Quaternion rotation from ECI to ECEF
#'
#' @return a data.frame of the quaternions resulting from the rotation of
#'   q_eci to ECEF with columns r, i1, i2, i3
#'
#' @family quaternion functions
#' @export
QuaternionEcefFromEci <- function(q_eci, q_ei) {

  # Rotate to ECEF
  attitude_quaternion_ecef <-
    QuaternionMultiply(
      q_eci,
      QuaternionInvert(q_ei)
    )

  return(attitude_quaternion_ecef)

}

#' Transform right ascension, declination, and distance to Earth-centered
#' inertial
#'
#' \code{EciFromRightAscensionDeclination} transforms coordinates in
#' Earth-Centered Inertial to Geodetic. It can compute the transformation matrices on its
#' own, or it can take in pre-computed transformation matrices. If you are
#' transforming many objects at many times, consider pre-computing the
#' transformation matrices with \code{RotationMatrices_EcefFromEci}.
#'
#' @param right_ascension_declination a data.frame with elements
#'   | Column | Description |
#'   | --- | --- |
#'   | right_ascension | angle east from the vernal equinox (radians) |
#'   | declination | angle north of the celestial equator (radians) |
#'   | distance | distance from the center of the Earth to the point (meters) |
#'
#' @return A matrix of vectors in Earth-Centered Inertial
#'
#' @family convert coordinate functions
#' @export
EciFromRightAscensionDeclination <- function(
    right_ascension_declination
) {

  eci <-
    data.frame(
      x = right_ascension_declination[, 3] *
        cos(right_ascension_declination[, 1]),
      y = right_ascension_declination[, 3] *
        sin(right_ascension_declination[, 1]),
      z = right_ascension_declination[, 3] *
        sin(right_ascension_declination[, 2])
    )

  return(eci)

}

#' Transform Earth-centered inertial to right ascension, declination, and
#' distance
#'
#' \code{EciFromRightAscensionDeclination} transforms coordinates in
#' Earth-Centered Inertial to right ascension, declination, and distance.
#'
#' @param eci vector, matrix, or data.frame with 3 columns of the
#'   position in meters Earth-Centered Inertial
#'
#' @return A data.frame with elements
#'   | Column | Description |
#'   | --- | --- |
#'   | right_ascension | angle east from the vernal equinox (radians) |
#'   | declination | angle north of the celestial equator (radians) |
#'   | distance | distance from the center of the Earth to the point (meters) |
#'
#' @family convert coordinate functions
#' @export
RightAscensionDeclinationFromEci <- function(
    eci
) {

  # Coerce to matrix
  if (is.vector(eci)) {
    eci <- matrix(nrow = 1, ncol = 3, data = eci)
  }
  if (is.data.frame(eci)) {
    eci <- as.matrix(eci)
  }

  # Calculate distance
  distance = NormByRow(eci)

  # Calculate right ascension
  right_ascension = atan2(eci[, 2], eci[, 1])
  # Normalize right ascension into [0,2*pi)
  if (right_ascension < 0) {
    right_ascension <- right_ascension + 2 * pi
  }

  # Calculate declination
  declination = asin(eci[, 3] / distance)

  # Arrange output to a data.frame
  output <-
    data.frame(
      right_ascension = right_ascension,
      declination = declination,
      distance = distance
    )

  return(output)

}

