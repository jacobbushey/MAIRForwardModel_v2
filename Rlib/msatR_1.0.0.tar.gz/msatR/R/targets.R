# Target functions

# These functions are used to generate MethaneSAT targets. MethaneSAT targets
# are designed to maximize the efficiency of scanning while tolerating
# ephemeris and pointing error. They are quadrilaterals in geodetic space that
# follow the azimuth of an example orbit. The example orbits can be supplied
# explicitly, but standard examples are supplied in the package data as
# "orbit_examples".

#' Calculate MethaneSAT target aim points
#'
#' \code{TargetBuildAimpoints} calculates the locations of the aim points for
#' MethaneSAT targets. The aim points are locations on the surface of the Earth
#' (geodetic and Earth-Centered Earth-Fixed) that are used to determine the
#' attitude of MethaneSAT during a scan activity. Variable pitch scans require
#' additional aimpoints. Use \code{TargetBuildVariablePitchAimpoints} for these.
#'
#' @param lon numeric vector of longitude
#' @param lat numeric vector of latitude
#' @param duration numeric alongtrack extent of the target in seconds.
#'   1 second is equal to 6.9 km.
#' @param multiple integer number of target multiples to string together along
#'   track for consecutive scanning with no slew.
#' @param orbit_example example orbit for tracing out target. Suggest one of
#'   orbit_examples$transporter_9 or orbit_examples$transporter_10.
#'
#' @return list, numbered by the member of the group, where each element
#'   is a data.frame with rows "left", "center", and "right" and columns
#'   "lon", "lat", "alt", "x_ecef", "y_ecef", and "z_ecef".
#'
#' @examples
#' TargetBuildAimpoints(
#'   lon = 0,
#'   lat = 0,
#'   duration = 29,
#'   multiple = 1,
#'   orbit_example = orbit_examples$transporter_9
#' )
#'
#' @family target functions
#' @export
TargetBuildAimpoints <- function(
  lon,
  lat,
  duration,
  multiple,
  orbit_example
) {

  # Output frequency - hard coded because it refers to the orbit_example,
  # which is a part of the package
  orbit_freq  <- 1

  # Interpolate the orbit example down to the centroid

  # Determine the row of the orbit example at the centroid
  orbit_example_centroid_row <-
    stats::approx(
      x = orbit_example$pos_geodetic$lat,
      xout = lat,
      y = 1:nrow(orbit_example)
    )$y

  # Interpolate the orbit_example
  orbit_example_centroid <-
    InterpolateDataFrame(
      df = orbit_example,
      x = orbit_example_centroid_row
    )

  # Interpolate the orbit example down to the aim points

  # Determine the row of the orbit example at the centroid

  duration_fractions <-
    seq(
      from = -(multiple - 1) / 2,
      to = (multiple - 1) / 2,
      by = 1
    )

  scan_row <-
    orbit_example_centroid_row +
    orbit_freq * duration * duration_fractions

  orbit_scan <- InterpolateDataFrame(df = orbit_example, x = scan_row)

  # Calculate projection to the ellipsoid
  aimpoints_list <- list()
  for (tick in 1:length(scan_row)) {

    # Calculate the intersections
    aimpoints <- data.frame(point = c("left", "center", "right"))
    aimpoints$geodetic <-
      rbind(
        IntersectEllipsoid(
          pos_ecef    = orbit_scan$pos_ecef[tick, ],
          ray_ecef    = orbit_scan$boresight_left_ecef[tick, ]
        ),
        IntersectEllipsoid(
          pos_ecef    = orbit_scan$pos_ecef[tick, ],
          ray_ecef    = orbit_scan$boresight_center_ecef[tick, ]
        ),
        IntersectEllipsoid(
          pos_ecef    = orbit_scan$pos_ecef[tick, ],
          ray_ecef    = orbit_scan$boresight_right_ecef[tick, ]
        )
      )

    # Center the longitude at the aimpoints
    aimpoints$geodetic$lon <-
      aimpoints$geodetic$lon - orbit_example_centroid$pos_geodetic$lon + lon

    # Get altitude
    aimpoints$geodetic$alt <-
      raster::extract(
        dem,
        sp::SpatialPoints(aimpoints$geodetic)
      )

    # Transform to ECEF
    aimpoints$ecef <-
      EcefFromGeodetic(
        data.frame(
          lon = aimpoints$geodetic$lon,
          lat = aimpoints$geodetic$lat,
          alt = aimpoints$geodetic$alt
        )
      )

    # Save to the list
    aimpoints_list[[tick]] <- aimpoints

  }

  # Return the result
  return(aimpoints_list)

}

# #' Calculate the additional MethaneSAT target aim points for the variable pitch
# #' scan
# #'
# #' \code{TargetBuildVariablePitchAimpoints} calculates the additional aim
# #' points required for a MethaneSAT variable pitch scan. The aim points are
# #' locations on the surface of the Earth (geodetic and
# #' Earth-Centered Earth-Fixed) that are used to determine the attitude of
# #' MethaneSAT during a scan activity. Variable pitch scans require
# #' additional aim points to define the start and end locations of the scan.
# #' This function provides them. The standard aim points calculated by
# #' \code{TargetBuildAimpoints} will also be required.
# #'
# #' @param lon numeric vector of longitude
# #' @param lat numeric vector of latitude
# #' @param duration numeric alongtrack extent of the target in seconds.
# #'   1 second is equal to 6.9 km.
# #' @param buffer numeric time to buffer after target in seconds (default 1).
# #' @param multiple integer number of target multiples to string together along
# #'   track for consecutive scanning with no slew.
# #' @param orbit_example example orbit for tracing out target. Suggest one of
# #'   orbit_examples$transporter_9 or orbit_examples$transporter_10.
# #'
# #' @return list, numbered by the member of the group, where each element
# #'  is a data.frame with rows "left", "center", and "right" and columns
# #'  "lon", "lat", "alt", "x_ecef", "y_ecef", and "z_ecef".
# #'
# #' @examples
# #' TargetBuildVariablePitchAimpoints(
# #'   lon = 0,
# #'   lat = 0,
# #'   duration = 29,
# #'   buffer = 1,
# #'   multiple = 2,
# #'   orbit_example = orbit_examples$transporter_9
# #' )
# #'
# #' @family target functions
# #' @export
# TargetBuildVariablePitchAimpoints <- function(
#     lon,
#     lat,
#     duration,
#     buffer,
#     multiple,
#     orbit_example
# ) {
#
#   # Output frequency - hard coded because it refers to the orbit_example,
#   # which is a part of the package
#   orbit_freq  <- 1
#
#   # Interpolate the orbit example down to the centroid
#
#   # Determine the row of the orbit example at the centroid
#   orbit_example_centroid_row <-
#     stats::approx(
#       x = orbit_example$pos_geodetic$lat,
#       xout = lat,
#       y = 1:nrow(orbit_example)
#     )$y
#
#   # Interpolate the orbit_example
#   orbit_example_centroid <-
#     InterpolateDataFrame(
#       df = orbit_example,
#       x = orbit_example_centroid_row
#     )
#
#   # The fractions of duration
#   duration_fractions <-
#     seq(
#       from = -(multiple) / 2,
#       to = (multiple) / 2,
#       by = 1
#     )
#
#   # Calculate projection to the ellipsoid
#   aimpoints_list <- list()
#   for (tick in 1:multiple) {
#
#     aimpoint_inds <- 1:2 + (tick - 1)
#
#     # Determine the row of the orbit example at the leading and trailing points
#
#     duration_fractions_now <- duration_fractions[aimpoint_inds]
#     scan_row <-
#      orbit_example_centroid_row +
#       orbit_freq * (duration) * duration_fractions_now +
#       orbit_freq * c(-buffer, buffer)
#
#     orbit_scan <- InterpolateDataFrame(df = orbit_example, x = scan_row)
#
#     # Calculate the intersections
#     aimpoints <- data.frame(point = c("bottom", "top"))
#
#     aimpoints$geodetic <-
#       IntersectEllipsoid(
#         pos_ecef    = orbit_scan$pos_ecef,
#         ray_ecef    = orbit_scan$boresight_center_ecef
#       )
#
#     # Center the longitude at the aimpoints
#     aimpoints$geodetic$lon <-
#       aimpoints$geodetic$lon - orbit_example_centroid$pos_geodetic$lon + lon
#
#     # Get altitude
#     aimpoints$geodetic$alt <-
#       raster::extract(
#         dem,
#         sp::SpatialPoints(aimpoints$geodetic)
#       )
#
#     # Transform to ECEF
#     aimpoints$ecef <-
#       EcefFromGeodetic(
#         data.frame(
#           lon = aimpoints$geodetic$lon,
#           lat = aimpoints$geodetic$lat,
#           alt = aimpoints$geodetic$alt
#         )
#       )
#
#     # Save to the list
#     aimpoints_list[[tick]] <- aimpoints
#
#   }
#
#   # Return the result
#   return(aimpoints_list)
#
# }

#' Calculate the geodetic coordinates of a MethaneSAT target
#'
#' \code{TargetBuildPolygons} builds the polygons representing a MethaneSAT
#' target. A MethaneSAT target must take on the shape of a nadir scan.
#' MethaneSAT targets are built using an example orbit, a target centroid,
#' and a time to sweep out the target (one second of time is equal to about
#' 6.9 km on the ground, depending on the latitude).
#'
#' @param lon numeric vector of longitude
#' @param lat numeric vector of latitude
#' @param duration numeric alongtrack extent of the target in seconds.
#'   1 second is equal to about 6.9 km, depending on the latitude.
#' @param multiple integer number of target multiples to string together along
#'   track for consecutive scanning with no slew.
#' @param orbit_example example orbit for tracing out target. Suggest one of
#'   orbit_examples$transporter_9 or orbit_examples$transporter_10.
#'
#' @return List, numbered by the member of the group, where each element
#'   is a data.frame with rows "left", "center", and "right" and columns
#'   "lon", "lat", "alt", "x_ecef", "y_ecef", and "z_ecef".
#'
#' @examples
#' TargetBuildPolygons(
#'   lon = 0,
#'   lat = 0,
#'   duration = 29,
#'   multiple = 1,
#'   orbit_example = orbit_examples$transporter_9
#' )
#'
#' @family target functions
#' @export
TargetBuildPolygons <- function(
  lon,
  lat,
  duration,
  multiple,
  orbit_example
) {

  # Output frequency - hard coded because it refers to the orbit_example,
  # which is a part of the package
  orbit_freq  <- 1

  # Interpolate the orbit example down to the centroid

  # Determine the row of the orbit example at the centroid
  orbit_example_centroid_row <-
    stats::approx(
      x = orbit_example$pos_geodetic$lat,
      xout = lat,
      y = 1:nrow(orbit_example)
    )$y

  # Interpolate the orbit_example
  orbit_example_centroid <-
    InterpolateDataFrame(
      df = orbit_example,
      x = orbit_example_centroid_row
    )

  # Interpolate the orbit example down to the aim points

  # Determine the row of the orbit example at the centroid

  duration_fractions <-
    seq(
      from = -(multiple) / 2,
      to = (multiple) / 2,
      by = 0.5
    )

  scan_row <-
    orbit_example_centroid_row +
    orbit_freq * duration * duration_fractions

  orbit_scan <- InterpolateDataFrame(df = orbit_example, x = scan_row)

  # Calculate the projection to the ellipsoid
  target_list <- list()
  for (tick in 1:length(scan_row)) {


    # Calculate the intersections
    target <- data.frame(
      point = c("left", "center", "right")
    )
    target$geodetic <-
      rbind(
        IntersectEllipsoid(
          pos_ecef    = orbit_scan$pos_ecef[tick, ],
          ray_ecef    = orbit_scan$boresight_left_ecef[tick, ]
        ),
        IntersectEllipsoid(
          pos_ecef    = orbit_scan$pos_ecef[tick, ],
          ray_ecef    = orbit_scan$boresight_center_ecef[tick, ]
        ),
        IntersectEllipsoid(
          pos_ecef    = orbit_scan$pos_ecef[tick, ],
          ray_ecef    = orbit_scan$boresight_right_ecef[tick, ]
        )
      )

    # Center the longitude at the target
    target$geodetic$lon <-
      target$geodetic$lon - orbit_example_centroid$pos_geodetic$lon + lon

    # Get altitude
    target$geodetic$alt <-
      raster::extract(
        dem,
        sp::SpatialPoints(target$geodetic)
      )

    target_list[[tick]] <- target

  }

  # Organize the target scan into polygons
  target_polygons <- list()
  for (scan.tick in 1:multiple) {
    target_inds <- 1:3 + 2 * (scan.tick - 1)
    target_shape <- data.frame(
      lon = c(
        # Lower left
        target_list[[target_inds[1]]]$geodetic$lon[1],
        # Lower center
        target_list[[target_inds[1]]]$geodetic$lon[2],
        # Lower right
        target_list[[target_inds[1]]]$geodetic$lon[3],
        # Middle right
        target_list[[target_inds[2]]]$geodetic$lon[3],
        # Top right
        target_list[[target_inds[3]]]$geodetic$lon[3],
        # Top middle
        target_list[[target_inds[3]]]$geodetic$lon[2],
        # Top left
        target_list[[target_inds[3]]]$geodetic$lon[1],
        # Middle left
        target_list[[target_inds[2]]]$geodetic$lon[1],
        # Lower left
        target_list[[target_inds[1]]]$geodetic$lon[1]
      ),

      lat = c(
        # Lower left
        target_list[[target_inds[1]]]$geodetic$lat[1],
        # Lower center
        target_list[[target_inds[1]]]$geodetic$lat[2],
        # Lower right
        target_list[[target_inds[1]]]$geodetic$lat[3],
        # Middle right
        target_list[[target_inds[2]]]$geodetic$lat[3],
        # Top right
        target_list[[target_inds[3]]]$geodetic$lat[3],
        # Top middle
        target_list[[target_inds[3]]]$geodetic$lat[2],
        # Top left
        target_list[[target_inds[3]]]$geodetic$lat[1],
        # Middle left
        target_list[[target_inds[2]]]$geodetic$lat[1],
        # Lower left
        target_list[[target_inds[1]]]$geodetic$lat[1])
    )

    # Convert to sf polygon
    target_polygon <- sfheaders::sf_polygon(target_shape)
    sf::st_crs(target_polygon) <- 4326

    # Save to the shapes object
    target_polygons[[scan.tick]] <- target_polygon
  }

  # Return the target shapes
  return(target_polygons)

}

#' Find the points in a GFS (Global  Forecast System) grid that fall inside
#' of a target
#'
#' \code{TargetBuildPolygons} finds the points in a GFS
#' (Global  Forecast System) grid that fall inside of a target. GFS forecasts
#' are the meteorological products that will be used to predict the
#' meteorological conditions at a target for target planning. The GFS points
#' allow the fast extraction of GFS data in NetCDF format via the
#' \code{raster::extract} function.
#'
#' @param target_polygon a polygon object generated by
#'   \code{target_buildpolygons}
#'
#' @return a data.frame with columns longitude and latitude giving the centers
#'   of points in the GFS grid. These points will work with the
#'   \code{raster::extract()} function.
#'
#' @examples
#' target_polygon <-
#'   TargetBuildPolygons(
#'     lon = 0,
#'     lat = 0,
#'     duration = 5,
#'     multiple = 1,
#'     orbit_example = orbit_examples$transporter_9
#'   )
#' TargetBuildGfsPoints(target_polygon[[1]])
#'
#' @family target functions
#' @export
TargetBuildGfsPoints <- function(target_polygon) {

  # Set up the GFS grid - this is hard coded because the GFS grid is fixed
  gfslons <- seq(from = -179.875, to = 179.875, by = 0.25)
  gfslats <- seq(from = -89.875, to = 89.875, by = 0.25)
  gfsgrid <- expand.grid(gfslons, gfslats)

  # Points for the GFS extract
  gfs_grid_in <-
    sp::point.in.polygon(
      point.x = gfsgrid[,1],
      point.y = gfsgrid[,2],
      pol.x = unlist(target_polygon$geometry)[1:9],
      pol.y = unlist(target_polygon$geometry)[10:18]
    )

  # Return the points for the GFS extract
  gfsgrid_extract <- gfsgrid[gfs_grid_in == 1, ]
  colnames(gfsgrid_extract) <- c("lon", "lat")

  return(gfsgrid_extract)

}

#' Build a local DEM (digital elevation map) as a data.frame for
#' orthorectification
#'
#' \code{TargetBuildDem} builds a local DEM (Digital Elevation Map) as a
#' data.frame for a MethaneSAT target. The local DEM aids in the fast
#' orthorectification of a MethaneSAT scan. This DEM is nnot high enough
#' resolution for full production, but is sufficient for STILT receptor list
#' generation.
#'
#' @param target_polygon a polygon object generated by target_buildpolygons
#' @param buffer a numeric distance to buffer the target in km
#' @param dem_raster pointer to a raster (e.g., .tif) file with a DEM.
#'   (default NULL uses a built-in DEM). Test to see if R will load your dem
#'   with the command raster::raster.
#'
#' @examples
#' target_polygon <-
#'   TargetBuildPolygons(
#'     lon = 0,
#'     lat = 0,
#'     duration = 5,
#'     multiple = 1,
#'     orbit_example = orbit_examples$transporter_9
#'   )
#' TargetBuildDem(target_polygon[[1]])
#'
#' @family target functions
#' @export
TargetBuildDem <- function(
    target_polygon,
    buffer = 50,
    dem_raster = NULL
) {

  # If the dem file was specified, load it
  if (!is.null(dem_raster)) {
    dem <- raster::raster(dem_raster)
  }

  # Generate the buffered polygon
  buffered_target_polygon <-
    sf::st_buffer(target_polygon, dist = buffer * 1000)

  # Extract the DEM
  dem_extracted <-
    raster::extract(
      dem,
      buffered_target_polygon,
      cellnumbers = TRUE
    )

  # Get the lon and lat values
  dem_lonlat <- raster::xyFromCell(dem, dem_extracted[[1]][,1])

  # Assemble to data.frame
  dem_extract_df <- data.frame(
    lon = dem_lonlat[,1],
    lat = dem_lonlat[,2],
    alt = dem_extracted[[1]][,2]
  )

  return(dem_extract_df)

}

#' Build the MethaneSAT target book rds file
#'
#' \code{TargetBuildRds} builds an .rds file
#'
#' @param target_df data.frame with information about the targets
#'   Must have columns: lon, lat, alt, multiple, duration.
#'   | column | description |
#'   | --- | --- |
#'   | type | character describing the type of target, e.g., "Oil_And_Gas" |
#'   | lon | numeric longitude |
#'   | lat | numeric latitude |
#'   | alt | numeric altitude in meters above WGS84 ellipsoid |
#'   | multiple | integer number of consecutive targets to chain together along track. |
#'   | duration | Numeric alongtrack extent of the target in seconds. 1 second is equal to 6.9km. |
#'   | buffer | numeric alongtrack buffer of the target for scans in seconds. 1 second is equal to 6.9km. |
#' @param verbose logical. If TRUE (defaut) the status will be printed.
#' @param orbit_example example orbit for tracing out target. Suggest one of
#'   orbit_examples$transporter_9 or orbit_examples$transporter_10.
#'
#' @return .RData object containing all the information necessary
#'   to add a target to the target book
#'
#' @examples
#' TargetBuildRds(
#'   target_df =
#'     data.frame(
#'       type = "Oil_And_Gas",
#'       lon = 0,
#'       lat = 0,
#'       alt = 0,
#'       multiple = 1,
#'       duration = 29,
#'       buffer = 1
#'     ),
#'    orbit_example = orbit_examples$transporter_9
#'  )
#'
#' @family target functions
#' @export
TargetBuildRds <- function(
  target_df,
  verbose = FALSE,
  orbit_example
) {

  # Initialize outputs
  target_info   <- data.frame(
    id      = 1:sum(target_df$multiple),
    type    = rep(NA, sum(target_df$multiple)),
    group   = rep(NA, sum(target_df$multiple)),
    member  = rep(NA, sum(target_df$multiple)),
    shore   = rep(NA, sum(target_df$multiple))
  )
  target_polygons   <- list()
  target_aimpoints  <- list()
  target_variable_pitch_aimpoints  <- list()
  target_gfspoints  <- list()

  if (verbose) {
    pb <- utils::txtProgressBar()
  }
  target_id <- 0

  # Fill the data
  for (tick in 1:nrow(target_df)) {

    if (verbose) {
      utils::setTxtProgressBar(pb, tick / nrow(target_df))
    }

    # Build target polygons
    target_polygon  <-
      TargetBuildPolygons(
        lon           = target_df$lon[tick],
        lat           = target_df$lat[tick],
        duration      = target_df$duration[tick],
        multiple      = target_df$multiple[tick],
        orbit_example = orbit_example
      )
    target_polygons <- append(target_polygons, target_polygon)
    target_ids <- target_id + 1:length(target_polygon)
    target_info$type[target_ids] <- target_df$type[tick]
    target_info$group[target_ids] <- tick
    target_info$member[target_ids] <- 1:length(target_polygon)

    # Build target aimpoints
    target_aimpoint <-
      TargetBuildAimpoints(
        lon           = target_df$lon[tick],
        lat           = target_df$lat[tick],
        duration      = target_df$duration[tick],
        multiple      = target_df$multiple[tick],
        orbit_example = orbit_example
      )
    target_aimpoints <- append(target_aimpoints, target_aimpoint)

    # # Build target aimpoints
    # target_variable_pitch_aimpoint <-
    #   TargetBuildVariablePitchAimpoints(
    #     lon           = target_df$lon[tick],
    #     lat           = target_df$lat[tick],
    #     duration      = target_df$duration[tick],
    #     multiple      = target_df$multiple[tick],
    #     buffer        = target_df$buffer[tick],
    #     orbit_example = orbit_example
    #   )
    # target_variable_pitch_aimpoints <-
    #   append(
    #     target_variable_pitch_aimpoints,
    #     target_variable_pitch_aimpoint
    #   )

    # Identify Onshore/Offshore/Shoreline polygons
    for (target.tick in 1:length(target_polygon)) {
      # Sample points in the current polygon
      pts <-
        suppressMessages(
          sf::st_sample(target_polygon[[target.tick]], 1000)
        )
      # Test if the sampled points are on land or ocean
      water <-
        suppressMessages(
          sf::st_intersects(pts, spData::world) %>%
          as.numeric() %>%
          is.na()
        )
      # Set onshore, offshore or shoreline
      target_info$shore[target_ids[target.tick]] <-
        c("onshore", "shoreline", "offshore")[
          c(!any(water),
            !all(water) & any(water),
            all(water)
          )
        ]

      # Build the target gfs points
      target_gfspoints[[target_ids[target.tick]]] <-
        TargetBuildGfsPoints(target_polygon[[target.tick]])

    }

    # Iterate the target id
    target_id <- max(target_ids)
  }

  # Combine the polygons into a single sf object
  target_polygons <- do.call("rbind", target_polygons)
  target_polygons$id <- target_info$id
  target_polygons$type <- target_info$type
  target_polygons$group <- target_info$group
  target_polygons$member <- target_info$member
  target_polygons$shore <- target_info$shore

  # # Add the centroid to the target_info data frame
  # target_polygons$centroid <-
  #   target_polygons                 %>%
  #   sf::st_centroid()               %>%
  #   sf::st_transform(4326)          %>%
  #   '$'(geometry)                   %>%
  #   sapply(unlist)                  %>%
  #   t()                             %>%
  #   as.data.frame()                 %>%
  #   'colnames<-'(c("lon", "lat"))   %>%
  #   suppressWarnings()

  # Return the product
  output <-
    list(
      #info      = target_info,
      polygons  = target_polygons,
      aimpoints = target_aimpoints,
      # variable_pitch_aimpoints = target_variable_pitch_aimpoints,
      gfspoints = target_gfspoints
    )

  return(output)

}
