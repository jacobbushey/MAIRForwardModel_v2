# NORAD TLE Functions

# These functions read NORAD Two-Line Element (TLE) orbit descriptions,
# derive orbital element quantities, and read and write CCSDS orbit files.
# These are used to decode orbits, find orbits, and readd and write orbit
# datasets in science planning.

# TLE's ----

#' Calculate the checksum of a string according to the NORAD TLE checksum rules
#'
#' \code{TleCheckSum} calculates the checksum of a NORAD
#' (North American Aerospace Defense Command) TLE (Two-Line Element)
#' description of orbital parameters.
#'
#' The checksum rules are:
#'
#' | character | value |
#' | --- | --- |
#' |letters, blanks, periods, plus signs | 0 |
#' |minus signs | 1 |
#' |numbers | the number |
#'
#' @param x A character string
#' @return An integer checksum, modulo 10
#'
#' @examples
#' tle <-
#'   c(
#'     "1 88888U  16001A  16001.00000000  .00000000  00000-0  00000-0 0  9996",
#'     "2 88888  97.7053 306.9476 0010625  90.0000  89.0000 14.9608950 1    1"
#'    )
#' TleCheckSum(tle[1])
#' TleCheckSum(tle[2])
#'
#' @keywords internal
#' @family norad tle functions
#' @export
TleCheckSum <- function(x) {

  running_sum <- 0
  for (tick in 1:68) {
    char_tick <- substr(x, tick ,tick)
    # Zero value characters
    if (grepl("[A-Za-z .+]", char_tick)) {
      next()
      # One value characters
    } else if (grepl("[-]", char_tick)) {
      running_sum <- running_sum + 1
      # Numeric values
    } else if (grepl("[0-9]", char_tick)) {
      running_sum <- running_sum + as.numeric(char_tick)
    }
  }

  # Return the checksum modulo 10
  checksum <- running_sum %% 10

  return(checksum)

}

#' Convert a NORAD Two-Line-Element character string to a named list
#'
#' The NORAD (North American Aerospace Defense Command) TLE (Two-Line Element)
#' is a two line (each with 69 characters) text description of orbital
#' parameters. It is a very terse format and not self-documenting. As such,
#' it is not easily human readable. This function decodes a TLE into a list
#' with self-documenting and human readable elements.
#'
#' @param tle length-2 character string, with each element having 69 characters
#' @param verbose logical: if TRUE, the checksum test will be reported
#' @return A list with elements:
#'   $direct
#'  |  Name | Class | Description |
#'  | --- | --- | --- |
#'  | $satellite_number | numeric | Satellite catalog number |
#'  | $classification | character | Classification (U: unclassified, C: classified, S: secret) |
#'  | $launch_year | numeric | Year the satellite was launched |
#'  | $launch_number_of_year | numeric | Launch number for this satellite's launch |
#'  | $peice_of_the_launch | numeric | Peice number for this satellite's launch |
#'  | $epoch_year | numeric | Year of the moment in time used as a reference point for this TLE |
#'  | $epoch_doy | numeric | Day of the moment in time used as a reference point for this TLE |
#'  | $first_time_derivative_of_mean_motion | numeric | First time derivative of mean motion; the ballistic coefficient (rev / day^2) |
#'  | $second_time_derivative_of_mean_motion | numeric | Seconds time derivative of mean motion; the ballistic coefficient (rev / day^3) |
#'  | $bstar_drag_term | numeric | Drag term, or radiation pressure coefficient (er^-1) |
#'  | $ephemeris_type | character | Ephemeris type (always zero; only used in undistributed TLE data) |
#'  | $element_number | numeric | Element set number. Incremented when a new TLE is generated for this object.|
#'  | $checksum1 | numeric | Checksum of line 1 - see TleChecksum() |
#'  | $inclination | numeric | Inclination (degrees) |
#'  | $right_ascension_of_the_angular_node | numeric | Right ascension of the ascending node (degrees) |
#'  | $eccentricity | numeric | Eccentricity (dimensionless) |
#'  | $argument_of_perigree | numeric | Argument of perigee (degrees) |
#'  | $mean_anomaly | numeric | Mean anomaly (degrees) |
#'  | $mean_motion | numeric | Mean motion (revolutions per day) |
#'  | $rev_at_epoch | numeric | Revolution number at epoch (revolutions) |
#'  | $checksum2 | numeric | Checksum of line 2 - see TleChecksum() |
#'
#'  $computed
#'  |  name | class | Description |
#'  | --- | --- | --- |
#'  | $computed$epoch_utc | POSIX | Moment in time used as a reference point for this TLE in UTC |
#'  | $computed$checksum1test | logical | Test for Checksum of line 1 |
#'  | $computed$checksum2test | logical | Test of Checksum of line 2 |
#'
#' @examples
#' tle <-
#'   c(
#'     "1 88888U 16001A   16001.00000000  .00000000  00000-0  00000-0 0  9996",
#'     "2 88888  97.7053 306.9476 0010625  90.0000  89.0000 14.9608950 1    1"
#'    )
#'
#' ReadTle(tle)
#'
#' @family norad tle functions
#' @export
ReadTle <- function(tle, verbose = FALSE) {

  tle_data <- list()

  # Directly read values
  tle_data$direct                          <- NULL
  tle_data$direct$satellite_number         <- substr(tle[1], 3, 7) %>%
                                              as.numeric()
  tle_data$direct$classification           <- substr(tle[1], 8, 8)
  tle_data$direct$launch_year              <- substr(tle[1], 10, 11) %>%
                                              as.numeric()
  tle_data$direct$launch_number_of_year    <- substr(tle[1], 12, 14) %>%
                                              as.numeric()
  tle_data$direct$peice_of_the_launch      <- substr(tle[1], 15, 17) %>%
                                              trimws()
  tle_data$direct$epoch_year               <- substr(tle[1], 19, 20) %>%
                                              as.numeric()
  tle_data$direct$epoch_doy                <- substr(tle[1], 21, 32) %>%
                                              as.numeric()
  tle_data$direct$first_deriv_mean_motion  <- substr(tle[1], 34, 43) %>%
                                              as.numeric()
  tle_data$direct$second_deriv_mean_motion <- paste0(
                                                substr(tle[1], 45, 50),
                                                "e",
                                                substr(tle[1], 51, 52)
                                              ) %>%
                                              as.numeric()
  tle_data$direct$bstar_drag_term          <- paste0(
                                                substr(tle[1], 54, 59),
                                                "e",
                                                substr(tle[1], 60, 61)
                                              ) %>%
                                              as.numeric()
  tle_data$direct$ephemeris_type           <- substr(tle[1], 63, 63)
  tle_data$direct$element_number           <- substr(tle[1], 65, 68) %>%
                                              as.numeric()
  tle_data$direct$checksum1                <- substr(tle[1], 69, 69) %>%
                                              as.numeric()
  tle_data$direct$inclination              <- substr(tle[2], 9, 16) %>%
                                              as.numeric()
  tle_data$direct$right_ascension          <- substr(tle[2], 18, 25) %>%
                                              as.numeric()
  tle_data$direct$eccentricity             <- paste0(
                                                "0.",
                                                substr(tle[2], 27, 33)
                                              ) %>%
                                              as.numeric()
  tle_data$direct$argument_of_perigree     <- substr(tle[2], 35, 42) %>%
                                              as.numeric()
  tle_data$direct$mean_anomaly             <- substr(tle[2], 44, 51) %>%
                                              as.numeric()
  tle_data$direct$mean_motion              <- substr(tle[2], 53, 63) %>%
                                              as.numeric()
  tle_data$direct$rev_at_epoch             <- substr(tle[2], 64, 68) %>%
                                              as.numeric()
  tle_data$direct$checksum2                <- substr(tle[2], 69, 69) %>%
                                              as.numeric()

  # Computed values
  tle_data$computed               <- NULL
  tle_data$computed$epoch_utc     <- UtcFromYyyyDoy(
                                       2000 + tle_data$direct$epoch_year,
                                       floor(tle_data$direct$epoch_doy)
                                     )
  tle_data$computed$checksum1test <- TleCheckSum(tle[1]) ==
                                     tle_data$direct$checksum1
  tle_data$computed$checksum2test <- TleCheckSum(tle[2]) ==
                                     tle_data$direct$checksum2

  # Report failed checksums
  if (verbose & !tle_data$computed$checksum1test) {
    cat("/nTLE checksum for line 1 failed")
  }
  if (verbose & !tle_data$computed$checksum1test) {
    cat("/nTLE checksum for line 2 failed")
  }

  return(tle_data)

}

# Instantaneous Orbital Elements ----

#' Calculate the specific angular velocity vector
#'
#' \code{SpecificAngularVelocityVector} calculates the vector pointing towards
#' the orbit normal with magnitude radius times speed.
#'
#' @param pos_eci vector, matrix, or data.frame with 3 columns of the
#'   position in meters Earth-centered-inertial
#' @param vel_eci vector, matrix, or data.frame with 3 columns of the
#'   velocity in meters Earth-centered-inertial
#'
#' @examples
#' # Vector inputs
#' pos_eci <- c(1951386, -6680883, 1883.776)
#' vel_eci <- c(-972.9733, -286.3350, -7501.300)
#' SpecificAngularVelocityVector(pos_eci, vel_eci)
#'
#' # matrix inputs
#' pos_eci <-
#'   rbind(
#'     c(1951386, 1950412, 1949436),
#'     c(-6680883, -6681165, -6681439),
#'     c(1883.776, -5617.490, -13119.050)
#'   )
#' vel_eci <-
#'   rbind(
#'     c(-972.9733, -975.2829, -977.5914),
#'     c(-286.3350, -278.4257, -270.5158),
#'     c(-7501.300, -7501.298, -7501.287)
#'   )
#'  SpecificAngularVelocityVector(pos_eci, vel_eci)
#'
#' # data.frame inputs
#' pos_eci <-
#'   data.frame(
#'     x = c(1951386, 1950412, 1949436),
#'     y = c(-6680883, -6681165, -6681439),
#'     z = c(1883.776, -5617.490, -13119.050)
#'   )
#' vel_eci <-
#'   data.frame(
#'     x = c(-972.9733, -975.2829, -977.5914),
#'     y = c(-286.3350, -278.4257, -270.5158),
#'     z = c(-7501.300, -7501.298, -7501.287)
#'   )
#'  SpecificAngularVelocityVector(pos_eci, vel_eci)
#'
#' @family norad tle functions
#' @export
SpecificAngularVelocityVector <- function(pos_eci, vel_eci) {

  CrossProductByRow(pos_eci, vel_eci)

}

#' Calculate the eccentricity vector
#'
#' \code{EccentricityVector} calculates the vector pointing from the apogee
#' (point on the orbit farthest from the center of the Earth) to the perigee
#' (point on the orbit nearest to the center of the Earth) with magnitude
#' equal to the orbit's scalar eccentricity.
#'
#' @param pos_eci vector, matrix, or data.frame with 3 columns of the
#'   position in meters Earth-centered-inertial
#' @param vel_eci vector, matrix, or data.frame with 3 columns of the
#'   velocity in meters Earth-centered-inertial
#'
#' @examples
#' # Vector inputs
#' pos_eci <- c(1951386, -6680883, 1883.776)
#' vel_eci <- c(-972.9733, -286.3350, -7501.300)
#' EccentricityVector(pos_eci, vel_eci)
#'
#' # matrix inputs
#' pos_eci <-
#'   rbind(
#'     c(1951386, 1950412, 1949436),
#'     c(-6680883, -6681165, -6681439),
#'     c(1883.776, -5617.490, -13119.050)
#'   )
#' vel_eci <-
#'   rbind(
#'     c(-972.9733, -975.2829, -977.5914),
#'     c(-286.3350, -278.4257, -270.5158),
#'     c(-7501.300, -7501.298, -7501.287)
#'   )
#'  EccentricityVector(pos_eci, vel_eci)
#'
#' # data.frame inputs
#' pos_eci <-
#'   data.frame(
#'     x = c(1951386, 1950412, 1949436),
#'     y = c(-6680883, -6681165, -6681439),
#'     z = c(1883.776, -5617.490, -13119.050)
#'   )
#' vel_eci <-
#'   data.frame(
#'     x = c(-972.9733, -975.2829, -977.5914),
#'     y = c(-286.3350, -278.4257, -270.5158),
#'     z = c(-7501.300, -7501.298, -7501.287)
#'   )
#'  EccentricityVector(pos_eci, vel_eci)
#'
#' @family norad tle functions
#' @export
EccentricityVector <- function(pos_eci, vel_eci) {

  # Standard gravitational parameter of the Earth
  mu <- 3.986004418e14

  # Calculate eccentricity vector
  specific_angvel <- SpecificAngularVelocityVector(pos_eci, vel_eci)
  eccentricity_vector <-
    (CrossProductByRow(vel_eci, specific_angvel) / mu) -
    NormalizeByRow(pos_eci)

  return(eccentricity_vector)

}

#' Calculate the line of nodes vector (ascending)
#'
#' \code{AscendingNodeVector} calculates the line of nodes vector, which
#' lies along the intersection of the fundamentaal plane (the Earth's Equator)
#' and the orbital plane and points towards the ascending node. This is
#' and instantaneous value since the orbital plane is changing with time.
#'
#' @param pos_eci vector, matrix, or data.frame with 3 columns of the
#'   position in meters Earth-centered-inertial
#' @param vel_eci vector, matrix, or data.frame with 3 columns of the
#'   velocity in meters Earth-centered-inertial
#'
#' @examples
#' # Vector inputs
#' pos_eci <- c(1951386, -6680883, 1883.776)
#' vel_eci <- c(-972.9733, -286.3350, -7501.300)
#' AscendingNodeVector(pos_eci, vel_eci)
#'
#' # matrix inputs
#' pos_eci <-
#'   rbind(
#'     c(1951386, 1950412, 1949436),
#'     c(-6680883, -6681165, -6681439),
#'     c(1883.776, -5617.490, -13119.050)
#'   )
#' vel_eci <-
#'   rbind(
#'     c(-972.9733, -975.2829, -977.5914),
#'     c(-286.3350, -278.4257, -270.5158),
#'     c(-7501.300, -7501.298, -7501.287)
#'   )
#'  AscendingNodeVector(pos_eci, vel_eci)
#'
#' # data.frame inputs
#' pos_eci <-
#'   data.frame(
#'     x = c(1951386, 1950412, 1949436),
#'     y = c(-6680883, -6681165, -6681439),
#'     z = c(1883.776, -5617.490, -13119.050)
#'   )
#' vel_eci <-
#'   data.frame(
#'     x = c(-972.9733, -975.2829, -977.5914),
#'     y = c(-286.3350, -278.4257, -270.5158),
#'     z = c(-7501.300, -7501.298, -7501.287)
#'   )
#'  AscendingNodeVector(pos_eci, vel_eci)
#'
#' @family norad tle functions
#' @export
AscendingNodeVector <- function(pos_eci, vel_eci) {

  # Coerce to matrix
  if (is.vector(pos_eci)) {
    pos_eci <- matrix(nrow = 1, data = pos_eci)
  }
  if (is.vector(vel_eci)) {
    vel_eci <- matrix(nrow = 1, data = vel_eci)
  }

  # Find the specific angular velocity vector
  specific_angvel <- SpecificAngularVelocityVector(pos_eci, vel_eci)

  # Find the ascending node vector
  ascending_node_vector <-
    CrossProductByRow(
      RepeatRows(c(0, 0, 1), nrow(pos_eci)),
      specific_angvel
    )

  return(ascending_node_vector)

}

#' Calculate the argument of perigee
#'
#' \code{ArgumentOfPerigee} calculates the angle between the the eccentricity
#' vector and the line of nodes vector. The eccentricity vector is the vector
#' pointing from the apogee (point on the orbit farthest from the center of the
#' Earth) to the perigee (point on the orbit nearest to the center of the
#' Earth). The line of nodes vector is the vector pointing along the
#' intersection of the fundamental plane (Earth's equator) and the orbital
#' plane.
#'
#'
#' @param pos_eci vector, matrix, or data.frame with 3 columns of the
#'   position in meters Earth-centered-inertial
#' @param vel_eci vector, matrix, or data.frame with 3 columns of the
#'   velocity in meters Earth-centered-inertial
#'
#' @examples
#' # Vector inputs
#' pos_eci <- c(1951386, -6680883, 1883.776)
#' vel_eci <- c(-972.9733, -286.3350, -7501.300)
#' ArgumentOfPerigee(pos_eci, vel_eci)
#'
#' # matrix inputs
#' pos_eci <-
#'   rbind(
#'     c(1951386, 1950412, 1949436),
#'     c(-6680883, -6681165, -6681439),
#'     c(1883.776, -5617.490, -13119.050)
#'   )
#' vel_eci <-
#'   rbind(
#'     c(-972.9733, -975.2829, -977.5914),
#'     c(-286.3350, -278.4257, -270.5158),
#'     c(-7501.300, -7501.298, -7501.287)
#'   )
#'  ArgumentOfPerigee(pos_eci, vel_eci)
#'
#' # data.frame inputs
#' pos_eci <-
#'   data.frame(
#'     x = c(1951386, 1950412, 1949436),
#'     y = c(-6680883, -6681165, -6681439),
#'     z = c(1883.776, -5617.490, -13119.050)
#'   )
#' vel_eci <-
#'   data.frame(
#'     x = c(-972.9733, -975.2829, -977.5914),
#'     y = c(-286.3350, -278.4257, -270.5158),
#'     z = c(-7501.300, -7501.298, -7501.287)
#'   )
#'  ArgumentOfPerigee(pos_eci, vel_eci)
#'
#' @family norad tle functions
#' @export
ArgumentOfPerigee <- function(pos_eci, vel_eci) {

  # Coerce to matrix
  if (is.vector(pos_eci)) {
    pos_eci <- matrix(nrow = 1, data = pos_eci)
  }
  if (is.vector(vel_eci)) {
    vel_eci <- matrix(nrow = 1, data = vel_eci)
  }

  # Find the eccentricity vector
  eccentricity_vector <- EccentricityVector(pos_eci, vel_eci)

  # Find the ascending node vector
  ascending_node_vector <- AscendingNodeVector(pos_eci, vel_eci)

  # Find the angle between the ascending node vector and the eccentricity vector
  perigee_angle <-
    AngleBetweenVectors(
      eccentricity_vector,
      ascending_node_vector
    )

  # The true anomaly must be taken about the angular velocity vector,
  # so any part where the
  perigee_angle[eccentricity_vector[,3] < 0] <-
    2 * pi - perigee_angle[eccentricity_vector[,3] < 0]

  return(perigee_angle)

}

#' Calculate the argument of latitude
#'
#' \code{ArgumentOfLatitude} calculates the angle between the the spacecraft
#' position and the line of nodes vector. The line of nodes vector is the
#' vector pointing along the intersection of the fundamental plane (Earth's
#' equator) and the orbital plane.
#'
#' @param pos_eci vector, matrix, or data.frame with 3 columns of the
#'   position in meters Earth-centered-inertial
#' @param vel_eci vector, matrix, or data.frame with 3 columns of the
#'   velocity in meters Earth-centered-inertial
#'
#' @examples
#' # Vector inputs
#' pos_eci <- c(1951386, -6680883, 1883.776)
#' vel_eci <- c(-972.9733, -286.3350, -7501.300)
#' ArgumentOfLatitude(pos_eci, vel_eci)
#'
#' # matrix inputs
#' pos_eci <-
#'   rbind(
#'     c(1951386, 1950412, 1949436),
#'     c(-6680883, -6681165, -6681439),
#'     c(1883.776, -5617.490, -13119.050)
#'   )
#' vel_eci <-
#'   rbind(
#'     c(-972.9733, -975.2829, -977.5914),
#'     c(-286.3350, -278.4257, -270.5158),
#'     c(-7501.300, -7501.298, -7501.287)
#'   )
#'  ArgumentOfLatitude(pos_eci, vel_eci)
#'
#' # data.frame inputs
#' pos_eci <-
#'   data.frame(
#'     x = c(1951386, 1950412, 1949436),
#'     y = c(-6680883, -6681165, -6681439),
#'     z = c(1883.776, -5617.490, -13119.050)
#'   )
#' vel_eci <-
#'   data.frame(
#'     x = c(-972.9733, -975.2829, -977.5914),
#'     y = c(-286.3350, -278.4257, -270.5158),
#'     z = c(-7501.300, -7501.298, -7501.287)
#'   )
#'  ArgumentOfLatitude(pos_eci, vel_eci)
#'
#' @family norad tle functions
#' @export
ArgumentOfLatitude <- function(pos_eci, vel_eci) {

  # Coerce to matrix
  if (is.vector(pos_eci)) {
    pos_eci <- matrix(nrow = 1, data = pos_eci)
  }
  if (is.vector(vel_eci)) {
    vel_eci <- matrix(nrow = 1, data = vel_eci)
  }

  # Find the ascending node vector
  ascending_node_vector <- AscendingNodeVector(pos_eci, vel_eci)

  # Find the angle between the ascending node vector and the eccentricity vector
  latitude_angle <-
    AngleBetweenVectors(
      pos_eci,
      ascending_node_vector
    )

  # The true anomaly must be taken about the angular velocity vector,
  # so any part where the
  latitude_angle[pos_eci[,3] < 0] <-
    2 * pi - latitude_angle[pos_eci[,3] < 0]

  return(latitude_angle)

}

#' Calculate the true anomaly
#'
#' \code{TrueAnomaly} calculates the angle between the spacecraft position
#' vector and the eccentricity vector about the specific angular momentum
#' vector. The eccentricity vector is the vector pointing from the apogee
#' (point on the orbit farthest from the center of the Earth) to the perigee
#' (point on the orbit nearest to the center of the Earth). The specific
#' angular momentum vector is defined as the cross product of position with
#' velocity.
#'
#' @param pos_eci vector, matrix, or data.frame with 3 columns of the
#'   position in meters Earth-centered-inertial
#' @param vel_eci vector, matrix, or data.frame with 3 columns of the
#'   velocity in meters Earth-centered-inertial
#'
#' @family norad tle functions
#' @export
TrueAnomaly <- function(pos_eci, vel_eci) {

  ArgumentOfLatitude(pos_eci, vel_eci) - ArgumentOfPerigee(pos_eci, vel_eci)

}

#' Count revolution number
#'
#' \code{RevNumber} is a rev (revolution) counter. There are two
#' definitions of revolutions that are relevant to MethaneSAT's mission
#' planning: the ascending and descending revs. The ascending revs iterate when
#' the spacecraft crosses the ascending node (on the sun-side for MethaneSAT),
#' and the descending revs iterate when the spacecraft crosses the descending
#' node (on the eclipse side for MethaneSAT). The ascending revs are the
#' required output for mission planning. The descending revs are more
#' convenient for target planning if the spacecraft is operating in ascending
#' ops since it iterates on the eclipse side where there are no targets.
#' This function will return both rev numbers, defined using the tle's
#' epoch and rev number at epoch.
#'
#' @param pos_eci vector, matrix, or data.frame with 3 columns of the
#'   position in meters Earth-centered-inertial
#' @param vel_eci vector, matrix, or data.frame with 3 columns of the
#'   velocity in meters Earth-centered-inertial
#' @param utc vector of UTC (Universal Coordinated Time) dates in POSIX
#'   (Portable Operating System Interface) format. Must have the same length as
#'   pos_eci.
#' @param tle length-2 character string, with each element having 69 characters
#' @return data.frame with columns
#' | name | description |
#' | rev_ascending | ascending rev count (starts at 1) |
#' | rev_descending | descending rev count (starts at 1) |
#' @export
RevNumber <- function(utc, pos_eci, vel_eci, tle) {

  # Read the TLE
  tle_list <- ReadTle(tle)

  # The rev counter is

  # Calculate the argument of latitude
  argument_of_latitude <- ArgumentOfLatitude(pos_eci, vel_eci)

  # If the argument of latitude decreases,
  # then we have iterated an ascending rev
  # This is more robust than counting rev crossings -
  # especially for partial revs
  revbreaks <- LocalMaxima(argument_of_latitude)

  # Empirical orbit period uses the argument of latitude.
  # This is most robust and accurate
  # (more sample points than the actual periods, accounts for more than tle)
  orbit_period <- 2 * pi /
    mean(diff(argument_of_latitude)[abs(diff(argument_of_latitude)) < 1])

  # # To find the starting rev, count the number of periods since epoch
  # Revs completed since epoch
  rev_start <-
    utc[1] %>%
    difftime(tle_list$computed$epoch_utc, units = "secs") %>%
    as.numeric() %>%
    "/"(orbit_period) %>%
    floor() %>%
    "+"(tle_list$direct$rev_at_epoch)

  # Walk through the rev breaks and label the ascending revs
  revs <-
    data.frame(
      rev_ascending = rep(rev_start, length(utc)),
      rev_descending = rep(NA, length(utc))
    )
  for (revbreak.tick in 1:(length(revbreaks) - 1)) {
    indices <- (revbreaks[revbreak.tick] + 1):revbreaks[revbreak.tick + 1]
    revs$rev_ascending[indices] <- rev_start + revbreak.tick
  }

  # The descending rev is always the same in the northern hemisphere
  # and 1 ahead in the southern hemisphere.
  revs$rev_descending <- revs$rev_ascending
  revs$rev_descending[pos_eci[,3] < 0] <-
    revs$rev_ascending[pos_eci[,3] < 0] + 1

  return(revs)

}

#' Calculate the mean motion of an orbit from the altitude and eccentricity
#'
#' \code{MeanMotion} calculates the mean motion required to produce an orbit
#' with a specified altitude and eccentricity
#'
#' @param altitude scalar mean altitude above the WGS84
#' (Word Geodetic System, 1984) ellipsoid (meters)
#' @param eccentricity orbital eccentricity
#'
#' @return mean motion (revs / day) required for the orbit
#' @export
MeanMotion <- function(
  altitude,
  eccentricity = 0
) {

  # constants
  mu <- 3.986004418e14  # Earth’s gravitational parameter [m^3/s^2]
  Re <- 6378000         # Earth radius [m]

  # Inputs to iterative inclination calculator
  a <- altitude + Re                          # Mean semimajor axis [m]
  h <- a * (1 - eccentricity^2)               # [m]
  n <- (mu/a^3)^0.5                           # Mean motion [radians s-1]
  mean_motion <- n * 60 * 60 * 24 / (2 * pi)  # Men motion [rev day-1]

  return(mean_motion)

}

#' Calculate the inclination required for a sun-synchronous orbit
#'
#' \code{SunSynchronousInclination} calculates the inclination required to
#' produce a sun-synchronous orbit with a specified altitude and eccentricity
#'
#' @param altitude scalar mean altitude above the WGS84
#' (Word Geodetic System, 1984) ellipsoid (meters)
#' @param eccentricity orbital eccentricity
#' @param tol error tolerance
#'
#' @return inclination (radians) of the sun-synchronous orbit
#'
#' @export
SunSynchronousInclination <- function(
  altitude,
  eccentricity = 0,
  tol = 1e-10
) {

  # constants
  mu <- 3.986004418e14  # Earth’s gravitational parameter [m^3/s^2]
  Re <- 6378000         # Earth radius [m]
  J2 <- 0.0010826269    # Second zonal gravity harmonic of the Earth
  we <- 1.99106e-7      # Mean motion of the Earth around the Sun [rad/s]

  a <- altitude + Re              # Mean semimajor axis [m]
  h <- a * (1 - eccentricity^2)   # [m]
  n <- (mu/a^3)^0.5               # Mean motion [s-1]

  # Initial guess for the  inclination
  inc_0 <- acos(-(2/3) * (h/Re)^2 * we/(n * J2))
  err <- 1e1
  while (err >= tol) {
    # J2 perturbed mean motion
    np  <- n*(1 + 1.5 * J2 * (Re/h)^2 *
                (1 - eccentricity^2)^0.5 * (1 - 3/2*sin(inc_0)^2))
    inc <- acos(-(2/3) * (h/Re)^2 * we/(np*J2))
    err <- abs(inc - inc_0)
    inc_0 <- inc
  }

  return(inc)

}

# CCSDS OEM Files ----

#' Read a CCSDS OEM File
#'
#' The Consultative Committee for Space Data Systems (CCSDS) Orbit Ephemeris
#' Message (OEM) file is a standard file format used for simulations of
#' spacecraft ephemera and associated metadata. This function converts a
#' CCSDS OEM file into a list with metadata and a data.frame of the spacecraft
#' ephemeris that can be passed to the msatR SpacecraftState function.
#'
#' @param ccsds_oem_file character string pointing to a Consultative Committee
#'   for Space Data Systems (CCSDS) Orbit Ephemeris Message (OEM) file.
#' @return A list with elements:
#'  $metadata
#'    a list with elements:
#'  $ephemeris
#'   | name | description |
#'   | --- | --- |
#'   | utc | UTC (Universal Coordinated Time) formatted fur \code{lubridate::ymd_hms} |
#'   | pos_eci | data.frame of the spacecraft position in meters ECI (Earth-Centered Inertial) |
#'   | vel_eci | data.frame of the spacecraft velocity in meters per second ECI |
#'
#' @family norad tle functions
#' @export
ReadCcsdsOem <- function(ccsds_oem_file) {

  # Metadata is contained as character strings in the first lines of the file.
  # Without warning, the file transitions to the ephemeris.
  # The ephemeris is the first line that starts with a numeric.

  # Initialize the metadata
  metadata <- list()
  # Scan the file as character strings
  ccsds_oem_txt <-
    scan(
      file = ccsds_oem_file,
      what = "character",
      sep = "\n",
      blank.lines.skip = FALSE
    )

  # Extract Metadata
  meta <-
    ccsds_oem_txt[
      (which(stringr::str_detect(ccsds_oem_txt, "META_START")) + 1):
      (which(stringr::str_detect(ccsds_oem_txt, "META_STOP")) - 1)
    ]
  meta_names <-
    sapply(
      meta,
      function(x) {unlist(stringr::str_split(x, " ", n = 2))[1]}
    ) %>%
    as.vector()
  meta_values <-
    sapply(
      meta,
      function(x) {unlist(stringr::str_split(x, "= "))[2]}
    ) %>%
    as.vector()
  metadata <- as.list(meta_values)
  names(metadata) <- meta_names

  # Extract comments
  metadata$COMMENT <-
    ccsds_oem_txt[stringr::str_detect(ccsds_oem_txt, "COMMENT")] %>%
    stringr::str_remove("COMMENT ")

  # Detect the first line of the
  ephemeris_line <-
    min(which(stringr::str_detect(substr(ccsds_oem_txt, 1, 1), "[0-9]")))

  # Read the ephemeris as a data.frame with grouped pos_eci and vel_eci
  ephemeris_raw <-
    utils::read.table(
      ccsds_oem_file,
      skip = ephemeris_line - 1,
      header = FALSE
    )
  ephemeris <-
    data.frame(
      UTC = Iso8601FromUtc(lubridate::ymd_hms(ephemeris_raw[,1]))
    )
  # Note that the pos_eci and vel_eci in the CCSDS OEM format are in kilometers
  # We want them in meters to maintain SI units, so we multiply by 1000
  ephemeris$pos_eci <-
    data.frame(
      x = ephemeris_raw[,2] * 1000,
      y = ephemeris_raw[,3] * 1000,
      z = ephemeris_raw[,4] * 1000
    )
  ephemeris$vel_eci <-
    data.frame(
      x = ephemeris_raw[,5] * 1000,
      y = ephemeris_raw[,6] * 1000,
      z = ephemeris_raw[,7] * 1000
    )

  # Return the metadata and the ephemeris as a list
  output <-
    list(
      metadata = metadata,
      ephemeris = ephemeris
    )

}

#' Write a CCSDS OEM File
#'
#' The Consultative Committee for Space Data Systems (CCSDS) Orbit Ephemeris
#' Message (OEM) file is a standard file format used for simulations of
#' spacecraft ephemera and associated metadata. This function writes a
#' spacecraft ephemeris to a CCSDS OEM file. It is useful for reformatting the
#' output of a file written by the Python SGP4 API, which is used in mission
#' simulations.
#'
#' There are hard-coded metadata values that mimic the metadata provided
#' by a Rocket Lab generated ephemeris.
#'
#' @param utc vector of UTC (Universal Coordinated Time) dates in POSIX
#'   (Portable Operating System Interface) format
#' @param pos_eci vector, matrix, or data.frame with 3 columns of the
#'   position in meters Earth-Centered Inertial
#' @param vel_eci vector, matrix, or data.frame with 3 columns of the
#'   position in meters Earth-Centered Inertial
#' @param ccsds_oem_file character string pointing to a Consultative Committee
#'   for Space Data Systems (CCSDS) Orbit Ephemeris Message (OEM) file to save.
#'
#' @return A list with elements:
#'  $metadata
#'    a list with elements:
#'  $ephemeris
#'   | name | description |
#'   | --- | --- |
#'   | utc | UTC (Universal Coordinated Time) formatted fur \code{lubridate::ymd_hms} |
#'   | pos_eci | data.frame of the spacecraft position in meters ECI (Earth-Centered Inertial) |
#'   | vel_eci | data.frame of the spacecraft velocity in meters per second ECI |
#'  A byproduct is that the ccsds_oem_file is saved.
#'
#' @family norad tle functions
#' @export
WriteCcsdsOem <- function(
    utc,
    pos_eci,
    vel_eci,
    ccsds_oem_file
) {

  # Write the header
  oem_header <- c(
    "CCSDS_OEM_VERS = 2.0",
    "",
    "COMMENT Orbit data are consistent with planetary ephemeris DE-430",
    "",
    paste0("CREATION_DATE  = ", Iso8601FromUtc(Sys.time())),
    "ORIGINATOR     = MSAT LLC",
    "",
    "META_START",
    "OBJECT_NAME          = MethaneSAT",
    "OBJECT_ID            = 2020-000A",
    "CENTER_NAME          = Earth",
    "REF_FRAME            = EME2000",
    "TIME_SYSTEM          = UTC",
    paste0("START_TIME           = ", min(utc)),
    paste0("USEABLE_START_TIME   = ", min(utc)),
    paste0("USEABLE_STOP_TIME    = ", min(utc)),
    paste0("STOP_TIME            = ", min(utc)),
    "INTERPOLATION        = Lagrange",
    "INTERPOLATION_DEGREE = 5",
    "META_STOP",
    "",
    "COMMENT Vehicle's position at any requested time was actually computed using an algorithm, not an interpolation of a table of ephemeris.",
    ""
  )
  cat(oem_header, file = ccsds_oem_file, sep = "\n")

  # Reformat the ephemeris to the CCSDS OEM format
  # Note that CCSDS format uses kilometers - divide by 1000
  ephemeris <-
    data.frame(
      utc = Iso8601FromUtc(utc),
      pos_x_char = format(pos_eci$x / 1000, scientific = TRUE, digits = 16),
      pos_y_char = format(pos_eci$y / 1000, scientific = TRUE, digits = 16),
      pos_z_char = format(pos_eci$z / 1000, scientific = TRUE, digits = 16),
      vel_x_char = format(vel_eci$x / 1000, scientific = TRUE, digits = 16),
      vel_y_char = format(vel_eci$y / 1000, scientific = TRUE, digits = 16),
      vel_z_char = format(vel_eci$z / 1000, scientific = TRUE, digits = 16)
    )

  # Write the file
  utils::write.table(
    ephemeris,
    ccsds_oem_file,
    row.names = FALSE,
    col.names = FALSE,
    quote = FALSE,
    sep = "  ",
    append = TRUE
  )

  # Read the file to return
  ccsds_oem <- ReadCcsdsOem(ccsds_oem_file)

  return(ccsds_oem)

}
