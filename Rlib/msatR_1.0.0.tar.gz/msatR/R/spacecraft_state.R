# Spacecraft state functions

# These functions work with the spacecraft state, which is the core
# object of science planning. The spacecraft state is a 1 Hz time series of
# the variables relevant to the spacecraft, including time, the
# orientation of the Earth with respect to the inertial frame, the spacecraft
# position and velocity, the sun position, the moon position,
# the spacecraft attitude the revolution number, the eclipse status,
# tracking of constraints, tracking of data management, and a real-time
# record of the activity schedule parameters needed to produce the scheduled
# activities.

# This code includes functions that initialize a spacecraft state,
# integrate activities into a spacecraft state, extract the vectors pointing
# along components of the bus (e.g., instrument boresight, radiator normal),
# test constraints, generate activity schedules and data management schedules.

# The functions in this code are complicated and computationally expesive
# and so unit tests are not provided. However, the code has been extensively
# tested in collaboration with Ball Aerospace and Bill Preetz of Ubiquity
# Robotics.

#' Read a groundstations file
#'
#' The groundstations file is a .json file that contains information about the
#' groundstations and antennas used for MethaneSAT downlinks. This function
#' reads that file and processes it to the groundstations and
#' groundstation_antennas objects used in the ActivityDownlink function.
#'
#' @param ground_configuration_file character string pointing to a
#'  ground configuration file produced by Rocket Lab and described in detail in
#'  the MOS-MP ICD.
#'
#' @return A list with elements:
#'  $filename
#'  $bus
#'  $constraints
#'  $scanning
#'  $instrument
#'  $data_management:List
#'  $downlink
#'  $ground_stations
#'   | name | description |
#'   | name | Station name |
#'   | geodetic | data.frame of geodetic coordinates (lon, lat, and alt ( in mabove WGS84) |
#'   | ecef | data.frame of Earth-Centered Earth-Fixed coordinates |
#'  $ground_station_antennas
#'   | name | description |
#'   | id | KSAT antenna id code |
#'   | name | Station name |
#'   | dishsize | Size of dish in meters |
#'   | band | Downlink bands |
#'   | geodetic | data.frame of geodetic coordinates (lon, lat, and alt ( in mabove WGS84))|
#'   | ecef | data.frame of Earth-Centered Earth-Fixed coordinates|
#'
#' @family spacecraft state functions
#' @export
ReadGroundConfiguration <- function(
    ground_configuration_file
) {

  # Read the ground stations file
  ground_configuration <-
    jsonlite::read_json(
      ground_configuration_file,
      simplifyVector = TRUE
    )

  # The ground station antennas requires additional information about the
  # location of the antennas in Earth-Centered Earth-Fixed coordinates.

  # Initialize the ground station antennas
  ground_station_antennas <-
    data.frame(
      id = ground_configuration$ground_stations$system,
      name = ground_configuration$ground_stations$station,
      band = ground_configuration$ground_stations$band
    )
  ground_station_antennas$geodetic <-
    data.frame(
      lon = as.numeric(ground_configuration$ground_stations$longitude),
      lat = as.numeric(ground_configuration$ground_stations$latitude),
      alt = as.numeric(ground_configuration$ground_stations$altitude)
    )

  # Filter out any TBD's
  ground_station_antennas <-
    dplyr::filter(
      ground_station_antennas,
      !is.na(geodetic$lon)
    )

  # Calculate the ECEF coordinates
  ground_station_antennas$ecef <-
    msatR::EcefFromGeodetic(
      geodetic =
        data.frame(
          lon = ground_station_antennas$geodetic$lon,
          lat = ground_station_antennas$geodetic$lat,
          alt = ground_station_antennas$geodetic$alt
        )
    )

  # Compute ground stations
  ground_stations <-
    data.frame(
      name = ground_station_antennas$name %>% unique() %>% sort()
    )
  ground_stations$geodetic =
    data.frame(
      lon =
        ground_station_antennas %>%
        dplyr::group_by(name) %>%
        dplyr::summarize(lon = mean(geodetic$lon, na.rm=TRUE)) %>%
        dplyr::select(lon),
      lat =
        ground_station_antennas %>%
        dplyr::group_by(name) %>%
        dplyr::summarize(lat = mean(geodetic$lat, na.rm=TRUE)) %>%
        dplyr::select(lat),
      alt =
        ground_station_antennas %>%
        dplyr::group_by(name) %>%
        dplyr::summarize(alt = mean(geodetic$alt, na.rm=TRUE)) %>%
        dplyr::select(alt) %>%
        "*"(1000)
    )
  ground_stations$ecef <-
    msatR::EcefFromGeodetic(
      geodetic = ground_stations$geodetic
    )

  ground_configuration$ground_stations <- ground_stations
  ground_configuration$ground_station_antennas <- ground_station_antennas

  return(ground_configuration)

}

#' Calculate spacecraft component vectors from spacecraft attitude
#'
#' \code{ComponentAttitudes} computes the attitude vectors of the spacecraft
#' components (instrument, thruster, solar panel drive axis, radiator normal,
#' reuben's plane normal, x-band antenna). The components are
#' contained in the spacecraft_configuration input
#' (see e.g., ground_configuration in the package data) in the body frame.
#' This function converts these into the frame of the spacecraft attitude
#' given in the attitude_quaternion object (e.g., Earth-Centered Inertial (ECI)
#' or Earth-Centered Earth-Fixed (ECEF)).
#'
#' @param spacecraft_configuration a list containing configuration data for the
#'   spacecraft. The default is saved in package data as
#'   \code{ground_configuration} and contains initial information about
#'   MethaneSAT. See the data documentation for \code{ground_configuration}
#'   for more detail.
#' @param attitude_quaternion data.frame of attitudes with columns:
#'
#'   | column | description |
#'   | --- | --- |
#'   | r | numeric real component of the quaternion |
#'   | i1 | numeric first imaginary component of quaternion |
#'   | i2 | numeric second imaginary component of quaternion |
#'   | i3 | numeric third imaginary component of quaternion |
#'
#' @return a list of data.frames of vectors with elements:
#'
#'   | element | description |
#'   | --- | --- |
#'   | instrument | points along instrument boresight |
#'   | instrument_left | points along instrument left edge |
#'   | instrument_right | points along instrument right edge |
#'   | thruster | points along thruster |
#'   | solarpanel_driveaxis | points along solar panel drive axis |
#'   | radiator | points along radiator normal |
#'   | reubensplane | points along Reuben's plane normal |
#'   | xband_antenna | points along X-band antenna boresight |
#'
#' @family spacecraft state functions
#' @export
ComponentAttitudes <- function(
    spacecraft_configuration = ground_configuration,
    attitude_quaternion
) {

  # Each component is a linear combination of the basis vectors of the
  # spacecraft body frame. We calculate them here.
  attitude_basisvectors <- BasisVectorsFromQuaternions(attitude_quaternion)

  # Most components are calculated at the time when the output is constructed.
  # The instrument boresight is calculated separately here since it is used
  # to calculate the instrument left and right sides via rotation.
  instrument_boresight <-
    spacecraft_configuration$bus$instrument[1] *
    attitude_basisvectors$x_hat +
    spacecraft_configuration$bus$instrument[2] *
    attitude_basisvectors$y_hat +
    spacecraft_configuration$bus$instrument[3] *
    attitude_basisvectors$z_hat
  instrument_boresight_left <-
    RotateVectorR3(
      vec = instrument_boresight,
      rotation_axis = attitude_basisvectors$x_hat,
      angle = (pi / 180) * spacecraft_configuration$instrument$fov_deg / 2
    )
  instrument_boresight_right <-
    RotateVectorR3(
      vec = instrument_boresight,
      rotation_axis = attitude_basisvectors$x_hat,
      angle = - (pi / 180) * spacecraft_configuration$instrument$fov_deg / 2
    )

  # Calculate the vectors for each component
  output <- list(
    instrument = instrument_boresight,
    instrument_left = instrument_boresight_left,
    instrument_right = instrument_boresight_right,
    thruster =
      spacecraft_configuration$bus$thruster[1] *
        attitude_basisvectors$x_hat +
      spacecraft_configuration$bus$thruster[2] *
        attitude_basisvectors$y_hat +
      spacecraft_configuration$bus$thruster[3] *
        attitude_basisvectors$z_hat,
    solarpanel_driveaxis =
      spacecraft_configuration$bus$solarpanel_driveaxis[1] *
        attitude_basisvectors$x_hat +
      spacecraft_configuration$bus$solarpanel_driveaxis[2] *
        attitude_basisvectors$y_hat +
      spacecraft_configuration$bus$solarpanel_driveaxis[3] *
        attitude_basisvectors$z_hat,
    radiator =
      spacecraft_configuration$bus$radiator[1] *
        attitude_basisvectors$x_hat +
      spacecraft_configuration$bus$radiator[2] *
        attitude_basisvectors$y_hat +
      spacecraft_configuration$bus$radiator[3] *
        attitude_basisvectors$z_hat,
    reubensplane =
      spacecraft_configuration$bus$reubensplane[1] *
        attitude_basisvectors$x_hat +
      spacecraft_configuration$bus$reubensplane[2] *
        attitude_basisvectors$y_hat +
      spacecraft_configuration$bus$reubensplane[3] *
        attitude_basisvectors$z_hat,
    xband_antenna =
      spacecraft_configuration$bus$xband_antenna[1] *
        attitude_basisvectors$x_hat +
      spacecraft_configuration$bus$xband_antenna[2] *
        attitude_basisvectors$y_hat +
      spacecraft_configuration$bus$xband_antenna[3] *
        attitude_basisvectors$z_hat
  )

  return(output)

}

#' Check constraints for a spacecraft attitude profile.
#'
#' \code{CheckConstraints} checks the constraints for a spacecraft_state.
#' The function checks the sun to instrument, sun to radiator,
#' earth to radiator, solar panel power, angular velocity, and angular
#' acceleration. It includes flags for sun, earth, and agility failures.
#' Note that the spacecraft_state must have at least 3 rows and
#' regularly spaced time, or else the angular velocity and acceleration will
#' fail and the function will return an error.
#'
#' @param spacecraft_state initial spacecraft state object. See documentation
#'   for the function \code{SpacecraftState} for more information.
#' @param spacecraft_configuration a list containing configuration data for the
#'   spacecraft. The default is saved in package data as
#'   \code{ground_configuration} and contains initial information about
#'   MethaneSAT. See the data documentation for \code{ground_configuration}
#'   for more detail.
#' @param verbose logical - if TRUE (FALSE is default) then print violations
#'
#' @return a data.frame with columns:
#'
#'   | column | description |
#'   | --- | --- |
#'   | sun_to_instrument | angle between sun and instrument boresight |
#'   | sun_to_radiator | angle between sun and radiator normal |
#'   | sun_to_reubensplane | angle between sun and Reuben's plane normal |
#'   | sun_violation | logical - if TRUE, then sun violation |
#'   | earth_to_radiator | angle between nadir and radiator normal |
#'   | earth_to_reubensplane | angle between nadir and Reuben's plane normal |
#'   | earth_violation | logical - if TRUE, then earth violation |
#'   | power_factor | fraction of the maximum power that can be produced |
#'   | angular_velocity | data.frame of spacecraft angular velocity |
#'   | angular_acceleration | data.frame of spacecraft angular acceleration |
#'   | agility_violation | logical - if TRUE, then agility violation |
#'
#' @family spacecraft state functions
#' @export
CheckConstraints <- function(
    spacecraft_state,
    spacecraft_configuration = ground_configuration,
    verbose = FALSE
) {

  # This code calculates vectors describing the attitude of each component
  # of the bus, then calculates the angles between select components and
  # the sun and/or earth, as well as the angular velocity and acceleration.

  # Prepare short forms of the constraints for readability
  constraint_sun_to_instrument <-
    pi / 180 *
    spacecraft_configuration$constraints$sun_to_instrument_deg
  constraint_sun_to_radiator <-
    pi / 180 *
    spacecraft_configuration$constraints$sun_to_radiator_deg
  constraint_sun_to_reubensplane <-
    pi / 180 *
    spacecraft_configuration$constraints$sun_to_reubensplane_deg
  constraint_earth_to_radiator <-
    pi / 180 *
    spacecraft_configuration$constraints$earth_to_radiator_deg
  constraint_earth_to_reubensplane <-
    pi / 180 *
    spacecraft_configuration$constraints$earth_to_reubensplane_deg
  constraint_angular_vel <-
    pi / 180 *
    spacecraft_configuration$constraints$angular_velocity_max_degps
  constraint_angular_accel <-
    pi / 180 *
    spacecraft_configuration$constraints$angular_acceleration_max_degps2

  # Get the component vectors
  component_attitudes <-
    ComponentAttitudes(
      spacecraft_configuration = spacecraft_configuration,
      attitude_quaternion = spacecraft_state$attitude_quaternion_eci
    )

  # Initialize the ouput as a data.frame with only UTC time,
  # then add columns as needed.
  output <-
    data.frame(
      utc = spacecraft_state$utc
    )

  # Sun Constraints

  # Measure the angle between the sun and relevant components
  output$sun_to_instrument =
    AngleBetweenVectors(
      u = spacecraft_state$sun_eci,
      v = component_attitudes$instrument
    )
  output$sun_to_radiator =
    AngleBetweenVectors(
      u = spacecraft_state$sun_eci,
      v = component_attitudes$radiator
    )
  output$sun_to_reubensplane =
    AngleBetweenVectors(
      u = spacecraft_state$sun_eci,
      v = component_attitudes$reubensplane
    )

  # A sun to instrument violation occurs when the sun ray is within X degrees
  # of the instrument boresight, where X is set in spacecraft_configuration.
  violation_sun_to_instrument <-
    output$sun_to_instrument < constraint_sun_to_instrument &
    !spacecraft_state$eclipse

  # A sun to radiator violation occurs when the ray from the apparent
  # position of the sun is within X degrees of both the radiator normal
  # and the Reuben's plane normal.
  # Where X is set in the spacecraft configuration.
  violation_sun_to_radiator <-
    output$sun_to_radiator < constraint_sun_to_radiator &
    output$sun_to_reubensplane < constraint_sun_to_reubensplane &
    !spacecraft_state$eclipse

  # The sun violation can be a sun-to-instrument or sun-to-radiator
  output$sun_violation <-
    violation_sun_to_instrument | violation_sun_to_radiator

  # Report sun violations to the user. This is important in some testing.
  if (any(output$sun_violation) & verbose) {
    warning("Sun Violation!")
  }

  # Earth Constraints

  # Measure the angle between nadir and relevant components
  output$earth_to_radiator <-
    AngleBetweenVectors(
      u = -spacecraft_state$pos_eci,
      v = component_attitudes$radiator
    )
  output$earth_to_reubensplane <-
    AngleBetweenVectors(
      u = -spacecraft_state$pos_eci,
      v = component_attitudes$reubensplane
    )

  # A Earth to radiator violation occurs when the ray from nadir is within X
  # degrees of both the radiator normal and the Reuben's plane normal.
  # Where X is set in the spacecraft configuration.
  violation_earth_to_radiator <-
    output$earth_to_radiator < constraint_earth_to_radiator &
    output$earth_to_reubensplane < constraint_earth_to_reubensplane

  # The earth violation is only earth-to-radiator
  output$earth_violation <- violation_earth_to_radiator

  # Report earth violations to the user. This is important in some testing.
  if (any(output$earth_violation) & verbose) {
    warning("Earth Violation!")
  }

  # The power factor is the cosine of the angle between the sun
  # and the normal plane to the solar panel drive axis, but is zero
  # when the spacecraft is in eclipse
  output$sun_to_solarpanel <-
    pi / 2 -
    AngleBetweenVectors(
      u = spacecraft_state$sun_eci,
      v = component_attitudes$solarpanel_driveaxis
    )
  output$power_factor <-
    cos(output$sun_to_solarpanel) * !spacecraft_state$eclipse

  # Agility Constraints

  # Measure the angular velocity and acceleration
  output$angular_velocity <-
    AngularVelocityFromQuaternions(
      q = spacecraft_state$attitude_quaternion_eci
    )
  output$angular_acceleration <-
    AngularAccelerationFromQuaternions(
      q = spacecraft_state$attitude_quaternion_eci
    )

  # An angular velocity violation is checked for each axis
  violation_angular_vel <-
    abs(output$angular_velocity$x) > constraint_angular_vel[1] |
    abs(output$angular_velocity$y) > constraint_angular_vel[2] |
    abs(output$angular_velocity$z) > constraint_angular_vel[3]

  # There will be a NA value at the end.
  # Set it to FALSE so that we don't report a violation.
  violation_angular_vel[is.na(violation_angular_vel)] <- FALSE

  # An angular acceleration violation occurs where
  # the angular acceleration about any axis is greater than its constraint
  violation_angular_accel <-
    abs(output$angular_acceleration$x) > constraint_angular_accel[1] |
    abs(output$angular_acceleration$y) > constraint_angular_accel[2] |
    abs(output$angular_acceleration$z) > constraint_angular_accel[3]

  # There will be a NA value at the beginning and end.
  # Set it to FALSE so that we don't report a violation.
  violation_angular_accel[is.na(violation_angular_accel)] <- FALSE

  # The agility violation can be an angular velocity or acceleration violation
  output$agility_violation <- violation_angular_vel | violation_angular_accel

  # Report agility violations to the user. This is important in some testing.
  if (any(output$agility_violation) & verbose) {
    warning("Agility Violation!")
  }

  return(output)

}

#' Initialize a spacecraft state with a pre-computed spacecraft ephemeris
#'
#' \code{SpacecraftState} will generate an initial spacecraft
#' state object associated with pre-computed spacecraft ephemeris.
#' The spacecraft state object is a data.frame containing a time series of
#' quantities that describe the position, velocity, attitude, constraint tests,
#' and informaiton needed to generate the activity and data management
#' schedules.
#'
#' The sun and moon ephemerides are computed using the Astronomical Almanac
#' algorithms. If you would like to supply external sun and moon ephemerides
#' please use the function \code{SpacecraftStateExternalSunMoon}.
#'
#' @param ephemeris a data.frame of the spacecraft ephemeris
#'   with the following columns:
#'
#'   | name | description |
#'   | --- | --- |
#'   | utc | UTC time formatted for \code{lubridate::ymd_hms} |
#'   | pos_eci_x | position x coordinate in kilometers ECI |
#'   | pos_eci_y | position y coordinate in kilometers ECI |
#'   | pos_eci_z | position z coordinate in kilometers ECI |
#'   | vel_eci_x | velocity x coordinate in kilometers per second ECI |
#'   | vel_eci_y | velocity y coordinate in kilometers per second ECI |
#'   | vel_eci_z | velocity z coordinate in kilometers per second ECI |
#'
#'   Notes: Ephemeris files in CCSDS format use kilometers, but all other
#'   objects in mission planning use meters to follow SI unit conventions.
#'   Definitions:
#'
#'   \itemize{
#'    \item{UTC: Universal Coordinated Time}
#'    \item{ECI: Earth-Centered Inertial Frame}
#'   }
#'
#' @param spacecraft_configuration a list containing configuration data for the
#'   spacecraft. The default is saved in package data as
#'   \code{ground_configuration} and contains initial information about
#'   MethaneSAT. See the data documentation for \code{ground_configuration}
#'   for more detail.
#' @param output_dir directory to save Earth orientation parameters
#'   (default "/tmp/")
#' @param bulletin character, either "A" for IERS bulletin A (default) or
#'   "B" for IERS bulletin B (default)
#' @param iers_file optional local IERS file. If NULL (default), then the file
#'   will be downloaded.
#' @param leap_seconds_file optional local IERS file. If NULL (default),
#'   then the file will be downloaded.
#' @param tle length-2 character string, with each element having 69 characters
#'   See https://en.wikipedia.org/wiki/Two-line_element_set for more info.
#' @param verbose logical (default FALSE) if TRUE, then the progress of the
#'   function is printed to screen. \code{SpacecraftState} is wall-clock
#'   intensive.
#'
#' @return a data.frame containing information about the the position,
#'   velocity, attitude, thermal, and power state of the spacecraft:
#'
#' \itemize{
#'   \item{utc: UTC time in POSIX format}
#'   \item{q_ei: unit quaternion rotating from ECI to ECEF}
#'   \item{pos_eci: spacecraft position (m ECI)}
#'   \item{pos_ecef: spacecraft position (m ECEF)}
#'   \item{pos_geodetic: spacecraft position (lon, lat, alt in m above WGS84)}
#'   \item{vel_eci: spacecraft velocity (m/s ECI)}
#'   \item{vel_ecef: spacecraft velocity (m/s ECEF)}
#'   \item{sun_eci: sun position (m ECI)}
#'   \item{sun_ecef: sun position (m ECEF)}
#'   \item{sun_geodetic: sub-solar point (lon, lat, alt in m above WGS84)}
#'   \item{moon_eci: moon position (m ECI)}
#'   \item{moon_ecef: moon position (m ECEF)}
#'   \item{eclipse: logical, if TRUE then the spacecraft is in eclipse}
#'   \item{rev: data.frame of revs since epoch}
#'   \itemize{
#'     \item{rev_ascending revs counted at the ascending node}
#'     \item{rev_descending revs counted at the descending node}
#'   }
#'   \item{attitude_quaternion_eci: attitude quaternion relative to ECI}
#'   \item{constraints: data.frame of spacecraft constraint variables and tests}
#'   \itemize{
#'     \item{sun_to_instrument: sun to instrument (rad)}
#'     \item{sun_to_radiator: sun to radiator normal (rad)}
#'     \item{sun_to_reubensplane: sun to Reuben's plane normal (rad)}
#'     \item{sun_violation: logical, sun violation}
#'     \item{earth_to_radiator: nadir to radiator normal (rad)}
#'     \item{earth_to_reubensplane: nadir to Reuben's plane normal (rad)}
#'     \item{earth_violation: logical, Earth violation}
#'     \item{power_factor: fraction of maximum power production possible}
#'     \item{angular_velocity: data.frame angular velocity (rad/s)}
#'     \item{angular_acceleration: data.frame angular acceleration (rad/s2)}
#'     \item{agility_violation: logical, agility violation}
#'   }
#'   \item{data_management: data.frame of data management state}
#'   \itemize{
#'     \item{superpages_used: integer number of superpages in use}
#'     \item{superpages_free: integer number of superpages available}
#'     \item{hsdr_used: numeric HSDR bytes in use}
#'     \item{hsdr_free: numeric HSDR bytes available}
#'   }
#'   \item{activity_schedule data.frame of activity schedule see MOS-MP ICD}
#'   \itemize{
#'     \item{utc: UTC time in POSIX format}
#'     \item{activity: character activity name}
#'     \item{TargX: numeric X component of target in ECEF}
#'     \item{TargY: numeric Y component of target in ECEF}
#'     \item{TargZ: numeric Z component of target in ECEF}
#'     \item{PriRefDir: character primary reference}
#'     \item{SecRefDir: character secondary reference}
#'     \item{PriCmdDir: character primary command}
#'     \item{SecCmdDir: character secondary command}
#'     \item{AttInterp: character primary command}
#'     \item{qTARGETwrtREF1: quaternion i1 component of target}
#'     \item{qTARGETwrtREF2: quaternion i2 component of target}
#'     \item{qTARGETwrtREF3: quaternion i3 component of target}
#'     \item{qTARGETwrtREF4: quaternion r component of target}
#'     \item{RateInterp: rate interpretation - always 1}
#'     \item{CmdRateX: X component of command frame rate (deg/s)}
#'     \item{CmdRateY: Y component of command frame rate (deg/s)}
#'     \item{CmdRateZ: Z component of command frame rate (deg/s)}
#'     \item{collectionID: character hexadecimal collection ID}
#'     \item{frameRate: numeric frame rate - 17.5 or 35 Hz}
#'     \item{window: character "science" or "calibration"}
#'     \item{LedDriveCurrent810nmCh4: 810 nm Ch4 channel drive current (mA)}
#'     \item{LedDriveCurrent1550nmCh4: 1550 nm Ch4 channel drive current (mA)}
#'     \item{LedDriveCurrent810nmO2: 810 nm O2 channel drive current (mA)}
#'     \item{LedDriveCurrent1550nmO2: 1550 nm O2 channel drive current (mA)}
#'     \item{stationName: character name of downlink station}
#'     \item{antennaID: character name of downlink antenna}
#'     \item{xBand: logical, TRUE if x band antenna is activated}
#'     \item{sBand: logical, TRUE if s band antenna is activated}
#'     \item{SPCount: integer count of superpages used by activity}
#'     \item{CCSDSBytes: numeric bytes of CCSDS used by activity}
#'     \item{PEBtoHSDR: numeric bytes transferred from PEB to HSDR}
#'     \item{DVBS2Bytes: numeric bytes transferred to DVBS2}
#'     \item{DownlinkTime: numeric time required to downlink}
#'   }
#' }
#'
#' Definitions:
#'
#' \itemize{
#'  \item{UTC: Universal Coordinated Time}
#'  \item{POSIX: Portable Operating System Interface}
#'  \item{ECI: Earth-Centered Inertial Frame}
#'  \item{ECEF: Earth-Centered Earth-Fixed Frame}
#'  \item{WGS84: World Geodetic System, 1984}
#'  \item{MOS-MP ICD: Mission Operation System to Mission Planning Interface
#'        Control Document}
#' }
#'
#' @family spacecraft state functions
#' @export
SpacecraftState <- function(
  ephemeris,
  spacecraft_configuration = ground_configuration,
  output_dir = "/tmp/",
  bulletin = "B",
  iers_file = NULL,
  leap_seconds_file = NULL,
  tle,
  verbose = FALSE
) {

  # Initialize with utc from ephemeris
  if (verbose) {
    cat("\nInitializing Spacecraft State\n")
  }
  spacecraft_state <-
    data.frame(
      utc = lubridate::ymd_hms(ephemeris$UTC)
    )

  # Initialize the activity
  spacecraft_state$activity <- "Cruise"
    # We may want to specify different tyoes of activities for the
    # attitude, instrument (i.e., turning on scanning) and the data management
    # (i.e., transferring data from the PEB to the HSDR). This will allow
    # us to plan consecutive activities that use different resources.
    # This is a TODO.
    #data.frame(
    #  attitude = rep(NA, nrow(spacecraft_state)),
    #  instrument = rep(NA, nrow(spacecraft_state)),
    #  data_management = rep(NA, nrow(spacecraft_state))
    #)

  # Get the Earth Orientation Parameters
  # There are two different sources of Earth Orientation Parameters:
  # Celestrak and IERS. We used to use Celestrak but have replaced this with
  # IERS since it is a more direct source.
  if (verbose) {
    cat("\nGetting Earth Orientation Parameters\n")
  }
  #spacecraft_state$eop <-
  #  GetEopCelestrak(
  #    utc = spacecraft_state$utc,
  #    output_dir = "/tmp/"
  #  )
  spacecraft_state$eop <-
    GetEopIERS(
      utc = spacecraft_state$utc,
      output_dir = output_dir,
      bulletin = bulletin,
      iers_file = iers_file,
      leap_seconds_file = leap_seconds_file
    )

  # Get the conversion from ECI to ECEF.
  # The quaternion inversion is needed since this is a directed cosine matrix,
  # not a rotation matrix.
  if (verbose) {
    cat("\nComputing Inertial to Earth-fixed Frame Conversion\n")
  }
  ecef_from_eci_mat <-
    RotationMatrices_EcefFromEci(eop = spacecraft_state$eop)
  spacecraft_state$q_ei <-
    ecef_from_eci_mat %>%
    QuaternionsFromRotationMatrices() %>%
    QuaternionInvert()

  # Get the position
  if (verbose) {
    cat("\nComputing Spacecraft Position\n")
  }
  spacecraft_state$pos_eci <-
    ephemeris$pos_eci
  spacecraft_state$pos_ecef <-
    EcefFromEci(
      eci = spacecraft_state$pos_eci,
      ecef_from_eci_matrices = ecef_from_eci_mat
    )
  spacecraft_state$pos_geodetic <-
    GeodeticFromEcef(spacecraft_state$pos_ecef)

  # Get the velocity
  if (verbose) {
    cat("\nComputing Spacecraft Velocity\n")
  }
  spacecraft_state$vel_eci <-
    ephemeris$vel_eci
  spacecraft_state$vel_ecef <-
    EcefFromEci(
      eci = spacecraft_state$vel_eci,
      ecef_from_eci_matrices = ecef_from_eci_mat
    )

  # Add sun position
  if (verbose) {
    cat("\nComputing Sun Position\n")
  }
  spacecraft_state$sun_eci <-
    SolarEphemeris(spacecraft_state$utc)
  spacecraft_state$sun_ecef <-
    EcefFromEci(
      eci = spacecraft_state$sun_eci,
      ecef_from_eci_matrices = ecef_from_eci_mat
    )
  spacecraft_state$sun_geodetic <-
    GeodeticFromEcef(spacecraft_state$sun_ecef)

  # Add moon position
  if (verbose) {
    cat("\nComputing Moon Position\n")
  }
  spacecraft_state$moon_eci <-
    LunarEphemeris(spacecraft_state$utc)
  spacecraft_state$moon_ecef <-
    EcefFromEci(
      eci = spacecraft_state$moon_eci,
      ecef_from_eci_matrices = ecef_from_eci_mat
    )

  # Detect eclipse
  if (verbose) {
    cat("\nDetecting Eclipse\n")
  }
  spacecraft_state$eclipse <-
    Eclipse(
      pos = spacecraft_state$pos_eci,
      sun = spacecraft_state$sun_eci
    )

  # Count the revs since epoch
  if (verbose) {
    cat("\nCounting Revs\n")
  }
  spacecraft_state$rev <-
    RevNumber(
      utc = spacecraft_state$utc,
      pos_eci = spacecraft_state$pos_eci,
      vel_eci = spacecraft_state$vel_eci,
      tle = tle
    )

  # Initialize attitude to cruise
  if (verbose) {
    cat("\nComputing Cruise Attitude\n")
  }
  spacecraft_state$attitude_quaternion_eci <-
    ActivityCruise(
      pos_eci = spacecraft_state$pos_eci,
      sun_eci = spacecraft_state$sun_eci
    )

  # Initialize constraints.
  # They are computed for real, but the cruise attitude should never violate.
  if (verbose) {
    cat("\nChecking Constraints\n")
  }
  spacecraft_state$constraints <-
    CheckConstraints(
      spacecraft_state = spacecraft_state,
      spacecraft_configuration = spacecraft_configuration,
      verbose = FALSE
    )

  # Initialize data management
  spacecraft_state$data_management <-
    data.frame(
      superpages_used = rep(0, nrow(spacecraft_state)),
      superpages_free =
        rep(
          spacecraft_configuration$data_management$superpages$number,
          nrow(spacecraft_state)
        ),
      hsdr_used = rep(0, nrow(spacecraft_state)),
      hsdr_free =
        rep(
          spacecraft_configuration$data_management$hsdr_storage$total_bytes,
          nrow(spacecraft_state)
        )
    )

  # Initialize the spacecraft activity data frame to cruise
  spacecraft_state$activity_schedule <-
    data.frame(
      utc = spacecraft_state$utc,
      activity = rep("Cruise", nrow(spacecraft_state)),
      TargX = rep(0, nrow(spacecraft_state)),
      TargY = rep(0, nrow(spacecraft_state)),
      TargZ = rep(0, nrow(spacecraft_state)),
      PriRefDir = rep(6, nrow(spacecraft_state)),
      SecRefDir = rep(3, nrow(spacecraft_state)),
      PriCmdDir = rep(6, nrow(spacecraft_state)),
      SecCmdDir = rep(4, nrow(spacecraft_state)),
      AttInterp = rep("Quaternion", nrow(spacecraft_state)),
      qTARGETwrtREF1 = rep(0, nrow(spacecraft_state)),
      qTARGETwrtREF2 = rep(0, nrow(spacecraft_state)),
      qTARGETwrtREF3 = rep(0, nrow(spacecraft_state)),
      qTARGETwrtREF4 = rep(1, nrow(spacecraft_state)),
      RateInterp = rep(1, nrow(spacecraft_state)),
      CmdRateX = rep(0, nrow(spacecraft_state)),
      CmdRateY = rep(0, nrow(spacecraft_state)),
      CmdRateZ = rep(0, nrow(spacecraft_state)),
      collectionID = rep(NA, nrow(spacecraft_state)),
      frameRate = rep(0, nrow(spacecraft_state)),
      window = rep(NA, nrow(spacecraft_state)),
      LedDriveCurrent810nmCh4 = rep(0, nrow(spacecraft_state)),
      LedDriveCurrent1550nmCh4 = rep(0, nrow(spacecraft_state)),
      LedDriveCurrent810nmO2 = rep(0, nrow(spacecraft_state)),
      LedDriveCurrent1550nmO2 = rep(0, nrow(spacecraft_state)),
      stationName = rep(NA, nrow(spacecraft_state)),
      antennaID = rep(NA, nrow(spacecraft_state)),
      xBand = rep(FALSE, nrow(spacecraft_state)),
      sBand = rep(FALSE, nrow(spacecraft_state)),
      thruster1 = rep(NA, nrow(spacecraft_state)),
      thruster2 = rep(NA, nrow(spacecraft_state)),
      thruster3 = rep(NA, nrow(spacecraft_state)),
      SPCount = rep(0, nrow(spacecraft_state)),
      CCSDSBytes = rep(0, nrow(spacecraft_state)),
      PEBtoHSDR = rep(0, nrow(spacecraft_state)),
      DVBS2Bytes = rep(0, nrow(spacecraft_state)),
      DownlinkTime = rep(0, nrow(spacecraft_state))
    )

  return(spacecraft_state)

}

#' Initialize a spacecraft state to pre-computed spacecraft, sun, and moon
#'
#' \code{SpacecraftStateFromEphemerides} will generate an initial spacecraft
#' state object associated with pre-computed spacecraft, sun, and moon
#' ephemeris. The spacecraft state object is a data.frame
#' containing a time series of quantities that describe the position, velocity,
#' attitude, constraint tests, and informaiton needed to generate the activity
#' and data management schedules.
#'
#' @param ephemeris_spacecraft a data.frame of the spacecraft ephemeris
#'   with the following columns:
#'
#'   | name | description |
#'   | --- | --- |
#'   | utc | UTC time formatted for \code{lubridate::ymd_hms} |
#'   | pos_eci$x | position x coordinate in kilometers ECI |
#'   | pos_eci$y | position y coordinate in kilometers ECI |
#'   | pos_eci$z | position z coordinate in kilometers ECI |
#'   | vel_eci$x | velocity x coordinate in kilometers per second ECI |
#'   | vel_eci$y | velocity y coordinate in kilometers per second ECI |
#'   | vel_eci$z | velocity z coordinate in kilometers per second ECI |
#'
#'   Notes: Ephemeris files in CCSDS format use kilometers, but all other
#'   objects in mission planning use meters to follow SI unit conventions.
#'   Definitions:
#'
#'   \itemize{
#'    \item{UTC: Universal Coordinated Time}
#'    \item{ECI: Earth-Centered Inertial Frame}
#'   }
#' @param ephemeris_sun a data.frame of the sun ephemeris
#'
#'   with the following columns:
#'   | name | description |
#'   | --- | --- |
#'   | utc | UTC time formatted for \code{lubridate::ymd_hms} |
#'   | pos_eci$x | position x coordinate in kilometers ECI |
#'   | pos_eci$y | position y coordinate in kilometers ECI |
#'   | pos_eci$z | position z coordinate in kilometers ECI |
#'
#'   Notes: Ephemeris files in CCSDS format use kilometers, but all other
#'   objects in mission planning use meters to follow SI unit conventions.
#'   Definitions:
#'
#'   \itemize{
#'    \item{UTC: Universal Coordinated Time}
#'    \item{ECI: Earth-Centered Inertial Frame}
#'   }
#'
#' @param ephemeris_moon a data.frame of the moon ephemeris
#'   with the following columns:
#'
#'   | name | description |
#'   | --- | --- |
#'   | utc | UTC time formatted for \code{lubridate::ymd_hms} |
#'   | pos_eci$x | position x coordinate in kilometers ECI |
#'   | pos_eci$y | position y coordinate in kilometers ECI |
#'   | pos_eci$z | position z coordinate in kilometers ECI |
#'
#' @param spacecraft_configuration a list containing configuration data for the
#'   spacecraft. The default is saved in package data as
#'   \code{ground_configuration} and contains initial information about
#'   MethaneSAT. See the data documentation for \code{ground_configuration}
#'   for more detail.
#' @param output_dir directory to save Earth orientation parameters
#'   (default "/tmp/")
#' @param bulletin character, either "A" for IERS bulletin A (default) or
#'   "B" for IERS bulletin B (default)
#' @param iers_file optional local IERS file. If NULL (default), then the file
#'   will be downloaded.
#' @param leap_seconds_file optional local IERS file. If NULL (default),
#'   then the file will be downloaded.
#' @param tle length-2 character string, with each element having 69 characters
#'   See https://en.wikipedia.org/wiki/Two-line_element_set for more info.
#' @param verbose logical (default FALSE) if TRUE, then the progress of the
#'   function is printed to screen. \code{SpacecraftState} is wall-clock
#'   intensive.
#'
#' @return a data.frame containing information about the the position,
#'   velocity, attitude, thermal, and power state of the spacecraft:
#'
#' \itemize{
#'   \item{utc: UTC time in POSIX format}
#'   \item{q_ei: unit quaternion rotating from ECI to ECEF}
#'   \item{pos_eci: spacecraft position (m ECI)}
#'   \item{pos_ecef: spacecraft position (m ECEF)}
#'   \item{pos_geodetic: spacecraft position (lon, lat, alt in m above WGS84)}
#'   \item{vel_eci: spacecraft velocity (m/s ECI)}
#'   \item{vel_ecef: spacecraft velocity (m/s ECEF)}
#'   \item{sun_eci: sun position (m ECI)}
#'   \item{sun_ecef: sun position (m ECEF)}
#'   \item{sun_geodetic: sub-solar point (lon, lat, alt in m above WGS84)}
#'   \item{moon_eci: moon position (m ECI)}
#'   \item{moon_ecef: moon position (m ECEF)}
#'   \item{eclipse: logical, if TRUE then the spacecraft is in eclipse}
#'   \item{rev: data.frame of revs since epoch}
#'   \itemize{
#'     \item{rev_ascending revs counted at the ascending node}
#'     \item{rev_descending revs counted at the descending node}
#'   }
#'   \item{attitude_quaternion_eci: attitude quaternion relative to ECI}
#'   \item{constraints: data.frame of spacecraft constraint variables and tests}
#'   \itemize{
#'     \item{sun_to_instrument: sun to instrument (rad)}
#'     \item{sun_to_radiator: sun to radiator normal (rad)}
#'     \item{sun_to_reubensplane: sun to Reuben's plane normal (rad)}
#'     \item{sun_violation: logical, sun violation}
#'     \item{earth_to_radiator: nadir to radiator normal (rad)}
#'     \item{earth_to_reubensplane: nadir to Reuben's plane normal (rad)}
#'     \item{earth_violation: logical, Earth violation}
#'     \item{power_factor: fraction of maximum power production possible}
#'     \item{angular_velocity: data.frame angular velocity (rad/s)}
#'     \item{angular_acceleration: data.frame angular acceleration (rad/s2)}
#'     \item{agility_violation: logical, agility violation}
#'   }
#'   \item{data_management: data.frame of data management state}
#'   \itemize{
#'     \item{superpages_used: integer number of superpages in use}
#'     \item{superpages_free: integer number of superpages available}
#'     \item{hsdr_used: numeric HSDR bytes in use}
#'     \item{hsdr_free: numeric HSDR bytes available}
#'   }
#'   \item{activity_schedule data.frame of activity schedule see MOS-MP ICD}
#'   \itemize{
#'     \item{utc: UTC time in POSIX format}
#'     \item{activity: character activity name}
#'     \item{TargX: numeric X component of target in ECEF}
#'     \item{TargY: numeric Y component of target in ECEF}
#'     \item{TargZ: numeric Z component of target in ECEF}
#'     \item{PriRefDir: character primary reference}
#'     \item{SecRefDir: character secondary reference}
#'     \item{PriCmdDir: character primary command}
#'     \item{SecCmdDir: character secondary command}
#'     \item{AttInterp: character primary command}
#'     \item{qTARGETwrtREF1: quaternion i1 component of target}
#'     \item{qTARGETwrtREF2: quaternion i2 component of target}
#'     \item{qTARGETwrtREF3: quaternion i3 component of target}
#'     \item{qTARGETwrtREF4: quaternion r component of target}
#'     \item{RateInterp: rate interpretation - always 1}
#'     \item{CmdRateX: X component of command frame rate (deg/s)}
#'     \item{CmdRateY: Y component of command frame rate (deg/s)}
#'     \item{CmdRateZ: Z component of command frame rate (deg/s)}
#'     \item{collectionID: character hexadecimal collection ID}
#'     \item{frameRate: numeric frame rate - 17.5 or 35 Hz}
#'     \item{window: character "science" or "calibration"}
#'     \item{LedDriveCurrent810nmCh4: 810 nm Ch4 channel drive current (mA)}
#'     \item{LedDriveCurrent1550nmCh4: 1550 nm Ch4 channel drive current (mA)}
#'     \item{LedDriveCurrent810nmO2: 810 nm O2 channel drive current (mA)}
#'     \item{LedDriveCurrent1550nmO2: 1550 nm O2 channel drive current (mA)}
#'     \item{stationName: character name of downlink station}
#'     \item{antennaID: character name of downlink antenna}
#'     \item{xBand: logical, TRUE if x band antenna is activated}
#'     \item{sBand: logical, TRUE if s band antenna is activated}
#'     \item{SPCount: integer count of superpages used by activity}
#'     \item{CCSDSBytes: numeric bytes of CCSDS used by activity}
#'     \item{PEBtoHSDR: numeric bytes transferred from PEB to HSDR}
#'     \item{DVBS2Bytes: numeric bytes transferred to DVBS2}
#'     \item{DownlinkTime: numeric time required to downlink}
#'   }
#' }
#'
#' Definitions:
#'
#' \itemize{
#'  \item{UTC: Universal Coordinated Time}
#'  \item{POSIX: Portable Operating System Interface}
#'  \item{ECI: Earth-Centered Inertial Frame}
#'  \item{ECEF: Earth-Centered Earth-Fixed Frame}
#'  \item{WGS84: World Geodetic System, 1984}
#'  \item{MOS-MP ICD: Mission Operation System to Mission Planning Interface
#'        Control Document}
#' }
#'
#' @family spacecraft state functions
#' @export
SpacecraftStateFromEphemerides <- function(
  ephemeris_spacecraft,
  ephemeris_sun,
  ephemeris_moon,
  spacecraft_configuration = ground_configuration,
  output_dir = "/tmp/",
  bulletin = "B",
  iers_file = NULL,
  leap_seconds_file = NULL,
  tle,
  verbose = FALSE
) {

  # Initialize with utc from ephemeris
  if (verbose) {
    cat("\nInitializing Spacecraft State\n")
  }
  spacecraft_state <-
    data.frame(
      utc = lubridate::ymd_hms(ephemeris_spacecraft$UTC)
    )
  # Initialize the activity
  spacecraft_state$activity <- "Cruise"
    # We may want to specify different tyoes of activities for the
    # attitude, instrument (i.e., turning on scanning) and the data management
    # (i.e., transferring data from the PEB to the HSDR). This will allow
    # us to plan consecutive activities that use different resources.
    # This is a TODO.
    #data.frame(
    #  attitude = rep(NA, nrow(spacecraft_state)),
    #  instrument = rep(NA, nrow(spacecraft_state)),
    #  data_management = rep(NA, nrow(spacecraft_state))
    #)

  # Get the Earth Orientation Parameters
  # There are two different sources of Earth Orientation Parameters:
  # Celestrak and IERS. We used to use Celestrak but have replaced this with
  # IERS since it is a more direct source.
  if (verbose) {
    cat("\nGetting Earth Orientation Parameters\n")
  }
  #spacecraft_state$eop <-
  #  GetEopCelestrak(
  #    utc = spacecraft_state$utc,
  #    output_dir = output_dir
  #  )
  spacecraft_state$eop <-
    GetEopIERS(
      utc = spacecraft_state$utc,
      output_dir = output_dir,
      bulletin = bulletin,
      iers_file = iers_file,
      leap_seconds_file = leap_seconds_file
    )
  # Get the conversion from ECI to ECEF.
  # The quaternion inversion is needed since this is a directed cosine matrix,
  # not a rotation matrix.
  if (verbose) {
    cat("\nComputing Inertial to Earth-fixed Frame Conversion\n")
  }
  ecef_from_eci_mat <-
    RotationMatrices_EcefFromEci(eop = spacecraft_state$eop)
  spacecraft_state$q_ei <-
    ecef_from_eci_mat %>%
    QuaternionsFromRotationMatrices() %>%
    QuaternionInvert()

  # Get the position
  if (verbose) {
    cat("\nComputing Spacecraft Position\n")
  }
  spacecraft_state$pos_eci <-
    ephemeris_spacecraft$pos_eci
  spacecraft_state$pos_ecef <-
    EcefFromEci(
      eci = spacecraft_state$pos_eci,
      ecef_from_eci_matrices = ecef_from_eci_mat
    )
  spacecraft_state$pos_geodetic <-
    GeodeticFromEcef(spacecraft_state$pos_ecef)

  # Get the velocity
  if (verbose) {
    cat("\nComputing Spacecraft Velocity\n")
  }
  spacecraft_state$vel_eci <-
    ephemeris_spacecraft$vel_eci
  spacecraft_state$vel_ecef <-
    EcefFromEci(
      eci = spacecraft_state$vel_eci,
      ecef_from_eci_matrices = ecef_from_eci_mat
    )

  # Add sun position
  if (verbose) {
    cat("\nComputing Sun Position\n")
  }
  spacecraft_state$sun_eci <-
    data.frame(
      ephemeris_sun$sun_eci_x,
      ephemeris_sun$sun_eci_y,
      ephemeris_sun$sun_eci_z
    )
  spacecraft_state$sun_ecef <-
    EcefFromEci(
      eci = spacecraft_state$sun_eci,
      ecef_from_eci_matrices = ecef_from_eci_mat
    )
  spacecraft_state$sun_geodetic <-
    GeodeticFromEcef(spacecraft_state$sun_ecef)

  # Add moon position
  if (verbose) {
    cat("\nComputing Moon Position\n")
  }
  spacecraft_state$moon_eci <-
    data.frame(
      ephemeris_moon$moon_eci_x,
      ephemeris_moon$moon_eci_y,
      ephemeris_moon$moon_eci_z
    )
  spacecraft_state$moon_ecef <-
    EcefFromEci(
      eci = spacecraft_state$moon_eci,
      ecef_from_eci_matrices = ecef_from_eci_mat
    )
  # Detect eclipse
  if (verbose) {
    cat("\nDetecting Eclipse\n")
  }
  spacecraft_state$eclipse <-
    Eclipse(
      pos = spacecraft_state$pos_eci,
      sun = spacecraft_state$sun_eci
    )

  # Count the revs since epoch
  if (verbose) {
    cat("\nCounting Revs\n")
  }
  spacecraft_state$rev <-
    RevNumber(
      utc = spacecraft_state$utc,
      pos_eci = spacecraft_state$pos_eci,
      vel_eci = spacecraft_state$vel_eci,
      tle = tle
    )

  # Initialize attitude to cruise
  if (verbose) {
    cat("\nComputing Cruise Attitude\n")
  }
  spacecraft_state$attitude_quaternion_eci <-
    ActivityCruise(
      pos_eci = spacecraft_state$pos_eci,
      sun_eci = spacecraft_state$sun_eci
    )
  # Initialize constraints.
  # They are computed for real, but the cruise attitude should never violate.
  if (verbose) {
    cat("\nChecking Constraints\n")
  }
  spacecraft_state$constraints <-
    CheckConstraints(
      spacecraft_state = spacecraft_state,
      spacecraft_configuration = spacecraft_configuration,
      verbose = FALSE
    )

  # Initialize data management
  spacecraft_state$data_management <-
    data.frame(
      superpages_used = rep(0, nrow(spacecraft_state)),
      superpages_free =
        rep(
          spacecraft_configuration$data_management$superpages$number,
          nrow(spacecraft_state)
        ),
      hsdr_used = rep(0, nrow(spacecraft_state)),
      hsdr_free =
        rep(
          spacecraft_configuration$data_management$hsdr_storage$total_bytes,
          nrow(spacecraft_state)
        )
    )
  # Initialize the spacecraft activity data frame to cruise
  spacecraft_state$activity_schedule <-
    data.frame(
      utc = spacecraft_state$utc,
      activity = rep("Cruise", nrow(spacecraft_state)),
      TargX = rep(0, nrow(spacecraft_state)),
      TargY = rep(0, nrow(spacecraft_state)),
      TargZ = rep(0, nrow(spacecraft_state)),
      PriRefDir = rep("Pos", nrow(spacecraft_state)),
      SecRefDir = rep("Sun", nrow(spacecraft_state)),
      PriCmdDir = rep("-Z", nrow(spacecraft_state)),
      SecCmdDir = rep("-X", nrow(spacecraft_state)),
      AttInterp = rep("Quaternion", nrow(spacecraft_state)),
      qTARGETwrtREF1 = rep(0, nrow(spacecraft_state)),
      qTARGETwrtREF2 = rep(0, nrow(spacecraft_state)),
      qTARGETwrtREF3 = rep(0, nrow(spacecraft_state)),
      qTARGETwrtREF4 = rep(1, nrow(spacecraft_state)),
      RateInterp = rep(1, nrow(spacecraft_state)),
      CmdRateX = rep(0, nrow(spacecraft_state)),
      CmdRateY = rep(0, nrow(spacecraft_state)),
      CmdRateZ = rep(0, nrow(spacecraft_state)),
      collectionID = rep(NA, nrow(spacecraft_state)),
      frameRate = rep(0, nrow(spacecraft_state)),
      window = rep(NA, nrow(spacecraft_state)),
      LedDriveCurrent810nmCh4 = rep(0, nrow(spacecraft_state)),
      LedDriveCurrent1550nmCh4 = rep(0, nrow(spacecraft_state)),
      LedDriveCurrent810nmO2 = rep(0, nrow(spacecraft_state)),
      LedDriveCurrent1550nmO2 = rep(0, nrow(spacecraft_state)),
      stationName = rep(NA, nrow(spacecraft_state)),
      antennaID = rep(NA, nrow(spacecraft_state)),
      xBand = rep(FALSE, nrow(spacecraft_state)),
      sBand = rep(FALSE, nrow(spacecraft_state)),
      thruster1 = rep(NA, nrow(spacecraft_state)),
      thruster2 = rep(NA, nrow(spacecraft_state)),
      thruster3 = rep(NA, nrow(spacecraft_state)),
      SPCount = rep(0, nrow(spacecraft_state)),
      CCSDSBytes = rep(0, nrow(spacecraft_state)),
      PEBtoHSDR = rep(0, nrow(spacecraft_state)),
      DVBS2Bytes = rep(0, nrow(spacecraft_state)),
      DownlinkTime = rep(0, nrow(spacecraft_state))
    )

  return(spacecraft_state)

}

#' Update the spacecraft state based on an attitude profile of an activity
#'
#' @param spacecraft_state initial spacecraft state object. See documentation
#'   for the function \code{SpacecraftState} for more information.
#' @param spacecraft_configuration a list containing configuration data for the
#'   spacecraft. The default is saved in package data as
#'   \code{ground_configuration} and contains initial information about
#'   MethaneSAT. See the data documentation for \code{ground_configuration}
#'   for more detail.
#' @param attitude_quaternion_eci data.frame of attitudes with columns
#'
#'   | column | description |
#'   | --- | --- |
#'   | r | numeric r component of the attitude quaternion in ECI |
#'   | i1 | numeric i1 component of the attitude quaternion in ECI |
#'   | i2 | numeric i2 component of the attitude quaternion relative to ECI |
#'   | i3 | numeric i3 component of the attitude quaternion relative to ECI |
#'
#'   Note: Number of rows must equal length of utc.
#'
#' @param activity_schedule character name of the activity being added
#' @param verbose logical - if TRUE (FALSE is default) then print updates
# @param slew_delay extra time to delay the slew to activity
#'
#' @return an updated spacecraft state object. See documentation for
#'   \code{SpacecraftState} for details.
#'
#' @family spacecraft state functions
#' @export
SpacecraftStateAddActivity <- function(
  spacecraft_state,
  spacecraft_configuration,
  attitude_quaternion_eci,
  activity_schedule,
  #slew_delay = 0,
  verbose = FALSE
) {

  # Make a dummy spacecraft_state to return if the addition fails
  spacecraft_state_dummy <- spacecraft_state

  # Find the indices to update the activity.
  # The attitude_quaternion_eci input should have row numbers corresponding
  # to the rows of the spacecraft_state, but this is a more flexible and
  # resilient way to find which indices to update.
  inds_update <- which(spacecraft_state$utc %in% attitude_quaternion_eci$utc)

  # Update the activity schedule and activity name
  if (!is.null(activity_schedule)) {
    spacecraft_state$activity_schedule[inds_update, ] <- activity_schedule
    spacecraft_state$activity[inds_update] <- activity_schedule$activity
  }

  # Update the attitude
  spacecraft_state$attitude_quaternion_eci[inds_update, ] <-
    dplyr::select(attitude_quaternion_eci, r, i1, i2, i3)
  spacecraft_state$attitude_quaternion_eci <-
    QuaternionRectify(spacecraft_state$attitude_quaternion_eci)

  # Slews

  # Find the slew to the activity from cruise or the next closest activity.
  # If you can't get to the activity, then return the dummy spacecraft state.

  # Get an estimate of the lower limit of the time to slew to cruise -
  t_slew_to_estimate <-
    SlewSlerpTime(
      q_0 = spacecraft_state$attitude_quaternion_eci[min(inds_update) - 1, ],
      q_k = spacecraft_state$attitude_quaternion_eci[min(inds_update), ],
      spacecraft_configuration = spacecraft_configuration
    ) %>%
    floor()

  inds_slew_to_estimate <-
    (min(inds_update) - t_slew_to_estimate - 1):(min(inds_update) - 1)

  # If there is nowhere to slew from,
  # then we have run out of time. Return NULL
  if (any(inds_slew_to_estimate <= 0)) {
    if (verbose) {
      warning("Slew to failed!")
    }
    return(spacecraft_state_dummy)
  }

  # This block ensures that the spacecraft can only slew from slew to the
  # new cativity. TODO: This should be replaced.
  if (any(spacecraft_state$activity[inds_slew_to_estimate] != "Cruise")) {
    t_slew_to_estimate <-
      inds_update[1] -
      max(
        inds_slew_to_estimate[
          spacecraft_state$activity[inds_slew_to_estimate] != "Cruise"
        ]
      )
  }

  # Slew from cruise to activity
  t_slew_to <- t_slew_to_estimate
  flag <- TRUE
  while (flag) {

    # If there is nowhere to slew from,
    # then we have run out of time. Return NULL
    if (inds_update[1] - t_slew_to < 3) {
      if (verbose) {
        warning("Slew to failed!")
      }
      return(spacecraft_state_dummy)
    }

    # If we are attempting to slew into another slew,
    # then keep going back in time until you hit the previous activity
    if (spacecraft_state$activity[inds_update[1] - t_slew_to] == "Slew") {
      # Add a second of slew time
      t_slew_to <- t_slew_to + 1
      next()
    }

    # Calculate the slew to the candidate spacecraft state
    slew_to <-
      SlewRampCoastRamp(
        t_k = t_slew_to,
        q_0m1 =
          spacecraft_state$attitude_quaternion_eci[
            inds_update[1] - t_slew_to - 1,
          ],
        q_0 =
          spacecraft_state$attitude_quaternion_eci[
            inds_update[1] - t_slew_to,
          ],
        q_k = spacecraft_state$attitude_quaternion_eci[inds_update[1], ],
        q_kp1 = spacecraft_state$attitude_quaternion_eci[inds_update[1] + 1, ],
        spacecraft_configuration = spacecraft_configuration,
        verbose = FALSE
      )

    # If the slew failed, then length(slew_to) == 1
    # (it will be the character string "Maneuver Failed").
    if (length(slew_to) == 1) {

      # Add a second of slew time
      t_slew_to <- t_slew_to + 1

      # If we are slewing from a non-cruise activity,
      # then we have run out of time. Return NULL
      if (spacecraft_state$activity[inds_update[1] - t_slew_to] != "Cruise") {
        if (verbose) {
          warning("Slew to failed!")
        }
        return(spacecraft_state_dummy)
      }

    } else {
      flag <- FALSE
      # If the slew to has succeeded, then add the slew_delay
      # t_slew_to <- t_slew_to + slew_delay
      # slew_to <-
      #   SlewRampCoastRamp(
      #     t_k = t_slew_to,
      #     q_0m1 =
      #       spacecraft_state$attitude_quaternion_eci[
      #         inds_update[1] - t_slew_to - 1,
      #       ],
      #     q_0 =
      #       spacecraft_state$attitude_quaternion_eci[
      #         inds_update[1] - t_slew_to,
      #       ],
      #     q_k = spacecraft_state$attitude_quaternion_eci[inds_update[1], ],
      #     q_kp1 = spacecraft_state$attitude_quaternion_eci[inds_update[1] + 1, ],
      #     spacecraft_configuration = spacecraft_configuration,
      #     verbose = FALSE
      #   )

    }

  }

  # Insert the slew
  inds_slew_to <- (inds_update[1] - t_slew_to + 1):(inds_update[1] - 1)
  spacecraft_state$attitude_quaternion_eci[inds_slew_to, ] <- slew_to
  spacecraft_state$activity[inds_slew_to] <- "Slew"

  # Find the slew from the activity to cruise or the next closest activity.
  # If you can't get to the activity, return NULL
  t_slew_from_estimate <-
    SlewSlerpTime(
      q_0 = spacecraft_state$attitude_quaternion_eci[max(inds_update), ],
      q_k = spacecraft_state$attitude_quaternion_eci[max(inds_update) + 1, ],
      spacecraft_configuration = spacecraft_configuration
    ) %>%
    floor()

  inds_slew_from_estimate <-
    (max(inds_update) + 1):(max(inds_update) + t_slew_to_estimate)

  # This block ensures that the spacecraft can only slew from slew to the
  # new activity. TODO: This should be replaced.
  if (any(spacecraft_state$activity[inds_slew_from_estimate] != "Cruise")) {
    t_slew_from_estimate <-
      min(
        inds_slew_from_estimate[
          spacecraft_state$activity[inds_slew_from_estimate] != "Cruise"
        ]
      ) -
      max(inds_update) - 1
  }

  # Slew from cruise to activity
  t_slew_from <- t_slew_from_estimate
  flag <- TRUE
  while (flag) {

    # If there is nowhere to slew to,
    # then we have run out of time. Return NULL
    if (inds_update[1] + t_slew_from > (nrow(spacecraft_state) - 2)) {
      if (verbose) {
        warning("Slew to failed!")
      }
      return(spacecraft_state_dummy)
    }

    # If we are attempting to slew into another slew,
    # Then keep going back in time until you hit the previous activity
    if (
      spacecraft_state$activity[
        inds_update[length(inds_update)] + t_slew_from
      ] == "Slew")
     {

      # Add a second of slew time
      t_slew_from <- t_slew_from + 1

      next()

    }

    # Calculate the slew to the candidate spacecraft state
    slew_from <-
      SlewRampCoastRamp(
        t_k = t_slew_from,
        q_0m1 =
          spacecraft_state$attitude_quaternion_eci[
            inds_update[length(inds_update) - 1],
          ],
        q_0 =
          spacecraft_state$attitude_quaternion_eci[
            inds_update[length(inds_update)],
          ],
        q_k =
          spacecraft_state$attitude_quaternion_eci[
            inds_update[length(inds_update)] + t_slew_from,
          ],
        q_kp1 =
          spacecraft_state$attitude_quaternion_eci[
            inds_update[length(inds_update)] + t_slew_from + 1,
          ],
        spacecraft_configuration = spacecraft_configuration,
        verbose = verbose
      )

    # If the slew failed, then length(slew_from) == 1
    # (it will be the character string "Maneuver Failed").
    if (length(slew_from) == 1) {

      # Add a second of slew time
      t_slew_from <- t_slew_from + 1

      # If we are slewing from a non-cruise activity,
      # then we have run out of time. Throw an error
      if (
        spacecraft_state$activity[
          inds_update[length(inds_update)] + t_slew_from - 1
        ] != "Cruise"
      ) {

        if (verbose) {
          warning("Slew to failed!")
        }

        return(spacecraft_state_dummy)

      }

    } else {
      flag <- FALSE
    }

  }

  # Insert the slew
  inds_slew_from <-
    (inds_update[length(inds_update)] + 1):(inds_update[length(inds_update)] +
    t_slew_from - 1)
  spacecraft_state$attitude_quaternion_eci[inds_slew_from, ] <- slew_from
  spacecraft_state$activity[inds_slew_from] <- "Slew"

  # Update the constraint checks

  # The constraint checks need to be performed from min - 3 to max + 3,
  # But only saved from min + 2 to max +2. This is to save the agility.
  inds_check <-
      c(
        min(inds_slew_to) - 3,
        min(inds_slew_to) - 2,
        min(inds_slew_to) - 1,
        inds_slew_to,
        inds_update,
        inds_slew_from,
        max(inds_slew_from) + 1,
        max(inds_slew_from) + 2,
        max(inds_slew_from) + 3
      )
  inds_check_save <-
    c(
      min(inds_slew_to) - 2,
      min(inds_slew_to) - 1,
      inds_slew_to,
      inds_update,
      inds_slew_from,
      max(inds_slew_from) + 1,
      max(inds_slew_from) + 2
    )

  # Rectify Quaternions for the whole segment at once.
  # This needs to be done at the end because if they were recified
  # independently they might not be rectified together.
  # The inclusion of the 2 points before ensure that the
  # rectification matches that of the greater profile

  spacecraft_state$attitude_quaternion_eci[inds_check, ] <-
    QuaternionRectify(
      spacecraft_state$attitude_quaternion_eci[inds_check, ]
    )

  # Check constraints and fill them into the spacecraft state
  spacecraft_constraints <-
    CheckConstraints(
      spacecraft_state = spacecraft_state[inds_check, ],
      spacecraft_configuration = spacecraft_configuration,
      verbose = verbose
    )
  spacecraft_state$constraints[inds_check_save, ] <-
    spacecraft_constraints[2:(nrow(spacecraft_constraints) - 1), ]

  # Update the activity schedule
  spacecraft_state$activity_schedule[c(inds_slew_to, inds_slew_from), ] <-
    data.frame(
      utc = spacecraft_state$utc[c(inds_slew_to, inds_slew_from)],
      activity = "Slew",
      TargX = 0,
      TargY = 0,
      TargZ = 0,
      PriRefDir = NA,
      SecRefDir = NA,
      PriCmdDir = NA,
      SecCmdDir = NA,
      AttInterp = "Quaternion",
      qTARGETwrtREF1 = NA,
      qTARGETwrtREF2 = NA,
      qTARGETwrtREF3 = NA,
      qTARGETwrtREF4 = NA,
      RateInterp = 1,
      CmdRateX = 0,
      CmdRateY = 0,
      CmdRateZ = 0,
      collectionID = "NA",
      frameRate = NA,
      window = NA,
      LedDriveCurrent810nmCh4 = 0,
      LedDriveCurrent1550nmCh4 = 0,
      LedDriveCurrent810nmO2 = 0,
      LedDriveCurrent1550nmO2 = 0,
      stationName = NA,
      antennaID = NA,
      xBand = FALSE,
      sBand = FALSE,
      thruster1 = NA,
      thruster2 = NA,
      thruster3 = NA,
      SPCount = 0,
      CCSDSBytes = 0,
      PEBtoHSDR = 0,
      DVBS2Bytes = 0,
      DownlinkTime = 0
    )

  # Manage data
  # If this is a scan activity, add the superpages at the end of the
  # $ data_management        :'data.frame':	5778 obs. of  4 variables:
  # ..$ superpages_used: num  0 0 0 0 0 0 0 0 0 0 ...
  # ..$ superpages_free: num  909824 909824 909824 909824 909824 ...
  # ..$ hsdr_used      : num  0 0 0 0 0 0 0 0 0 0 ...
  # ..$ hsdr_free      : num  4.8e+10 4.8e+10 4.8e+10 4.8e+10 4.8e+10 ...
  if (!is.null(activity_schedule)) {

    # Add the data requirement at the end of the activity
    inds_data <- max(inds_update):nrow(spacecraft_state)

    # If this is a scan activity, then add the data to the superpages
    if (
      activity_schedule$activity[1] %in%
      c("Settle", "Scan","DarkScan", "LedMeasurementScan",
        "AirglowLimbScan", "VicariousScan")
    ) {
      spacecraft_state$data_management$superpages_used[inds_data] <-
        spacecraft_state$data_management$superpages_used[inds_data] +
        activity_schedule$SPCount[1]
      spacecraft_state$data_management$superpages_free[inds_data] <-
        spacecraft_state$data_management$superpages_free[inds_data] -
        activity_schedule$SPCount[1]
    }

    # If this is a downlink activity then remove data from the hsdr
    if (activity_schedule$activity[1] %in% c("Downlink")) {
      spacecraft_state$data_management$hsdr_used[inds_data] <-
        spacecraft_state$data_management$hsdr_used[inds_data] +
        activity_schedule$SPCount[1]
      spacecraft_state$data_management$hsdr_free[inds_data] <-
        spacecraft_state$data_management$hsdr_free[inds_data] -
        activity_schedule$SPCount[1]
    }
  }

  # Return the resulting spacecraft state
  return(spacecraft_state)

}

#' Restrict an attitude profile to allow a slew from cruise
#'
#' Some activities have variable length and are slotted in when they can be
#' slewed to from cruise. This function restricts the time of an attitude
#' profile to the time that can be slewed to from cruise.
#'
#' @param spacecraft_state initial spacecraft state object. See documentation
#'   for the function SpacecraftState for more information.
#' @param spacecraft_configuration a list containing configuration data for the
#'   spacecraft. The default is saved in package data as
#'   \code{ground_configuration} and contains initial information about
#'   MethaneSAT. See the data documentation for \code{ground_configuration}
#'   for more detail.
#' @param attitude_quaternion_eci data.frame of attitudes with columns
#'
#'   | column | description |
#'   | --- | --- |
#'   | row | row of the spacecraft state |
#'   | utc | UTC time in POSIX format |
#'   | r | numeric real component of the quaternion rotation from ECI |
#'   | i1 | numeric first imaginary component of quaternion rotation from ECI |
#'   | i2 | numeric first imaginary component of quaternion rotation from ECI |
#'   | i3 | numeric first imaginary component of quaternion rotation from ECI |
#'
#' Notes:
#'
#' \itemize{
#'  \item{"UTC"}{"Universal Coordinated Time"}
#'  \item{"POSIX"}{"Portable Operating System Interface"}
#' }
#'
#' @param buffer_before numeric time buffer to stay in cruise before
#'   slewing into activity
#' @param buffer_after numeric time buffer to stay in cruise after
#'   slewing from activity
#' @param verbose logical - if TRUE (FALSE is default) then print updates
#'
#' @return an updated attitude_quaternion_eci object
#'
#' @family spacecraft state functions
#' @export
SlewIntoAttitude <- function(
    spacecraft_state,
    spacecraft_configuration,
    attitude_quaternion_eci,
    buffer_before = 10,
    buffer_after = 10,
    verbose = FALSE
) {

  # Add an activity to the attitude quaternion
  attitude_quaternion_eci$activity <- "activity"

  # Find the indices to update
  inds_update <- which(spacecraft_state$utc %in% attitude_quaternion_eci$utc)

  # Slews

  # Find the slew to the activity from cruise, eating into the activity

  # Get an estimate of the lower limit of the time to slew to cruise
  t_slew_to_estimate <-
    SlewSlerpTime(
      q_0 = spacecraft_state$attitude_quaternion_eci[min(inds_update) - 1, ],
      q_k = attitude_quaternion_eci[1, 3:6],
      spacecraft_configuration = spacecraft_configuration
    ) %>%
    floor()

  inds_slew_to_estimate <- 1:t_slew_to_estimate

  # Slew from cruise to activity
  t_slew_to <- t_slew_to_estimate
  flag <- TRUE
  while (flag) {

    # If t_slew_to grows to the length of the activity,
    # then we have run out of time
    if (t_slew_to > (nrow(attitude_quaternion_eci) - 5)) {
      warning("Ran out of time to slew to activity")
      return(NULL)
    }

    # Calculate the slew to the activity point
    slew_to <-
      SlewRampCoastRamp(
        t_k = t_slew_to,
        q_0m1 =
          spacecraft_state$attitude_quaternion_eci[min(inds_update) - 2, ],
        q_0 =
          spacecraft_state$attitude_quaternion_eci[min(inds_update) - 1, ],
        q_k =
          attitude_quaternion_eci[t_slew_to, 3:6],
        q_kp1 =
          attitude_quaternion_eci[t_slew_to + 1, 3:6],
        spacecraft_configuration = spacecraft_configuration,
        verbose = verbose
      )

    # If the slew failed, then length(slew_to) == 1
    # (it will be the character string "Maneuver Failed").
    if (length(slew_to) == 1) {

      # Add a second of slew time
      t_slew_to <- t_slew_to + 1

    } else {
      flag <- FALSE
    }

  }

  # Insert the slew
  inds_slew_to <- 1:(nrow(slew_to) - 1)
  attitude_quaternion_eci[inds_slew_to, 3:6] <-
    slew_to[2:nrow(slew_to), ]
  attitude_quaternion_eci[, 3:6] <-
    QuaternionRectify(attitude_quaternion_eci[, 3:6])
  attitude_quaternion_eci$activity[inds_slew_to] <- "Slew"

  # Find the slew from the activity back to cruise

  # Get an estimate of the lower limit of the time to slew to cruise
  t_slew_from_estimate <-
    SlewSlerpTime(
      q_0 = attitude_quaternion_eci[nrow(attitude_quaternion_eci), 3:6],
      q_k = spacecraft_state$attitude_quaternion_eci[max(inds_update) + 1, ],
      spacecraft_configuration = spacecraft_configuration
    ) %>%
    floor()

  # Test to see if we are trying to overwrite the slew to
  # If we are, then we've run out of time
  inds_slew_from_estimate <-
    (nrow(attitude_quaternion_eci) - t_slew_from_estimate):
    nrow(attitude_quaternion_eci)

  if (
    any(attitude_quaternion_eci$activity[inds_slew_from_estimate] == "Slew")
  ) {
    warning("Ran out of time to slew from activity to cruise")
    return(NULL)
  }

  # Slew from cruise to activity
  t_slew_from <- t_slew_from_estimate
  flag <- TRUE
  while (flag) {

    # If t_slew_to grows to the length of the activity,
    # then we have run out of time
    if (
      attitude_quaternion_eci$activity[
        nrow(attitude_quaternion_eci) - t_slew_from
      ] == "Slew"
    ) {
      warning("Ran out of time to slew to activity")
      return(NULL)
    }

    # Calculate the slew to the candidate spacecraft state
    slew_from <-
      SlewRampCoastRamp(
        t_k = t_slew_from,
        q_0m1 =
          attitude_quaternion_eci[
            nrow(attitude_quaternion_eci) - t_slew_from, 3:6
          ],
        q_0 =
          attitude_quaternion_eci[
            nrow(attitude_quaternion_eci) - t_slew_from + 1, 3:6
          ],
        q_k =
          spacecraft_state$attitude_quaternion_eci[
            max(inds_update) + 1,
          ],
        q_kp1 =
          spacecraft_state$attitude_quaternion_eci[
            max(inds_update) + 2,
          ],
        spacecraft_configuration = spacecraft_configuration,
        verbose = verbose
      )

    # If the slew failed, then length(slew_from) == 1
    # (it will be the character string "Maneuver Failed").
    if (length(slew_from) == 1) {

      # Add a second of slew time
      t_slew_from <- t_slew_from + 1

    } else {
      flag <- FALSE
    }
  }

  # Insert the slew
  inds_slew_from <-
    seq(
      from = nrow(attitude_quaternion_eci) - nrow(slew_from) + 2,
      to = nrow(attitude_quaternion_eci),
      by = 1
    )
  attitude_quaternion_eci[inds_slew_from, 3:6] <-
    slew_from[1:(nrow(slew_from) - 1), ]
  attitude_quaternion_eci[, 3:6] <-
    QuaternionRectify(attitude_quaternion_eci[, 3:6])
  attitude_quaternion_eci$activity[inds_slew_from] <- "Slew"

  # Filter down to the activity
  attitude_quaternion_eci <-
    dplyr::filter(
      attitude_quaternion_eci,
      activity == "activity"
    )

  # Add the buffer before and after
  buffered_indices <-
    (buffer_before + 1):(nrow(attitude_quaternion_eci) - buffer_after)
  attitude_quaternion_eci <-
    attitude_quaternion_eci[buffered_indices, ]

  # Remove the activity column to return to the attitude_quaternion_eci format
  attitude_quaternion_eci <- dplyr::select(attitude_quaternion_eci, -activity)

  return(attitude_quaternion_eci)

}

#' Convert a spacecraft state to an activity schedule
#'
#' @param spacecraft_state initial spacecraft state object. See documentation
#'   for the function SpacecraftState for more information.
#' @param spacecraft_configuration a list containing configuration data for the
#'   spacecraft. The default is saved in package data as
#'   \code{ground_configuration} and contains initial information about
#'   MethaneSAT. See the data documentation for \code{ground_configuration}
#'   for more detail.
#' @param peb list describing the payload electronics box data recorder.
#'   Each element contains utc, activity, and superpages.
#' @param version_number integer version number for file
#' @param ephemeris_file character file name of the ephemeris used for metadata
#' @param planId character planId name for metadata
#'
#' @return activity schedule as a list that can be saved as json
#'
#' @family spacecraft state functions
#' @export
ActivitySchedule <- function(
    spacecraft_state,
    spacecraft_configuration,
    peb,
    version_number,
    ephemeris_file,
    planId
) {

  # Note: this function breaks the 80 charcater width limit severely.
  # This is because there nested objects with long names.
  # There is really no better way to call the objects than the
  # way they are called. Sorry!

  # Get the dates when the state on the peb changes
  peb_dates <- do.call("c", lapply(peb, function(x) {x$utc}))

  # Initialize the activity schedule
  activity_schedule <- list()

  # Skip activities that are not written to the activity schedule
  spacecraft_state$activity[
    !(spacecraft_state$activity %in%
        c("Cruise",
          "Slew",
          "Settle",
          "Scan",
          "VicariousScan",
          "AirglowLimbScan",
          "DarkScan",
          "LedMeasurementScan",
          "Thrust",
          "SKM",
          "ORM",
          "CAM",
          "Downlink"))
    ] <- "Cruise"

  # Find the run length encoding of activities
  activity_rle <- rle(spacecraft_state$activity)
  activity_rle_df <- RleToDataFrame(activity_rle)

  # activity_rle.tick tracks where we are in the activity_rle
  activity_rle.tick <- 1

  # activity_schedule.tick tracks where we are in the activity_schedule
  activity_schedule.tick <- 1

  # Walk through the activity_rle, adding them to the activity schedule
  while (activity_rle.tick <= nrow(activity_rle_df)) {

    # Cruise ----
    # The cruise activity can come up alone -
    # particularly at the beginning of each activity schedule
    if (activity_rle_df$value[activity_rle.tick] == "Cruise") {

      print("Adding Cruise")

      # Insert the cruise activity
      activity_schedule[[activity_schedule.tick]] <-
        list(
          activityType = "Cruise",
          startTime = Iso8601FromUtc(spacecraft_state$utc[activity_rle_df$start[activity_rle.tick]]),
          endTime = Iso8601FromUtc(spacecraft_state$utc[activity_rle_df$end[activity_rle.tick] + 1])
        )

      # Iterate the counters
      activity_rle.tick <- activity_rle.tick + 1
      activity_schedule.tick <- activity_schedule.tick + 1

      # Proceed to the next loop iteration
      next()

    }

    # The rest of the activities are always preceded by a slew
    # Slew ----
    if (activity_rle_df$value[activity_rle.tick] == "Slew") {

      # Cruise ----
      if (activity_rle_df$value[activity_rle.tick + 1] == "Cruise") {

        print("Adding Cruise")

        # Insert the slew
        activity_schedule[[activity_schedule.tick]] <-
          list(
            activityType = "Maneuver",
            startTime = Iso8601FromUtc(spacecraft_state$utc[activity_rle_df$start[activity_rle.tick] - 1]),
            endTime = Iso8601FromUtc(spacecraft_state$utc[activity_rle_df$end[activity_rle.tick]]),
            target = list(
              targetType = "Cruise",
              origin = activity_rle_df$value[activity_rle.tick - 1],
              targetAttitude = list(
                TargX = 0,
                TargY = 0,
                TargZ = 0,
                PriRefDir = 6,
                SecRefDir = 3,
                PriCmdDir = 6,
                SecCmdDir = 4,
                AttInterp = 1,
                qTARGETwrtREF1 = 0,
                qTARGETwrtREF2 = 0,
                qTARGETwrtREF3 = 0,
                qTARGETwrtREF4 = 1,
                RateInterp = 1,
                CmdRateX = 0,
                CmdRateY = 0,
                CmdRateZ = 0,
                Time = TaiFromUtc(utc = spacecraft_state$utc[activity_rle_df$end[activity_rle.tick]], tai_utc = spacecraft_state$eop$TAI_UTC[activity_rle_df$end[activity_rle.tick]]),
                EndCycle = 0
              )
            )
          )

        # Iterate the counters
        activity_rle.tick <- activity_rle.tick + 1
        activity_schedule.tick <- activity_schedule.tick + 1

        # Insert the cruise
        activity_schedule[[activity_schedule.tick]] <-
          list(
            activityType = "Cruise",
            startTime = Iso8601FromUtc(spacecraft_state$utc[activity_rle_df$start[activity_rle.tick] - 1]),
            endTime = Iso8601FromUtc(spacecraft_state$utc[activity_rle_df$end[activity_rle.tick] + 1])
          )

        # Iterate the counters
        activity_rle.tick <- activity_rle.tick + 1
        activity_schedule.tick <- activity_schedule.tick + 1

        # Proceed to the next loop iteration
        next()
      }

      # Standard Scan ----
      if (activity_rle_df$value[activity_rle.tick + 2] == "Scan") {

        print("Adding Scan")

        # Get the index of the peb object for this activity
        peb_now <- peb[[which(peb_dates == spacecraft_state$utc[activity_rle_df$end[activity_rle.tick + 2]])]]

        # Insert the slew
        activity_schedule[[activity_schedule.tick]] <-
          list(
            activityType = "Maneuver",
            startTime = Iso8601FromUtc(spacecraft_state$utc[activity_rle_df$start[activity_rle.tick]]),
            endTime = Iso8601FromUtc(spacecraft_state$utc[activity_rle_df$end[activity_rle.tick] + 1]),
            target = list(
              targetType = "Settle",
              targetAttitude = list(
                TargX = spacecraft_state$activity_schedule$TargX[activity_rle_df$start[activity_rle.tick + 2]],
                TargY = spacecraft_state$activity_schedule$TargY[activity_rle_df$start[activity_rle.tick + 2]],
                TargZ = spacecraft_state$activity_schedule$TargZ[activity_rle_df$start[activity_rle.tick + 2]],
                PriRefDir = spacecraft_state$activity_schedule$PriRefDir[activity_rle_df$start[activity_rle.tick + 2]],
                SecRefDir = spacecraft_state$activity_schedule$SecRefDir[activity_rle_df$start[activity_rle.tick + 2]],
                PriCmdDir = spacecraft_state$activity_schedule$PriCmdDir[activity_rle_df$start[activity_rle.tick + 2]],
                SecCmdDir = spacecraft_state$activity_schedule$SecCmdDir[activity_rle_df$start[activity_rle.tick + 2]],
                AttInterp = spacecraft_state$activity_schedule$AttInterp[activity_rle_df$start[activity_rle.tick + 2]],
                qTARGETwrtREF1 = spacecraft_state$activity_schedule$qTARGETwrtREF1[activity_rle_df$start[activity_rle.tick + 2]],
                qTARGETwrtREF2 = spacecraft_state$activity_schedule$qTARGETwrtREF2[activity_rle_df$start[activity_rle.tick + 2]],
                qTARGETwrtREF3 = spacecraft_state$activity_schedule$qTARGETwrtREF3[activity_rle_df$start[activity_rle.tick + 2]],
                qTARGETwrtREF4 = spacecraft_state$activity_schedule$qTARGETwrtREF4[activity_rle_df$start[activity_rle.tick + 2]],
                RateInterp = spacecraft_state$activity_schedule$RateInterp[activity_rle_df$start[activity_rle.tick + 2]],
                CmdRateX = spacecraft_state$activity_schedule$CmdRateX[activity_rle_df$start[activity_rle.tick + 2]],
                CmdRateY = spacecraft_state$activity_schedule$CmdRateY[activity_rle_df$start[activity_rle.tick + 2]],
                CmdRateZ = spacecraft_state$activity_schedule$CmdRateZ[activity_rle_df$start[activity_rle.tick + 2]],
                Time = TaiFromUtc(utc = spacecraft_state$utc[activity_rle_df$end[activity_rle.tick]] + lubridate::seconds(1), tai_utc = spacecraft_state$eop$TAI_UTC[activity_rle_df$end[activity_rle.tick]]),
                EndCycle = 0
              )
            )
          )

        # Iterate the counters
        activity_rle.tick <- activity_rle.tick + 1
        activity_schedule.tick <- activity_schedule.tick + 1

        # Insert the settle
        activity_schedule[[activity_schedule.tick]] <-
          list(
            activityType = "Settle",
            startTime = Iso8601FromUtc(spacecraft_state$utc[activity_rle_df$start[activity_rle.tick]]),
            endTime = Iso8601FromUtc(spacecraft_state$utc[activity_rle_df$end[activity_rle.tick] + 1])
          )

        # Iterate the counters
        activity_rle.tick <- activity_rle.tick + 1
        activity_schedule.tick <- activity_schedule.tick + 1

        # Insert the scan
        activity_schedule[[activity_schedule.tick]] <-
          list(
            activityType = "Scan",
            startTime = Iso8601FromUtc(spacecraft_state$utc[activity_rle_df$start[activity_rle.tick]]),
            endTime = Iso8601FromUtc(spacecraft_state$utc[activity_rle_df$end[activity_rle.tick]]),
            collectionID = spacecraft_state$activity_schedule$collectionID[activity_rle_df$start[activity_rle.tick]],
            frameRate = spacecraft_state$activity_schedule$frameRate[activity_rle_df$start[activity_rle.tick]],
            window = spacecraft_state$activity_schedule$window[activity_rle_df$start[activity_rle.tick]],
            LedDriveCurrent810nmCh4 = spacecraft_state$activity_schedule$LedDriveCurrent810nmCh4[activity_rle_df$start[activity_rle.tick]],
            LedDriveCurrent1550nmCh4 = spacecraft_state$activity_schedule$LedDriveCurrent1550nmCh4[activity_rle_df$start[activity_rle.tick]],
            LedDriveCurrent810nmO2 = spacecraft_state$activity_schedule$LedDriveCurrent810nmO2[activity_rle_df$start[activity_rle.tick]],
            LedDriveCurrent1550nmO2 = spacecraft_state$activity_schedule$LedDriveCurrent1550nmO2[activity_rle_df$start[activity_rle.tick]],
            startingSP = min(which(peb_now$superpages == spacecraft_state$activity_schedule$collectionID[activity_rle_df$start[activity_rle.tick]])),
            SPcount = spacecraft_state$activity_schedule$SPCount[activity_rle_df$start[activity_rle.tick]]
          )

        # Iterate the counters
        activity_rle.tick <- activity_rle.tick + 1
        activity_schedule.tick <- activity_schedule.tick + 1

        # Proceed to the next loop iteration
        next()

      }

      # Downlink ----
      if (activity_rle_df$value[activity_rle.tick + 1] == "Downlink") {

        print("Adding Downlink")

        # Insert the slew
        activity_schedule[[activity_schedule.tick]] <-
            list(
              activityType = "Maneuver",
              startTime = Iso8601FromUtc(spacecraft_state$utc[activity_rle_df$start[activity_rle.tick]]),
              endTime = Iso8601FromUtc(spacecraft_state$utc[activity_rle_df$end[activity_rle.tick] + 1]),
              target = list(
                targetType = "Downlink",
                stationName = spacecraft_state$activity_schedule$stationName[activity_rle_df$start[activity_rle.tick + 1]],
                antennaID = spacecraft_state$activity_schedule$antennaID[activity_rle_df$start[activity_rle.tick + 1]],
                targetAntennaPoint = list(
                  TargX = spacecraft_state$activity_schedule$TargX[activity_rle_df$start[activity_rle.tick + 1]],
                  TargY = spacecraft_state$activity_schedule$TargY[activity_rle_df$start[activity_rle.tick + 1]],
                  TargZ = spacecraft_state$activity_schedule$TargZ[activity_rle_df$start[activity_rle.tick + 1]],
                  PriRefDir = as.numeric(spacecraft_state$activity_schedule$PriRefDir[activity_rle_df$start[activity_rle.tick + 1]]),
                  SecRefDir = as.numeric(spacecraft_state$activity_schedule$SecRefDir[activity_rle_df$start[activity_rle.tick + 1]]),
                  PriCmdDir = as.numeric(spacecraft_state$activity_schedule$PriCmdDir[activity_rle_df$start[activity_rle.tick + 1]]),
                  SecCmdDir = as.numeric(spacecraft_state$activity_schedule$SecCmdDir[activity_rle_df$start[activity_rle.tick + 1]]),
                  AttInterp = spacecraft_state$activity_schedule$AttInterp[activity_rle_df$start[activity_rle.tick + 1]],
                  qTARGETwrtREF1 = spacecraft_state$activity_schedule$qTARGETwrtREF1[activity_rle_df$start[activity_rle.tick + 1]],
                  qTARGETwrtREF2 = spacecraft_state$activity_schedule$qTARGETwrtREF2[activity_rle_df$start[activity_rle.tick + 1]],
                  qTARGETwrtREF3 = spacecraft_state$activity_schedule$qTARGETwrtREF3[activity_rle_df$start[activity_rle.tick + 1]],
                  qTARGETwrtREF4 = spacecraft_state$activity_schedule$qTARGETwrtREF4[activity_rle_df$start[activity_rle.tick + 1]],
                  RateInterp = spacecraft_state$activity_schedule$RateInterp[activity_rle_df$start[activity_rle.tick + 1]],
                  CmdRateX = spacecraft_state$activity_schedule$CmdRateX[activity_rle_df$start[activity_rle.tick + 1]],
                  CmdRateY = spacecraft_state$activity_schedule$CmdRateY[activity_rle_df$start[activity_rle.tick + 1]],
                  CmdRateZ = spacecraft_state$activity_schedule$CmdRateZ[activity_rle_df$start[activity_rle.tick + 1]],
                  Time = TaiFromUtc(utc = spacecraft_state$utc[activity_rle_df$end[activity_rle.tick]] + lubridate::seconds(1), tai_utc = spacecraft_state$eop$TAI_UTC[activity_rle_df$end[activity_rle.tick]]),
                  EndCycle = 0
                )
              )
            )

        # Iterate the counters
        activity_rle.tick <- activity_rle.tick + 1
        activity_schedule.tick <- activity_schedule.tick + 1

        # Insert the downlink
        activity_schedule[[activity_schedule.tick]] <-
          list(
            activityType = "Downlink",
            stationName = spacecraft_state$activity_schedule$stationName[activity_rle_df$start[activity_rle.tick]],
            antennaID = spacecraft_state$activity_schedule$antennaID[activity_rle_df$start[activity_rle.tick]],
            startTime = Iso8601FromUtc(spacecraft_state$utc[activity_rle_df$start[activity_rle.tick]]),
            endTime = Iso8601FromUtc(spacecraft_state$utc[activity_rle_df$end[activity_rle.tick]]),
            # These are coming from the ground station views
            aos_x = Iso8601FromUtc(spacecraft_state$utc[activity_rle_df$start[activity_rle.tick]]), # X-Band window opens (5 deg)
            los_x = Iso8601FromUtc(spacecraft_state$utc[activity_rle_df$end[activity_rle.tick]]), # X-Band window closes (5 deg)
            aos_s = Iso8601FromUtc(spacecraft_state$utc[activity_rle_df$start[activity_rle.tick]]), # 0 degrees geometric
            los_s = Iso8601FromUtc(spacecraft_state$utc[activity_rle_df$end[activity_rle.tick]]), # 0 degrees geometric
            start_tc = Iso8601FromUtc(spacecraft_state$utc[activity_rle_df$start[activity_rle.tick]]), # 5 degrees geometric
            end_tc = Iso8601FromUtc(spacecraft_state$utc[activity_rle_df$end[activity_rle.tick]]) # 5 degrees geometric
          )

        # Iterate the counters
        activity_rle.tick <- activity_rle.tick + 1
        activity_schedule.tick <- activity_schedule.tick + 1

        # Proceed to the next loop iteration
        next()

      }

      # Dark Scan ----
      if (activity_rle_df$value[activity_rle.tick + 1] %in% c("DarkScan", "LedMeasurementScan")) {

        print("Adding Dark Scan")

        # Get the index of the peb object for this activity
        peb_now <- peb[[which(peb_dates == spacecraft_state$utc[activity_rle_df$end[activity_rle.tick + 1]])]]

        # Insert the slew
        activity_schedule[[activity_schedule.tick]] <-
          list(
            activityType = "Maneuver",
            startTime = Iso8601FromUtc(spacecraft_state$utc[activity_rle_df$start[activity_rle.tick]]),
            endTime = Iso8601FromUtc(spacecraft_state$utc[activity_rle_df$end[activity_rle.tick] + 1]),
            target = list(
              targetType = activity_rle_df$value[activity_rle.tick+1],
              targetAttitude = list(
                TargX = spacecraft_state$activity_schedule$TargX[activity_rle_df$start[activity_rle.tick + 1]],
                TargY = spacecraft_state$activity_schedule$TargY[activity_rle_df$start[activity_rle.tick + 1]],
                TargZ = spacecraft_state$activity_schedule$TargZ[activity_rle_df$start[activity_rle.tick + 1]],
                PriRefDir = as.numeric(spacecraft_state$activity_schedule$PriRefDir[activity_rle_df$start[activity_rle.tick + 1]]),
                SecRefDir = as.numeric(spacecraft_state$activity_schedule$SecRefDir[activity_rle_df$start[activity_rle.tick + 1]]),
                PriCmdDir = as.numeric(spacecraft_state$activity_schedule$PriCmdDir[activity_rle_df$start[activity_rle.tick + 1]]),
                SecCmdDir = as.numeric(spacecraft_state$activity_schedule$SecCmdDir[activity_rle_df$start[activity_rle.tick + 1]]),
                AttInterp = spacecraft_state$activity_schedule$AttInterp[activity_rle_df$start[activity_rle.tick + 1]],
                qTARGETwrtREF1 = spacecraft_state$activity_schedule$qTARGETwrtREF1[activity_rle_df$start[activity_rle.tick + 1]],
                qTARGETwrtREF2 = spacecraft_state$activity_schedule$qTARGETwrtREF2[activity_rle_df$start[activity_rle.tick + 1]],
                qTARGETwrtREF3 = spacecraft_state$activity_schedule$qTARGETwrtREF3[activity_rle_df$start[activity_rle.tick + 1]],
                qTARGETwrtREF4 = spacecraft_state$activity_schedule$qTARGETwrtREF4[activity_rle_df$start[activity_rle.tick + 1]],
                RateInterp = spacecraft_state$activity_schedule$RateInterp[activity_rle_df$start[activity_rle.tick + 1]],
                CmdRateX = spacecraft_state$activity_schedule$CmdRateX[activity_rle_df$start[activity_rle.tick + 1]],
                CmdRateY = spacecraft_state$activity_schedule$CmdRateY[activity_rle_df$start[activity_rle.tick + 1]],
                CmdRateZ = spacecraft_state$activity_schedule$CmdRateZ[activity_rle_df$start[activity_rle.tick + 1]],
                Time = TaiFromUtc(utc = spacecraft_state$utc[activity_rle_df$end[activity_rle.tick]] + lubridate::seconds(1), tai_utc = spacecraft_state$eop$TAI_UTC[activity_rle_df$end[activity_rle.tick]]),
                EndCycle = 0
              )
            )
          )

        # Iterate the counters
        activity_rle.tick <- activity_rle.tick + 1
        activity_schedule.tick <- activity_schedule.tick + 1

        # Insert the dark scan
        activity_schedule[[activity_schedule.tick]] <-
          list(
            activityType = activity_rle_df$value[activity_rle.tick],
            startTime = Iso8601FromUtc(spacecraft_state$utc[activity_rle_df$start[activity_rle.tick]]),
            endTime = Iso8601FromUtc(spacecraft_state$utc[activity_rle_df$end[activity_rle.tick]]),
            collectionID = spacecraft_state$activity_schedule$collectionID[activity_rle_df$start[activity_rle.tick]],
            frameRate = spacecraft_state$activity_schedule$frameRate[activity_rle_df$start[activity_rle.tick]],
            window = spacecraft_state$activity_schedule$window[activity_rle_df$start[activity_rle.tick]],
            LedDriveCurrent810nmCh4 = spacecraft_state$activity_schedule$LedDriveCurrent810nmCh4[activity_rle_df$start[activity_rle.tick]],
            LedDriveCurrent1550nmCh4 = spacecraft_state$activity_schedule$LedDriveCurrent1550nmCh4[activity_rle_df$start[activity_rle.tick]],
            LedDriveCurrent810nmO2 = spacecraft_state$activity_schedule$LedDriveCurrent810nmO2[activity_rle_df$start[activity_rle.tick]],
            LedDriveCurrent1550nmO2 = spacecraft_state$activity_schedule$LedDriveCurrent1550nmO2[activity_rle_df$start[activity_rle.tick]],
            startingSP = min(which(peb_now$superpages == spacecraft_state$activity_schedule$collectionID[activity_rle_df$start[activity_rle.tick]])),
            SPcount = spacecraft_state$activity_schedule$SPCount[activity_rle_df$start[activity_rle.tick]]
          )

        # Iterate the counters
        activity_rle.tick <- activity_rle.tick + 1
        activity_schedule.tick <- activity_schedule.tick + 1

        # Proceed to the next loop iteration
        next()

      }

      # Vicarious Scan ----
      if (activity_rle_df$value[activity_rle.tick + 2] == "VicariousScan") {

        print("Adding Vicarious Scan")

        # Get the index of the peb object for this activity
        peb_now <- peb[[which(peb_dates == spacecraft_state$utc[activity_rle_df$end[activity_rle.tick + 2]])]]

        # Insert the slew
        activity_schedule[[activity_schedule.tick]] <-
          list(
            activityType = "Maneuver",
            startTime = Iso8601FromUtc(spacecraft_state$utc[activity_rle_df$start[activity_rle.tick]]),
            endTime = Iso8601FromUtc(spacecraft_state$utc[activity_rle_df$end[activity_rle.tick] + 1]),
            target = list(
              targetType = "Settle",
              targetAttitude = list(
                TargX = spacecraft_state$activity_schedule$TargX[activity_rle_df$start[activity_rle.tick + 2]],
                TargY = spacecraft_state$activity_schedule$TargY[activity_rle_df$start[activity_rle.tick + 2]],
                TargZ = spacecraft_state$activity_schedule$TargZ[activity_rle_df$start[activity_rle.tick + 2]],
                PriRefDir = as.numeric(spacecraft_state$activity_schedule$PriRefDir[activity_rle_df$start[activity_rle.tick + 2]]),
                SecRefDir = as.numeric(spacecraft_state$activity_schedule$SecRefDir[activity_rle_df$start[activity_rle.tick + 2]]),
                PriCmdDir = as.numeric(spacecraft_state$activity_schedule$PriCmdDir[activity_rle_df$start[activity_rle.tick + 2]]),
                SecCmdDir = as.numeric(spacecraft_state$activity_schedule$SecCmdDir[activity_rle_df$start[activity_rle.tick + 2]]),
                AttInterp = spacecraft_state$activity_schedule$AttInterp[activity_rle_df$start[activity_rle.tick + 2]],
                qTARGETwrtREF1 = spacecraft_state$activity_schedule$qTARGETwrtREF1[activity_rle_df$start[activity_rle.tick + 2]],
                qTARGETwrtREF2 = spacecraft_state$activity_schedule$qTARGETwrtREF2[activity_rle_df$start[activity_rle.tick + 2]],
                qTARGETwrtREF3 = spacecraft_state$activity_schedule$qTARGETwrtREF3[activity_rle_df$start[activity_rle.tick + 2]],
                qTARGETwrtREF4 = spacecraft_state$activity_schedule$qTARGETwrtREF4[activity_rle_df$start[activity_rle.tick + 2]],
                RateInterp = spacecraft_state$activity_schedule$RateInterp[activity_rle_df$start[activity_rle.tick + 2]],
                CmdRateX = spacecraft_state$activity_schedule$CmdRateX[activity_rle_df$start[activity_rle.tick + 2]],
                CmdRateY = spacecraft_state$activity_schedule$CmdRateY[activity_rle_df$start[activity_rle.tick + 2]],
                CmdRateZ = spacecraft_state$activity_schedule$CmdRateZ[activity_rle_df$start[activity_rle.tick + 2]],
                Time = TaiFromUtc(utc = spacecraft_state$utc[activity_rle_df$end[activity_rle.tick]] + lubridate::seconds(1), tai_utc = spacecraft_state$eop$TAI_UTC[activity_rle_df$end[activity_rle.tick]]),
                EndCycle = 0
              )
            )
          )

        # Iterate the counters
        activity_rle.tick <- activity_rle.tick + 1
        activity_schedule.tick <- activity_schedule.tick + 1

        # Insert the settle
        activity_schedule[[activity_schedule.tick]] <-
          list(
            activityType = "Settle",
            startTime = Iso8601FromUtc(spacecraft_state$utc[activity_rle_df$start[activity_rle.tick]]),
            endTime = Iso8601FromUtc(spacecraft_state$utc[activity_rle_df$end[activity_rle.tick] + 1])
          )

        # Iterate the counters
        activity_rle.tick <- activity_rle.tick + 1
        activity_schedule.tick <- activity_schedule.tick + 1

        # Insert the scan
        activity_schedule[[activity_schedule.tick]] <-
          list(
            activityType = "VicariousScan",
            startTime = Iso8601FromUtc(spacecraft_state$utc[activity_rle_df$start[activity_rle.tick]]),
            endTime = Iso8601FromUtc(spacecraft_state$utc[activity_rle_df$end[activity_rle.tick] + 1]),
            collectionID = spacecraft_state$activity_schedule$collectionID[activity_rle_df$start[activity_rle.tick]],
            frameRate = spacecraft_state$activity_schedule$frameRate[activity_rle_df$start[activity_rle.tick]],
            window = spacecraft_state$activity_schedule$window[activity_rle_df$start[activity_rle.tick]],
            LedDriveCurrent810nmCh4 = spacecraft_state$activity_schedule$LedDriveCurrent810nmCh4[activity_rle_df$start[activity_rle.tick]],
            LedDriveCurrent1550nmCh4 = spacecraft_state$activity_schedule$LedDriveCurrent1550nmCh4[activity_rle_df$start[activity_rle.tick]],
            LedDriveCurrent810nmO2 = spacecraft_state$activity_schedule$LedDriveCurrent810nmO2[activity_rle_df$start[activity_rle.tick]],
            LedDriveCurrent1550nmO2 = spacecraft_state$activity_schedule$LedDriveCurrent1550nmO2[activity_rle_df$start[activity_rle.tick]],
            startingSP = min(which(peb_now$superpages == spacecraft_state$activity_schedule$collectionID[activity_rle_df$start[activity_rle.tick]])),
            SPcount = spacecraft_state$activity_schedule$SPCount[activity_rle_df$start[activity_rle.tick]]
          )

        # Iterate the counters
        activity_rle.tick <- activity_rle.tick + 1
        activity_schedule.tick <- activity_schedule.tick + 1

        # Proceed to the next loop iteration
        next()

      }

      # Limb Scan ----
      if (activity_rle_df$value[activity_rle.tick + 2] == "AirglowLimbScan") {

        print("Adding Limb Scan")

        # Get the index of the peb object for this activity
        peb_now <- peb[[which(peb_dates == spacecraft_state$utc[activity_rle_df$end[activity_rle.tick + 2]])]]

        # Insert the slew
        activity_schedule[[activity_schedule.tick]] <-
          list(
            activityType = "Maneuver",
            startTime = Iso8601FromUtc(spacecraft_state$utc[activity_rle_df$start[activity_rle.tick]]),
            endTime = Iso8601FromUtc(spacecraft_state$utc[activity_rle_df$end[activity_rle.tick] + 1]),
            target = list(
              targetType = "Settle",
              targetAttitude = list(
                TargX = spacecraft_state$activity_schedule$TargX[activity_rle_df$start[activity_rle.tick + 2]],
                TargY = spacecraft_state$activity_schedule$TargY[activity_rle_df$start[activity_rle.tick + 2]],
                TargZ = spacecraft_state$activity_schedule$TargZ[activity_rle_df$start[activity_rle.tick + 2]],
                PriRefDir = as.numeric(spacecraft_state$activity_schedule$PriRefDir[activity_rle_df$start[activity_rle.tick + 2]]),
                SecRefDir = as.numeric(spacecraft_state$activity_schedule$SecRefDir[activity_rle_df$start[activity_rle.tick + 2]]),
                PriCmdDir = as.numeric(spacecraft_state$activity_schedule$PriCmdDir[activity_rle_df$start[activity_rle.tick + 2]]),
                SecCmdDir = as.numeric(spacecraft_state$activity_schedule$SecCmdDir[activity_rle_df$start[activity_rle.tick + 2]]),
                AttInterp = spacecraft_state$activity_schedule$AttInterp[activity_rle_df$start[activity_rle.tick + 2]],
                qTARGETwrtREF1 = spacecraft_state$activity_schedule$qTARGETwrtREF1[activity_rle_df$start[activity_rle.tick + 2]],
                qTARGETwrtREF2 = spacecraft_state$activity_schedule$qTARGETwrtREF2[activity_rle_df$start[activity_rle.tick + 2]],
                qTARGETwrtREF3 = spacecraft_state$activity_schedule$qTARGETwrtREF3[activity_rle_df$start[activity_rle.tick + 2]],
                qTARGETwrtREF4 = spacecraft_state$activity_schedule$qTARGETwrtREF4[activity_rle_df$start[activity_rle.tick + 2]],
                RateInterp = spacecraft_state$activity_schedule$RateInterp[activity_rle_df$start[activity_rle.tick + 2]],
                CmdRateX = spacecraft_state$activity_schedule$CmdRateX[activity_rle_df$start[activity_rle.tick + 2]],
                CmdRateY = spacecraft_state$activity_schedule$CmdRateY[activity_rle_df$start[activity_rle.tick + 2]],
                CmdRateZ = spacecraft_state$activity_schedule$CmdRateZ[activity_rle_df$start[activity_rle.tick + 2]],
                Time = TaiFromUtc(utc = spacecraft_state$utc[activity_rle_df$end[activity_rle.tick]] + lubridate::seconds(1), tai_utc = spacecraft_state$eop$TAI_UTC[activity_rle_df$end[activity_rle.tick]]),
                EndCycle = 0
              )
            )
          )

        # Iterate the counters
        activity_rle.tick <- activity_rle.tick + 1
        activity_schedule.tick <- activity_schedule.tick + 1

        # Insert the settle
        activity_schedule[[activity_schedule.tick]] <-
          list(
            activityType = "Settle",
            startTime = Iso8601FromUtc(spacecraft_state$utc[activity_rle_df$start[activity_rle.tick]]),
            endTime = Iso8601FromUtc(spacecraft_state$utc[activity_rle_df$end[activity_rle.tick] + 1])
          )

        # Iterate the counters
        activity_rle.tick <- activity_rle.tick + 1
        activity_schedule.tick <- activity_schedule.tick + 1

        # Insert the scan
        activity_schedule[[activity_schedule.tick]] <-
          list(
            activityType = "AirglowLimbScan",
            startTime = Iso8601FromUtc(spacecraft_state$utc[activity_rle_df$start[activity_rle.tick]]),
            endTime = Iso8601FromUtc(spacecraft_state$utc[activity_rle_df$end[activity_rle.tick] + 1]),
            collectionID = spacecraft_state$activity_schedule$collectionID[activity_rle_df$start[activity_rle.tick]],
            frameRate = spacecraft_state$activity_schedule$frameRate[activity_rle_df$start[activity_rle.tick]],
            window = spacecraft_state$activity_schedule$window[activity_rle_df$start[activity_rle.tick]],
            LedDriveCurrent810nmCh4 = spacecraft_state$activity_schedule$LedDriveCurrent810nmCh4[activity_rle_df$start[activity_rle.tick]],
            LedDriveCurrent1550nmCh4 = spacecraft_state$activity_schedule$LedDriveCurrent1550nmCh4[activity_rle_df$start[activity_rle.tick]],
            LedDriveCurrent810nmO2 = spacecraft_state$activity_schedule$LedDriveCurrent810nmO2[activity_rle_df$start[activity_rle.tick]],
            LedDriveCurrent1550nmO2 = spacecraft_state$activity_schedule$LedDriveCurrent1550nmO2[activity_rle_df$start[activity_rle.tick]],
            startingSP = min(which(peb_now$superpages == spacecraft_state$activity_schedule$collectionID[activity_rle_df$start[activity_rle.tick]])),
            SPcount = spacecraft_state$activity_schedule$SPCount[activity_rle_df$start[activity_rle.tick]]
          )

        # Iterate the counters
        activity_rle.tick <- activity_rle.tick + 1
        activity_schedule.tick <- activity_schedule.tick + 1

        # Proceed to the next loop iteration
        next()

      }

      # Thrust ----
      if (activity_rle_df$value[activity_rle.tick + 1] %in% c("Thrust", "SKM", "ORM", "CAM")) {

        print("Adding Thrust")

        # Insert the slew
        activity_schedule[[activity_schedule.tick]] <-
          list(
            activityType = "Maneuver",
            startTime = Iso8601FromUtc(spacecraft_state$utc[activity_rle_df$start[activity_rle.tick]]),
            endTime = Iso8601FromUtc(spacecraft_state$utc[activity_rle_df$end[activity_rle.tick] + 1]),
            target = list(
              targetType = activity_rle_df$value[activity_rle.tick + 1],
              targetAttitude = list(
                TargX = spacecraft_state$activity_schedule$TargX[activity_rle_df$start[activity_rle.tick + 1]],
                TargY = spacecraft_state$activity_schedule$TargY[activity_rle_df$start[activity_rle.tick + 1]],
                TargZ = spacecraft_state$activity_schedule$TargZ[activity_rle_df$start[activity_rle.tick + 1]],
                PriRefDir = as.numeric(spacecraft_state$activity_schedule$PriRefDir[activity_rle_df$start[activity_rle.tick + 1]]),
                SecRefDir = as.numeric(spacecraft_state$activity_schedule$SecRefDir[activity_rle_df$start[activity_rle.tick + 1]]),
                PriCmdDir = as.numeric(spacecraft_state$activity_schedule$PriCmdDir[activity_rle_df$start[activity_rle.tick + 1]]),
                SecCmdDir = as.numeric(spacecraft_state$activity_schedule$SecCmdDir[activity_rle_df$start[activity_rle.tick + 1]]),
                AttInterp = spacecraft_state$activity_schedule$AttInterp[activity_rle_df$start[activity_rle.tick + 1]],
                qTARGETwrtREF1 = spacecraft_state$activity_schedule$qTARGETwrtREF1[activity_rle_df$start[activity_rle.tick + 1]],
                qTARGETwrtREF2 = spacecraft_state$activity_schedule$qTARGETwrtREF2[activity_rle_df$start[activity_rle.tick + 1]],
                qTARGETwrtREF3 = spacecraft_state$activity_schedule$qTARGETwrtREF3[activity_rle_df$start[activity_rle.tick + 1]],
                qTARGETwrtREF4 = spacecraft_state$activity_schedule$qTARGETwrtREF4[activity_rle_df$start[activity_rle.tick + 1]],
                RateInterp = spacecraft_state$activity_schedule$RateInterp[activity_rle_df$start[activity_rle.tick + 1]],
                CmdRateX = spacecraft_state$activity_schedule$CmdRateX[activity_rle_df$start[activity_rle.tick + 1]],
                CmdRateY = spacecraft_state$activity_schedule$CmdRateY[activity_rle_df$start[activity_rle.tick + 1]],
                CmdRateZ = spacecraft_state$activity_schedule$CmdRateZ[activity_rle_df$start[activity_rle.tick + 1]],
                Time = TaiFromUtc(utc = spacecraft_state$utc[activity_rle_df$end[activity_rle.tick]] + lubridate::seconds(1), tai_utc = spacecraft_state$eop$TAI_UTC[activity_rle_df$end[activity_rle.tick]]),
                EndCycle = 0
              )
            )
          )

        # Iterate the counters
        activity_rle.tick <- activity_rle.tick + 1
        activity_schedule.tick <- activity_schedule.tick + 1

        # Insert the cruise activity
        activity_schedule[[activity_schedule.tick]] <-
          list(
            activityType = activity_rle_df$value[activity_rle.tick],
            startTime = Iso8601FromUtc(spacecraft_state$utc[activity_rle_df$start[activity_rle.tick]]),
            endTime = Iso8601FromUtc(spacecraft_state$utc[activity_rle_df$end[activity_rle.tick] + 1]),
            thruster1 = spacecraft_state$activity_schedule$thruster1[activity_rle_df$start[activity_rle.tick]],
            thruster2 = spacecraft_state$activity_schedule$thruster2[activity_rle_df$start[activity_rle.tick]],
            thruster3 = spacecraft_state$activity_schedule$thruster3[activity_rle_df$start[activity_rle.tick]]
          )

        # Iterate the counters
        activity_rle.tick <- activity_rle.tick + 1
        activity_schedule.tick <- activity_schedule.tick + 1

        next()

      }
    }
  }

  # Add the end time
  activity_schedule[[activity_schedule.tick - 1]]$endTime <- Iso8601FromUtc(max(spacecraft_state$utc))

  filename <-
    paste0(
      "ActivitySchedule_targets_v",
      stringr::str_pad(version_number, pad = "0", width = 2),
      "_",
      lubridate::year(spacecraft_state$utc[1]), "_",
      stringr::str_pad(lubridate::yday(spacecraft_state$utc[1]), pad = "0", width = 3),
      ".json"
    )
  # Assemble output
  output <- list(
      filename = filename,
      messageType = "ActivitySchedule",
      created = Iso8601FromUtc(Sys.time()),
      ephemeris = ephemeris_file,
      planId = planId,
      requestStart = Iso8601FromUtc(min(spacecraft_state$utc)),
      requestEnd = Iso8601FromUtc(max(spacecraft_state$utc)),
      activities = activity_schedule
    )

  # Return the output
  return(output)

}


#' Convert a spacecraft state to a data management file
#'
#' @param hsdr list object describing state of the high speed data recorder.
#'   Each element contains utc_start, utc_end, activity, files, bytes,
#'   bytes_used, bytes_free, and, for TransferMissionData activities, sp_start
#'   and sp_end.
#' @param spacecraft_configuration a list containing configuration data for the
#'   spacecraft. The default is saved in package data as
#'   \code{ground_configuration} and contains initial information about
#'   MethaneSAT. See the data documentation for \code{ground_configuration}
#'   for more detail.
#' @param version_number integer version number for file
#' @param ephemeris_file character file name of the ephemeris used for metadata
#' @param planId character planId name for metadata
#'
#' @return activity schedule as a list that can be saved as json
#'
#' @family spacecraft state functions
#' @export
DataManagementSchedule <- function(
    hsdr,
    spacecraft_configuration,
    version_number,
    ephemeris_file,
    planId
) {

  # Initialize the activity schedule
  activity_schedule <- list()

  # Walk through the activity_rle, adding them to the activity schedule
  for (activity.tick in 1:length(hsdr)) {

    # CreateDataFile ----
    if (hsdr[[activity.tick]]$activity == "CreateDataFile") {

      print("Adding CreateDataFile")

      # Insert the CreateDataFile activity
      activity_schedule[[activity.tick]] <-
        list(
          activityType = "CreateDataFile",
          startTime = Iso8601FromUtc(hsdr[[activity.tick]]$utc_start),
          endTime = Iso8601FromUtc(hsdr[[activity.tick]]$utc_end),
          filename = hsdr[[activity.tick]]$files
        )

      # Proceed to the next loop iteration
      next()

    }

    # TransferMissionData ----
    if (hsdr[[activity.tick]]$activity == "TransferMissionData") {

      print("Adding TransferMissionData")

      # Insert the TransferMissionData activity
      activity_schedule[[activity.tick]] <-
        list(
          activityType = "TransferMissionData",
          startTime = Iso8601FromUtc(hsdr[[activity.tick]]$utc_start),
          endTime = Iso8601FromUtc(hsdr[[activity.tick]]$utc_end),
          filename = hsdr[[activity.tick]]$files,
          startingSP = hsdr[[activity.tick]]$sp_start,
          SPcount = hsdr[[activity.tick]]$sp_count
        )

      # Proceed to the next loop iteration
      next()

    }

    # QueueDataFile ----
    if (hsdr[[activity.tick]]$activity == "QueueDataFile") {

      print("Adding QueueDataFile")

      # Insert the QueueDataFile activity
      activity_schedule[[activity.tick]] <-
        list(
          activityType = "QueueDataFile",
          startTime = Iso8601FromUtc(hsdr[[activity.tick]]$utc_start),
          endTime = Iso8601FromUtc(hsdr[[activity.tick]]$utc_end),
          filename = hsdr[[activity.tick]]$files
        )

      # Proceed to the next loop iteration
      next()

    }

    # DeleteDataFile ----
    if (hsdr[[activity.tick]]$activity == "DeleteDataFile") {

      print("Adding DeleteDataFile")

      # Insert the DeleteDataFile activity
      activity_schedule[[activity.tick]] <-
        list(
          activityType = "DeleteDataFile",
          startTime = Iso8601FromUtc(hsdr[[activity.tick]]$utc_start),
          endTime = Iso8601FromUtc(hsdr[[activity.tick]]$utc_end),
          filename = hsdr[[activity.tick]]$files
        )

      # Proceed to the next loop iteration
      next()

    }
  }

  # File name
  filename <-
    paste0(
      "ActivitySchedule_datamgmt_v",
      stringr::str_pad(version_number, pad = "0", width = 2),
      "_",
      lubridate::year(hsdr[[1]]$utc_start), "_",
      stringr::str_pad(lubridate::yday(hsdr[[1]]$utc_start), pad = "0", width = 3),
      ".json"
    )

  # Assemble output
  output <- list(
    filename = filename,
    messageType = "ActivitySchedule",
    created = Iso8601FromUtc(Sys.time()),
    ephemeris = ephemeris_file,
    planId = planId,
    requestStart = Iso8601FromUtc(hsdr[[1]]$utc_start),
    requestEnd = Iso8601FromUtc(hsdr[[1]]$utc_end),
    activities = activity_schedule
  )

  # Return the output
  return(output)

}
