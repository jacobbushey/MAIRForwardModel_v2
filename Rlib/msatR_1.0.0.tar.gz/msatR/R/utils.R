# Utility functions

# this code contains a largge library of useful utility functions that are used
# throughout the msatR package.

#' Rotation matrix about the x axis
#'
#' @param angle numeric vector of the angle to rotate in radians
#'
#' @return list of rotation matrices
#'
#' @examples
#' # A scalar input produces a rotation matrix
#' R_x(pi/2)
#'
#' # A vector input produces a list of rotation matrices
#' R_x(c(pi/2, pi))
#'
#' @keywords internal
#' @seealso [R_y()], [R_z()]
#' @export
R_x <- function(angle) {

  if (length(angle) == 1) {
    rx <-
      rbind(
        c(1, 0,          0),
        c(0, cos(angle),  -sin(angle)),
        c(0, sin(angle),  cos(angle))
      )
  } else {
    rx <-
      lapply(angle,
             function(x) {
               rbind(
                 c(1, 0,       0),
                 c(0, cos(x),  -sin(x)),
                 c(0, sin(x),  cos(x))
               )
             }
      )
  }

  return(rx)

}

#' Rotation matrix about the y axis
#'
#' @param angle numeric vector of the angle to rotate in radians
#'
#' @return list of rotation matrices
#'
#' @examples
#' # A scalar input produces a rotation matrix
#' R_y(pi/2)
#'
#' R_y(c(pi/2, pi))
#'
#' @keywords internal
#' @seealso [R_x()], [R_z()]
#' @export
R_y <- function(angle) {

  if (length(angle) == 1) {
    ry <-
      rbind(
        c(cos(angle),  0, sin(angle)),
        c(0,           1, 0),
        c(-sin(angle), 0, cos(angle))
      )
  } else {
    ry <-
      lapply(angle,
             function(x) {
               rbind(
                 c(cos(x),  0, sin(x)),
                 c(0,       1, 0),
                 c(-sin(x), 0, cos(x))
               )
              }
      )
  }

  return(ry)

}

#' Rotation matrix about the z axis
#'
#' @param angle numeric vector of the angle to rotate in radians
#'
#' @return list of rotation matrices
#'
#' @examples
#' # A scalar input produces a rotation matrix
#' R_z(pi/2)
#'
#' R_z(c(pi/2, pi))
#'
#' @keywords internal
#' @seealso [R_x()], [R_y()]
#' @export
R_z <- function(angle) {

  if (length(angle) == 1) {
    rz <-
      rbind(
        c(cos(angle),  -sin(angle), 0),
        c(sin(angle),  cos(angle), 0),
        c(0,           0,          1)
      )
  } else {
    rz <-
      lapply(angle,
             function(x) {
               rbind(
                 c(cos(x),  -sin(x), 0),
                 c(sin(x),  cos(x),  0),
                 c(0,       0,       1)
               )
              }
      )
  }

  return(rz)

}

#' Calculates the skew-symmetric matrix representation of the cross product
#' such that: a x b = CrossProductMatrix(a) %*% b where a and b are vectors
#'
#' @param a a numeric vector
#'
#' @return a numeric matrix representation of the cross product
#'
#' @examples
#' CrossProductMatrix(c(1,2,3))
#'
#' @keywords internal
#' @seealso [CrossProductByRow()]
#' @export
CrossProductMatrix <- function(a) {

  # Error handling
  stopifnot(
    length(a) == 3
  )

  # Compute cross product matrix
  mat <- rbind(
    c(0,    -a[3],  a[2]),
    c(a[3],  0,    -a[1]),
    c(-a[2], a[1],  0)
  )

  return(mat)

}

#' Computes the cross product of of each row of two matrices
#'
#' @param vectors_a a numeric vector, matrix, or data.frame with 3 columns of
#'   the first vectors
#'
#' @param vectors_b a numeric vector, matrix, or data.frame with 3 columns of
#'   the second vectors
#'
#' @return a numeric vector or matrix with rows composed of the cross product
#'
#' @examples
#' CrossProductByRow(c(1,0,0), c(0,1,0))
#' CrossProductByRow(
#'   matrix(ncol = 3, data = c(1,0,0,0,1,0), byrow = TRUE),
#'   matrix(ncol = 3, data = c(0,1,0,0,0,1), byrow = TRUE)
#'  )
#'
#' @keywords internal
#' @seealso [CrossProductMatrix()]
#' @export
CrossProductByRow <- function(
    vectors_a,
    vectors_b
) {

  # data.frame to matrix conversion
  if (is.data.frame(vectors_a)) {
    vectors_a <- as.matrix(vectors_a)
  }
  if (is.data.frame(vectors_b)) {
    vectors_b <- as.matrix(vectors_b)
  }

  # If vectors_a and vectors_b are length-3 vectors,
  # return the normal cross product
  if (
    is.vector(vectors_a) &
    length(vectors_a) == 3 &
    is.vector(vectors_b) &
    length(vectors_b) == 3
  ) {
    crossproduct <-
      c(
        vectors_a[2] * vectors_b[3] - vectors_a[3] * vectors_b[2],
        vectors_a[3] * vectors_b[1] - vectors_a[1] * vectors_b[3],
        vectors_a[1] * vectors_b[2] - vectors_a[2] * vectors_b[1]
      )

    # If vectors_a and vectors_b are matrices with the same number of rows,
    # return the cross product of each row
  } else if (
    is.matrix(vectors_a) &
    ncol(vectors_a) == 3 &
    is.matrix(vectors_b) &
    ncol(vectors_b) == 3 &
    nrow(vectors_a) == nrow(vectors_b)
  ) {
    crossproduct <-
      cbind(
        vectors_a[,2] * vectors_b[,3] - vectors_a[,3] * vectors_b[,2],
        vectors_a[,3] * vectors_b[,1] - vectors_a[,1] * vectors_b[,3],
        vectors_a[,1] * vectors_b[,2] - vectors_a[,2] * vectors_b[,1]
      )

    # Else return an error message
  } else {
    stop("vectors_a and vectors_b must be length-3 vectors or
          3-column matrices or data.frames with the same number of rows.")
  }

  return(crossproduct)

}

#' The base function sapply column binds the result. This is generally not
#' what we want. This funciton, stapply, row binds the result.
#'
#' @param X vector (atomic or list) or an expression object. Other objects
#'   (including classed objects) will be coerced by base::as.list.
#' @param FUN the function to be applied to each element of X: see ‘Details’.
#'   In the case of functions like +, %*%, the function name must be backquoted
#'   or quoted.
#'
#' @return a matrix, each row is the product of applying the function FUN to an
#'   element of X.
#'
#' @examples
#' # stapply binds by the row
#' stapply(1:3, function(x) {rep(x, 3)})
#'
#' # Compare tosapply, which binds by the column:
#' sapply(1:3, function(x) {rep(x, 3)})
#'
#' @keywords internal
#' @seealso [sapply()]
#' @export
stapply <- function(X, FUN) {

  X %>% sapply(FUN) %>% t()

}

#' Matrix multiple a list of matrices
#' @param list1 a list of matrices
#' @param list2 a list of matrices, congruent to the matrices in list1 for
#'   right-multiplication
#'
#' @return a list of matrices resulting from the multiplication
#'   list1(x) %*% list2(x)
#'
#' @examples
#' MultiplyMatrixLists(
#'   list1 = R_x(c(pi/2, pi)),
#'   list2 = R_y(c(pi/2, pi))
#' )
#'
#' @keywords internal
#' @export
MultiplyMatrixLists <- function(list1, list2) {

  lapply(1:length(list1),
         function(x) {
           list1[[x]] %*% list2[[x]]
         }
  )

}

#' Matrix of repeated columns
#'
#' @param vec vector to repeat
#' @param n number of repetitions
#'
#' @return matrix, where v is repeated as the n columns
#'
#' @examples
#' RepeatColumns(c(1,2,3), 3)
#'
#' @keywords internal
#' @seealso [RepeatRows()]
#' @export
RepeatColumns <- function(vec, n) {

  # Error handling
  stopifnot(
    is.vector(vec),
    is.numeric(vec),
    is.numeric(n),
    (length(n) == 1)
  )

  mat <- do.call("cbind", replicate(n, vec, simplify = FALSE))

  return(mat)

}

#' Matrix of repeated rows
#'
#' @param vec a vector to repeat
#' @param n number of repetitions
#'
#' @return a matrix, where vec is repeated as the n rows
#'
#' @examples
#' RepeatRows(c(1,2,3), 3)
#'
#' @keywords internal
#' @seealso [RepeatColumns()]
#' @export
RepeatRows <- function(vec, n) {

  mat <- do.call("rbind", replicate(n, vec, simplify = FALSE))

  return(mat)

}

#' Aggregate a matrix by separate row and column factors
#'
#' @param mat matrix to aggregate
#' @param row_aggregate integer factor by which to aggregate rows
#' @param col_aggregate integer factor by which to aggregate columns
#' @param na_frac numeric fraction of data points allowed to be NA
#' @param verbose logical - if TRUE (default FALSE), then print a progress bar
#'
#' @return a matrix, where vec is repeated as the n rows
#'
#' @examples
#' RepeatRows(c(1,2,3), 3)
#'
#' @keywords internal
#' @seealso [RepeatColumns()]
#' @export
AggregateMatrix <-
  function(
    mat,
    row_aggregate,
    col_aggregate,
    na_frac = 0.5,
    verbose = FALSE
  ) {

  # Initialize progress bar
  if (verbose) {
    pb <- utils::txtProgressBar()
  }

  aggregate_x <- rep(1:floor(nrow(mat) / row_aggregate), each = row_aggregate)
  aggregate_y <- rep(1:floor(ncol(mat) / col_aggregate), each = col_aggregate)
  mat_aggregated <-
    matrix(
      nrow = max(aggregate_x),
      ncol = max(aggregate_y)
    )

  for (row.tick in 1:max(aggregate_x)) {
    if (verbose) {utils::setTxtProgressBar(pb, row.tick / max(aggregate_x))}
    for (col.tick in 1:max(aggregate_y)) {
      indices <-
        expand.grid(
          which(aggregate_x == row.tick),
          which(aggregate_y == col.tick)
        ) %>% as.matrix()
      values <- mat[indices]
      if(sum(is.na(values)) / length(values) > na_frac) {next}
      mat_aggregated[row.tick, col.tick] <- mean(values, na.rm = TRUE)
    }
  }

  return(mat_aggregated)

}

#' Take the norm of each row of a matrix
#'
#' @param mat matrix
#'
#' @return vector, where each element is the norm of the corresponding
#'   row of mat
#'
#' @examples
#' NormByRow(c(3,4))
#'
#' NormByRow(matrix(nrow = 2, data = c(3,4,6,8), byrow = TRUE))
#'
#' @keywords internal
#' @seealso [NormalizeByRow()], [DistanceByRow()]
#' @export
NormByRow <- function(mat) {

  if (is.vector(mat)) {
    return(sqrt(sum(mat^2)))
  } else {
    return(apply(mat, 1, function(x) {sqrt(sum(x^2))}))
  }

}

#' Normalize each row of a matrix
#'
#' @param mat matrix
#'
#' @return matrix, where each row is the normalized corresponding row of mat
#'
#' @examples
#' NormalizeByRow(c(3,4))
#'
#' NormalizeByRow(matrix(nrow = 2, data = c(3,4,6,8), byrow = TRUE))
#'
#' @keywords internal
#' @seealso [NormByRow()], [DistanceByRow()]
#' @export
NormalizeByRow <- function(mat) {

  if (is.vector(mat)) {
    return(mat / NormByRow(mat))
  } else {
    return(mat / RepeatColumns(vec = NormByRow(mat), n = ncol(mat)))
  }

}

#' Calculate the distance between each row of two matrices
#'
#' @param mat1 matrix
#' @param mat2 matrix with the same number of columns as mat1
#'
#' @return matrix with dimension nrow(mat1) X nrow(mat2), where the i,j^th
#'   element is the distance from the ith row of mat1 to the jth row of mat2
#'
#' @examples
#' DistanceByRow(
#'   mat1 = matrix(nrow = 2, data = c(1,0,0,1), byrow = TRUE),
#'   mat2 = matrix(nrow = 2, data = c(1,0,1,0), byrow = TRUE)
#' )
#'
#' @keywords internal
#' @seealso [NormByRow()], [NormalizeByRow()]
#' @export
DistanceByRow <- function(mat1, mat2) {

  mat <- matrix(nrow = nrow(mat1), ncol = nrow(mat2))
  for (tick in 1:nrow(mat1)) {
    mat[tick, ] <- NormByRow(RepeatRows(mat1[tick, ], nrow(mat2)) - mat2)
  }

  return(mat)

}

#' Extract decimal part of float
#'
#' @param x numeric vector
#'
#' @return numeric vector, where each element is the decimal part of the
#'   corresponding element of x
#'
#' @examples
#' IsolateDecimal(3.1415)
#'
#' @keywords internal
#' @seealso [CharacterSign()], [LabelEastWest()], [LabelNorthSouth()]
#' @export
IsolateDecimal <- function(x) {

  x - floor(x)

}

#' Test if all values are identical. This function works by taking the variance
#' of the vector - if it is within a tolerance of 0, then all values are equal.
#'
#' @param ... numeric values to compare
#' @param tol a tolerance around 0 to allow for machine error (default 8).
#'   Any number within 10^-tol will be rounded to 0.
#'
#' @return logical. TRUE if all numeric values of x are equal (within tolerance).
#'   FALSE if at least one of the numeric values of x are not equal.
#'
#' @examples
#' AllIdentical(1,1.01,1.001)
#' AllIdentical(1L, 1.0, 1+1e-9)
#'
#' @keywords internal
#' @export
AllIdentical <- function(..., tol = 8) {

  # Get the values to compare
  x <- c(...)

  # Error handling
  stopifnot(is.numeric(x))

  # Find if all are identical within the tolerance
  identicalTF <- stats::var(x) < 10^{-tol}

  return(identicalTF)

}

#' Take the floor with respect to an arbitrary modulus
#' @param x numeric vector
#' @param modulo an integer to use as the modulus against which to floor
#' @param tol a tolerance around 0 to allow for machine error (default 8).
#'   Any number within 10^-tol will be rounded to 0.
#'
#' @return numeric vector, where each element is the floor of \code{x} with
#'   respect to \code{modulo}
#'
#' @examples
#' SuperFloor(x = 6, modulo = 5)
#' # [1] 5
#' SuperFloor(x = 5, modulo = 5)
#' # [1] 5
#' SuperFloor(x = 5 - 1e-8, modulo = 5)
#' # [1] 5
#' SuperFloor(x = 5 - 1e-7, modulo = 5)
#' # [1] 0
#'
#' @keywords internal
#' @seealso [SuperCeiling()]
#' @export
SuperFloor <- function(x, modulo, tol = 8) {

  # Find the remainder
  frac <- x %% modulo

  # Round away numerical precision
  frac[abs(frac - modulo) < 10^-tol] <- 0

  # find the floor
  superfloor <- x - frac

  return(superfloor)

}

#' Take the ceiling with respect to an arbitrary modulus
#'
#' @param x numeric vector
#' @param modulo an integer to use as the modulus against which to ceiling
#' @param tol a tolerance around 0 to allow for machine error (default 8).
#'   Any number within 10^-tol will be rounded to 0.
#'
#' @return numeric vector, where each element is the ceiling of \code{x} with
#'  respect to \code{modulo}
#'
#' @examples
#' SuperCeiling(x = 4, modulo = 5)
#' # [1] 5
#' SuperCeiling(x = 5, modulo = 5)
#' # [1] 5
#' SuperCeiling(x = 5 + 1e-8, modulo = 5)
#' # [1] 5
#' SuperCeiling(x = 5 + 1e-7, modulo = 5)
#' # [1] 10
#'
#' @keywords internal
#' @seealso [SuperFloor()]
#' @export
SuperCeiling <- function(x, modulo, tol = 8) {

  # Find the remainder
  frac <- x %% modulo

  # Round away numerical precision
  frac[abs(frac) < 10^-tol] <- modulo

  # find the ceiling
  superceiling <- x + modulo - frac

  return(superceiling)

}

#' Convert a numeric to a string with a "+" or "-"
#'
#' @param x numeric vector
#'
#' @return character string of the numeric vector with the sign prepended
#'
#' @examples
#' CharacterSign(1)
#' # [1] "+"
#' CharacterSign(0)
#' # [1] "+"
#' CharacterSign(-1)
#' # [1] "-"
#'
#' @keywords internal
#' @seealso [IsolateDecimal()], [LabelEastWest()], [LabelNorthSouth()]
#' @export
CharacterSign <- function(x) {

  c("-", "+", "+")[sign(x) + 2]

}

#' Convert an integer to a binary string with a given width
#'
#' @param x integer to be converted to binary
#' @param width width of the binary string
#'
#' @return binary string
#'
#' @keywords internal
#' @export
BinaryStringFromInteger <- function(x, width) {

  binary_string <-
    x %>%
    intToBits() %>%
    as.numeric() %>%
    "["(1:width) %>%
    rev() %>%
    paste0(collapse = "")

  # Check if the number was too large to be described by the binary string
  binary_string_cut <-
    x %>%
    intToBits() %>%
    as.numeric() %>%
    "["((width + 1):32) %>%
    rev() %>%
    paste0(collapse = "")
  all_cut_bits_zero <-
    binary_string_cut %>%
    regmatches(gregexpr("0", binary_string_cut)) %>%
    lengths() %>%
    "=="(nchar(binary_string_cut))

  # Stop if not all are zeros
  stopifnot(all_cut_bits_zero)

  return(binary_string)

}

#' Convert binary string into an integer
#'
#' @param x binary string to be converted to an integer
#'
#' @return integer
#'
#' @keywords internal
#' @export
IntegerFromBinaryString <- function(x) {

  int <- strtoi(x, base = 2)

  return(int)

}


#' Find the local maxima of a vector
#'
#' @param x numeric vector
#'
#' @return vector of indices of the local maxima
#'
#' @examples
#' LocalMaxima(c(1,2,3,4,3,2,3,4,3,2,1))
#'
#' @keywords internal
#' @export
LocalMaxima <- function(x) {

  # Find where the vector is increasing, starting with negative infinity
  y <- diff(c(-Inf, x)) > 0L

  # Mark the segments of increasing/decreasing
  y <- cumsum(rle(y)$lengths)

  # Extract the increasing segments - remember we started at -Inf
  y <- y[seq.int(1L, length(y), 2L)]
  if (x[[1]] == x[[2]]) {
    y <- y[-1]
  }

  return(y)

}

#' Find the local minima of a vector
#'
#' @param x numeric vector
#'
#' @return vector of indices of the local minima
#'
#' @examples
#' LocalMinima(c(4,3,2,1,2,3,3,2,1,2,3))
#'
#' @keywords internal
#' @seealso [LocalMaxima()]
#' @export
LocalMinima <- function(x) {

  LocalMaxima(-x)

}

#' Compute the difference between two angles
#'
#' @param a numeric vector of angles in radians
#' @param b numeric vector of angles in radians
#'
#' @return vector of element-wise distances in radians between
#'
#' @examples
#' AngleDifference(pi/2, pi)
#' # [1] 1.570796
#'
#' # The angle difference is in radians!
#' AngleDifference(45, 90)
#' # [1] -38.71681
#'
#' # The direction doesn't matter
#' AngleDifference(pi, pi/2)
#' # [1] 1.570796
#'
#' # It wraps at 2 * pi
#' AngleDifference(2 * pi - 0.5, 0.5)
#' # [1] 1
#'
#' @keywords internal
#' @seealso [AngleBetweenQuaternions()], [AngleBetweenVectors()]
#' @export
AngleDifference <- function(a, b) {

  # Fix the order of the angles
  ang1 <- apply(cbind(a,b), 1, max)
  ang2 <- apply(cbind(a,b), 1, min)

  # Apply the difference
  angle_diff <- apply(cbind((ang1 - ang2), (ang2 - (ang1 - 2 * pi))), 1, min)

  return(angle_diff)

}

#' Convert a numeric longitude to a text longitude with E/W
#'
#' @param x numeric vector
#'
#' @return character vector of the longitude in East/West format
#'
#' @examples
#' LabelEastWest(45)
#' # [1] "E"
#'
#' LabelEastWest(0)
#' # [1] "E"
#'
#' LabelEastWest(-45)
#' # [1] "W"
#'
#' @keywords internal
#' @seealso [CharacterSign()], [IsolateDecimal()], [LabelNorthSouth()]
#' @export
LabelEastWest <- function(x) {

  c("W", "E", "E")[sign(x) + 2]

}

#' Convert a numeric longitude to a text longitude with N/S
#' @param x numeric vector
#'
#' @return character vector of the longitude in East/West format
#'
#' @examples
#' LabelNorthSouth(45)
#' # [1] "N"
#'
#' LabelNorthSouth(0)
#' # [1] "N"
#'
#' LabelNorthSouth(-45)
#' # [1] "S"
#'
#' @keywords internal
#' @seealso [CharacterSign()], [IsolateDecimal()], [LabelEastWest()]
#' @export
LabelNorthSouth <- function(x) {

  c("S", "N", "N")[sign(x) + 2]

}

#' Linear interpolate a data.frame to a fractional row
#' @param df data.frame
#' @param x numeric vector of fractional row numbers
#'
#' @return a data.frame with the same columns as df
#'
#' @examples
#' InterpolateDataFrame(df = orbit_examples$transporter_9, x = 44.6)
#'
#' @keywords internal
#' @export
InterpolateDataFrame <- function(
    df,
    x
) {

  df_out <- data.frame(row = x)
  for (col.tick in 1:length(df)) {

    # If this row is a character or logical, then round the row number
    if (is.character(df[[col.tick]]) |
        is.logical(df[[col.tick]])) {
      df_out[[names(df)[col.tick]]] <- df[[col.tick]][round(x)]
    } else if ("data.frame" %in% class(df[[col.tick]])) {
      df_out[[names(df)[col.tick]]] <-
        lapply(
          df[[col.tick]],
          function(z) {
            stats::approx(
              x = 1:nrow(df),
              xout = x,
              y = z
            )$y
          }
        ) %>% as.data.frame()
    } else {
      y <-
        stats::approxfun(
          x = 1:nrow(df),
          y = df[[col.tick]]
        )(x)
      attributes(y) <- attributes(df[[col.tick]][1])
      df_out[[names(df)[col.tick]]] <- y
    }
  }

  df_out <- dplyr::select(df_out, -row)

  return(df_out)

}

#' Convert an rle object to a data.frame with the starting and ending indices
#' @param rle_x an rle object. See the base function rle().
#'
#' @return a data.frame with columns value, start, and end
#'
#' @examples
#' rle_x <- rle(c(rep(TRUE, 10), rep(FALSE, 5), rep(TRUE, 10)))
#' RleToDataFrame(rle_x)
#'
#' @keywords internal
#' @export
RleToDataFrame <- function(rle_x) {
  output <- data.frame(
    value = rle_x$values,
    start = c(1, cumsum(rle_x$lengths)[1:(length(rle_x$lengths) - 1)] + 1),
    end = cumsum(rle_x$lengths),
    length = rle_x$lengths
  )
  if (length(rle_x$lengths) == 1) {
    output <- output[1, ]
  }
  return(output)
}

#' Clip a raster to a buffer around a point
#'
#' @param ras A raster object
#' @param lon Numeric longitude of the clipping region centroid
#' @param lat Numeric latitude of the clipping region centroid
#' @param buffer_m Numeric meters of buffer around the centorid
#' @param dateline Logical, if TRUE the dateline will be wrapped
#'
#' @return A raster geometry
ClipRasterBuffer <- function(ras, lon, lat, buffer_m, dateline = FALSE) {

  # Calculate the UTM zone
  utm <- (floor((lon + 180) / 6) %% 60) + 1
  utm[lat > 0]  <- utm[lat > 0]  + 32600
  utm[lat <= 0] <- utm[lat <= 0] + 32700

  # Calculate the UTM zone
  utm <- (floor((lon + 180) / 6) %% 60) + 1
  utm[lat > 0]  <- utm[lat > 0]  + 32600
  utm[lat <= 0] <- utm[lat <= 0] + 32700

  # Find the polygon to clip
  if (dateline) {
    utmshapes <- sapply(1:length(lon), function(x) {
      data.frame(lon = lon[x], lat = lat[x]) %>%
        sf::st_as_sf(coords = c("lon", "lat"), crs = 4326) %>%
        sf::st_transform(utm[x]) %>%
        sf::st_buffer(dist = buffer_m) %>%
        sf::st_transform(4326) %>%
        sf::st_wrap_dateline()
    })
  } else {
    utmshapes <- sapply(1:length(lon), function(x) {
      data.frame(lon = lon[x], lat = lat[x]) %>%
        sf::st_as_sf(coords = c("lon", "lat"), crs = 4326) %>%
        sf::st_transform(utm[x]) %>%
        sf::st_buffer(dist = buffer_m) %>%
        sf::st_transform(4326)
    })
  }

  # Clip the raster
  ras_clipped <- lapply(utmshapes, function(x) {
    raster::crop(ras, raster::extent(sf::st_bbox(x)[c(1,3,2,4)]))
  })

  # Return the raster geometry
  return(ras_clipped[[1]])

}

#' Convert a binary character string to hexidecimal
#'
#' @param binary character string of 0's and 1's representing a binary number.
#'   The number of characters must be divisible by 4.
#'
#' @return character string representing a hexadecimal number
HexFromBinary <-function(binary) {

  # The binary data should be a string and the length of the string should be
  # divisible by 4.
  is_binary <- all(strsplit(binary, split = "")[[1]] %in% c(0,1))
  if ((!is.character(binary)) | (nchar(binary) %% 4 != 0) | !is_binary) {
    stop("Binary must be a character string of 0's and 1's with nchar divisible by 4")
  }

  # A lookup table to find the hexadecimal digit for each binary
  hex_from_binary_lut <-
    data.frame(
      binary =
        c("0000",	"0001",	"0010",	"0011",	"0100",	"0101",	"0110",	"0111",
          "1000", "1001",	"1010",	"1011",	"1100",	"1101",	"1110",	"1111"),
      hex =
        c("0", "1", "2", "3", "4", "5", "6", "7",
          "8", "9", "A", "B", "C", "D", "E", "F")
    )

  # Loop through the binary digits and find the corresponding hexadecimal
  # digit using the lookup table
  hex <- ""
  for (hex.tick in 1:(nchar(binary) / 4)) {
    binary_now <- substr(binary, (hex.tick - 1) * 4 + 1, hex.tick * 4)
    hex <-
      paste0(
        hex,
        hex_from_binary_lut$hex[hex_from_binary_lut$binary == binary_now]
      )
  }

  return(hex)

}

#' Convert a hexadecimal character string to binary
#'
#' @param hex character string of 0-9 A-F representing a hexadecimal number
#'
#' @return character string representing a binary number
BinaryFromHex <-function(hex) {

  # The binary data should be a string and the length of the string should be
  # divisible by 4.
  is_hex <-
    all(
      strsplit(hex, split = "")[[1]]
      %in%
      c("0", "1", "2", "3", "4", "5", "6", "7",
        "8", "9", "A", "B", "C", "D", "E", "F")
    )
  if (!is.character(hex) | !is_hex) {
    stop("Hex must be a character string of 0-9 A-F")
  }

  # A lookup table to find the binary digits for each hexadecimal
  binary_from_hex_lut <-
    data.frame(
      binary =
        c("0000",	"0001",	"0010",	"0011",	"0100",	"0101",	"0110",	"0111",
          "1000", "1001",	"1010",	"1011",	"1100",	"1101",	"1110",	"1111"),
      hex =
        c("0", "1", "2", "3", "4", "5", "6", "7",
          "8", "9", "A", "B", "C", "D", "E", "F")
    )

  # Loop through the binary digits and find the corresponding hexadecimal
  # digit using the lookup table
  binary <- ""
  for (hex.tick in 1:nchar(hex)) {
    binary <-
      paste0(
        binary,
        binary_from_hex_lut$binary[binary_from_hex_lut$hex == substr(hex, hex.tick, hex.tick)]
      )
  }

  return(binary)

}
