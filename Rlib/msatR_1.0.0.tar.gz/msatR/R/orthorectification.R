# Orthorectification functions

# Orthorectification is the intersection of a vector with the Earth's surface.
# These functions calculate the orthorectification of the instrument array or
# the X-band antennas with varying levels of computational cost and accuracy.
# There are functions that calculate the intersection of a general ray with the
# spherical Earth, the intersection of a general ray with an ellipsoid,
# a camera model, and a full orthorectification of an instrument to a digital
# elevation map, with the option to save the output as a standardized netCDF
# with self-documentation.

#' Calculate the intersection of a ray with a sphere
#'
#' \code{IntersectSphere} calculates the intersection of a ray with a sphere.
#' A "ray" here is defined as half of a line, or a part of a line with a
#' starting point but no ending point. In the context of orthorectification,
#' the starting point (the parameter \code{pos_ecef}) is the position of the
#' instrument, and the half-line is the bore sight of a pixel. The default
#' sphere is the Earth mean radius sphere.
#'
#' @param pos_ecef vector, matrix, or data.frame with 3 columns giving
#'   the position of the spacecraft in meters Earth-Centered Earth-Fixed
#' @param ray_ecef vector, matrix, or data.frame with 3 columns giving the
#'   vector pointing along the ray (the vector from the spacecraft along the
#'   instrument bore sight) in Earth-Centered Earth-Fixed. Must have the
#'   same shape as \code{pos_ecef}.
#' @param r the radius of the sphere in meters (default 6371000, the mean
#'   radius of the Earth). To intersect with a surface above the Earth,
#'   enter a value of e.g., 6371000 + altitude.
#'
#' @return a data.frame of geocentric coordinates (lon, lat, alt)
#'
#' @examples
#' IntersectSphere(
#'   pos_ecef =
#'     rbind(
#'       c(6381000, 0, 0),
#'       c(0, 0, 6381000)
#'     ),
#'   ray_ecef =
#'     rbind(
#'       c(-1, 0, 0),
#'       c(0, 0, -1)
#'     )
#' )
#'
#' @family orthorectification functions
#' @export
IntersectSphere <- function(
    pos_ecef,
    ray_ecef,
    r = 6371000
) {

  # Coerce inputs to matrix
  if (is.vector(pos_ecef)) {
    pos_ecef <- matrix(
      nrow = 1,
      ncol = 3,
      data = as.numeric(pos_ecef))
  }
  if (is.vector(ray_ecef)) {
    ray_ecef <- matrix(
      nrow = 1,
      ncol = 3,
      data = as.numeric(ray_ecef))
  }

  # Calculate the components of the quadratic equation
  a <- rowSums(ray_ecef * ray_ecef)
  b <- 2 * rowSums(ray_ecef * pos_ecef)
  c <- rowSums(pos_ecef * pos_ecef) - r^2
  descriminant <- b * b - 4 * a * c
  sqrt_descriminant <- rep(NA, length(descriminant))
  sqrt_descriminant[descriminant >= 0] <- sqrt(descriminant[descriminant >= 0])

  # Find the solution to the quadratic
  t1 <-
    cbind((-b + sqrt_descriminant) / (2 * a),
          (-b - sqrt_descriminant) / (2 * a)) %>%
    apply(1, min)

  # Find the intersection with the Earth
  ortho_ecef <-
    pos_ecef +
    stapply(1:nrow(ray_ecef), function(x) {ray_ecef[x,] * t1[x]})

  # Convert to geocentric
  ortho_geocentric <- GeocentricFromEcef(ortho_ecef)

  return(ortho_geocentric)

}

#' Calculate the intersection of a ray with an ellipsoid
#'
#' #' \code{IntersectEllipsoid} calculates the intersection of a ray with an
#' ellipsoid. A "ray" here is defined as half of a line, or a part of a line
#' with a starting point but no ending point. In the context of
#' orthorectification, the starting point (the parameter \code{pos_ecef}) is
#' the position of the instrument, and the half-line is the bore sight of a
#' pixel. The default ellipsoid is the WGS84 ellipsoid. An elevation can be
#' applied as a shell of constant elevation above the ellipsoid.
#'
#' @param pos_ecef vector, matrix, or data.frame with 3 columns of the
#'   position of the spacecraft in meters Earth-Centered Earth-Fixed
#' @param ray_ecef vector, matrix, or data.frame with 3 columns giving the
#'   vector pointing along the ray (the vector from the spacecraft along the
#'   instrument bore sight) in Earth-Centered Earth-Fixed. Must have the
#'   same shape as \code{pos_ecef}.
#' @param elevation optional. A vector with length equal to the number of rows
#'   in pos_ecef and ray_ecef. The surface elevation above the WGS84
#'   ellipsoid in meters. This is nonzero when you know the grid cell of the
#'   DEM that you are shooting to. When performing orthorectification, you
#'   first find the grid cell that best matches the ray, then you intersect the
#'   ellipsoid for that grid cell.
#' @param a semi-major axis in meters (default 6378137.0 for WGS84 ellipsoid)
#' @param b semi-minor axis in meters (default 6356752.3 for WGS84 ellipsoid)
#'
#' @return a data.frame of geodetic coordinates (lon, lat, alt)
#'
#' @examples
#' IntersectEllipsoid(
#'   pos_ecef =
#'     rbind(
#'       c(6379137.0, 0, 0),
#'       c(0, 0, 6356852.3)
#'     ),
#'   ray_ecef =
#'     rbind(
#'       c(-1, 0, 0),
#'       c(0, 0, -1)
#'     ),
#'   elevation = c(10, 10)
#' )
#'
#' @family orthorectification functions
#' @export
IntersectEllipsoid <- function(
    pos_ecef,
    ray_ecef,
    elevation = 0,
    a = 6378137.0,
    b = 6356752.3
) {

  # Inflate the ellipsoid parameters
  a <- a + elevation
  b <- b + elevation

  # Create abbreviated object names to shorten the code
  # for the solution to the quadratic
  x <- pos_ecef[1]
  y <- pos_ecef[2]
  z <- pos_ecef[3]
  u <- ray_ecef[1]
  v <- ray_ecef[2]
  w <- ray_ecef[3]

  # Define components of the solution to the quadratic
  value <-
    -a^2* a^2 * w * z -
    a^2 * b^2 * v * y -
    a^2 * b^2 * u * x
  radical <-
    a^2 * a^2 * w^2 +
    a^2 * b^2 * v^2 -
    a^2 * v^2 * z^2 +
    2 * a^2 * v * w * y * z -
    a^2 * w^2 * y^2 +
    a^2 * b^2 * u^2 -
    a^2 * u^2 * z^2 +
    2 * a^2 * u * w * x * z -
    a^2 * w^2 * x^2 -
    b^2 * u^2 * y^2 +
    2 * b^2 * u * v * x * y -
    b^2 * v^2 * x^2
  magnitude <-
    a^2 * a^2 * w^2 +
    a^2 * b^2 * v^2 +
    a^2 * b^2 * u^2

  # Solve the distance to the ellipsoid
  d <- (value - a * a * b * sqrt(radical)) / magnitude
  d[d < 0] <- NA

  # Calculate the point of intersection with the ellipsoid
  ortho_ecef <- data.frame(
    x = x + d * u,
    y = y + d * v,
    z = z + d * w
  )

  # convert to geodetic
  ortho_geodetic <-
    data.frame(
      lon = rep(NA, nrow(ortho_ecef)),
      lat = rep(NA, nrow(ortho_ecef)),
      alt = rep(NA, nrow(ortho_ecef))
    )
  ortho_geodetic[!is.na(ortho_ecef[,1]), ] <-
    GeodeticFromEcef(
      ecef = ortho_ecef[!is.na(ortho_ecef[,1]), ]
    )

  return(ortho_geodetic)

}

#' Compute pixel angles from camera model
#'
#' \code{CameraModel} is a function that computes the angles from center where
#' each pixel is located in a camera. It is a simple equation of a lens and
#' does not account for distortion.
#'
#' @param focal_length numeric focal length of the camera in mm
#' @param fov numeric angular field of view in radians
#' @param pixels numeric number of pixels
#' @param aggregate integer factor to aggregate pixels (default 1)
#'
#' @return A vector of rotation angles to produce pixels
#'
#' @examples
#' CameraModel(
#'   focal_length = 16,
#'   fov = 21.3 * pi / 180,
#'   pixels = 3,
#'   aggregate = 1
#'  )
#'
#' @family orthorectification functions
#' @export
CameraModel <- function(
    focal_length,
    fov,
    pixels,
    aggregate = 1
) {

  angles <-
    atan2(
      seq(
        from   = -focal_length * tan(fov/2),
        to     =  focal_length * tan(fov/2),
        length = pixels / aggregate
      ),
      (focal_length)
    )

  return(angles)

}

#' Restrict a digital elevation map to reduce its size for orthorectification
#'
#' @param spacecraft_state initial spacecraft state object. See documentation
#'   for the function SpacecraftState for more information. The entire
#'   time series will be orthorectified, so the user should restrict the file
#'   beforehand. The user should supply the spacecraft state at all indices
#'   until the end of the attitude, which likely includes one time after the
#'   labeled spacecraft state.
#' @param spacecraft_configuration a list containing configuration data for the
#'   spacecraft. The default is saved in package data as
#'   \code{ground_configuration} and contains initial information about
#'   MethaneSAT. See the data documentation for \code{ground_configuration}
#'   for more detail.
#' @param dem raster object of digital elevation map
#'
#' @return A digital elevation map raster
#'
#' @family orthorectification functions
#' @export

ClipDemToSpacecraftState <- function(
    dem,
    spacecraft_state,
    spacecraft_configuration = ground_configuration
  ) {

  # Select down to only the rows you need
  spacecraft_state <-
    dplyr::select(
      spacecraft_state,
      utc, pos_ecef, pos_geodetic, attitude_quaternion_eci, q_ei
    )

  points_alongtrack <- nrow(spacecraft_state)
  points_acrosstrack <- 2

  # Compute the camera model
  camera_model <-
    CameraModel(
      focal_length = spacecraft_configuration$instrument$focal_length_mm,
      fov          = (pi/180) * spacecraft_configuration$instrument$fov_deg,
      pixels       = 2
    )

  # Compute the boresight vectors
  spacecraft_state$attitude_quaternion_ecef <-
    QuaternionEcefFromEci(
      spacecraft_state$attitude_quaternion_eci,
      spacecraft_state$q_ei
    )

  # Calculate component attitudes
  component_attitudes <-
    ComponentAttitudes(
      spacecraft_configuration = spacecraft_configuration,
      attitude_quaternion = spacecraft_state$attitude_quaternion_ecef
    )

  # Calculate the pixel bores
  pixel_bores_ecef <-
    lapply(
      1:points_alongtrack,
      function(x) {
        RotateVectorR3(
          unlist(component_attitudes$instrument[x, ]),
          unlist(component_attitudes$radiator[x, ]),
          camera_model
        )
      }
    )

  # Find the center point on the ellipsoid for DEM cropping
  center_WGS84 <-
    IntersectEllipsoid(
      pos_ecef = spacecraft_state$pos_ecef[round(points_alongtrack / 2), ],
      ray_ecef = component_attitudes$instrument[round(points_alongtrack / 2), ],
      elevation = 0
    )

  # Find the corner points on the ellipsoid for DEM cropping
  corners_WGS84 <-
    rbind(
      IntersectEllipsoid(
        pos_ecef = spacecraft_state$pos_ecef[1, ],
        ray_ecef = pixel_bores_ecef[[1]][1, ],
        elevation = 0
      ),
      IntersectEllipsoid(
        pos_ecef = spacecraft_state$pos_ecef[1, ],
        ray_ecef = pixel_bores_ecef[[1]][points_acrosstrack, ],
        elevation = 0
      ),
      IntersectEllipsoid(
        pos_ecef = spacecraft_state$pos_ecef[points_alongtrack, ],
        ray_ecef = pixel_bores_ecef[[points_alongtrack]][1, ],
        elevation = 0
      ),
      IntersectEllipsoid(
        pos_ecef = spacecraft_state$pos_ecef[points_alongtrack, ],
        ray_ecef = pixel_bores_ecef[[points_alongtrack]][points_acrosstrack, ],
        elevation = 0
      )
    )

  # Find distance to clip raster
  buffer_dist <-
    sp::spDistsN1(
      pt      = c(center_WGS84$lon, center_WGS84$lat),
      pts     = cbind(corners_WGS84$lon, corners_WGS84$lat),
      longlat = TRUE) %>%
    max()

  # Clip the DEM to the desired area to speed up the orthorectification
  dem_raster_clipped  <-
    ClipRasterBuffer(
      ras       = dem,
      lon       = center_WGS84$lon,
      lat       = center_WGS84$lat,
      buffer_m  = 1.25 * buffer_dist * 1000,
      dateline  = TRUE
    )

  return(dem_raster_clipped)

}

#' Orthorectify scans to rectangular pixels, with the option to save to NetCDF
#'
#' @param spacecraft_state initial spacecraft state object. See documentation
#'   for the function SpacecraftState for more information. The entire
#'   time series will be orthorectified, so the user should restrict the file
#'   beforehand. The user should supply the spacecraft state at all indices
#'   until the end of the attitude, which likely includes one time after the
#'   labeled spacecraft state.
#' @param spacecraft_configuration a list containing configuration data for the
#'   spacecraft. The default is saved in package data as
#'   \code{ground_configuration} and contains initial information about
#'   MethaneSAT. See the data documentation for \code{ground_configuration}
#'   for more detail.
#' @param filename file base name base for output. ".nc" will be appended.
#'   If NA (default) then no file will be written.
#' @param framerate imaging frame rate in Hz (default 1 Hz for orthorectifying)
#'   simulated scans.
#' @param aggregate_alongtrack integer number of pixels to aggregate along
#'   track (default 1).
#' @param aggregate_acrosstrack integer number of pixels to aggregate across
#'   track (default 128).
#' @param dem_raster raster digital elevation map
#' @param verbose logical. If TRUE (default FALSE), then the progress is reported.
#'
#' @return A list of lonc, latc, altc - also saves a NetCDF defined by file name
#'
#' @family orthorectification functions
#' @export

OrthorectifyScan <- function(
    spacecraft_state,
    spacecraft_configuration = ground_configuration,
    filename = NA,
    framerate = 1,
    aggregate_alongtrack = 1,
    aggregate_acrosstrack = 128,
    dem_raster = NULL,
    verbose = FALSE
) {

  # Initialize progress bar
  if (verbose) {
    pb <- utils::txtProgressBar()
  }

  # Prep spacecraft_state ----

  # Select down to only the rows you need
  spacecraft_state <-
    dplyr::select(
      spacecraft_state,
      utc, pos_ecef, pos_geodetic, attitude_quaternion_eci, q_ei
    )

  # Calculate the required times for orthorectification
  # These are the start, center, and end of each aggregated frame
  utc <-
    seq(
      from = min(spacecraft_state$utc),
      to = max(spacecraft_state$utc),
      by = aggregate_alongtrack / (2 * framerate)
    )
  # Remove a partial frame
  if (length(utc) %% 2 == 0) {
    utc <- utc[1:(length(utc) - 1)]
  }
  # Count the number of frames
  frames <- (length(utc) - 1) / 2

  # Determine the fractional rows of the spacecraft state for interpolation
  spacecraft_state_rows <-
    stats::approx(
      x = spacecraft_state$utc,
      xout = utc,
      y = 1:nrow(spacecraft_state)
    )$y

  # Interpolate the spacecraft state
  spacecraft_state_interp <-
    InterpolateDataFrame(
      df = spacecraft_state,
      x = spacecraft_state_rows
    )

  # Generate camera model ----

  # Along-track
  points_alongtrack <- 2 * frames + 1
  inds_alongtrack_lower <- seq(from = 1, to = points_alongtrack - 2, by = 2)
  inds_alongtrack_middle <- seq(from = 2, to = points_alongtrack - 1, by = 2)
  inds_alongtrack_upper <- seq(from = 3, to = points_alongtrack, by = 2)

  # Across-track
  pixels_acrosstrack <-
    spacecraft_configuration$data_management$image$columns[1] /
    aggregate_acrosstrack
  points_acrosstrack <- 2 * pixels_acrosstrack + 1
  inds_acrosstrack_left <- seq(from = 1, to = points_acrosstrack - 2, by = 2)
  inds_acrosstrack_center <- seq(from = 2, to = points_acrosstrack - 1, by = 2)
  inds_acrosstrack_right <- seq(from = 3, to = points_acrosstrack, by = 2)

  # Compute the camera model
  camera_model <-
    CameraModel(
      focal_length = spacecraft_configuration$instrument$focal_length_mm,
      fov          = (pi/180) * spacecraft_configuration$instrument$fov_deg,
      pixels       = points_acrosstrack
    )

  # Compute the boresight vectors
  spacecraft_state_interp$attitude_quaternion_ecef <-
    QuaternionEcefFromEci(
      spacecraft_state_interp$attitude_quaternion_eci,
      spacecraft_state_interp$q_ei
    )

  # Calculate component attitudes
  component_attitudes <-
    ComponentAttitudes(
      spacecraft_configuration = spacecraft_configuration,
      attitude_quaternion = spacecraft_state_interp$attitude_quaternion_ecef
    )

  # Calculate the pixel bores
  pixel_bores_ecef <-
    lapply(
      1:points_alongtrack,
      function(x) {
        RotateVectorR3(
          unlist(component_attitudes$instrument[x, ]),
          unlist(component_attitudes$radiator[x, ]),
          camera_model
        )
      }
    )

  # Generate DEM ----

  # If the dem was given, overwrite the standard package dem
  if (!is.null(dem_raster)) {
    dem <- dem_raster
  }

  # Clip the raster to the local DEM
  dem_raster_clipped <-
    ClipDemToSpacecraftState(
      dem = dem,
      spacecraft_state = spacecraft_state_interp,
      spacecraft_configuration = ground_configuration
    )

  # Convert raster to geodetic data frame to get altitudes to shoot ellipsoid
  dem_geodetic <-
    raster::rasterToPoints(dem_raster_clipped, spatial=TRUE) %>%
    as.data.frame() %>%
    'colnames<-'(c("alt", "lon", "lat"))

  # Convert geodetic to ecef to calculate boresight pointing
  dem_ecef <- EcefFromGeodetic(dem_geodetic)

  # Orthorectify ----

  if (verbose) {cat("\nOrthorectifying")}

  # Surface variables
  orthorectified_lon <- array(dim = c(points_alongtrack, points_acrosstrack))
  orthorectified_lat <- array(dim = c(points_alongtrack, points_acrosstrack))
  orthorectified_alt <- array(dim = c(points_alongtrack, points_acrosstrack))

  # Orthorectify
  for (tick in 1:points_alongtrack) {

    if (verbose) {
      cat(paste0("\nOrthorectifying scan line ",
                 tick, " of ", points_alongtrack, "\n"))
    }

    # Pixel bore sights simulated to each DEM point
    pos_ecef_mat <-
      RepeatRows(spacecraft_state_interp$pos_ecef[tick, ], nrow(dem_ecef))
    boresight_sim_ecef <- NormalizeByRow(dem_ecef - pos_ecef_mat)

    # Snap the instrument boresights to the simulated pixel boresights
    dem_row <-
      boresight_sim_ecef %>%
      DistanceByRow(pixel_bores_ecef[[tick]]) %>%
      apply(2, which.min) %>%
      as.vector()

    # This gives
    orthorectified_alt[tick, ] <- dem_geodetic$alt[dem_row]

    # Shoot the ellipsoid for sub-grid accuracy
    orthorectified_now <-
      stapply(
        1:points_acrosstrack,
        function(x) {
          IntersectEllipsoid(
            pos_ecef    = spacecraft_state_interp$pos_ecef[tick, ],
            ray_ecef    = pixel_bores_ecef[[tick]][x, ],
            elevation   = dem_geodetic$alt[dem_row[x]]
          ) %>% unlist()
        }
      ) %>%
      as.data.frame() %>%
      'colnames<-'(c("lon", "lat", "alt"))

    # Save the result
    orthorectified_lon[tick, ] <- orthorectified_now$lon
    orthorectified_lat[tick, ] <- orthorectified_now$lat

  }

  # Separate pixel corners and centers -----

  # Centers
  lon <- orthorectified_lon[inds_alongtrack_middle, inds_acrosstrack_center]
  lat <- orthorectified_lat[inds_alongtrack_middle, inds_acrosstrack_center]
  alt <- orthorectified_alt[inds_alongtrack_middle, inds_acrosstrack_center]

  # Corners
  lonc <-
    abind::abind(
      orthorectified_lon[inds_alongtrack_lower, inds_acrosstrack_left],
      orthorectified_lon[inds_alongtrack_lower, inds_acrosstrack_right],
      orthorectified_lon[inds_alongtrack_upper, inds_acrosstrack_left],
      orthorectified_lon[inds_alongtrack_upper, inds_acrosstrack_right],
      along = 3
    )
  latc <-
    abind::abind(
      orthorectified_lat[inds_alongtrack_lower, inds_acrosstrack_left],
      orthorectified_lat[inds_alongtrack_lower, inds_acrosstrack_right],
      orthorectified_lat[inds_alongtrack_upper, inds_acrosstrack_left],
      orthorectified_lat[inds_alongtrack_upper, inds_acrosstrack_right],
      along = 3
    )
  altc <-
    abind::abind(
      orthorectified_alt[inds_alongtrack_lower, inds_acrosstrack_left],
      orthorectified_alt[inds_alongtrack_lower, inds_acrosstrack_right],
      orthorectified_alt[inds_alongtrack_upper, inds_acrosstrack_left],
      orthorectified_alt[inds_alongtrack_upper, inds_acrosstrack_right],
      along = 3
    )

  # Write Netcdf ----

  if (!is.na(filename)) {

    if (verbose) {cat("\nGenerating NetCDF")}

    # Make dimensions
    xvals <- 1:pixels_acrosstrack
    yvals <- 1:frames
    cvals <- 1:4
    nx <- pixels_acrosstrack
    ny <- frames
    nc <- 4
    xdim <-
      ncdf4::ncdim_def(
        'x',
        'acrosstrack',
        xvals)
    ydim <-
      ncdf4::ncdim_def(
        'y',
        'alongtrack',
        yvals)
    cdim <-
      ncdf4::ncdim_def(
        'c',
        'corner: lowerleft, lowerright, upperleft, upperright',
        cvals)

    # Make var
    mv <- 99999 # missing value
    var_lon  <-
      ncdf4::ncvar_def(
        'Geolocation/CenterLongitude',
        'degrees',
        list(xdim,ydim),
        mv)
    var_lat  <-
      ncdf4::ncvar_def(
        'Geolocation/CenterLatitude',
        'degrees',
        list(xdim,ydim),
        mv)
    var_alt  <- ncdf4::ncvar_def(
      'Geolocation/CenterAltitude',
      'm WGS84',
      list(xdim,ydim),
      mv)
    var_lonc <- ncdf4::ncvar_def(
      'Geolocation/CornerLongitude',
      'degrees',
      list(xdim,ydim,cdim),
      mv)
    var_latc <- ncdf4::ncvar_def(
      'Geolocation/CornerLatitude',
      'degrees',
      list(xdim,ydim,cdim),
      mv)
    var_altc <- ncdf4::ncvar_def(
      'Geolocation/CornerAltitude',
      'm WGS84',
      list(xdim,ydim,cdim),
      mv)
    # Make new output file
    ncid_new <-
      ncdf4::nc_create(
        paste0(filename, ".nc"),
        list(var_lon,
             var_lat,
             var_alt,
             var_lonc,
             var_latc,
             var_altc))

    # Fill the file with data
    ncdf4::ncvar_put(
      ncid_new, var_lon,
      t(lon),
      start=c(1,1),
      count=c(nx,ny))
    ncdf4::ncvar_put(
      ncid_new,
      var_lat,
      t(lat),
      start=c(1,1),
      count=c(nx,ny))
    ncdf4::ncvar_put(
      ncid_new,
      var_alt,
      t(alt),
      start=c(1,1),
      count=c(nx,ny))
    ncdf4::ncvar_put(
      ncid_new,
      var_lonc,
      aperm(lonc, c(2,1,3)),
      start=c(1,1,1),
      count=c(nx,ny,nc))
    ncdf4::ncvar_put(
      ncid_new,
      var_latc,
      aperm(latc, c(2,1,3)),
      start=c(1,1,1),
      count=c(nx,ny,nc))
    ncdf4::ncvar_put(
      ncid_new,
      var_altc,
      aperm(altc, c(2,1,3)),
      start=c(1,1,1),
      count=c(nx,ny,nc))

    # Close our new output file
    ncdf4::nc_close(ncid_new)

  }

  # Return the corner longitude and latitude
  output <-
    list(
      center =
        list(
          lon = lon,
          lat = lat,
          alt = alt
        ),
      corners =
        list(
          lon = lonc,
          lat = latc,
          alt = altc
        )
    )
  return(output)

}

#' Orthorectify scans to pixel centers
#'
#' @param spacecraft_state initial spacecraft state object. See documentation
#'   for the function SpacecraftState for more information. The entire
#'   time series will be orthorectified, so the user should restrict the file
#'   beforehand. The user should supply the spacecraft state at all indices
#'   until the end of the attitude, which likely includes one time after the
#'   labeled spacecraft state.
#' @param spacecraft_configuration a list containing configuration data for the
#'   spacecraft. The default is saved in package data as
#'   \code{ground_configuration} and contains initial information about
#'   MethaneSAT. See the data documentation for \code{ground_configuration}
#'   for more detail.
#' @param framerate imaging frame rate in Hz (default 1 Hz for orthorectifying)
#'   simulated scans.
#' @param aggregate_alongtrack integer number of pixels to aggregate along
#'   track (default 1).
#' @param aggregate_acrosstrack integer number of pixels to aggregate across
#'   track (default 128).
#' @param dem_raster raster digital elevation map
#' @param verbose logical. If TRUE (default), then the progress is reported.
#'
#' @return A list of lonc, latc, altc - also saves a NetCDF defined by file name
#'
#' @family orthorectification functions
#' @export

OrthorectifyScanCenters <- function(
    spacecraft_state,
    spacecraft_configuration = ground_configuration,
    framerate = 1,
    aggregate_alongtrack = 1,
    aggregate_acrosstrack = 128,
    dem_raster = NULL,
    verbose = FALSE
) {

  # Initialize progress bar
  if (verbose) {
    pb <- utils::txtProgressBar()
  }

  # Prep spacecraft_state ----

  # Select down to only the rows you need
  spacecraft_state <-
    dplyr::select(
      spacecraft_state,
      utc, pos_ecef, pos_geodetic, attitude_quaternion_eci, q_ei
    )

  # Calculate the required times for orthorectification
  # These are the start, center, and end of each aggregated frame
  utc <-
    seq(
      from = min(spacecraft_state$utc),
      to = max(spacecraft_state$utc),
      by = aggregate_alongtrack / (2 * framerate)
    )
  # Remove a partial frame
  if (length(utc) %% 2 == 0) {
    utc <- utc[1:(length(utc) - 1)]
  }
  # Count the number of frames
  frames <- (length(utc) - 1) / 2

  # Determine the fractional rows of the spacecraft state for interpolation
  spacecraft_state_rows <-
    stats::approx(
      x = spacecraft_state$utc,
      xout = utc,
      y = 1:nrow(spacecraft_state)
    )$y

  # Interpolate the spacecraft state
  spacecraft_state_interp <-
    InterpolateDataFrame(
      df = spacecraft_state,
      x = spacecraft_state_rows
    )

  # For pixel centers we only want the middle
  inds_alongtrack_middle <- seq(from = 2, to = 2 * frames, by = 2)
  spacecraft_state_interp <- spacecraft_state_interp[inds_alongtrack_middle, ]
  points_alongtrack <- length(inds_alongtrack_middle)

  # Generate camera model ----

  # Across-track
  pixels_acrosstrack <-
    spacecraft_configuration$data_management$image$columns[1] /
    aggregate_acrosstrack
  inds_acrosstrack_center <- seq(from = 2, to = 2 * pixels_acrosstrack, by = 2)
  points_acrosstrack <- length(inds_acrosstrack_center)

  # Compute the camera model -
  # This must be done with the full pixel array then narrowed to the centers
  camera_model <-
    CameraModel(
      focal_length = spacecraft_configuration$instrument$focal_length_mm,
      fov          = (pi/180) * spacecraft_configuration$instrument$fov_deg,
      pixels       = 2 * points_acrosstrack + 1
    )
  camera_model <- camera_model[inds_acrosstrack_center]

  # Compute the boresight vectors
  spacecraft_state_interp$attitude_quaternion_ecef <-
    QuaternionEcefFromEci(
      spacecraft_state_interp$attitude_quaternion_eci,
      spacecraft_state_interp$q_ei
    )

  # Calculate component attitudes
  component_attitudes <-
    ComponentAttitudes(
      spacecraft_configuration = spacecraft_configuration,
      attitude_quaternion = spacecraft_state_interp$attitude_quaternion_ecef
    )

  # Calculate the pixel bores
  pixel_bores_ecef <-
    lapply(
      1:points_alongtrack,
      function(x) {
        RotateVectorR3(
          unlist(component_attitudes$instrument[x, ]),
          unlist(component_attitudes$radiator[x, ]),
          camera_model
        )
      }
    )

  # Generate DEM ----

  # If the dem was given, overwrite the standard package dem
  if (!is.null(dem_raster)) {
    dem <- dem_raster
  }

  # Clip the raster to the local DEM
  dem_raster_clipped <-
    ClipDemToSpacecraftState(
      dem = dem,
      spacecraft_state = spacecraft_state_interp,
      spacecraft_configuration = ground_configuration
    )

  # Convert raster to geodetic data frame to get altitudes to shoot ellipsoid
  dem_geodetic <-
    raster::rasterToPoints(dem_raster_clipped, spatial=TRUE) %>%
    as.data.frame() %>%
    'colnames<-'(c("alt", "lon", "lat"))

  # Convert geodetic to ecef to calculate boresight pointing
  dem_ecef <- EcefFromGeodetic(dem_geodetic)

  # Orthorectify ----

  if (verbose) {cat("\nOrthorectifying")}

  # Surface variables
  orthorectified_lon <- array(dim = c(points_alongtrack, points_acrosstrack))
  orthorectified_lat <- array(dim = c(points_alongtrack, points_acrosstrack))
  orthorectified_alt <- array(dim = c(points_alongtrack, points_acrosstrack))

  # Orthorectify
  for (tick in 1:points_alongtrack) {

    if (verbose) {
      cat(paste0("\nOrthorectifying scan line ",
                 tick, " of ", points_alongtrack, "\n"))
    }

    # Pixel bore sights simulated to each DEM point
    pos_ecef_mat <- RepeatRows(spacecraft_state_interp$pos_ecef[tick, ], nrow(dem_ecef))
    boresight_sim_ecef <- NormalizeByRow(dem_ecef - pos_ecef_mat)

    # Snap the instrument boresights to the simulated pixel boresights
    dem_row <-
      boresight_sim_ecef %>%
      DistanceByRow(pixel_bores_ecef[[tick]]) %>%
      apply(2, which.min) %>%
      as.vector()

    # This gives
    orthorectified_alt[tick, ] <- dem_geodetic$alt[dem_row]

    # Shoot the ellipsoid for sub-grid accuracy
    orthorectified_now <-
      stapply(1:points_acrosstrack,
              function(x) {
                IntersectEllipsoid(
                  pos_ecef    = spacecraft_state_interp$pos_ecef[tick, ],
                  ray_ecef    = pixel_bores_ecef[[tick]][x, ],
                  elevation   = dem_geodetic$alt[dem_row[x]]
                ) %>% unlist()
              }
      ) %>%
      as.data.frame() %>%
      'colnames<-'(c("lon", "lat", "alt"))

    # Save the result
    orthorectified_lon[tick, ] <- orthorectified_now$lon
    orthorectified_lat[tick, ] <- orthorectified_now$lat

  }

  # Return the corner longitude and latitude
  output <-
    list(
      lon = orthorectified_lon,
      lat = orthorectified_lat,
      alt = orthorectified_alt
    )
  return(output)

}

#' Orthorectify scans to rectangular pixels on the WGS84 Ellipsoid
#'
#' This function is a faster version of OrthorectifyScan that orthorectifies to
#' the WGS84 ellipsoid instead of a DEM. It is useful for applications where
#' a rough estimate of the pixel locations is all that is needed. It is over 12x
#' faster than OrthorectifyScan, and will give error equal to the height of the
#' surface elevation above WGS84.
#'
#' @param spacecraft_state initial spacecraft state object. See documentation
#'   for the function SpacecraftState for more information. The entire
#'   time series will be orthorectified, so the user should restrict the file
#'   beforehand. The user should supply the spacecraft state at all indices
#'   until the end of the attitude, which likely includes one time after the
#'   labeled spacecraft state.
#' @param spacecraft_configuration a list containing configuration data for the
#'   spacecraft. The default is saved in package data as
#'   \code{ground_configuration} and contains initial information about
#'   MethaneSAT. See the data documentation for \code{ground_configuration}
#'   for more detail.
#' @param filename file base name base for output. ".nc" will be appended.
#'   If NA (default) then no file will be written.
#' @param framerate imaging frame rate in Hz (default 1 Hz for orthorectifying)
#'   simulated scans.
#' @param aggregate_alongtrack integer number of pixels to aggregate along
#'   track (default 1).
#' @param aggregate_acrosstrack integer number of pixels to aggregate across
#'   track (default 128).
#' @param verbose logical. If TRUE (default), then the progress is reported.
#'
#' @return A list of lonc, latc, altc - also saves a NetCDF defined by file name
#'
#' @family orthorectification functions
#' @export

OrthorectifyScanWGS84 <- function(
    spacecraft_state,
    spacecraft_configuration = ground_configuration,
    filename = NA,
    framerate = 1,
    aggregate_alongtrack = 1,
    aggregate_acrosstrack = 128,
    verbose = FALSE
) {

  # Initialize progress bar
  if (verbose) {
    pb <- utils::txtProgressBar()
  }

  # Prep spacecraft_state ----

  # Select down to only the rows you need
  spacecraft_state <-
    dplyr::select(
      spacecraft_state,
      utc, pos_ecef, pos_geodetic, attitude_quaternion_eci, q_ei
    )

  # Calculate the required times for orthorectification
  # These are the start, center, and end of each aggregated frame
  utc <-
    seq(
      from = min(spacecraft_state$utc),
      to = max(spacecraft_state$utc),
      by = aggregate_alongtrack / (2 * framerate)
    )
  # Remove a partial frame
  if (length(utc) %% 2 == 0) {
    utc <- utc[1:(length(utc) - 1)]
  }
  # Count the number of frames
  frames <- (length(utc) - 1) / 2

  # Determine the fractional rows of the spacecraft state for interpolation
  spacecraft_state_rows <-
    stats::approx(
      x = spacecraft_state$utc,
      xout = utc,
      y = 1:nrow(spacecraft_state)
    )$y

  # Interpolate the spacecraft state
  spacecraft_state_interp <-
    InterpolateDataFrame(
      df = spacecraft_state,
      x = spacecraft_state_rows
    )

  # Generate camera model ----

  # Along-track
  points_alongtrack <- 2 * frames + 1
  inds_alongtrack_lower <- seq(from = 1, to = points_alongtrack - 2, by = 2)
  inds_alongtrack_middle <- seq(from = 2, to = points_alongtrack - 1, by = 2)
  inds_alongtrack_upper <- seq(from = 3, to = points_alongtrack, by = 2)

  # Across-track
  pixels_acrosstrack <-
    spacecraft_configuration$data_management$image$columns[1] /
    aggregate_acrosstrack
  points_acrosstrack <- 2 * pixels_acrosstrack + 1
  inds_acrosstrack_left <- seq(from = 1, to = points_acrosstrack - 2, by = 2)
  inds_acrosstrack_center <- seq(from = 2, to = points_acrosstrack - 1, by = 2)
  inds_acrosstrack_right <- seq(from = 3, to = points_acrosstrack, by = 2)

  # Compute the camera model
  camera_model <-
    CameraModel(
      focal_length = spacecraft_configuration$instrument$focal_length_mm,
      fov          = (pi/180) * spacecraft_configuration$instrument$fov_deg,
      pixels       = points_acrosstrack
    )

  # Compute the boresight vectors
  spacecraft_state_interp$attitude_quaternion_ecef <-
    QuaternionEcefFromEci(
      spacecraft_state_interp$attitude_quaternion_eci,
      spacecraft_state_interp$q_ei
    )

  # Calculate component attitudes
  component_attitudes <-
    ComponentAttitudes(
      spacecraft_configuration = spacecraft_configuration,
      attitude_quaternion = spacecraft_state_interp$attitude_quaternion_ecef
    )

  # Calculate the pixel bores
  pixel_bores_ecef <-
    lapply(
      1:points_alongtrack,
      function(x) {
        RotateVectorR3(
          unlist(component_attitudes$instrument[x, ]),
          unlist(component_attitudes$radiator[x, ]),
          camera_model
        )
      }
    )

  # Orthorectify ----

  if (verbose) {cat("\nOrthorectifying")}

  # Surface variables
  orthorectified_lon <- array(dim = c(points_alongtrack, points_acrosstrack))
  orthorectified_lat <- array(dim = c(points_alongtrack, points_acrosstrack))
  orthorectified_alt <- array(dim = c(points_alongtrack, points_acrosstrack))

  # Orthorectify
  for (tick in 1:points_alongtrack) {

    if (verbose) {
      cat(paste0("\nOrthorectifying scan line ",
                 tick, " of ", points_alongtrack, "\n"))
    }

    # Shoot the ellipsoid
    orthorectified_now <-
      stapply(1:points_acrosstrack,
              function(x) {
                IntersectEllipsoid(
                  pos_ecef    = spacecraft_state_interp$pos_ecef[tick, ],
                  ray_ecef    = pixel_bores_ecef[[tick]][x, ],
                  elevation   = 0
                ) %>% unlist()
              }
      ) %>%
      as.data.frame() %>%
      'colnames<-'(c("lon", "lat", "alt"))

    # Save the result
    orthorectified_lon[tick, ] <- orthorectified_now$lon
    orthorectified_lat[tick, ] <- orthorectified_now$lat

  }

  # Separate pixel corners and centers -----

  # Centers
  lon <- orthorectified_lon[inds_alongtrack_middle, inds_acrosstrack_center]
  lat <- orthorectified_lat[inds_alongtrack_middle, inds_acrosstrack_center]
  alt <- orthorectified_alt[inds_alongtrack_middle, inds_acrosstrack_center]

  # Corners
  lonc <-
    abind::abind(
      orthorectified_lon[inds_alongtrack_lower, inds_acrosstrack_left],
      orthorectified_lon[inds_alongtrack_lower, inds_acrosstrack_right],
      orthorectified_lon[inds_alongtrack_upper, inds_acrosstrack_left],
      orthorectified_lon[inds_alongtrack_upper, inds_acrosstrack_right],
      along = 3
    )
  latc <-
    abind::abind(
      orthorectified_lat[inds_alongtrack_lower, inds_acrosstrack_left],
      orthorectified_lat[inds_alongtrack_lower, inds_acrosstrack_right],
      orthorectified_lat[inds_alongtrack_upper, inds_acrosstrack_left],
      orthorectified_lat[inds_alongtrack_upper, inds_acrosstrack_right],
      along = 3
    )
  altc <-
    abind::abind(
      orthorectified_alt[inds_alongtrack_lower, inds_acrosstrack_left],
      orthorectified_alt[inds_alongtrack_lower, inds_acrosstrack_right],
      orthorectified_alt[inds_alongtrack_upper, inds_acrosstrack_left],
      orthorectified_alt[inds_alongtrack_upper, inds_acrosstrack_right],
      along = 3
    )

  # Return the corner longitude and latitude
  output <-
    list(
      center =
        list(
          lon = lon,
          lat = lat,
          alt = alt
        ),
      corners =
        list(
          lon = lonc,
          lat = latc,
          alt = altc
        )
    )
  return(output)

}

#' Orthorectify the X-band antenna to the WGS84 ellipsoid for plotting
#'
#' This function calculates the orthorectification of the X-Band antenna to the
#' surface of the Earth. During a downlink, the X-Band antenna is pointed at
#' the intersection of the dish gimbal azimuth and zenith. The point will be
#' static and will not intersect pervectly with the WGS84 ellipsoid.
#' This function therefore is valuable for plotting purposes only - to display
#' the approach of the antenna boresight during a simulation.
#'
#' @param spacecraft_state initial spacecraft state object. See documentation
#'   for the function SpacecraftState for more information. The entire
#'   time series will be orthorectified, so the user should restrict the file
#'   beforehand. The user should supply the spacecraft state at all indices
#'   until the end of the attitude, which likely includes one time after the
#'   labeled spacecraft state.
#' @param spacecraft_configuration a list containing configuration data for the
#'   spacecraft. The default is saved in package data as
#'   \code{ground_configuration} and contains initial information about
#'   MethaneSAT. See the data documentation for \code{ground_configuration}
#'   for more detail.
#'
#' @return A data.frame of xband intersections with lon, lat, and alt in
#'   meters above WGS84
#'
#' @family orthorectification functions
#' @export
OrthorectifyAntenna <- function(
    spacecraft_state,
    spacecraft_configuration
  ) {

  # Select down to only the rows you need
  spacecraft_state <-
    dplyr::select(
      spacecraft_state,
      utc, pos_ecef, pos_geodetic, attitude_quaternion_eci, q_ei
    )

  # Compute the boresight vectors
  spacecraft_state$attitude_quaternion_ecef <-
    QuaternionEcefFromEci(
      spacecraft_state$attitude_quaternion_eci,
      spacecraft_state$q_ei
    )

  # Calculate component attitudes
  component_attitudes <-
    ComponentAttitudes(
      spacecraft_configuration = spacecraft_configuration,
      attitude_quaternion = spacecraft_state$attitude_quaternion_ecef
    )

  # Orthorectify
  xband_intersection <-
    IntersectEllipsoid(
      pos_ecef    = spacecraft_state$pos_ecef,
      ray_ecef    = component_attitudes$xband_antenna,
      elevation   = 0
    )

  return(xband_intersection)

}

#' Orthorectify the center o the instrument array to a point on the limb
#'
#' This function finds the lowest point in the atmosphere where the center
#' of the instrument array intersects the atmosphere (i.e. the limb). It
#' will find the longitude, latitude, and altitude of the limb intersection.
#' If center of the instrument array intersects the Earth's surface, it will
#' report an error and return null. To orthorectify a scan to the Earth's
#' surface, please see the function \code{OrthorectifyScan}.
#'
#' @param spacecraft_state initial spacecraft state object. See documentation
#'   for the function SpacecraftState for more information. The entire
#'   time series will be orthorectified, so the user should restrict the time
#'   beforehand. The user should supply the spacecraft state at all indices
#'   until the end of the attitude, which likely includes one time after the
#'   spacecraft state is labeled with the activity.
#' @param spacecraft_configuration a list containing configuration data for the
#'   spacecraft. The default is saved in package data as
#'   \code{ground_configuration} and contains initial information about
#'   MethaneSAT. See the data documentation for \code{ground_configuration}
#'   for more detail.
#' @param verbose logical. If TRUE (default FALSE), then the progress is reported.
#'
#' @return A data.frame of array center intersections with lon, lat, and alt in
#'   meters above WGS84.
#'
#' @family orthorectification functions
#' @export
OrthorectifyLimb <- function(
    spacecraft_state,
    spacecraft_configuration = ground_configuration,
    verbose = FALSE
) {

  # Constants
  R_Earth <- 6371000 # Radius of the Earth in meters
  n_alt <- 1000
  altitudes <-
    seq(
      from = 0,
      to = NormByRow(spacecraft_state$pos_ecef[1, ]) - R_Earth,
      length = n_alt
    )
  # Get the instrument attitude to use as a ray to shoot at the ellipsoid of
  # various altitudes
  instrument_eci <-
    ComponentAttitudes(
      spacecraft_configuration = spacecraft_configuration,
      attitude_quaternion = spacecraft_state$attitude_quaternion_eci
    )$instrument
  instrument_ecef <-
    EcefFromEci(
      eci = instrument_eci,
      q_ei = spacecraft_state$q_ei
    )
  if (verbose) {
    pb <- utils::txtProgressBar(style = 3)
  }

  # Initialize the data frame of intersections for the entire limb scan.
  intersections <-
    data.frame(
      lon = rep(NA, nrow(spacecraft_state)),
      lat = rep(NA, nrow(spacecraft_state)),
      alt = rep(NA, nrow(spacecraft_state))
    )
  for (index in 1:nrow(spacecraft_state)) {
    if (verbose) {
      cat("\n index ", index, " of ", nrow(spacecraft_state))
    }
    # Initialize the possible intersections for this index
    intersections_now <-
      data.frame(
        lon = rep(NA, n_alt),
        lat = rep(NA, n_alt),
        alt = rep(NA, n_alt)
      )
    # For each possible altitude of intersection, find the angle
    for (alt.tick in 1:n_alt) {
      if (verbose) {
        utils::setTxtProgressBar(pb, alt.tick / n_alt)
      }
      # Find the location where the ray intersects with the ellipsoid
      intersection_point_geodetic <-
        suppressWarnings(
          IntersectEllipsoid(
            pos_ecef = spacecraft_state$pos_ecef[index, ],
            ray_ecef = instrument_ecef[index, ],
            elevation = altitudes[alt.tick]
          )
        )
      intersections_now$lon[alt.tick] <- intersection_point_geodetic$lon
      intersections_now$lat[alt.tick] <- intersection_point_geodetic$lat
      intersections_now$alt[alt.tick] <- intersection_point_geodetic$alt
    }
    intersections[index, ] <-
      intersections_now[min(which(!is.na(intersections_now$alt))), ]
  }
  return(intersections)
}

