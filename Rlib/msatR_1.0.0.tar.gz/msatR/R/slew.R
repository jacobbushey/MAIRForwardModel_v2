# Slew functions

# These functions calculate slews from one attitude and rate to another.
# They are designed to calculate short slews with low computational cost.
# There are two slew algorithms: a very simple and low computational cost
# algorithm that follows the path of a Spherical Linear intERPolarion (SLERP),
# And a near-optimal slew algorithm that solves a system of differential
# equations in rotation vectors.
#
# The SLERP slew algorithm is a rest-to-rest slew, meaning that it first
# computes the deceleration of the spacecraft to rest in the inertial frame,
# then computes the rest-to-rest slew between the starting and ending
# rest attitudes.
#
# The near-optimal slew algorithm was adapted from Aucoin et al., (2019)
# Real-Time Optimal Slew Maneuver Planning for Small Satellites.
# 33rd Annual AIAA/USU Conference on Small Satellites. SSC19-VIII-02.
# It is a generic algorithm for fast computation of near-optimal slews
# with non-zero initial angular velocity and acceleration.
# Agility is constrained by the axis (my own adaptation), but the
# algorithm does not consider keep-out regions.
#
# This code also contains helper functions that compute time derivatives
# of rotation vectors.

# Bezier Slew------------------------------------------------------------------

#' Compute a slew along the path of a cubic Bezier curve
#'
#' This slew model calculates a slew using the interpolation
#' along a spherical quadrilateral using a cubic Bezier curve in quaternion
#' space. It uses the initial and final attitudes as the control points q_0
#' and q_3, and applies the quaternion rate of change to find the control
#' points q_1 and q_2. This allows a slew similar to the SLERP that does not
#' have to start and and at rest.
#'
#' @param q_0 vector quaternion initial attitude (Hamilton's order convention)
#' @param q_1 vector quaternion initial attitude plus 1 second (Hamilton's
#'   order convention)
#' @param q_2 vector quaternion final attitude minus 1 second (Hamilton's ordero
#'   convention)
#' @param q_3 vector quaternion final attitude (Hamilton's order convention)
#' @param spacecraft_configuration a list containing configuration data for the
#'   spacecraft. The default is saved in package data as
#'   "ground_configuration" and contains initial information about
#'   MethaneSAT. See the data documentation for "ground_configuration" for
#'   more detail.
#'
#' @keywords internal
#' @family slew functions
#' @export
SlewBezier <- function(
    q_0,
    q_1,
    q_2,
    q_3,
    slerp_progress,
    spacecraft_configuration
) {

  # Compute cubic Bezier curve for every point along slerp_progress
  q_out <-
    stapply(slerp_progress,
      function(x) {
        unlist(q_0) * (1-x)^3  +
        unlist(q_1) * 3 * (1 - x)^2 * x +
        unlist(q_2) * 3 * (1 - x) * x^2 +
        unlist(q_3) * x^3
      }
    ) %>%
    as.data.frame() %>%
    NormalizeByRow()

  return(q_out)

}

# SLERP slew-------------------------------------------------------------------

#' Compute the SLERP interpolation between quaternions
#'
#' This function interpolates between quaternions along the spherical path.
#'
#' @param q_0 vector quaternion initial attitude (Hamilton's order convention)
#' @param q_k vector quaternion final attitude (Hamilton's order convention)
#' @param slerp_progress numeric in 0 to 1 preogress along slew
#'
#' @keywords internal
#' @family slew functions
#' @export
QuaternionSlerp <- function(
    q_0,
    q_k,
    slerp_progress,
    dot_threshold = 0.9995
) {

  dot <- sum(q_0 * q_k)
  if (dot < 0) {
    q_k <- - q_k
    dot <- - dot
  }

  if (dot > 0.999995) {
    result <- as.data.frame(rbind(c(1, q_0), c(2, q_k)))
    colnames(result) <- c("t", "q_r", "q_i1", "q_i2", "q_i3")
  } else {
    if (dot > dot_threshold) {
      result  <-
        stapply(
          slerp_progress,
          function(x) {
            unlist(NormalizeByRow(q_0 + x * (q_k - q_0)))
          }
        )
      result  <- data.frame(
        t     = seq(from = 0, to = (length(slerp_progress) - 1), by = 1),
        q_r   = result[,1],
        q_i1  = result[,2],
        q_i2  = result[,3],
        q_i3  = result[,4]
      )
    } else {
      theta_0 <- acos(dot)
      theta   <- theta_0 * slerp_progress
      s0      <- cos(theta) - dot * sin(theta) / sin(theta_0)
      s1      <- sin(theta) / sin(theta_0)
      result  <-
        stapply(
          1:length(slerp_progress),
          function(x) {
            unlist(NormalizeByRow(s0[x] * q_0 + s1[x] * q_k))
            }
          )
      result  <- data.frame(
        t     = seq(from = 0, to = (length(slerp_progress) - 1), by = 1),
        q_r   = result[,1],
        q_i1  = result[,2],
        q_i2  = result[,3],
        q_i3  = result[,4]
      )
    }
  }

  return(result)

}

#' Compute the slew to bring the spacecraft to rest
#'
#' The quaternion Spherical Linear intERPolation (SLERP) slew can only
#' compute the slew from rest-to-rest. In order to implement this slew,
#' we ned to bring the spacecraft to rest without violating the agility
#' constraints. This function calculates that slew. It is used as a
#' component of the full SLERP slew code in \code{Slew_Slerp}.
#'
#' @param q_0m1 vector quaternion initial attitude minus 1 second (q_r leads)
#' @param q_0 vector quaternion initial attitude (q_r leads)
#' @param spacecraft_configuration a list containing configuration data for the
#'   spacecraft. The default is saved in package data as
#'   "ground_configuration" and contains initial information about
#'   MethaneSAT. See the data documentation for "ground_configuration" for
#'   more detail.
#'
#' @keywords internal
#' @family slew functions
#' @export
SlewToRest <- function(
    q_0m1,
    q_0,
    spacecraft_configuration
) {

  # Measure the angle and axis between the quaternions
  rotation <- AxisBetweenQuaternions(q_0m1, q_0)

  # Measure how fast we can slew around this axis
  acceleration_max <-
    (spacecraft_configuration$constraints$angular_acceleration_max_degps2 /
    c(rotation$x, rotation$y, rotation$z)) %>%
    abs() %>%
    min() %>%
    "*"(pi / 180)
  velocity_max <-
    (spacecraft_configuration$constraints$angular_velocity_max_degps /
    c(rotation$x, rotation$y, rotation$z)) %>%
    abs() %>%
    min() %>%
    "*"(pi / 180)

  # Measure the time to decelerate to rest about the axis
  time_decel <- ceiling(rotation$angle / acceleration_max)

  # Calculate the deceleration quaternion
  q_decel <- matrix(nrow = time_decel + 3, ncol = 4)
  q_decel[1, ] <- unlist(q_0m1)
  q_decel[2, ] <- unlist(q_0)
  quat_diff <- QuaternionMultiply(q_0m1, QuaternionInvert(q_0))
  for (tick in 1:time_decel) {
    vel_norm <-
      0.5 * sqrt(1 - cos(rotation$angle - tick * acceleration_max)^2)
    accel_quat <-
      c(
        cos(tick * acceleration_max),
        -quat_diff[2:4] * vel_norm / NormByRow(quat_diff[2:4])
      ) %>%
      unlist()
    new_quat <-
      QuaternionMultiply(
        accel_quat,
        q_decel[tick + 1, ]
      ) %>%
      NormalizeByRow() %>%
      unlist()
    q_decel[tick + 2, ] <- new_quat
  }
  q_decel[nrow(q_decel), ] <- new_quat

  # Return as a data.frame
  q_decel <- as.data.frame(q_decel)
  colnames(q_decel) <- c("r", "i1", "i2", "i3")

  return(q_decel)

}

#' Compute the time required for an axis-independent rest-to-rest SLERP slew
#'
#' The fastest possible spacecraft slew from one attitude at rest to another
#' attitude at rest, with limited angular velocity and acceleration
#' (independent of the axis) is the kinematic movement through a Spherical
#' Linear intERPolation (SLERP). This function calculates the time required
#' for a SLERP between attitudes given as quaternions.
#'
#' @param q_0 vector quaternion initial attitude (q_r leads)
#' @param q_k vector quaternion final attitude plus 1 (q_r leads)
#' @param spacecraft_configuration a list containing configuration data for the
#'   spacecraft. The default is saved in package data as
#'   "ground_configuration" and contains initial information about
#'   MethaneSAT. See the data documentation for "ground_configuration" for
#'   more detail.
#'
#' @return numeric time required to slew in seconds
#'
#' @keywords internal
#' @family slew functions
#' @export
SlewSlerpTime <- function(
    q_0,
    q_k,
    spacecraft_configuration
) {

  # Measure the angle and axis between the quaternions
  rotation <- AxisBetweenQuaternions(q_0, q_k)

  # Measure how fast we can slew around this axis
  acceleration_max <-
    stapply(
      1:nrow(rotation),
      function(s) {
        (spacecraft_configuration$constraints$angular_acceleration_max_degps2 /
        c(rotation$x[s], rotation$y[s], rotation$z[s])) %>%
        abs() %>%
        min() %>%
        "*"(pi / 180)
      }
    ) %>%
    as.vector()
  velocity_max <-
    stapply(
      1:nrow(rotation),
      function(s) {
        (spacecraft_configuration$constraints$angular_velocity_max_degps /
        c(rotation$x[s], rotation$y[s], rotation$z[s])) %>%
        abs() %>%
        min() %>%
        "*"(pi / 180)
      }
    ) %>%
    as.vector()

  # Determine if there is a coast period in the middle of the slew
  coastflag <-
    (rotation$angle > (velocity_max^2 / acceleration_max))

  # Calculate the slew time
  slerp_time <- rep(NA, length(rotation$angle))
  slerp_time[ coastflag] <-
    (rotation$angle[coastflag] / velocity_max + velocity_max / acceleration_max)
  slerp_time[!coastflag] <-
    2 * sqrt(rotation$angle[!coastflag] / acceleration_max)

  return(slerp_time)

}

#' Compute the axis-independent rest-to-rest SLERP slew
#'
#' The fastest possible spacecraft slew from one attitude at rest to another
#' attitude at rest, with limited angular velocity and acceleration
#' (independent of the axis) is the kinematic movement through a Spherical
#' Linear intERPolation (SLERP). This function calculates the attitude profile
#' for a SLERP between attitudes given as quaternions.
#'
#' @param q_0m1 vector quaternion initial attitude minus 1 second (q_r leads)
#' @param q_0 vector quaternion initial attitude (q_r leads)
#' @param q_k vector quaternion final attitude plus 1 (q_r leads)
#' @param q_kp1 vector quaternion final attitude plus 1 second (q_r leads)
#' @param spacecraft_configuration a list containing configuration data for the
#'   spacecraft. The default is saved in package data as
#'   "ground_configuration" and contains initial information about
#'   MethaneSAT. See the data documentation for "ground_configuration" for
#'   more detail.
#' @param dot_threshold numeric maximum dot product between quaternions to
#'   default out of algorithm (something near 1, 0.9995 is default),
#'
#' @return numeric time required to slew in seconds
#'
#' @keywords internal
#' @family slew functions
#' @export
SlewSlerpRestToRest <- function(
    q_0m1,
    q_0,
    q_k,
    q_kp1,
    spacecraft_configuration,
    dot_threshold = 0.9995
) {

  # Bring the spacecraft to rest at the beginning and end of the slew
  # From the starting attitude to rest
  to_rest <-
    SlewToRest(
      q_0m1 = q_0m1,
      q_0 = q_0,
      spacecraft_configuration = spacecraft_configuration
    )
  # From rest to the ending attitude
  rest_to <-
    SlewToRest(
      q_0m1 = q_kp1,
      q_0 = q_k,
      spacecraft_configuration = spacecraft_configuration
    )
  rest_to <- rest_to[nrow(rest_to):1, ]

  # Slew between the rest states
  q_0 <- to_rest[nrow(to_rest), ]
  q_k <- rest_to[1, ]

  # Measure the angle and axis between the quaternions
  rotation <- AxisBetweenQuaternions(q_0, q_k)

  # Measure how fast we can slew around this axis
  acceleration_max <-
    (spacecraft_configuration$constraints$angular_acceleration_max_degps2 /
    c(rotation$x, rotation$y, rotation$z)) %>%
    abs() %>%
    min() %>%
    "*"(pi / 180)
  velocity_max <-
    (spacecraft_configuration$constraints$angular_velocity_max_degps /
    c(rotation$x, rotation$y, rotation$z)) %>%
    abs() %>%
    min() %>%
    "*"(pi / 180)

  # Ensure that the slew is rectified
  dot <- sum(q_0 * q_k)
  if (dot < 0) {
    q_k <- - q_k
    dot <- - dot
  }

  # If the quaternions are essentially the same, return the initial and final
  if (dot > 0.999995) {
    result <- as.data.frame(rbind(c(1, q_0), c(2, q_k)))
    colnames(result) <- c("t", "q_r", "q_i1", "q_i2", "q_i3")
  } else {

    # Find the time to slew
    slerp_time <-
      SlewSlerpTime(
        q_0 = q_0,
        q_k = q_k,
        spacecraft_configuration = spacecraft_configuration
      )
    t <- seq(from = 0, to = ceiling(slerp_time), by = 1)

    # Calculate the progress along the Slerp curve

    # If there is enough time to reach coast
    if (rotation$angle > (velocity_max^2 / acceleration_max)) {

      # Flag the times when the coast begins and ends
      t1 <- velocity_max / acceleration_max
      t2 <- slerp_time - (velocity_max / acceleration_max)

      # Initialize
      slerp_progress <- rep(NA, length(t))

      # Accelerate to coast
      slerp_progress[t <= t1] <- acceleration_max * t[t <= t1]^2 / 2

      # Coast
      slerp_progress[(t > t1) & (t <= t2)] <-
        velocity_max * t[(t > t1) & (t <= t2)] -
        velocity_max^2 / (2 * acceleration_max)

      # Decelerate to rest
      slerp_progress[t > t2] <-
        rotation$angle -
        acceleration_max * (slerp_time - t[t > t2])^2 / 2

    }

    # If there is not enough time to reach coast
    if (rotation$angle <= (velocity_max^2 / acceleration_max)) {

      # Flag the time when the peak angular velocity is reached
      t1 <- sqrt(rotation$angle/acceleration_max)

      # Initialize
      slerp_progress <- rep(NA, length(t))

      # Accelerate to peak angular velocity
      slerp_progress[t <= t1] <-
        acceleration_max * t[t <= t1]^2 / 2

      # Decelerate to rest
      slerp_progress[t > t1] <-
        rotation$angle -
        acceleration_max *
        (t[t > t1] - 2 * sqrt(rotation$angle / acceleration_max))^2 / 2

    }

    # Clean and normalize the slerp progress
    slerp_progress[length(t)] <- rotation$angle
    slerp_progress <- slerp_progress / rotation$angle

    # Compute the attitude along the slew

    # If the quaternions are very close together, perform a linear interpolation
    if (dot > dot_threshold) {
      result  <-
        stapply(
          slerp_progress,
          function(x) {
            unlist(NormalizeByRow(q_0 + x * (q_k - q_0)))
          }
        )
      result  <- data.frame(
        r   = result[,1],
        i1  = result[,2],
        i2  = result[,3],
        i3  = result[,4]
      )

    # If the quaternions are further apart, perform the full Slerp
    } else {
      theta_0 <- acos(dot)
      theta   <- theta_0 * slerp_progress
      s0      <- cos(theta) - dot * sin(theta) / sin(theta_0)
      s1      <- sin(theta) / sin(theta_0)
      result  <-
        stapply(
          1:length(slerp_progress),
          function(x) {
            unlist(NormalizeByRow(s0[x] * q_0 + s1[x] * q_k))
            }
          )
      result  <- data.frame(
        r   = result[,1],
        i1  = result[,2],
        i2  = result[,3],
        i3  = result[,4]
      )
    }
  }

  # Add to_rest and rest_to to the result
  result <-
    rbind(
      to_rest[1:(nrow(to_rest) - 1), ],
      result,
      rest_to[2:nrow(rest_to), ]
    )

  # Cut the initial conditions
  result <- result[3:(nrow(result) - 2), ]
  rownames(result) <- 1:nrow(result)

  return(result)

}

# Near-optimal slew------------------------------------------------------------

#' Calculate the time derivatives of a rotation vector.
#'
#' This function is only used by the Slew function and is not exported.
#'
#' @param angular_velocity vector, matrix or data.frame of angular velocity
#'   vectors in radians per second
#' @param rotation_vectors vector, matrix or data.frame of rotation vectors
#'   in radians
#'
#' @return Numeric vector, the rate of change of the rotation vector
#'
#' @family slew functions
#' @export
RotationVectorsTimeDerivative <- function(
  angular_velocity,
  rotation_vectors
) {

  # Coerce rotation vectors to matrix
  if (is.data.frame(rotation_vectors)) {
    rotation_vectors <- as.matrix(rotation_vectors)
  }
  if (is.vector(rotation_vectors)) {
    rotation_vectors <- matrix(ncol = 3, data = rotation_vectors)
  }
  rotation_vectors <- as.matrix(rotation_vectors)

  # Coerce angular velocity to matrix
  if (is.data.frame(angular_velocity)) {
    angular_velocity <- as.matrix(angular_velocity)
  }
  if (is.vector(angular_velocity)) {
    angular_velocity <- matrix(ncol = 3, data = angular_velocity)
  }
  angular_velocity <- as.matrix(angular_velocity)

  # Norms
  rotation_vectors_norm  <- NormByRow(rotation_vectors)
  rotation_vectors_hat   <- NormalizeByRow(rotation_vectors)

  # This should be a lot more readable
  rotation_vectors_time_derivative <-
    data.frame(
      x = rep(NA, nrow(rotation_vectors)),
      y = rep(NA, nrow(rotation_vectors)),
      z = rep(NA, nrow(rotation_vectors))
    )

  for (tick in 1:nrow(rotation_vectors)) {
    cross_product_matrix <- CrossProductMatrix(rotation_vectors_hat[tick, ])

    gamma <-
      rotation_vectors_hat[tick, ] %*% t(rotation_vectors_hat[tick, ]) +
      (rotation_vectors_norm[tick] / 2) *
        (cross_product_matrix - pracma::cot(rotation_vectors_norm[tick] / 2) *
        cross_product_matrix %*% cross_product_matrix)

    rotation_vectors_time_derivative[tick, ] <-
      gamma %*% angular_velocity[tick, ]

  }

  return(rotation_vectors_time_derivative)

}

#' Compute a fast near-optimal slew.
#'
#' @param t_k numeric length of time for the slew
#' @param q_0m1 vector quaternion initial attitude minus 1 second (q_r leads)
#' @param q_0 vector quaternion initial attitude (q_r leads)
#' @param q_k vector quaternion final attitude plus 1 (q_r leads)
#' @param q_kp1 vector quaternion final attitude plus 1 second (q_r leads)
#' @param spacecraft_configuration a list containing configuration data for the
#'   spacecraft. The default is saved in package data as
#'   "ground_configuration" and contains initial information about
#'   MethaneSAT. See the data documentation for "ground_configuration" for
#'   more detail.
#' @param verbose logical (default FALSE), if TRUE, then informaiton about the
#'   slew will be printed to screen
#'
#' @return data.frame of quaternion attitude sequence at 1-Hz with columns
#'   r, i1, i2, i3
#'
#' @family slew functions
#' @export
SlewRampCoastRamp <- function(
    t_k,
    q_0m1,
    q_0,
    q_k,
    q_kp1,
    spacecraft_configuration,
    verbose = FALSE
) {

  if (verbose) {
    cat("\nComputing slew using rotation vector differential equation")
  }

  # Initialize output: state for failure
  output <- "Maneuver Failed"

  # If t_k is less than 5, then this algorithm will fail
  if (t_k <= 5) {return(output)}

  # If the quaternion conventions are different, then flip them
  norm1 <- NormByRow(q_k - q_0)
  norm2 <- NormByRow(q_k + q_0)
  if (norm2 < norm1) {
    if (verbose) {
      cat("\nQuaternion sign conventions were flipped, correcting them")
    }
    q_0   <- - q_0
    q_0m1 <- - q_0m1
  }

  # This algorithm solves the slew as a 3 step process:
  #   1) ramp up from the initial attitude and angular velocity to the maximum
  #      angular velocity about some arbitarary axis
  #   2) coast at the maximum angular velocity
  #   3) ramp down to the final attitude and angular velocity
  #
  # If the slew is short, the coast step might be omitted.
  #
  # Each step is described by a differential equation in rotation vectors.
  # There are one or two time breaks (tau_1 and tau_2) and two or three
  # coefficients (beta_1, beta_2, and beta_3) for rotation vector polynomials
  # that describe each step.

  # Initialization: transform from quaternions to rotation vectors

  # Transform the quaternions to rotation vectors
  rotation_vectors_0 <- RotationVectorsFromQuaternions(q_0) %>% unlist()
  rotation_vectors_k <- RotationVectorsFromQuaternions(q_k) %>% unlist()

  # Is this really the cleanest way to do this?

  # Check the convention of the rotation vector
  # If the dot product is negative, then they have different convention
  # Add 2 * pi * unit
  flag <-
    sum(
      NormalizeByRow(rotation_vectors_0) * NormalizeByRow(rotation_vectors_k)
    ) < 0
  if (flag & verbose) {
    cat("\nRotation vector conventions are different - correcting them")
  }
  multiple <- -1
  while (flag) {
    rotation_vectors_k_test <-
      rotation_vectors_k +
      multiple * 2 * pi * NormalizeByRow(rotation_vectors_k)
    flag_test <-
      sum(
        NormalizeByRow(rotation_vectors_0) *
        NormalizeByRow(rotation_vectors_k_test)
      ) >= 0
    if (flag_test) {
      rotation_vectors_k <- rotation_vectors_k_test
      flag <- FALSE
    }
    multiple <- multiple + 1
  }

  # Get the initial and final rate of change of the rotation vectors
  # This uses the equations of RotationVectorsTimeDerivative, which
  # are non-trivial
  rotation_vectors_dot_0 <-
    RotationVectorsTimeDerivative(
      angular_velocity =
        AngularVelocityFromQuaternions(rbind(q_0m1, q_0))[1,],
      rotation_vectors = rotation_vectors_0
    ) %>% t()

  rotation_vectors_dot_k <-
    RotationVectorsTimeDerivative(
      angular_velocity =
        AngularVelocityFromQuaternions(rbind(q_k, q_kp1))[1,],
      rotation_vectors = rotation_vectors_k
    ) %>% t()

  # beta_0 and beta_1 are trivial
  beta_0  <- matrix(nrow = 3, ncol = 1, data = rotation_vectors_0)
  beta_1  <- matrix(nrow = 3, ncol = 1, data = rotation_vectors_dot_0)

  # Ramp up tau_1 and tau_2 until it works or you run out of time
  # We need a more efficient way to estimate and update tau_1 and tau_2
  tau_1       <- 2
  tau_2       <- t_k - 3

  # Create a flag for the exit
  exit        <- FALSE
  # Create a flag for a successful maneuver
  success     <- FALSE

  # Optimize the slew
  while (!exit) {

    # Optimize this for t_k, tau_1, tau_2
    kappa     <- 2 * tau_1 * (2 * t_k - tau_1) * (t_k - tau_2) -
                   2 * tau_1 * (t_k - tau_2) ^ 2
    W_inv_11  <- 2 * (t_k - tau_2) * diag(3)
    W_inv_12  <- - (t_k - tau_2) ^ 2 * diag(3)
    W_inv_21  <- - 2 * tau_1 * diag(3)
    W_inv_22  <- tau_1 * (2 * t_k - tau_1) * diag(3)
    W_inv     <-
      rbind(
        cbind(W_inv_11, W_inv_12),
        cbind(W_inv_21, W_inv_22)
      )
    rotation_vectors <-
      rbind(
        rotation_vectors_k - (beta_0 + beta_1 * t_k),
        rotation_vectors_dot_k - beta_1
      )
    beta      <- (1/kappa) * W_inv %*% rotation_vectors
    beta_2    <- matrix(nrow = 3, ncol = 1, data = beta[1:3, ])
    beta_3    <- matrix(nrow = 3, ncol = 1, data = beta[4:6, ])

    # Create the time variable
    t_1 <- matrix(0:tau_1, nrow = 1)
    t_2 <- matrix((tau_1 + 1):tau_2, nrow = 1)
    t_3 <- matrix((tau_2 + 1):t_k, nrow = 1)

    # Attitude as a rotation vector
    # Why is this not just an rbind?
    rotation_vectors_all <-
      cbind(
        matrix(nrow = 3, ncol = length(t_1), data = beta_0) +
          beta_1 %*% t_1 +
          beta_2 %*% t_1 ^ 2,
        matrix(nrow = 3, ncol = length(t_2), data = beta_0) +
          beta_1 %*% t_2 +
          (tau_1 * beta_2) %*% (2 * t_2 - tau_1),
        matrix(nrow = 3, ncol = length(t_3), data = beta_0) +
          beta_1 %*% t_3 +
          (tau_1 * beta_2) %*% (2 * t_3 - tau_1) +
          beta_3 %*% (t_3 - tau_2)^2
      ) %>% t()

    # Attitude as a quaternion
    quat_out <-
      rotation_vectors_all %>%
      QuaternionsFromRotationVectors() %>%
      QuaternionRectify()

    #matplot(quat_out, type = "l")

    # Calculate the angular velocity and acceleration to test against the
    # agility constraints
    angular_velocity <-
      AngularVelocityFromQuaternions(quat_out) * 180 / pi
    angular_acceleration <-
      AngularAccelerationFromQuaternions(quat_out) * 180 / pi
    #matplot(angular_velocity, type = "l")
    #matplot(angular_acceleration, type = "l")

    # Conditions
    # Accelerations

    # If the first ramp is too high, then increase tau_1 and move on
    angular_acceleration_first_ramp_max <-
      apply(
        angular_acceleration[t_1 + 1, ],
        2,
        function(x) {
          max(abs(x), na.rm = TRUE)
        }
      )
    if (
      any(
        angular_acceleration_first_ramp_max >
        spacecraft_configuration$constraints$angular_acceleration_max_degps2
      )
    ) {
      tau_1 <- tau_1 + 1
      # If tau_1 is greater than tau_2,
      # then you've run out of time and you've lost
      if (tau_1 > tau_2) exit <- TRUE
      # Go to the next iteration
      next()
    }

    # If the second ramp is too high, then decrease tau_2 and move on
    angular_acceleration_second_ramp_max <-
      apply(
        angular_acceleration[t_3 + 1, ],
        2,
        function(x) {
          max(abs(x), na.rm = TRUE)
        }
      )
    if (
      any(
        angular_acceleration_second_ramp_max >
        spacecraft_configuration$constraints$angular_acceleration_max_degps2
      )
    ) {
      tau_2 <- tau_2 - 1
      # If tau_1 is greater than tau_2,
      # then you've run out of time and you've lost
      if (tau_1 > tau_2) exit <- TRUE
      # Go to the next iteration
      next()
    }

    # If the angular velocity is too high you've lost
    angular_velocity_max <-
      apply(
        angular_velocity,
        2,
        function(x) {
          max(abs(x), na.rm = TRUE)
        }
      )
    if (
      any(
        angular_velocity_max >
        spacecraft_configuration$constraints$angular_velocity_max_degps
      )
    ) {
      exit <- TRUE
      # Go to the next iteration
      next()
    }

    # If you have made it this far, then you have succeeded.
    # Set success and create the output.
    exit    <- TRUE
    success <- TRUE

    # The output is the atttitude profile as a quaternion
    output <-
      QuaternionsFromRotationVectors(rotation_vectors_all) %>%
      QuaternionRectify()

    # Remove the fist and last element - they belong to the start and end state
    output <- output[2:(nrow(output) - 1), ]

  }

  # Return the output
  return(output)

}

