# Convert Time Functions

# These functions convert time between a variety of representations that are
# used in different algorithms, inputs, and outputs.

# Times are represented as:
# - UTC: (Universal Coordinated Time, within 1 second of local solar time at
#         the prime meridian. Adjusted periodically using leap seconds)
# - Julian date: (fractional days since 12:00 January 1, 4713 BC)
# - Modified julian date: (Julian date - 2400000.5)
# - Year and Day of year
# - ISO8601 date
#     (character string of UTC in format "YYYY-MM-DDTHH:MM:SS.SSSSZ")
# - Solar time (time derived from angle relative to the apparent sun position)
# - Seconds since J2000 (Noon on January 1, 2000)

# Examples and unit tests are provided for all these functions.

#' Convert Julian dates to UTC dates in POSIX format
#'
#' @param jd numeric vector of Julian dates (days since 1 January 4713 BCE)
#'
#' @return vector of UTC (Universal Coordinated Time) dates in POSIX
#'   (Portable Operating System Interface) format
#'
#' @examples
#' UtcFromJulian(2446848.50000)
#'
#' @family convert time functions
#' @export
UtcFromJulian <- function(jd) {

  # The Julian date is calculated by reference to
  # 2451545 on 2000-01-01 12:00:00 UTC (AKA J2000)
  utc <- lubridate::ymd_hms("2000-01-01 12:00:00") +
         lubridate::seconds(round((jd - 2451545) * 24 * 60 * 60))

  return(utc)

}

#' Convert Julian dates to modified Julian dates
#'
#' @param jd numeric vector of Julian dates (days since 1 January 4713 BCE)
#'
#' @return numeric vector of modified Julian dates
#'   (days since 1 January 4713 BCE - 2400000.5)
#'
#' @examples
#' ModifiedJulianFromJulian(2446848.50000)
#'
#' @family convert time functions
#' @export
ModifiedJulianFromJulian <- function(jd) {

  mjd <- jd - 2400000.5

  return(mjd)

}

#' Convert modified Julian dates to Julian dates
#'
#' @param mjd numeric vector of modified Julian dates
#'   (days since 1 January 4713 BCE - 2400000.5)
#'
#' @return numeric vector of Julian dates (days since 1 January 4713 BCE)
#'
#' @examples
#' JulianFromModifiedJulian(46848)
#'
#' @family convert time functions
#' @export
JulianFromModifiedJulian <- function(mjd) {

  jd <- mjd + 2400000.5

  return(jd)

}

#' Convert modified Julian dates to UTC dates in POSIX format
#'
#' @param mjd numeric vector of modified Julian dates
#'   (days since 1 January 4713 BCE - 2400000.5)
#'
#' @return vector of UTC (Universal Coordinated Time) dates in POSIX
#'   (Portable Operating System Interface) format
#'
#' @examples
#' UtcFromModifiedJulian(46848)
#'
#' @family convert time functions
#' @export
UtcFromModifiedJulian <- function(mjd) {

  utc <- JulianFromModifiedJulian(mjd) %>% UtcFromJulian()

  return(utc)

}

#' Convert UTC dates in POSIX format to Julian dates
#'
#' @param utc vector of UTC (Universal Coordinated Time) dates in POSIX
#'   (Portable Operating System Interface) format
#'
#' @return numeric vector of Julian dates (days since 1 January 4713 BCE)
#'
#' @examples
#' JulianFromUtc("1987-02-22")
#'
#' @family convert time functions
#' @export
JulianFromUtc <- function(utc) {

  #if (!lubridate::is.POSIXct(utc)) {
  #  utc <- lubridate::ymd_hms(utc)
  #}

  # Initialize the date components
  t_year    <- lubridate::year(utc)
  t_month   <- lubridate::month(utc)
  t_day     <- lubridate::day(utc)
  t_hour    <- lubridate::hour(utc)
  t_minute  <- lubridate::minute(utc)
  t_second  <- lubridate::second(utc)

  # Adjust
  t_year[t_month < 3]  <- t_year[t_month < 3] - 1
  t_month[t_month < 3] <- t_month[t_month < 3] + 12

  # Coefficients
  A <- trunc(t_year / 100)
  B <- 2 - A + trunc(A / 4)
  C <- (((t_second / 60) + t_minute) / 60 + t_hour) / 24

  # Compute and return the julian date
  jd <- trunc(365.25 * (t_year + 4716)) +
    trunc(30.6001 * (t_month + 1)) +
    t_day + B - 1524.5 + C

  return(jd)

}

#' Convert UTC dates in POSIX format to modified Julian dates
#'
#' @param utc vector of UTC (Universal Coordinated Time) dates in POSIX
#'   (Portable Operating System Interface) format
#'
#' @return numeric vector of modified Julian dates
#'   (days since 1 January 4713 BCE - 2400000.5)
#'
#' @examples
#' ModifiedJulianFromUtc("1987-02-22")
#'
#' @family convert time functions
#' @export
ModifiedJulianFromUtc <- function(utc) {

  mjd <- JulianFromUtc(utc) - 2400000.5

  return(mjd)

}

#' Convert a year and fractional day of the year to a UTC dates in POSIX format
#'
#' @param yyyy numeric vector of years
#' @param doy numeric vector of fractional days of the year
#'
#' @return vector of UTC (Universal Coordinated Time) dates in POSIX
#'   (Portable Operating System Interface) format
#'
#' @examples
#' UtcFromYyyyDoy(1987, 53)
#'
#' @family convert time functions
#' @export
UtcFromYyyyDoy <- function(yyyy, doy) {

  # Check for correct types
  stopifnot(is.numeric(yyyy), is.numeric(doy))

  # Check that all lengths are equal
  if (length(unique(c(length(yyyy), length(doy)))) != 1) {
    stop("All inputs must have equal length")
  }

  # Add components together to get the UTC date
  utc <-
    lubridate::ymd_hms(paste0(yyyy, "-01-01 00:00:00 UTC")) +
    lubridate::days(doy - 1)

  return(utc)

}

#' Convert UTC dates in POSIX format to UTC dates in ISO8601 format
#'
#' @param utc vector of UTC (Universal Coordinated Time) dates in POSIX
#'   (Portable Operating System Interface) format
#'
#' @return character vector of ISO8601 UTC (Universal Coordinated Time) dates
#'
#' @examples
#' Iso8601FromUtc("1987-02-22")
#'
#' @family convert time functions
#' @export
Iso8601FromUtc <- function(utc) {

  # Paste the components of the date together in the ISO8691 style
  iso8601 <- paste0(
    lubridate::year(utc),
    "-",
    stringr::str_pad(lubridate::month(utc), pad = 0, width = 2),
    "-",
    stringr::str_pad(lubridate::day(utc), pad = 0, width = 2),
    "T",
    stringr::str_pad(lubridate::hour(utc), pad = 0, width = 2),
    ":",
    stringr::str_pad(lubridate::minute(utc), pad = 0, width = 2),
    ":",
    stringr::str_pad(round(lubridate::second(utc)), pad = 0, width = 2),
    ".000Z")

  return(iso8601)

}

#' Compute the solar time from the longitude of the sun and spacecraft
#'
#' @param utc vector of UTC (Universal Coordinated Time) dates in POSIX
#'   (Portable Operating System Interface) format
#' @param lon_spacecraft numeric vector of spacecraft longitude
#' @param lon_sun numeric vector of sun longitude
#'
#' @return data.frame with columns solar_time:
#'   solar times in POSIX (Portable Operating System Interface) format, and
#'   solar_hour: fraction hour of solar time
#'
#' @examples
#' SolarTime(
#'   utc = lubridate::ymd_hms("2021-12-31 04:26:22 UTC"),
#'   lon_spacecraft = 105.8568,
#'   lon_sun = 114.478
#' )
#'
#' @family convert time functions
#' @export
SolarTime <- function(utc, lon_spacecraft, lon_sun) {

  # Find the angles from the spacecraft and prime meridian to the sun
  hours_after_sun <- ((lon_spacecraft - lon_sun + 180) %% 360) / 15
  hours_after_utc <- ((lon_spacecraft + 180) %% 360) / 15

  # Separate the time components
  spacecraft_day    <-
    lubridate::date(
      utc + lubridate::hours(floor(hours_after_utc))
    )
  solar_hour        <- floor(hours_after_sun)
  minutes_after_sun <- 60 * (hours_after_sun - solar_hour)
  solar_minute      <- floor(minutes_after_sun)
  seconds_after_sun <- 60 * (minutes_after_sun - solar_minute)
  solar_second      <- floor(seconds_after_sun)

  # Assemble the solar time
  solar_time <-
    spacecraft_day +
    lubridate::hours(solar_hour) +
    lubridate::minutes(solar_minute) +
    lubridate::seconds(solar_second)

  # Return both the hours after the sun and the solar time
  output <-
    data.frame(
      solar_time = solar_time,
      solar_hour = hours_after_sun
    )
  return(output)

}

#' Compute the number of seconds since J2000 from UTC time
#'
#' @param utc vector of UTC (Universal Coordinated Time) dates in POSIX
#'   (Portable Operating System Interface) format
#'
#' @return numeric vector of seconds since J2000
#'
#' @examples
#'
#' SecondsSinceJ2000(lubridate::ymd_hms("2000-01-01 12:00:00"))
#'
#' @family convert time functions
#' @export
SecondsSinceJ2000 <- function(utc) {

  sec_since_j2000 <-
    utc %>%
    difftime(lubridate::ymd_hms("2000-01-01 12:00:00"), units = "secs") %>%
    as.numeric()

  return(sec_since_j2000)

}

#' Compute UTC (Universal Coordinated Time) from seconds since 2000-01-01
#'
#' The BCT Xact TAI Time coordinate is used in the activity schedules.
#' This time coordinate is defined as the number of seconds elapsed in TAI
#' (International Atomic Time) since 2000-01-01 00:00:00. This time coordinate
#' plays an important part in the determination of atttitude when the
#' CmdRate is non-zero. This function computes the UTC time from this time
#' coordinate and the current number of leap seconds.
#'
#' @param utc vector of UTC (Universal Coordinated Time) dates in POSIX
#'   (Portable Operating System Interface) format
#' @param tai_utc vector of numeric TAI (International Atomic Time) minus
#'   UTC (Universal Coordinated) time
#' @return numeric vector of seconds since J2000
#'
#' @examples
#'
#' UtcFromTai(694310437, 37)
#'
#' @family convert time functions
#' @export
UtcFromTai <- function(tai, tai_utc) {

  utc <-
    lubridate::ymd_hms("2000-01-01 00:00:00") +
    lubridate::seconds(tai) -
    lubridate::seconds(tai_utc)

  return(utc)

}

#' Compute seconds since 2000-01-01 from UTC (Universal Coordinated Time)
#'
#' The BCT Xact TAI Time coordinate is used in the activity schedules.
#' This time coordinate is defined as the number of seconds elapsed in TAI
#' (International Atomic Time) since 2000-01-01 00:00:00. This time coordinate
#' plays an important part in the determination of atttitude when the
#' CmdRate is non-zero. This function computes this time coordinate and the
#' current number of leap seconds.
#'
#' @param utc vector of UTC (Universal Coordinated Time) dates in POSIX
#'   (Portable Operating System Interface) format
#' @param tai_utc vector of numeric TAI (International Atomic Time) minus
#'   UTC (Universal Coordinated) time, equal to the number of leap seconds
#'
#' @return vector of UTC (Universal Coordinated Time) dates in POSIX
#'   (Portable Operating System Interface) format
#'
#' @examples
#'
#' TaiFromUtc(lubridate::ymd_hms("2022-01-01 00:00:00"), tai_utc = 37)
#'
#' @family convert time functions
#' @export
TaiFromUtc <- function(utc, tai_utc) {

  tai <-
    utc %>%
    "+"(lubridate::seconds(tai_utc)) %>%
    difftime(lubridate::ymd_hms("2000-01-01 00:00:00"), units = "secs") %>%
    as.numeric()

  return(tai)

}

