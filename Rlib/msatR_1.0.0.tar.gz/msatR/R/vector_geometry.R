# Vector geometry functions

# This code contains helper functions for vector geometry, including functions
# that rotate vectors about abitrary axes, decompose vectors into components
# parallel and perpendicular to a basis vector, calculate angles between
# vectors, and compute the angular velocity and acceleration of a time series
# of vectors (assuming no spin about the vector).

# These functions are used throughout the msatR code.

#' Rotate 2-dimensional vectors about an angle
#'
#' \code{RotateVectorR2} rotates vectors in R2, about the axis pointing
#' out of the page, using simple trigonometric functions. It accepts the
#' vectors to be rotated as vectors, matrices (2 columns, each row is a vector)
#' or data.frames (with columns x, and y). It can apply one rotation to one
#' vector, many rotations to one vector, or many rotations to many vectors, on
#' a one-to-one basis.
#'
#' @param vec a numeric vector, matrix, or data.frame of vectors to be rotated.
#'   If \code{vec} is a data.frame, then it must have columns x and y. If
#'   \code{vec} is a vector/matrix, it is assumed that the first element/column
#'   is the x component, and the second element/column is the y component.
#' @param angle a numeric scalar or vector of the angle to rotate in radians
#'
#' @return rotations of \code{vec} by \code{angle}.
#'   The result will have shape nx2, where n is the maximum of the
#'   number of rows of \code{vec} or the length of \code{angle}. If \code{vec}
#'   had shape nx2, then \code{RotateVectorR2} will return an object with the
#'   same class as \code{vec}. Otherwise, \code{RotateVectorR2} will return a
#'   data.frame.
#'
#' @examples
#' # Rotate a vector
#' RotateVectorR2(
#'   vec = c(1, 0),
#'   angle = pi/2
#' )
#'
#' # Rotate a matrix where each row is a vector
#' RotateVectorR2(
#'   vec = data.frame(x = c(1, 0), y = c(0, 1)),
#'   angle = pi/2
#' )
#'
#' # Rotate a data.frame where each row is a vector
#' RotateVectorR2(
#'   vec = data.frame(x = c(1, 0), y = c(0, 1)),
#'   angle = pi/2
#' )
#'
#' # Rotate each vector by a different angle
#' RotateVectorR2(
#'   vec = data.frame(x = 1, y = 0),
#'   angle = c(pi/2, -pi/2)
#' )
#'
#' @keywords internal
#' @family vector geometry functions
#' @export
RotateVectorR2 <- function(vec, angle) {

  # Coerce vec to a data.frame (error handling along the way)
  if ("numeric" %in% class(vec)) {
    stopifnot(class(vec) == "numeric" & length(vec) == 2)
    vec_df <- data.frame(x = vec[1], y = vec[2])
  }
  if ("matrix" %in% class(vec)) {
    stopifnot("matrix" %in% class(vec) & ncol(vec) == 2)
    vec_df <- data.frame(x = vec[, 1], y = vec[, 2])
  }
  if ("data.frame" %in% class(vec)) {
    stopifnot(
      class(vec) == "data.frame" &
      ncol(vec) == 2
    )
    vec_df <- data.frame(x = vec[, 1], y = vec[, 2])
  }

  # Compute the rotated vectors
  rotated_vectors <- data.frame(
    x = cos(angle) * vec_df$x - sin(angle) * vec_df$y,
    y = sin(angle) * vec_df$x + cos(angle) * vec_df$y
  )

  # if the number of rows is unchanged, coerce back to the class of vec
  # if the number of rows is changed, then return the data.frame
  if (nrow(rotated_vectors) == nrow(vec_df)) {
    rotated_vectors <- methods::as(rotated_vectors, class(vec))
    attributes(rotated_vectors) <- attributes(vec)
  }

  return(rotated_vectors)

}

#' Rotate 3-dimensional vectors about arbitrary axes
#'
#' \code{RotateVectorR3} rotates vectors about arbitrary axes in R3 using
#' Rodrique's formula. It accepts the vectors to be rotated as vectors,
#' matrices (3 columns, each row is a vector) or data.frames
#' (with columns x, y, and z). It can apply one rotation to one vector,
#' many rotations to one vector, or many rotations to many vectors, on a
#' one-to-one basis.
#'
#' @param vec a numeric vector, matrix, or data.frame of
#'   the vectors to be rotated. If \code{vec} is a data.frame, then it
#'   must have columns x, y, and z. If \code{vec} is a
#'   vector/matrix, then it is assumed that the first
#'   element/column is the x component, the second element/column is the y
#'   component, and the third element/column is the z component.
#' @param rotation_axis a numeric vector, matrix, or
#'   data.frame giving the axes about which vec is to be rotated.
#'   If \code{rotation_axis} is a data.frame, then it
#'   must have columns x, y, and z. If \code{rotation_axis}
#'   is a vector/matrix, then it is assumed that the first
#'   element/column is the x component, the second element/column is the y
#'   component, and the third element/column is the z component.
#' @param angle a numeric vector of rotation angles in radians
#'
#' @return rotations of \code{vec} about \code{rotation_axis} by \code{angle}.
#'   The result will have shape nx3, where n is the maximum of the
#'   number of rows of \code{vec} or \code{rotation_axis} or the length of
#'   \code{angle}. If \code{vec} has shape nx3, then \code{RotateVectorR3} will
#'   return an object with the same class as \code{vec}. Otherwise,
#'   \code{RotateVectorR3} will return a data.frame.
#'
#' @examples
#' # Rotate a vector about an axis by an angle
#' RotateVectorR3(
#'   vec = c(1, 0, 0),
#'   rotation_axis = c(0, 0, 1),
#'   angle = pi/2
#' )
#'
#' # Rotate multiple vectors about an axis by an angle
#' RotateVectorR3(
#'   vec = rbind(c(1, 0, 0), c(0, 1, 0)),
#'   rotation_axis = c(0, 0, 1),
#'   angle = pi/2
#' )
#'
#' # The multiple vectors can come in the form of a data.frame
#' RotateVectorR3(
#'   vec =
#'     data.frame(
#'       x = c(1, 0),
#'       y = c(0, 1),
#'       z = c(0, 0)
#'     ),
#'   rotation_axis = c(0, 0, 1),
#'   angle = pi/2
#' )
#'
#' # Rotate a single vector about multiple axes
#' RotateVectorR3(
#'   vec = c(1, 0, 0),
#'   rotation_axis =
#'     data.frame(
#'       x = c(0, 0),
#'       y = c(1, 0),
#'       z = c(0, 1)
#'      ),
#'   angle = pi/2
#' )
#'
#' # Rotate a single vector about a single axis by several different angles
#' RotateVectorR3(
#'   vec = c(1, 0, 0),
#'   rotation_axis = c(0, 1, 0),
#'   angle = c(pi/4, pi / 2)
#' )
#'
#' @keywords internal
#' @family vector geometry functions
#'
#' @export
RotateVectorR3 <- function(vec, rotation_axis, angle) {

  # Coerce vec to a data.frame (error handling along the way)
  if ("numeric" %in% class(vec)) {
    stopifnot(class(vec) == "numeric" & length(vec) == 3)
    vec_df <- data.frame(x = vec[1], y = vec[2], z = vec[3])
  }
  if ("matrix" %in% class(vec)) {
    stopifnot("matrix" %in% class(vec) & ncol(vec) == 3)
    vec_df <- data.frame(x = vec[, 1], y = vec[, 2], z = vec[, 3])
  }
  if ("data.frame" %in% class(vec)) {
    stopifnot(
      class(vec) == "data.frame" &
        ncol(vec) == 3
    )
    vec_df <- data.frame(x = vec[, 1], y = vec[, 2], z = vec[, 3])
  }

  # Coerce rotation_axis to a data.frame (error handling along the way)
  if ("numeric" %in% class(rotation_axis)) {
    stopifnot(class(rotation_axis) == "numeric" & length(rotation_axis) == 3)
    rotation_axis_df <-
      data.frame(
        x = rotation_axis[1],
        y = rotation_axis[2],
        z = rotation_axis[3]
      )
  }
  if ("matrix" %in% class(rotation_axis)) {
    stopifnot("matrix" %in% class(rotation_axis) & ncol(rotation_axis) == 3)
    rotation_axis_df <-
      data.frame(
        x = rotation_axis[, 1],
        y = rotation_axis[, 2],
        z = rotation_axis[, 3]
      )
  }
  if ("data.frame" %in% class(rotation_axis)) {
    stopifnot(
      class(rotation_axis) == "data.frame" &
      ncol(rotation_axis) == 3
    )
    rotation_axis_df <-
      data.frame(
        x = rotation_axis[, 1],
        y = rotation_axis[, 2],
        z = rotation_axis[, 3]
      )
  }

  # Ensure rotation_axis is normalized
  rotation_axis_df <- NormalizeByRow(rotation_axis_df)

  # Find the length to coerce to
  input_lengths <- c(nrow(vec_df), nrow(rotation_axis_df), length(angle))
  max_input_lengths <- max(input_lengths)

  # Error handling - length congruencies
  if (!(nrow(vec_df) %in% c(1, max_input_lengths))) {
    stop("vec is incongruent with other inputs")
  }
  if (!(nrow(rotation_axis_df) %in% c(1, max_input_lengths))) {
    stop("rotation_axis is incongruent with other inputs")
  }
  if (!(length(angle) %in% c(1, max_input_lengths))) {
    stop("angle is incongruent with other inputs")
  }

  # Coerce objects to be congruent
  if (max_input_lengths > 1) {
    if (nrow(vec_df) == 1) {
      vec_df <-
        RepeatRows(
          unlist(vec_df),
          max_input_lengths
        ) %>%
        as.data.frame()
    }
    if (nrow(rotation_axis_df) == 1) {
      rotation_axis_df <-
        RepeatRows(
          unlist(rotation_axis_df),
          max_input_lengths
        ) %>%
        as.data.frame()
    }
    if (length(angle) == 1) {
      angle <- rep(angle, max_input_lengths)
    }
  }

  # Compute the rotations
  rotated_vectors <- vec_df * RepeatColumns(cos(angle), 3) +
    CrossProductByRow(rotation_axis_df, vec_df) * sin(angle) +
    rotation_axis_df * rowSums(rotation_axis_df * vec_df) *
    RepeatColumns(1 - cos(angle), 3)

  return(rotated_vectors)

}

#' Decompose vectors into components parallel and perpendicular to basis
#' vectors
#'
#' \code{DecomposeVector} decomposes vectors into components parallel and
#' perpendicular to basis vectors. It accepts the vectors to be decomposed as
#' vectors, matrices (3 columns, each row is a vector) or data.frames
#' (with columns x, y, and z). It can decompose one vector onto one basis,
#' many vectors onto many bases, or many vectors onto many bases
#' (on a one-to-one basis).
#'
#' @param vec a numeric vector, matrix, or data.frame of
#'   the vectors to be decomposed. If \code{vec} is a data.frame, then it
#'   must have columns x, y, and z. If \code{vec} is a
#'   vector/matrix, then it is assumed that the first
#'   element/column is the x component, the second element/column is the y
#'   component, and the third element/column is the z component.
#' @param basis a numeric vector, matrix, or data.frame of
#'   representing the normal onto which to decompose the vector.
#'   If \code{basis} is a data.frame, then it must have columns
#'   x, y, and z. If \code{basis} is a vector/matrix, then it is assumed that
#'   the first element/column is the x component, the second element/column is
#'   the y component, and the third element/column is the z component.
#'   \code{basis} should have either one row or the same number of rows as
#'   \code{vec}.
#'
#' @return a length-2 list. \code{$parallel} is a data.frame of the component
#'   of \code{vec} parallel to \code{basis}. \code{$perpendicular} is a
#'   data.frame of the component of \code{vec} perpendicular to \code{basis}.
#'
#' @examples
#' # Decompose one vector, one basis
#' DecomposeVector(
#'   vec = c(1/sqrt(2), 0, 1/sqrt(2)),
#'   basis = c(0,0,1)
#' )
#'
#' # Decompose one vector, many bases
#' DecomposeVector(
#'   vec = c(1/sqrt(2), 0, 1/sqrt(2)),
#'   basis = rbind(c(0,0,1), c(0,1,0))
#' )
#'
#' # Decompose many vectors, one basis
#' DecomposeVector(
#'   vec = rbind(c(1/sqrt(2), 0, 1/sqrt(2)), c(0,1,0)),
#'   basis = c(0,0,1)
#' )
#'
#' # Decompose many vectors, many bases
#' DecomposeVector(
#'   vec = rbind(c(1/sqrt(2), 0, 1/sqrt(2)), c(0,1,0)),
#'   basis = rbind(c(0,0,1), c(0,1,0))
#'  )
#'
#' # Decompose many vectors, many bases - data.frame input
#' DecomposeVector(
#'   vec =
#'     data.frame(
#'       x = c(1/sqrt(2), 0),
#'       y = c(0, 1),
#'       z = c(1/sqrt(2), 0)
#'     ),
#'   basis =
#'     data.frame(
#'       x = c(0, 0),
#'       y = c(0, 1),
#'       z = c(1, 0)
#'     )
#'  )
#'
#' @keywords internal
#' @family vector geometry functions
#' @export
DecomposeVector <- function(vec, basis) {

  # Coerce vec to a data.frame (error handling along the way)
  if ("numeric" %in% class(vec)) {
    stopifnot(class(vec) == "numeric" & length(vec) == 3)
    vec_df <- data.frame(x = vec[1], y = vec[2], z = vec[3])
  }
  if ("matrix" %in% class(vec)) {
    stopifnot("matrix" %in% class(vec) & ncol(vec) == 3)
    vec_df <- data.frame(x = vec[, 1], y = vec[, 2], z = vec[, 3])
  }
  if ("data.frame" %in% class(vec)) {
    stopifnot(
      class(vec) == "data.frame" &
        ncol(vec) == 3
    )
    vec_df <- data.frame(x = vec[, 1], y = vec[, 2], z = vec[, 3])
  }

  # Coerce normal to a data.frame (error handling along the way)
  if ("numeric" %in% class(basis)) {
    stopifnot(class(basis) == "numeric" & length(basis) == 3)
    basis_df <- data.frame(x = basis[1], y = basis[2], z = basis[3])
  }
  if ("matrix" %in% class(basis)) {
    stopifnot("matrix" %in% class(basis) & ncol(basis) == 3)
    basis_df <- data.frame(x = basis[, 1], y = basis[, 2], z = basis[, 3])
  }
  if ("data.frame" %in% class(basis)) {
    stopifnot(class(basis) == "data.frame" & ncol(basis) == 3)
    basis_df <- data.frame(x = basis[, 1], y = basis[, 2], z = basis[, 3])
  }

  # Find the length to coerce to
  input_lengths <- c(nrow(vec_df), nrow(basis_df))
  max_input_lengths <- max(input_lengths)

  # Error handling - length congruencies
  if (!(nrow(vec_df) %in% c(1, max_input_lengths))) {
    stop("inputs are incongruent")
  }
  if (!(nrow(basis_df) %in% c(1, max_input_lengths))) {
    stop("inputs are incongruent")
  }

  # Coerce objects to be congruent
  if (max_input_lengths > 1) {
    if (nrow(vec_df) == 1) {
      vec_df <-
        RepeatRows(
          unlist(vec_df),
          max_input_lengths
        ) %>%
        as.data.frame()
    }
    if (nrow(basis_df) == 1) {
      basis_df <-
        RepeatRows(
          unlist(basis_df),
          max_input_lengths
        ) %>%
        as.data.frame()
    }
  }

  # Ensure that the basis vector is normalized
  basis_df <- NormalizeByRow(basis_df)

  # Calculate parallel and perpendicular
  vec_parallel <- rowSums(vec_df * basis_df) * basis_df
  vec_perpendicular <- vec_df - vec_parallel

  # Return as a list
  vec_out <- list(parallel = vec_parallel, perpendicular = vec_perpendicular)

  return(vec_out)

}

#' Shortest angle between vectors
#'
#' \code{AngleBetweenVectors} calculates the shortest angle between vectors.
#' It accepts the vectors as vectors, matrices
#' (3 columns, each row is a vector) or data.frames (with columns x, y, and z).
#' Either vector can be one or many, though if both are many they must have the
#' same length.
#'
#' @param u numeric vector, matrix, or data.frame of the first vectors.
#'   If \code{u} is a data.frame, then it must have columns x, y, and z.
#'   If \code{u} is a vector/matrix, then it is assumed that the first
#'   element/column is the x component, the second element/column is the y
#'   component, and the third element/column is the z component.
#' @param v numeric vector, matrix, or data.frame of the second vectors.
#'   If \code{v} is a data.frame, then it must have columns x, y, and z.
#'   If \code{v} is a vector/matrix, then it is assumed that the first
#'   element/column is the x component, the second element/column is the y
#'   component, and the third element/column is the z component.
#'
#' @return numeric vector of the angles between u and v in radians
#'
#' @examples
#' AngleBetweenVectors(
#'   u =
#'     data.frame(
#'       x = c(1, 0),
#'       y = c(0, 1),
#'       x = c(0, 0)
#'     ),
#'   v =
#'     data.frame(
#'       x = c(0, 1/sqrt(2)),
#'       y = c(0, 0),
#'       x = c(1, 1/sqrt(2))
#'     )
#' )
#'
#' @keywords internal
#' @family vector geometry functions
#' @export
AngleBetweenVectors <- function(u, v) {

  # Coerce u to a data.frame (error handling along the way)
  if ("numeric" %in% class(u)) {
    stopifnot(class(u) == "numeric" & length(u) == 3)
    u_df <- data.frame(x = u[1], y = u[2], z = u[3])
  }
  if ("matrix" %in% class(u)) {
    stopifnot("matrix" %in% class(u) & ncol(u) == 3)
    u_df <- data.frame(x = u[, 1], y = u[, 2], z = u[, 3])
  }
  if ("data.frame" %in% class(u)) {
    stopifnot(
      class(u) == "data.frame" &
        ncol(u) == 3
    )
    u_df <- data.frame(x = u[, 1], y = u[, 2], z = u[, 3])
  }

  # Coerce normal to a data.frame (error handling along the way)
  if ("numeric" %in% class(v)) {
    stopifnot(class(v) == "numeric" & length(v) == 3)
    v_df <- data.frame(x = v[1], y = v[2], z = v[3])
  }
  if ("matrix" %in% class(v)) {
    stopifnot("matrix" %in% class(v) & ncol(v) == 3)
    v_df <- data.frame(x = v[, 1], y = v[, 2], z = v[, 3])
  }
  if ("data.frame" %in% class(v)) {
    stopifnot(class(v) == "data.frame" & ncol(v) == 3)
    v_df <- data.frame(x = v[, 1], y = v[, 2], z = v[, 3])
  }

  # Find the length to coerce to
  input_lengths <- c(nrow(u_df), nrow(v_df))
  max_input_lengths <- max(input_lengths)

  # Error handling - length congruencies
  if (!(nrow(u_df) %in% c(1, max_input_lengths))) {
    stop("inputs are incongruent")
  }
  if (!(nrow(v_df) %in% c(1, max_input_lengths))) {
    stop("inputs are incongruent")
  }

  # Coerce objects to be congruent
  if (max_input_lengths > 1) {
    if (nrow(u_df) == 1) {
      u_df <-
        RepeatRows(
          unlist(u_df),
          max_input_lengths
        ) %>%
        as.data.frame()
    }
    if (nrow(v_df) == 1) {
      v_df <-
        RepeatRows(
          unlist(v_df),
          max_input_lengths
        ) %>%
        as.data.frame()
    }
  }

  # Calculate the angle
  arg <- rowSums(u_df * v_df) / (NormByRow(u_df) * NormByRow(v_df))
  arg[abs(arg) > 1] <- sign(arg[abs(arg) > 1])
  angle <- as.vector(acos(arg))

  return(angle)

}

#' Angular velocity from a time series of vectors
#'
#' \code{AngularVelocityFromVectors} calculates the angular velocity of a time
#' series of vectors using forward finite differencing. The time series of
#' vectors should be a matrix or data.frame where each row is the vector at a
#' time. The time is not explicitly specified, except that the time difference
#' between successive rows is given by the parameter delt_sec.
#'
#' @param vec a numeric matrix, or data.frame of vectors (at least 2 rows).
#'   If \code{vec} is a data.frame, then it must have columns x, y, and z.
#'   If \code{vec} is a matrix, then it must have 2 columns.
#' @param delt_sec the time step between elements of the sequence
#'   (default 1 second)
#'
#' @return a numeric vector of the angular velocities, the last element is NA
#'
#' @examples
#' # Set up a timesereis of vectors
#' vec <-
#'   cbind(
#'     rep(0, 4),
#'     seq(from = 0, to = 1, length = 4),
#'     seq(from = 1, to = 0, length = 4)
#'   ) %>%
#'   NormalizeByRow()
#'
#' # Find the angular velocity
#' AngularVelocityFromVectors(vec)
#'
#' @keywords internal
#' @family vector geometry functions
#' @export
AngularVelocityFromVectors <- function(vec, delt_sec = 1) {

  # Rate of change of the vectors
  vec_dot  <- (vec[2:nrow(vec), ] - vec[1:(nrow(vec) - 1), ]) / delt_sec

  # Return vector angular velocity
  angular_velocity <-
    rbind(
      CrossProductByRow(vec[1:(nrow(vec) - 1), ], vec_dot),
      c(NA, NA, NA)
    ) %>%
    as.data.frame() %>%
    "colnames<-"(c("x", "y", "z"))

  return(angular_velocity)

}


#' Angular acceleration from a time series of vectors
#'
#' \code{AngularAccelerationFromVectors} calculates the angular acceleration
#' of a time series of vectors using centered finite differencing. The time
#' series of vectors should be a matrix or data.frame where each row is the
#' vector at a time. The time is not explicitly specified, except that the
#' time difference between successive rows is given by the parameter delt_sec.
#'
#' @param vec a numeric matrix, or data.frame of vectors (at least 3 rows).
#'   If \code{vec} is a data.frame, then it must have columns x, y, and z.
#'   If \code{vec} is a matrix, then it must have 2 columns.
#' @param delt_sec the time step between elements of the sequence (default 1)
#'
#' @return a numeric vector of the angular velocities, the last element is NA
#'
#' @examples
#' vec <-
#'   cbind(
#'     rep(0, 4),
#'     seq(from = 0, to = 1, length = 4),
#'     seq(from = 1, to = 0, length = 4)
#'   ) %>%
#'   NormalizeByRow()
#' AngularAccelerationFromVectors(vec)
#'
#' @family vector geometry functions
#' @keywords internal
#' @export
AngularAccelerationFromVectors <- function(vec, delt_sec = 1) {

  # Sort the vectors
  v1 <- vec[1:(nrow(vec) - 2), ]
  v2 <- vec[2:(nrow(vec) - 1), ]
  v3 <- vec[3:nrow(vec), ]

  # Rate of change of the vectors
  vdot <- (v3 - v2) / delt_sec

  # Second rate of change of the vectors
  vdotdot <- (v3 - 2 * v2 + v1) / delt_sec^2

  # Return vector angular acceleration
  angular_acceleration <-
    rbind(
      c(NA, NA, NA),
      CrossProductByRow(v2, vdotdot) + CrossProductByRow(vdot, vdot),
      c(NA, NA, NA)
    ) %>%
    as.data.frame() %>%
    "colnames<-"(c("x", "y", "z"))

  return(angular_acceleration)

}
