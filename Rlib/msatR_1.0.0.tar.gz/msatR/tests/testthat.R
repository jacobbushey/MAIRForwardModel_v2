library(testthat)
library(msatR)

test_check("msatR")
