# RotateVectorR2 ----

test_that("RotateVectorR2 works for one vector", {
  actual <-
    RotateVectorR2(
      vec = c(1, 0),
      angle = pi/2
    )
  expected <- c(0, 1)
  expect_equal(actual, expected)
})

test_that("RotateVectorR2 works for a matrix of vectors and one angle", {
  actual <-
    RotateVectorR2(
      vec = rbind(c(1, 0), c(0,1)),
      angle = pi/2
    )
  expected <- rbind(c(0, 1), c(-1, 0))
  expect_equal(actual, expected)
})

test_that("RotateVectorR2 works for a data.frame of vectors and one angle", {
  actual <-
    RotateVectorR2(
      vec = data.frame(x = c(1, 0), y = c(0,1)),
      angle = pi/2
    )
  expected <- data.frame(x = c(0, -1), y = c(1, 0))
  expect_equal(actual, expected)
})

test_that("RotateVectorR2 works for multiple vectors and multiple angles", {
  actual <-
    RotateVectorR2(
      vec = rbind(c(1, 0), c(0,1)),
      angle = c(pi/2, -pi/2)
    )
  expected <- rbind(c(0, 1), c(1, 0))
  expect_equal(actual, expected)
})

test_that("RotateVectorR2 works for one vector and multiple angles", {
  actual <-
    RotateVectorR2(
      vec = c(0,1),
      angle = c(pi/2, -pi/2)
    )
  expected <- data.frame(x = c(-1, 1), y = c(0, 0))
  expect_equal(actual, expected)
})

# RotateVectorR3 ----

test_that("RotateVectorR3 works for one vector, one axis, one angle", {
  actual <-
    RotateVectorR3(
      vec = c(1, 0, 0),
      rotation_axis = c(0, 0, 1),
      angle = pi/2)
  expected <- data.frame(
    x = 0,
    y = 1,
    z = 0)
  expect_equal(actual, expected)
})

test_that("RotateVectorR3 works for multiple vectors, one axis, one angle", {
  actual <-
    RotateVectorR3(
      vec = rbind(c(1, 0, 0), c(0, 1, 0)),
      rotation_axis = c(0, 0, 1),
      angle = pi/2)
  expected <-
    data.frame(
      x = c(0, -1),
      y = c(1, 0),
      z = c(0, 0)
    )
  expect_equal(actual, expected)
})

test_that("RotateVectorR3 works for one vectors, multiple axes, one angle", {
  actual <-
    RotateVectorR3(
      vec = rbind(c(1, 0, 0), c(0, 1, 0)),
      rotation_axis = c(0, 0, 1),
      angle = pi/2)
  expected <-
    data.frame(
      x = c(0, -1),
      y = c(1, 0),
      z = c(0, 0)
    )
  expect_equal(actual, expected)
})

# DecomposeVector ----

test_that("DecomposeVector works for one vector, one basis", {
  actual <-
    DecomposeVector(
      vec = c(1/sqrt(2), 0, 1/sqrt(2)),
      basis = c(0,0,1)
    )
  expected <-
    list(
      parallel = data.frame(x = 0, y = 0, z = 1/sqrt(2)),
      perpendicular = data.frame(x = 1/sqrt(2), y = 0, z = 0)
    )
  expect_equal(actual, expected)
})

test_that("DecomposeVector works for one vector, many basis", {
  actual <-
    DecomposeVector(
      vec = c(1/sqrt(2), 0, 1/sqrt(2)),
      basis = rbind(c(0,0,1), c(0,1,0))
    )
  expected <-
    list(
      parallel =
        data.frame(
          x = c(0, 0),
          y = c(0, 0),
          z = c(1/sqrt(2), 0)
        ),
      perpendicular =
        data.frame(
          x = c(1/sqrt(2), 1/sqrt(2)),
          y = c(0, 0),
          z = c(0, 1/sqrt(2))
        )
    )
  expect_equal(actual, expected)
})

test_that("DecomposeVector works for many vectors, one basis", {
  actual <-
    DecomposeVector(
      vec = rbind(c(1/sqrt(2), 0, 1/sqrt(2)), c(0,1,0)),
      basis = c(0,0,1)
    )
  expected <-
    list(
      parallel =
        data.frame(
          x = c(0, 0),
          y = c(0, 0),
          z = c(1/sqrt(2), 0)
        ),
      perpendicular =
        data.frame(
          x = c(1/sqrt(2), 0),
          y = c(0, 1),
          z = c(0, 0)
        )
    )
  expect_equal(actual, expected)
})

test_that("DecomposeVector works for many vectors, many basis", {
  actual <-
    DecomposeVector(
      vec = rbind(c(1/sqrt(2), 0, 1/sqrt(2)), c(0,1,0)),
      basis = rbind(c(0,0,1), c(0,1,0))
    )
  expected <-
    list(
      parallel =
        data.frame(
          x = c(0, 0),
          y = c(0, 1),
          z = c(1/sqrt(2), 0)
        ),
      perpendicular =
        data.frame(
          x = c(1/sqrt(2), 0),
          y = c(0, 0),
          z = c(0, 0)
        )
    )
  expect_equal(actual, expected)
})

# AngleBetweenVectors ----

test_that("AngleBetweenVectors works for one to one", {
  actual <-
    AngleBetweenVectors(
      u = c(1/sqrt(2), 0, 1/sqrt(2)),
      v = c(0,0,1)
    )
  expected <- pi / 4
  expect_equal(actual, expected)
})

test_that("AngleBetweenVectors works for one to many", {
  actual <-
    AngleBetweenVectors(
      u = c(1/sqrt(2), 0, 1/sqrt(2)),
      v =
        data.frame(
          x = c(0, 0),
          y = c(0, 1),
          x = c(1, 0)
        )
    )
  expected <- c(pi / 4, pi / 2)
  expect_equal(actual, expected)
})

test_that("AngleBetweenVectors works for many to many", {
  actual <-
    AngleBetweenVectors(
      u =
        data.frame(
          x = c(1, 0),
          y = c(0, 1),
          x = c(0, 0)
        ),
      v =
        data.frame(
          x = c(0, 1/sqrt(2)),
          y = c(0, 0),
          x = c(1, 1/sqrt(2))
        )
    )
  expected <- c(pi/2, pi/2)
  expect_equal(actual, expected)
})

# AngularVelocityFromVectors ----

test_that("AngularVelocityFromVectors works with default delt_sec", {
  vec <-
      cbind(
        rep(0, 4),
        seq(from = 0, to = 1, length = 4),
        seq(from = 1, to = 0, length = 4)
      ) %>%
      NormalizeByRow()
  actual <- AngularVelocityFromVectors(vec)
  expected <-
    data.frame(
      x = c(-0.4472136, -0.6000000, -0.4472136, NA),
      y = c(0, 0, 0, NA),
      z = c(0, 0, 0, NA)
    )
  expect_equal(actual, expected)
})

test_that("AngularVelocityFromVectors works with 10 delt_sec", {
  vec <-
    cbind(
      rep(0, 4),
      seq(from = 0, to = 1, length = 4),
      seq(from = 1, to = 0, length = 4)
    ) %>%
    NormalizeByRow()
  actual <- AngularVelocityFromVectors(vec, delt_sec = 10)
  expected <-
    data.frame(
      x = c(-0.04472136, -0.06000000, -0.04472136, NA),
      y = c(0, 0, 0, NA),
      z = c(0, 0, 0, NA)
    )
  expect_equal(actual, expected)
})

# AngularVelocityFromVectors ----

test_that("AngularAccelerationFromVectors works with default delt_sec", {
  vec <-
    cbind(
      rep(0, 4),
      seq(from = 0, to = 1, length = 4),
      seq(from = 1, to = 0, length = 4)
    ) %>%
    NormalizeByRow()
  actual <- AngularAccelerationFromVectors(vec)
  expected <-
    data.frame(
      x = c(NA, -0.152786405, 0.152786405, NA),
      y = c(NA, 0, 0, NA),
      z = c(NA, 0, 0, NA)
    )
  expect_equal(actual, expected)
})

test_that("AngularAccelerationFromVectors works with 10 delt_sec", {
  vec <-
    cbind(
      rep(0, 4),
      seq(from = 0, to = 1, length = 4),
      seq(from = 1, to = 0, length = 4)
    ) %>%
    NormalizeByRow()
  actual <- AngularAccelerationFromVectors(vec, delt_sec = 10)
  expected <-
    data.frame(
      x = c(NA, -0.0015278640450004217, 0.0015278640450004217, NA),
      y = c(NA, 0, 0, NA),
      z = c(NA, 0, 0, NA)
    )
  expect_equal(actual, expected)
})
