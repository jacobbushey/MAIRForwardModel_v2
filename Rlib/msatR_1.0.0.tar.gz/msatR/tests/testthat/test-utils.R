# R_x ----

test_that("R_x works for a scalar", {
  actual <- R_x(pi/2)
  expected <-
    rbind(
      c(1, 0, 0),
      c(0, 0, -1),
      c(0, 1, 0)
    )
  expect_equal(actual, expected)
})

test_that("R_x works for a vector", {
  actual <- R_x(c(pi/2, pi))
  expected <-
    list(
      rbind(
        c(1, 0, 0),
        c(0, 0, -1),
        c(0, 1, 0)
      ),
      rbind(
        c(1, 0, 0),
        c(0, -1, 0),
        c(0, 0, -1)
      )
    )
  expect_equal(actual, expected)
})

# R_y -----

test_that("R_y works for a scalar", {
  actual <- R_y(pi/2)
  expected <-
    rbind(
      c(0, 0, 1),
      c(0, 1, 0),
      c(-1, 0, 0)
    )
  expect_equal(actual, expected)
})

test_that("R_y works for a vector", {
  actual <- R_y(c(pi/2, pi))
  expected <-
    list(
      rbind(
        c(0, 0, 1),
        c(0, 1, 0),
        c(-1, 0, 0)
      ),
      rbind(
        c(-1, 0, 0),
        c(0, 1, 0),
        c(0, 0, -1)
      )
    )
  expect_equal(actual, expected)
})

# R_z ----

test_that("R_z works for a scalar", {
  actual <- R_z(pi/2)
  expected <-
    rbind(
      c(0, -1, 0),
      c(1, 0, 0),
      c(0, 0, 1)
    )
  expect_equal(actual, expected)
})

test_that("R_z works for a vector", {
  actual <- R_z(c(pi/2, pi))
  expected <-
    list(
      rbind(
        c(0, -1, 0),
        c(1, 0, 0),
        c(0, 0, 1)
      ),
      rbind(
        c(-1, 0, 0),
        c(0, -1, 0),
        c(0, 0, 1)
      )
    )
  expect_equal(actual, expected)
})

# CrossProductMatrix ----

test_that("CrossProductMatrix works", {
  actual <- CrossProductMatrix(c(1,2,3))
  expected <-
    rbind(
      c(0, -3, 2),
      c(3, 0, -1),
      c(-2, 1, 0)
    )
  expect_equal(actual, expected)
})

# CrossProductByRow ----

test_that("CrossProductByRow works", {
  actual <-
    CrossProductByRow(
      matrix(ncol = 3, data = c(1,0,0,0,1,0), byrow = TRUE),
      matrix(ncol = 3, data = c(0,1,0,0,0,1), byrow = TRUE)
    )
  expected <-
    rbind(
      c(0, 0, 1),
      c(1, 0, 0)
    )
  expect_equal(actual, expected)
})

# stapply ----

test_that("stapply works", {
  actual <- stapply(1:3, function(x) {rep(x, 3)})
  expected <-
    rbind(
      c(1, 1, 1),
      c(2, 2, 2),
      c(3, 3, 3)
    )
  expect_equal(actual, expected)
})

# MultiplyMatrixLists ----

test_that("MultiplyMatrixLists works", {
  actual <-
    MultiplyMatrixLists(
      list1 = R_x(c(pi/2, pi)),
      list2 = R_y(c(pi/2, pi))
    )
  expected <-
    list(
      rbind(
        c(0, 0, 1),
        c(1, 0, 0),
        c(0, 1, 0)
      ),
      rbind(
        c(-1, 0, 0),
        c(0, -1, 0),
        c(0, 0, 1)
      )
    )
  expect_equal(actual, expected)
})

# RepeatColumns ----

test_that("RepeatColumns works", {
  actual <- RepeatColumns(c(1,2,3), 3)
  expected <-
    rbind(
      c(1, 1, 1),
      c(2, 2, 2),
      c(3, 3, 3)
    )
  expect_equal(actual, expected)
})

# RepeatRows ----

test_that("RepeatRows works", {
  actual <- RepeatRows(c(1,2,3), 3)
  expected <-
    rbind(
      c(1, 2, 3),
      c(1, 2, 3),
      c(1, 2, 3)
    )
  expect_equal(actual, expected)
})

# NormByRow ----

test_that("NormByRow works for vectors", {
  actual <- NormByRow(c(3,4))
  expected <- 5
  expect_equal(actual, expected)
})

test_that("NormByRow works for matrices", {
  actual <- NormByRow(matrix(nrow = 2, data = c(3,4,6,8), byrow = TRUE))
  expected <- c(5, 10)
  expect_equal(actual, expected)
})

# NormalizeByRow ----

test_that("NormalizeByRow works for vectors", {
  actual <- NormalizeByRow(c(3,4))
  expected <- c(0.6, 0.8)
  expect_equal(actual, expected)
})

test_that("NormalizeByRow works for matrices", {
  actual <- NormalizeByRow(matrix(nrow = 2, data = c(3,4,6,8), byrow = TRUE))
  expected <-
    rbind(
      c(0.6, 0.8),
      c(0.6, 0.8)
    )
  expect_equal(actual, expected)
})

# DistanceByRow ----

test_that("DistanceByRow works", {
  actual <-
    DistanceByRow(
      mat1 = matrix(nrow = 2, data = c(1,0,0,1), byrow = TRUE),
      mat2 = matrix(nrow = 2, data = c(1,0,1,0), byrow = TRUE)
    )
  expected <-
    rbind(
      c(0, 0),
      c(1.41421356, 1.41421356)
    )
  expect_equal(actual, expected)
})

# IsolateDecimal ----

test_that("IsolateDecimal works for scalars", {
  actual <- IsolateDecimal(3.1415)
  expected <- 0.1415
  expect_equal(actual, expected)
})

test_that("IsolateDecimal works for vectors", {
  actual <- IsolateDecimal(c(3.1415, 2.718))
  expected <- c(0.1415, 0.718)
  expect_equal(actual, expected)
})

# AllIdentical ----

test_that("AllIdentical works 1", {
  actual <- AllIdentical(1,1.01,1.001)
  expected <- FALSE
  expect_equal(actual, expected)
})

test_that("AllIdentical works 2", {
  actual <- AllIdentical(1L, 1.0, 1+1e-9)
  expected <- TRUE
  expect_equal(actual, expected)
})

# SuperFloor ----

test_that("SuperFloor works 1", {
  actual <- SuperFloor(x = 6, modulo = 5)
  expected <- 5
  expect_equal(actual, expected)
})

test_that("SuperFloor works 2", {
  actual <- SuperFloor(x = 5, modulo = 5)
  expected <- 5
  expect_equal(actual, expected)
})

test_that("SuperFloor works 3", {
  actual <- SuperFloor(x = 5 - 1e-8, modulo = 5)
  expected <- 5
  expect_equal(actual, expected)
})

test_that("SuperFloor works 4", {
  actual <- SuperFloor(x = 5 - 1e-7, modulo = 5)
  expected <- 0
  expect_equal(actual, expected)
})

test_that("SuperFloor works for vectors", {
  actual <-
    SuperFloor(
      x = c(6, 5, 5 - 1e-8, 5 - 1e-7),
      modulo = 5
    )
  expected <- c(5, 5, 5, 0)
  expect_equal(actual, expected)
})

# SuperCeiling ----

test_that("SuperCeiling works 1", {
  actual <- SuperCeiling(x = 4, modulo = 5)
  expected <- 5
  expect_equal(actual, expected)
})

test_that("SuperCeiling works 2", {
  actual <- SuperCeiling(x = 5, modulo = 5)
  expected <- 5
  expect_equal(actual, expected)
})

test_that("SuperCeiling works 3", {
  actual <- SuperCeiling(x = 5 + 1e-8, modulo = 5)
  expected <- 5
  expect_equal(actual, expected)
})

test_that("SuperCeiling works 4", {
  actual <- SuperCeiling(x = 5 + 1e-7, modulo = 5)
  expected <- 10
  expect_equal(actual, expected)
})

test_that("SuperCeiling works for vectors", {
  actual <-
    SuperCeiling(
      x = c(4, 5, 5 + 1e-8, 5 + 1e-7),
      modulo = 5
    )
  expected <- c(5, 5, 5, 10)
  expect_equal(actual, expected)
})

# CharacterSign ----

test_that("CharacterSign works 1", {
  actual <- CharacterSign(1)
  expected <- "+"
  expect_equal(actual, expected)
})

test_that("CharacterSign works 2", {
  actual <- CharacterSign(0)
  expected <- "+"
  expect_equal(actual, expected)
})

test_that("CharacterSign works 3", {
  actual <- CharacterSign(-1)
  expected <- "-"
  expect_equal(actual, expected)
})

test_that("CharacterSign works for vectors", {
  actual <- CharacterSign(c(1, 0, -1))
  expected <- c("+", "+", "-")
  expect_equal(actual, expected)
})

# LocalMaxima ----

test_that("LocalMaxima works", {
  actual <- LocalMaxima(c(1,2,3,4,3,2,3,4,3,2,1))
  expected <- c(4, 8)
  expect_equal(actual, expected)
})

# LocalMaxima ----

test_that("LocalMaxima works", {
  actual <- LocalMinima(c(4,3,2,1,2,3,3,2,1,2,3))
  expected <- c(4, 9)
  expect_equal(actual, expected)
})

# AngleDifference ----

test_that("AngleDifference works with a 2 * pi wrap", {
  actual <- AngleDifference(2 * pi - 0.5, 0.5)
  expected <- 1
  expect_equal(actual, expected)
})

test_that("AngleDifference works for vectors", {
  actual <-
    AngleDifference(
      c(2 * pi - 0.5, pi/2),
      c(0.5, pi)
    )
  expected <- c(1, pi/2)
  expect_equal(actual, expected)
})

# LabelEastWest ----

test_that("LabelEastWest works 1", {
  actual <- LabelEastWest(45)
  expected <- "E"
  expect_equal(actual, expected)
})

test_that("LabelEastWest works 2", {
  actual <- LabelEastWest(0)
  expected <- "E"
  expect_equal(actual, expected)
})

test_that("LabelEastWest works 3", {
  actual <- LabelEastWest(-45)
  expected <- "W"
  expect_equal(actual, expected)
})

test_that("LabelEastWest works for vectors", {
  actual <- LabelEastWest(c(45, 0, -45))
  expected <- c("E", "E", "W")
  expect_equal(actual, expected)
})

# LabelNorthSouth ----

test_that("LabelNorthSouth works 1", {
  actual <- LabelNorthSouth(45)
  expected <- "N"
  expect_equal(actual, expected)
})

test_that("LabelNorthSouth works 2", {
  actual <- LabelNorthSouth(0)
  expected <- "N"
  expect_equal(actual, expected)
})

test_that("LabelNorthSouth works 3", {
  actual <- LabelNorthSouth(-45)
  expected <- "S"
  expect_equal(actual, expected)
})

test_that("LabelNorthSouth works for vectors", {
  actual <- LabelNorthSouth(c(45, 0, -45))
  expected <- c("N", "N", "S")
  expect_equal(actual, expected)
})

# InterpolateDataFrame ----

test_that("InterpolateDataFrame works", {
  actual <-
    InterpolateDataFrame(
      df = data.frame(
        date = lubridate::ymd_hms("2000-01-01 00:00:00") + 1:10,
        logical = c(rep(TRUE, 5), rep(FALSE, 5)),
        character = c(rep("hello", 5), rep("hello", 5)),
        numeric = 1:10,
        dataframe = data.frame(
          x = 1:10,
          y = 11:20,
          z = 21:30
        )
      ),
      x = 5.5
    )
  expected <- data.frame(
    date = lubridate::ymd_hms("2000-01-01 00:00:05") + 0.5,
    logical = FALSE,
    character = "hello",
    numeric = 5.5,
    dataframe = data.frame(
      x = 5.5,
      y = 15.5,
      z = 25.5
    )
  )
  expect_equal(actual, expected)
})
