

# Earth Orientation Model ----

## TimeConversions ----

test_that("TimeConversions works", {
  actual <- TimeConversions(1,1)
  expected <-
    data.frame(
      ut1_tai = 0,
      utc_gps = 18,
      ut1_gps = 19,
      tt_utc = 33.184,
      gps_utc = -18
    )
  expect_equal(actual, expected)
})

## PrecessionMatrix ----

test_that("PrecessionMatrix works", {
  actual <- PrecessionMatrix(c(0,1))
  expected <-
    list(
      rbind(
        c(0.99940848, 0.0315374101, 0.0137143994),
        c(-0.03153741, 0.9995025488, -0.0002163748),
        c(-0.01371440, -0.0002162698, 0.9999059298)
      ),
      rbind(
        c(0.99940850,  0.0315367987,  0.0137141334),
        c(-0.03153680,  0.9995025681, -0.0002163664),
        c(-0.01371414, -0.0002162614,  0.9999059334)
      )
    )
  expect_equal(actual, expected)
})

## MeanObliquity ----

test_that("MeanObliquity works", {
  actual <- MeanObliquity(c(0,1))
  expected <- c(0.81882614, 0.81882613)
  expect_equal(actual, expected)
})

## NutationAngles ----

test_that("NutationAngles works", {
  actual <- NutationAngles(c(46848, 46849))
  expected <-
    data.frame(
      dpsi = c(-1.463627664e-05, -1.402262207e-05),
      deps = c(4.411988547e-05, 4.407834219e-05)
    )
  expect_equal(actual, expected)
})

## NutationMatrix ----

test_that("NutationMatrix works", {
  actual <-  NutationMatrix(c(46848, 46849))
  expected <-
    list(
      rbind(
        c(9.999999999e-01, 1.000348320e-05, -1.068414329e-05),
        c(-1.000395457e-05, 9.999999990e-01, -4.411983201e-05),
        c(1.068370193e-05, 4.411993889e-05,  9.999999990e-01)
      ),
      rbind(
        c(9.999999999e-01, 9.584068118e-06, -1.023618913e-05),
        c(-9.584519303e-06, 9.999999990e-01, -4.407829313e-05),
        c(1.023576667e-05, 4.407839123e-05,  9.999999990e-01)
      )
    )
  expect_equal(actual, expected)
})

## GMST ----

test_that("GMST works", {
  actual <- GMST(c(46848, 46849))
  expected <- c(2.64186595, 2.65906874)
  expect_equal(actual, expected)
})

## EquationOfEquinox ----

test_that("EquationOfEquinox works", {
  actual <- EquationOfEquinox(c(46848, 46849))
  expected <- c(-0.0000100039546, -0.0000095845193)
  expect_equal(actual, expected)
})

## GAST ----

test_that("GAST works", {
  actual <- GAST(c(46848, 46849))
  expected <- c(2.641855947, 2.659059158)
  expect_equal(actual, expected)
})

## GHAMatrix ----

test_that("GHAMatrix works", {
  actual <- GHAMatrix(c(46848, 46849))
  expected <-
    list(
      rbind(
        c(-0.8777087610,  0.4791944603,    0),
        c(-0.4791944603, -0.8777087610,    0),
        c(0.0000000000,  0.0000000000,    1)
      ),
      rbind(
        c(-0.8858221620,  0.4640248888,    0),
        c(-0.4640248888, -0.8858221620,    0),
        c(0.0000000000,  0.0000000000,    1)
      )
    )
  expect_equal(actual, expected)
})

## PoleMatrix ----

test_that("PoleMatrix works", {
  actual <-
    PoleMatrix(
      xp = c(2.645822e-07, 2.645822e-07),
      yp = c(1.342851e-06, 1.342851e-06)
    )
  expected <-
    list(
      rbind(
        c(1.000000000e+00, 0.000000e+00,  2.645822e-07),
        c(3.552944719e-13, 1.000000e+00, -1.342851e-06),
        c(-2.645822000e-07, 1.342851e-06,  1.000000e+00)
      ),
      rbind(
        c(1.000000000e+00, 0.000000e+00,  2.645822e-07),
        c(3.552944719e-13, 1.000000e+00, -1.342851e-06),
        c(-2.645822000e-07, 1.342851e-06,  1.000000e+00)
      )
    )
  expect_equal(actual, expected)
})

# Co-ordinate Transformation ----

## EcefFromGeodetic ----

test_that("EcefFromGeodetic works", {
  geodetic <-
    data.frame(
      lon = 0,
      lat = 0,
      alt = 0
    )
  actual <- EcefFromGeodetic(geodetic)
  expected <-
    data.frame(
      x = 6378137,
      y = 0,
      z = 0
    )
  expect_equal(actual, expected)
})

## GeocentricFromEcef ----

test_that("GeocentricFromEcef works", {
  actual <- GeocentricFromEcef(c(6372000, 0, 0))
  expected <-
    data.frame(
      lon = 0,
      lat = 0,
      alt = 1000
    )
  expect_equal(actual, expected)
})

## GeodeticFromEcef ----

test_that("GeodeticFromEcef works", {
  actual <- GeodeticFromEcef(c(6378137, 0, 0))
  expected <-
    data.frame(
      lon = 0,
      lat = 0,
      alt = 0
    )
  expect_equal(actual, expected)
})

test_that("Geodetic and Ecef loops", {
  expected <-
    data.frame(
      lon = 0,
      lat = 0,
      alt = 0
    )
  actual <- expected %>% EcefFromGeodetic() %>% GeodeticFromEcef()
  expect_equal(actual, expected)
})


## RotationMatrices_EcefFromEci ----

test_that("RotationMatrices_EcefFromEci works", {

  eop <- data.frame(
    eop_interpolated <- data.frame(
      utc     = lubridate::ymd_hms("2022-02-15 00:00:00 UTC"),
      mjd     = 59625,
      x_pole  = 0.016814,
      y_pole  = 0.345848,
      UT1_UTC = -0.1029937,
      LOD     = -0.0005407,
      dpsi    = -0.108690,
      deps    = -0.006864,
      dx_pole = 0.000227,
      dy_pole = 0.000127,
      TAI_UTC = 37
    )
  )
  actual <- RotationMatrices_EcefFromEci(eop)
  expected <-
    rbind(
      c(-0.8159862263,  0.5777722606,  0.01859283244),
      c(-0.5490321805, -0.7645285509, -0.33772734514),
      c(-0.1809147404, -0.2857889252,  0.94106033118)
    )
  expect_equal(actual, expected)
})

## RotationMatrices_EciFromEcef ----

test_that("RotationMatrices_EciFromEcef works", {

  eop <- data.frame(
    eop_interpolated <- data.frame(
      utc     = lubridate::ymd_hms("2022-02-15 00:00:00 UTC"),
      mjd     = 59625,
      x_pole  = 0.016814,
      y_pole  = 0.345848,
      UT1_UTC = -0.1029937,
      LOD     = -0.0005407,
      dpsi    = -0.108690,
      deps    = -0.006864,
      dx_pole = 0.000227,
      dy_pole = 0.000127,
      TAI_UTC = 37
    )
  )
  actual <- RotationMatrices_EciFromEcef(eop)
  expected <-
    rbind(
      c(-0.81598622626, -0.5490321805, -0.1809147404),
      c(0.57777226061, -0.7645285509, -0.2857889252),
      c(0.01859283244, -0.3377273451,  0.9410603312)
    )
  expect_equal(actual, expected)
})

test_that("Eci and Ecef conversion matrices are each other's inverse", {

  eop <- data.frame(
    eop_interpolated <- data.frame(
      utc     = lubridate::ymd_hms("2022-02-15 00:00:00 UTC"),
      mjd     = 59625,
      x_pole  = 0.016814,
      y_pole  = 0.345848,
      UT1_UTC = -0.1029937,
      LOD     = -0.0005407,
      dpsi    = -0.108690,
      deps    = -0.006864,
      dx_pole = 0.000227,
      dy_pole = 0.000127,
      TAI_UTC = 37
    )
  )
  eci_from_ecef <- RotationMatrices_EciFromEcef(eop)
  ecef_from_eci <- RotationMatrices_EcefFromEci(eop)
  actual <- eci_from_ecef %*% ecef_from_eci
  expected <- diag(3)
  expect_equal(actual, expected)
})

## EcefFromEci ----

test_that("EcefFromEci works", {

  eop <- data.frame(
    eop_interpolated <- data.frame(
      utc     = rep(lubridate::ymd_hms("2022-02-15 00:00:00 UTC"), 2),
      mjd     = rep(59625, 2),
      x_pole  = rep(0.016814, 2),
      y_pole  = rep(0.345848, 2),
      UT1_UTC = rep(-0.1029937, 2),
      LOD     = rep(-0.0005407, 2),
      dpsi    = rep(-0.108690, 2),
      deps    = rep(-0.006864, 2),
      dx_pole = rep(0.000227, 2),
      dy_pole = rep(0.000127, 2),
      TAI_UTC = rep(37, 2)
    )
  )
  eci <- data.frame(
    x = c(6378137, 0),
    y = c(0, 6378137),
    z = c(0, 0)
  )
  actual <- EcefFromEci(eci = eci, eop = eop)
  expected <-
    data.frame(
      x = c(-5204471.941, 3685110.633),
      y = c(-3501802.465, -4876267.838),
      z = c(-1153899.000, -1822800.918)
    )
  expect_equal(actual, expected)
})

## EciFromEcef ----

test_that("EciFromEcef works", {

  eop <- data.frame(
    eop_interpolated <- data.frame(
      utc     = rep(lubridate::ymd_hms("2022-02-15 00:00:00 UTC"), 2),
      mjd     = rep(59625, 2),
      x_pole  = rep(0.016814, 2),
      y_pole  = rep(0.345848, 2),
      UT1_UTC = rep(-0.1029937, 2),
      LOD     = rep(-0.0005407, 2),
      dpsi    = rep(-0.108690, 2),
      deps    = rep(-0.006864, 2),
      dx_pole = rep(0.000227, 2),
      dy_pole = rep(0.000127, 2),
      TAI_UTC = rep(37, 2)
    )
  )
  ecef <- data.frame(
    x = c(6378137, 0),
    y = c(0, 6378137),
    z = c(0, 0)
  )
  actual <- EciFromEcef(ecef = ecef, eop = eop)
  expected <-
    data.frame(
      x = c(-5204471.941, -3501802.465),
      y = c(3685110.633, -4876267.838),
      z = c(118587.6325, -2154071.2760)
    )
  expect_equal(actual, expected)
})

test_that("Eci and Ecef loop", {

  eop <- data.frame(
    eop_interpolated <- data.frame(
      utc     = rep(lubridate::ymd_hms("2022-02-15 00:00:00 UTC"), 2),
      mjd     = rep(59625, 2),
      x_pole  = rep(0.016814, 2),
      y_pole  = rep(0.345848, 2),
      UT1_UTC = rep(-0.1029937, 2),
      LOD     = rep(-0.0005407, 2),
      dpsi    = rep(-0.108690, 2),
      deps    = rep(-0.006864, 2),
      dx_pole = rep(0.000227, 2),
      dy_pole = rep(0.000127, 2),
      TAI_UTC = rep(37, 2)
    )
  )
  ecef <- data.frame(
    x = c(6378137, 0),
    y = c(0, 6378137),
    z = c(0, 0)
  )
  actual <- ecef %>% EciFromEcef(eop = eop) %>% EcefFromEci(eop = eop)
  expected <- ecef
  expect_equal(actual, expected)
})

## GeodeticFromEci ----

test_that("GeodeticFromEci works", {

  eop <- data.frame(
    eop_interpolated <- data.frame(
      utc     = rep(lubridate::ymd_hms("2022-02-15 00:00:00 UTC"), 2),
      mjd     = rep(59625, 2),
      x_pole  = rep(0.016814, 2),
      y_pole  = rep(0.345848, 2),
      UT1_UTC = rep(-0.1029937, 2),
      LOD     = rep(-0.0005407, 2),
      dpsi    = rep(-0.108690, 2),
      deps    = rep(-0.006864, 2),
      dx_pole = rep(0.000227, 2),
      dy_pole = rep(0.000127, 2),
      TAI_UTC = rep(37, 2)
    )
  )
  eci <- data.frame(
    x = c(6378137, 0),
    y = c(0, 6378137),
    z = c(0, 0)
  )
  actual <- GeodeticFromEci(eci = eci, eop = eop)
  expected <-
    data.frame(
      lon = c(-146.06556260, -52.92079831),
      lat = c(-10.49172912, -16.71167796),
      alt = c(703.3433072, 1754.6981158)
    )
  expect_equal(actual, expected)
})

## EciFromGeodetic ----

test_that("EciFromGeodetic works", {

  eop <- data.frame(
    eop_interpolated <- data.frame(
      utc     = rep(lubridate::ymd_hms("2022-02-15 00:00:00 UTC"), 2),
      mjd     = rep(59625, 2),
      x_pole  = rep(0.016814, 2),
      y_pole  = rep(0.345848, 2),
      UT1_UTC = rep(-0.1029937, 2),
      LOD     = rep(-0.0005407, 2),
      dpsi    = rep(-0.108690, 2),
      deps    = rep(-0.006864, 2),
      dx_pole = rep(0.000227, 2),
      dy_pole = rep(0.000127, 2),
      TAI_UTC = rep(37, 2)
    )
  )
  geodetic <-
    data.frame(
      lon = c(-146.06556260, -52.92079831),
      lat = c(-10.49172912, -16.71167796),
      alt = c(703.3433072, 1754.6981158)
    )
  actual <- EciFromGeodetic(geodetic = geodetic, eop = eop)
  expected <-
    data.frame(
      x = c(6378137, 0),
      y = c(0, 6378137),
      z = c(0, 0)
    )
  expect_equal(actual, expected, tolerance = 3)
})

test_that("Eci and Geodetic loop", {

  eop <- data.frame(
    eop_interpolated <- data.frame(
      utc     = rep(lubridate::ymd_hms("2022-02-15 00:00:00 UTC"), 2),
      mjd     = rep(59625, 2),
      x_pole  = rep(0.016814, 2),
      y_pole  = rep(0.345848, 2),
      UT1_UTC = rep(-0.1029937, 2),
      LOD     = rep(-0.0005407, 2),
      dpsi    = rep(-0.108690, 2),
      deps    = rep(-0.006864, 2),
      dx_pole = rep(0.000227, 2),
      dy_pole = rep(0.000127, 2),
      TAI_UTC = rep(37, 2)
    )
  )
  eci <- data.frame(
    x = c(6378137, 0),
    y = c(0, 6378137),
    z = c(0, 0)
  )
  actual <- eci %>% GeodeticFromEci(eop = eop) %>% EciFromGeodetic(eop = eop)
  expected <- eci
  expect_equal(actual, expected)
})

