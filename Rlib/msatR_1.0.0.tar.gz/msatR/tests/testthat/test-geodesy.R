# RadiusAtLatitude ----

test_that("RadiusAtLatitude works", {
  actual <- RadiusAtLatitude(c(0, 90))
  expected <- c(6378137, 6356752.3)
  expect_equal(actual, expected)
})

# ParallelOfLatitudeCircumference ----

test_that("ParallelOfLatitudeCircumference works", {
  actual <- ParallelOfLatitudeCircumference(c(0, 90))
  expected <- c(40075017, 0)
  expect_equal(actual, expected)
})

# LocalTangentPlane ----

test_that("LocalTangentPlane works", {
  actual <- LocalTangentPlane(0, 0)
  expected <-
    list(
      x_hat = data.frame(x = 0, y = 1, z = 0),
      y_hat = data.frame(x = 0, y = 0, z = 1),
      z_hat = data.frame(x = 1, y = 0, z = 0)
    )
  expect_equal(actual, expected)
})

# LocalVerticalLocalHorizontal ----

test_that("LocalVerticalLocalHorizontal works", {
  pos <- c(6378137, 0, 0)
  vel <- c(0, 0, 6000)
  actual <- LocalVerticalLocalHorizontal(pos, vel)
  expected <-
    list(
      x_hat = data.frame(x = 0, y = 0, z = 1),
      y_hat = data.frame(x = 0, y = 1, z = 0),
      z_hat = data.frame(x = -1, y = 0, z = 0)
    )
  expect_equal(actual, expected)
})

# Eclipse ----

test_that("Eclipse works", {
  pos <-
    data.frame(
      x = c(6378137, 6378137),
      y = c(0, 0),
      z = c(0, 0)
    )
  sun <-
    data.frame(
      x = c(1.496e+11, -1.496e+11),
      y = c(0, 0),
      z = c(0, 0)
     )
  actual <- Eclipse(pos, sun)
  expected <- c(FALSE, TRUE)
  expect_equal(actual, expected)
})

# ZenithAngle ----

test_that("ZenithAngle works", {
  actual <-
    ZenithAngle(
      lon_observer = 0,
      lat_observer = 0,
      alt_observer = 0,
      object_ecef = c(sqrt(2) * 1.496e+11, sqrt(2) * 1.496e+11, 0)
    )
  expected <- 0.78541324
  expect_equal(actual, expected)
})

# ZenithAndAzimuthAngles ----

test_that("ZenithAndAzimuthAngles works", {
  actual <-
    ZenithAndAzimuthAngles(
      lon_observer = 0,
      lat_observer = 0,
      alt_observer = 0,
      object_ecef = c(sqrt(2) * 1.496e+11, sqrt(2) * 1.496e+11, 0)
    )
  expected <-
    data.frame(
      zenith = 0.7854132372,
      azimuth = 1.570796327
    )
  expect_equal(actual, expected)
})

# SolarEphemeris ----

test_that("SolarEphemeris works", {
  actual <- SolarEphemeris("1987-02-22")
  expected <- data.frame(
    x = 131636047647,
    y = -62003170276,
    z = -26883705086
  )
  expect_equal(actual, expected)
})

