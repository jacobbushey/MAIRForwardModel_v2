
# TargetBuildAimpoints ----

test_that("TargetBuildAimpoints works", {
  actual <-
    TargetBuildAimpoints(
      lon = 0,
      lat = 0,
      duration = 29,
      multiple = 1,
      orbit_example = orbit_examples$transporter_9
    )
  expected <- list()
  expected[[1]] <-
    data.frame(
      point = c("left", "center", "right")
    )
  expected[[1]]$geodetic <-
    data.frame(
      lon =
        c(
          -8.443039868e-01,
           3.839474516e-09,
           8.443039946e-01
        ),
      lat =
        c(
          -1.136336408e-01,
          -1.987749686e-08,
          1.136336011e-01
        ),
      alt = c(17.38604736, 17.23013115, 17.02026558)
    )
  expected[[1]]$ecef <-
    data.frame(
      x =
        c(
          6377449.444 ,
          6378154.230,
          6377449.078
        ),
      y =
        c(
          -9.398416101e+04,
           4.274095027e-04,
           9.398415648e+04
        ),
      z =
        c(
          -1.256498390e+04,
          -2.197945788e-03,
           1.256497878e+04
        )
    )
  expect_equal(actual, expected)
})

# # TargetBuildVariablePitchAimpoints ----
#
# test_that("TargetBuildVariablePitchAimpoints works", {
#   actual <-
#     TargetBuildVariablePitchAimpoints(
#       lon = 0,
#       lat = 0,
#       duration = 29,
#       buffer = 1,
#       multiple = 1,
#       orbit_example = orbit_examples$transporter_9
#     )
#   expected <- list()
#   expected[[1]] <-
#     data.frame(
#       point = c("bottom", "top")
#     )
#   expected[[1]]$geodetic <-
#     data.frame(
#       lon =
#         c(
#           0.1942339504,
#           -0.1942386580
#         ),
#       lat =
#         c(
#           -0.9748724606,
#           0.9749080644
#         ),
#       alt = c(17.90157700, 17.12766838)
#     )
#   expected[[1]]$ecef <-
#     data.frame(
#       x =
#         c(
#           6377201.217,
#           6377200.374
#         ),
#       y =
#         c(
#           21618.93494,
#           -21619.45607
#         ),
#       z =
#         c(
#           -107791.0238,
#           107794.9469
#         )
#     )
#   expect_equal(actual, expected)
# })
#
# test_that("TargetBuildPolygons produces a list of polygons", {
#   actual <-
#     TargetBuildPolygons(
#       lon = 0,
#       lat = 0,
#       duration = 29,
#       multiple = 1,
#       orbit_example = orbit_examples$transporter_9
#     )
#   expect_true(
#     all(
#       class(actual[[1]])[1] == "sf",
#       class(actual[[1]])[2] == "data.frame"
#       )
#     )
# })

test_that("TargetBuildPolygons works", {
  target_polygon <-
    TargetBuildPolygons(
      lon = 0,
      lat = 0,
      duration = 5,
      multiple = 1,
      orbit_example = orbit_examples$transporter_10
    )
  actual <- TargetBuildGfsPoints(target_polygon[[1]])
  expected <-
    data.frame(
      lon = c(-0.125, 0.125, 0.375, 0.625, -0.625, -0.375, -0.125, 0.125),
      lat = c(-0.125, -0.125, -0.125, -0.125, 0.125, 0.125, 0.125, 0.125)
    )
  rownames(expected) <- c(517680, 517681, 517682, 517683,
                          519118, 519119, 519120, 519121)
  attributes(expected) <- attributes(actual)
  expect_equal(actual, expected)
})

test_that("TargetBuildDem works", {
  target_polygon <-
    TargetBuildPolygons(
      lon = 0,
      lat = 0,
      duration = 5,
      multiple = 1,
      orbit_example = orbit_examples$transporter_10
    )
  actual <- TargetBuildDem(target_polygon[[1]])[1:5, ]
  expected <-
    data.frame(
      lon =
        c(-0.8749895766,
          -0.7916562408,
          -0.7083229049,
          -1.0416562482,
          -0.9583229124),
      lat =
        c(0.7083332164,
          0.7083332164,
          0.7083332164,
          0.6249998806,
          0.6249998806),
      alt =
        c(17.25558281,
          17.24564171,
          17.23653412,
          17.37541771,
          17.31451225)
    )
  expect_equal(actual, expected)
})

test_that("TargetBuildRds works", {
  target_rds <-
    TargetBuildRds(
      target_df =
        data.frame(
          type = "Oil_And_Gas",
          lon = 0,
          lat = 0,
          alt = 0,
          multiple = 1,
          duration = 29,
          buffer = 1
        ),
      orbit_example = orbit_examples$transporter_10
     )
  actual <- names(target_rds)
  expected <- c("polygons", "aimpoints", "gfspoints")
  expect_equal(actual, expected)
})
