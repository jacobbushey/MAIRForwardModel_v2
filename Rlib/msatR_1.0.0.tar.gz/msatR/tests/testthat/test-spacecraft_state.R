# This set of tests includes everything that uses the spacecraft state
# We only want to generate the spacecraft state once, and then apply all
# tests that follow from it.

ephemeris <- ReadCcsdsOem("../testdata/Ephemeris_v01_2022_046.oem")
spacecraft_state <-
  SpacecraftState(
    ephemeris = ephemeris$ephemeris,
    spacecraft_configuration = ground_configuration,
    bulletin = "B",
    iers_file = "../testdata/finals.data.csv",
    leap_seconds_file = "../testdata/leap-seconds.list",
    tle =
      c(
        "1 88888U  20001A  20001.50000000  .00000000  00000-0  00000-0 0  9991",
        "2 88888  97.5055  78.4960 0000000  00.0000  00.0000 15.1339254 1    1"
      ),
    verbose = FALSE
  )

test_that("SpacecraftState works", {
  actual <- names(spacecraft_state)
  expected <-
    c("utc", "activity", "eop", "q_ei", "pos_eci", "pos_ecef", "pos_geodetic",
      "vel_eci", "vel_ecef", "sun_eci", "sun_ecef", "sun_geodetic", "moon_eci",
      "moon_ecef", "eclipse", "rev", "attitude_quaternion_eci",
      "constraints", "data_management", "activity_schedule")
  expect_equal(actual, expected)
})
