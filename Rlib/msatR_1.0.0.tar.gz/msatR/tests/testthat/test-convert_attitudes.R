# RotationMatricesFromBasisVectors ----

test_that("RotationMatricesFromBasisVectors works", {
  basis_vectors <- list()
  basis_vectors$x_hat <- data.frame(x = 1, y = 0, z = 0)
  basis_vectors$y_hat <- data.frame(x = 0, y = 1, z = 0)
  basis_vectors$z_hat <- data.frame(x = 0, y = 0, z = 1)
  actual <- RotationMatricesFromBasisVectors(basis_vectors)
  expected <-
    rbind(
      c(1, 0, 0),
      c(0, 1, 0),
      c(0, 0, 1)
    )
  expect_equal(actual, expected)
})

test_that("RotationMatrices BasisVectors loop", {
  basis_vectors <- list()
  basis_vectors$x_hat <- data.frame(x = 1, y = 0, z = 0)
  basis_vectors$y_hat <- data.frame(x = 0, y = 1, z = 0)
  basis_vectors$z_hat <- data.frame(x = 0, y = 0, z = 1)
  actual <-
    basis_vectors %>%
    RotationMatricesFromBasisVectors() %>%
    BasisVectorsFromRotationMatrices()
  expected <- basis_vectors
  expect_equal(actual, expected)
})

# BasisVectorsFromRotationMatrices ----

test_that("BasisVectorsFromRotationMatrices works", {
  actual <- BasisVectorsFromRotationMatrices(diag(3))
  expected <-
    list(
      x_hat = data.frame(x = 1, y = 0, z = 0),
      y_hat = data.frame(x = 0, y = 1, z = 0),
      z_hat = data.frame(x = 0, y = 0, z = 1)
    )
  expect_equal(actual, expected)
})

test_that("BasisVectors RotationMatrices loop", {
  actual <-
    diag(3) %>%
    BasisVectorsFromRotationMatrices() %>%
    RotationMatricesFromBasisVectors()
  expected <- diag(3)
  expect_equal(actual, expected)
})

# RotationMatricesFromRotationVectors ----

test_that("RotationMatricesFromRotationVectors works", {
  actual <- RotationMatricesFromRotationVectors(c(pi/2,0,0))
  expected <- R_x(pi / 2)
  expect_equal(actual, expected)
})

test_that("RotationMatrices RotationVectors loop", {
  actual <-
    data.frame(x = pi/2, y = 0, z = 0) %>%
    RotationMatricesFromRotationVectors() %>%
    RotationVectorsFromRotationMatrices()
  expected <- data.frame(x = pi/2, y = 0, z = 0)
  expect_equal(actual, expected)
})

# RotationVectorsFromRotationMatrices ----

test_that("RotationVectorsFromRotationMatrices works", {
  actual <- RotationVectorsFromRotationMatrices(diag(3))
  expected <-
    data.frame(
      x = 0,
      y = 0,
      z = 0
    )
  expect_equal(actual, expected)
})

test_that("RotationVectors RotationMatrices loop", {
  actual <-
    diag(3) %>%
    RotationVectorsFromRotationMatrices() %>%
    RotationMatricesFromRotationVectors()
  expected <- diag(3)
  expect_equal(actual, expected)
})


# RotationMatricesFromPitchRollYaw ----

test_that("RotationMatricesFromPitchRollYaw works", {
  pitch_roll_yaw <-
    data.frame(
      pitch = c(0, pi/36),
      roll = c(0, pi/8),
      yaw = c(0, pi/72)
    )
  actual <- RotationMatricesFromPitchRollYaw(pitch_roll_yaw)
  expected <-
    list(
      rbind(
        c(1, 0, 0),
        c(0, 1, 0),
        c(0, 0, 1)
      ),
      rbind(
        c(0.99670138, -0.01013209, 0.08052141),
        c(0.04029906, 0.92300020, -0.38268343),
        c(-0.07044389, 0.38466604, 0.92036389)
      )
    )
  expect_equal(actual, expected)
})

test_that("RotationMatrices PitchRollYaw loop", {
  pitch_roll_yaw <-
    data.frame(
      pitch = c(pi/2),
      roll = c(pi/4),
      yaw = c(pi/6)
    )
  actual <-
    pitch_roll_yaw %>%
    RotationMatricesFromPitchRollYaw() %>%
    PitchRollYawFromRotationMatrices()
  expected <- pitch_roll_yaw
  expect_equal(actual, expected)
})

# PitchRollYawFromRotationMatrices ----

test_that("PitchRollYawFromRotationMatrices works for scalars", {
  actual <- PitchRollYawFromRotationMatrices(diag(3))
  expected <-
    data.frame(
      pitch = 0,
      roll = 0,
      yaw = 0
    )
  expect_equal(actual, expected)
})

test_that("PitchRollYawFromRotationMatrices works for vectors", {
  actual <- PitchRollYawFromRotationMatrices(list(R_z(pi/8), R_x(pi/6)))
  expected <-
    data.frame(
      pitch = c(0, 0),
      roll = c(0, 0.52359878),
      yaw = c(0.39269908, 0)
    )
  expect_equal(actual, expected)
})

test_that("PitchRollYaw RotationMatrices loop", {
  rotmat <- list(R_z(pi/8), R_x(pi/6))
  actual <-
    list(R_z(pi/8), R_x(pi/6)) %>%
    PitchRollYawFromRotationMatrices() %>%
    RotationMatricesFromPitchRollYaw()
  expected <- list(R_z(pi/8), R_x(pi/6))
  expect_equal(actual, expected)
})

# RotationMatricesFromQuaternions ----

test_that("RotationMatricesFromQuaternions works for scalars", {
  actual <- RotationMatricesFromQuaternions(c(1,0,0,0))
  expected <-
    rbind(
      c(1, 0, 0),
      c(0, 1, 0),
      c(0, 0, 1)
    )
  expect_equal(actual, expected)
})

test_that("RotationMatricesFromQuaternions works for vectors", {
  actual <- RotationMatricesFromQuaternions(rbind(c(1,0,0,0), c(0,1,0,0)))
  expected <-
    list(
      rbind(
        c(1, 0, 0),
        c(0, 1, 0),
        c(0, 0, 1)
      ),
      rbind(
        c(1, 0, 0),
        c(0, -1, 0),
        c(0, 0, -1)
      )
    )
  expect_equal(actual, expected)
})

test_that("RotationMatrices Quaternions loop", {
  actual <-
    data.frame(
      r = c(1, 1/sqrt(2)),
      i1 = c(0, 1/sqrt(2)),
      i2 = c(0, 0),
      i3 = c(0, 0)
    ) %>%
    RotationMatricesFromQuaternions() %>%
    QuaternionsFromRotationMatrices()
  expected <-
    data.frame(
      r = c(1, 1/sqrt(2)),
      i1 = c(0, 1/sqrt(2)),
      i2 = c(0, 0),
      i3 = c(0, 0)
    )
  expect_equal(actual, expected)
})


# QuaternionFromRotationMatrices ----

test_that("QuaternionsFromRotationMatrices works for a single matrix", {
  actual <- QuaternionsFromRotationMatrices(diag(3))
  expected <-
    data.frame(
      r = 1,
      i1 = 0,
      i2 = 0,
      i3 = 0
    )
  expect_equal(actual, expected)
})

test_that("QuaternionsFromRotationMatrices works for a list of matrices", {
  actual <- QuaternionsFromRotationMatrices(list(diag(3), R_x(pi/2)))
  expected <-
    data.frame(
      r = c(1, 1/sqrt(2)),
      i1 = c(0, 1/sqrt(2)),
      i2 = c(0, 0),
      i3 = c(0, 0)
    )
  expect_equal(actual, expected)
})

test_that("Quaternions RotationMatrices loop", {
  actual <-
    list(diag(3), R_x(pi/2)) %>%
    QuaternionsFromRotationMatrices() %>%
    RotationMatricesFromQuaternions()
  expected <- list(diag(3), R_x(pi/2))
  expect_equal(actual, expected)
})

# QuaternionFromPitchRollYaw ----

test_that("QuaternionsFromPitchRollYaw works", {
  pitch_roll_yaw <-
    data.frame(
      pitch = c(0, pi/36),
      roll = c(0, pi/8),
      yaw = c(0, pi/72)
    )
  actual <- QuaternionsFromPitchRollYaw(pitch_roll_yaw)
  expected <-
    data.frame(
      r = c(1, 0.97980425),
      i1 = c(0, 0.195791525),
      i2 = c(0, 0.03851925),
      i3 = c(0, 0.012867659)
    )
  expect_equal(actual, expected)
})

test_that("Quaternions PitchRollYaw loop", {
  pitch_roll_yaw <-
    data.frame(
      pitch = c(0, pi/36),
      roll = c(0, pi/8),
      yaw = c(0, pi/72)
    )
  actual <-
    pitch_roll_yaw %>%
    QuaternionsFromPitchRollYaw() %>%
    PitchRollYawFromQuaternions()
  expected <-
    data.frame(
      pitch = c(0, pi/36),
      roll = c(0, pi/8),
      yaw = c(0, pi/72)
    )
  expect_equal(actual, expected)
})

# PitchRollYawFromQuaternion ----

test_that("PitchRollYawFromQuaternions works", {
  q <-
    data.frame(
      r = c(1, 1/sqrt(2)),
      i1 = c(0, 1/sqrt(2)),
      i2 = c(0, 0),
      i3 = c(0, 0)
    )
  actual <- PitchRollYawFromQuaternions(q)
  expected <-
    data.frame(
      pitch = c(0, 0),
      roll = c(0, pi / 2),
      yaw = c(0, 0)
    )
  expect_equal(actual, expected)
})

test_that("PitchRollYaw Quaternions loop", {
  q <-
    data.frame(
      r = c(1, 1/sqrt(2)),
      i1 = c(0, 1/sqrt(2)),
      i2 = c(0, 0),
      i3 = c(0, 0)
    )
  actual <-
    q %>%
    PitchRollYawFromQuaternions() %>%
    QuaternionsFromPitchRollYaw()
  expected <-
    data.frame(
      r = c(1, 1/sqrt(2)),
      i1 = c(0, 1/sqrt(2)),
      i2 = c(0, 0),
      i3 = c(0, 0)
    )
  expect_equal(actual, expected)
})

# QuaternionFromBasisVectors ----

test_that("QuaternionsFromBasisVectors works", {
  basis_vectors <- list()
  basis_vectors$x_hat <- data.frame(x = 1, y = 0, z = 0)
  basis_vectors$y_hat <- data.frame(x = 0, y = 1, z = 0)
  basis_vectors$z_hat <- data.frame(x = 0, y = 0, z = 1)
  actual <- QuaternionsFromBasisVectors(basis_vectors)
  expected <-
    data.frame(
      r = 1,
      i1 = 0,
      i2 = 0,
      i3 = 0
    )
  expect_equal(actual, expected)
})

test_that("Quaternions BasisVectors loop", {
  basis_vectors <- list()
  basis_vectors$x_hat <- data.frame(x = 1, y = 0, z = 0)
  basis_vectors$y_hat <- data.frame(x = 0, y = 1, z = 0)
  basis_vectors$z_hat <- data.frame(x = 0, y = 0, z = 1)
  actual <-
    basis_vectors %>%
    QuaternionsFromBasisVectors() %>%
    BasisVectorsFromQuaternions()
  expected <- basis_vectors
  expect_equal(actual, expected)
})


# BasisVectorsFromQuaternions ----

test_that("BasisVectorsFromQuaternions works for scalars", {
  actual <- BasisVectorsFromQuaternions(c(1, 0, 0, 0))
  expected <-
    list(
      x_hat = data.frame(x = 1, y = 0, z = 0),
      y_hat = data.frame(x = 0, y = 1, z = 0),
      z_hat = data.frame(x = 0, y = 0, z = 1)
    )
  expect_equal(actual, expected)
})

test_that("BasisVectors Quaternions works for scalars", {
  actual <-
    data.frame(
      r = c(1, 1 / sqrt(2)),
      i1 = c(0, 1/ sqrt(2)),
      i2 = c(0, 0),
      i3 = c(0, 0)
    ) %>%
    BasisVectorsFromQuaternions() %>%
    QuaternionsFromBasisVectors()
  expected <-
    data.frame(
      r = c(1, 1 / sqrt(2)),
      i1 = c(0, 1/ sqrt(2)),
      i2 = c(0, 0),
      i3 = c(0, 0)
    )
  expect_equal(actual, expected)
})

# QuaternionFromRotationVectors ----

test_that("QuaternionsFromRotationVectors works", {
  actual <- QuaternionsFromRotationVectors(c(pi/2,0,0))
  expected <-
    data.frame(
      r = c(0.70710678),
      i1 = c(0.70710678),
      i2 = c(0),
      i3 = c(0)
    )
  expect_equal(actual, expected)
})

test_that("Quaternions RotationVectors loop", {
  actual <-
    data.frame(
      x = c(pi/2),
      y = c(pi/6),
      z = c(1)
    ) %>%
    QuaternionsFromRotationVectors() %>%
    RotationVectorsFromQuaternions()
  expected <-
    data.frame(
      x = c(pi/2),
      y = c(pi/6),
      z = c(1)
    )
  expect_equal(actual, expected)
})

# RotationVectorsFromQuaternions ----

test_that("RotationVectorsFromQuaternions works", {
  actual <- RotationVectorsFromQuaternions(c(1,0,0,0))
  expected <-
    data.frame(
      x = 0,
      y = 0,
      z = 0
    )
  expect_equal(actual, expected)
})

# RotationVectorsFromPitchRollYaw ----

test_that("RotationVectorsFromPitchRollYaw works", {
  pitch_roll_yaw <-
    data.frame(
      pitch = c(0),
      roll = c(0),
      yaw = c(0)
    )
  actual <- RotationVectorsFromPitchRollYaw(pitch_roll_yaw)
  expected <-
    data.frame(
      x = c(0),
      y = c(0),
      z = c(0)
    )
  expect_equal(actual, expected)
})

# BasisVectorsFromPitchRollYaw ----

test_that("BasisVectorsFromPitchRollYaw works", {
  pitch_roll_yaw <-
    data.frame(
      pitch = c(0),
      roll = c(0),
      yaw = c(0)
    )
  actual <- BasisVectorsFromPitchRollYaw(pitch_roll_yaw)
  expected <-
    list(
      x_hat =
        data.frame(
          x = c(1),
          y = c(0),
          z = c(0)
        ),
      y_hat =
        data.frame(
          x = c(0),
          y = c(1),
          z = c(0)
        ),
      z_hat =
        data.frame(
          x = c(0),
          y = c(0),
          z = c(1)
        )
      )
  expect_equal(actual, expected)
})

# PitchRollYawFromBasisVectors ----

test_that("PitchRollYawFromBasisVectors works", {
  basis_vectors <- list()
  basis_vectors$x_hat <- data.frame(x = 1, y = 0, z = 0)
  basis_vectors$y_hat <- data.frame(x = 0, y = 1, z = 0)
  basis_vectors$z_hat <- data.frame(x = 0, y = 0, z = 1)
  actual <- PitchRollYawFromBasisVectors(basis_vectors)
  expected <-
    data.frame(
      pitch = 0,
      roll = 0,
      yaw = 0
    )
  expect_equal(actual, expected)
})

# RotationVectorsFromBasisVectors ----

test_that("RotationVectorsFromBasisVectors works", {
  basis_vectors <- list()
  basis_vectors$x_hat <- data.frame(x = 1, y = 0, z = 0)
  basis_vectors$y_hat <- data.frame(x = 0, y = 1, z = 0)
  basis_vectors$z_hat <- data.frame(x = 0, y = 0, z = 1)
  actual <- RotationVectorsFromBasisVectors(basis_vectors)
  expected <-
    data.frame(
      x = 0,
      y = 0,
      z = 0
    )
  expect_equal(actual, expected)
})

# BasisVectorsFromRotationVectors ----

test_that("BasisVectorsFromRotationVectors works", {
  basis_vectors <- list()
  basis_vectors$x_hat <- data.frame(x = 1, y = 0, z = 0)
  basis_vectors$y_hat <- data.frame(x = 0, y = 1, z = 0)
  basis_vectors$z_hat <- data.frame(x = 0, y = 0, z = 1)
  actual <- BasisVectorsFromRotationVectors(c(pi/2,0,0))
  expected <-
    list(
      x_hat =
        data.frame(
          x = 1,
          y = 0,
          z = 0
        ),
      y_hat =
        data.frame(
          x = 0,
          y = 0,
          z = 1
        ),
      z_hat =
        data.frame(
          x = 0,
          y = -1,
          z = 0
        )
    )
  expect_equal(actual, expected)
})
