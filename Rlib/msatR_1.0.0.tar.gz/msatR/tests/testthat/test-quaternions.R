# QuaternionMultiply ----

test_that("QuaternionMultiply works for vectors", {
  actual <- QuaternionMultiply(c(1,0,0,0), c(0,1,0,0))
  expected <-
    data.frame(
      r = 0,
      i1 = 1,
      i2 = 0,
      i3 = 0
    )
  expect_equal(actual, expected)
})

test_that("QuaternionMultiply works for data.frames", {
  actual <-
    QuaternionMultiply(
      data.frame(
        r = c(1, -1),
        i1 = c(0, 0),
        i2 = c(0, 0),
        i3 = c(0, 0)
      ),
      data.frame(
        r = c(0, 0),
        i1 = c(1, 1),
        i2 = c(0, 0),
        i3 = c(0, 0)
      )
    )
  expected <-
    data.frame(
      r = c(0, 0),
      i1 = c(1, -1),
      i2 = c(0, 0),
      i3 = c(0, 0)
    )
  expect_equal(actual, expected)
})

# QuaternionInvert ----

test_that("QuaternionInvert works", {
  actual <-
    QuaternionInvert(
      data.frame(
        r = c(1, -1),
        i1 = c(0, 1),
        i2 = c(1, 0),
        i3 = c(0, 0)
      )
    )
  expected <-
    data.frame(
      r = c(0.5, -0.5),
      i1 = c(0, -0.5),
      i2 = c(-0.5, 0),
      i3 = c(0, 0)
    )
  expect_equal(actual, expected)
})


# AngleBetweenQuaternions ----

test_that("AngleBetweenQuaternions works", {
  actual <-
    AngleBetweenQuaternions(
      data.frame(
        r = c(1, -1),
        i1 = c(0, 0),
        i2 = c(0, 0),
        i3 = c(0, 0)
      ),
      data.frame(
        r = c(-1, 1),
        i1 = c(0, 1),
        i2 = c(0, 0),
        i3 = c(0, 0)
      )
    )
  expected <- c(0, pi / 2)
    data.frame(
      r = c(0.5, -0.5),
      i1 = c(0, -0.5),
      i2 = c(-0.5, 0),
      i3 = c(0, 0)
    )
  expect_equal(actual, expected)
})

# QuaternionRectify ----

test_that("QuaternionRectify works", {
  q <-
    data.frame(
      r = c(1, 0.9, -0.9),
      i1 = c(0, 0.1, -0.1),
      i2 = c(0, 0, 0),
      i3 = c(0, 0, 0)
    )
  actual <- QuaternionRectify(q)
  expected <-
    data.frame(
      r = c(1, 0.9, 0.9),
      i1 = c(0, 0.1, 0.1),
      i2 = c(0, 0, 0),
      i3 = c(0, 0, 0)
    )
  expect_equal(actual, expected)
})

# AngularVelocityFromQuaternions ----

test_that("AngularVelocityFromQuaternions works", {
  q <-
    data.frame(
      r = c(1, 0.9, -0.9),
      i1 = c(0, 0.1, -0.1),
      i2 = c(0, 0, 0),
      i3 = c(0, 0, 0)
    )
  actual <- AngularVelocityFromQuaternions(q)
  expected <-
    data.frame(
      x = c(0.2, 0, NA),
      y = c(0, 0, NA),
      z = c(0, 0, NA)
    )
  expect_equal(actual, expected)
})

# AngularAccelerationFromQuaternions ----

test_that("AngularAccelerationFromQuaternions works", {
  q <-
    data.frame(
      r = c(1, 0.9, -0.9),
      i1 = c(0, 0.1, -0.1),
      i2 = c(0, 0, 0),
      i3 = c(0, 0, 0)
    )
  actual <- AngularAccelerationFromQuaternions(q)
  expected <-
    data.frame(
      x = c(NA, -0.24390244, NA),
      y = c(NA, 0, NA),
      z = c(NA, 0, NA)
    )
  expect_equal(actual, expected)
})
