test_that("IntersectSphere works", {
  actual <-
    IntersectSphere(
      pos_ecef =
        rbind(
          c(6381000, 0, 0),
          c(0, 0, 6381000)
        ),
      ray_ecef =
        rbind(
          c(-1, 0, 0),
          c(0, 0, -1)
        )
    )
  expected <-
    data.frame(
      lon = c(0, 0),
      lat = c(0, 90),
      alt = c(0, 0)
    )
  expect_equal(expected, actual)
})

test_that("IntersectEllipsoid works", {
  actual <-
    IntersectEllipsoid(
      pos_ecef =
        rbind(
          c(6379137.0, 0, 0),
          c(0, 0, 6356852.3)
        ),
      ray_ecef =
        rbind(
          c(-1, 0, 0),
          c(0, 0, -1)
        ),
      elevation = c(10, 10)
    )
   expected <-
     data.frame(
       lon = c(0, 0),
       lat = c(0, 0),
       alt = c(10, 10)
     )
  expect_equal(expected, actual)
})

test_that("CameraModel works", {
  actual <-
   CameraModel(
     focal_length = 16,
     fov = 21.3 * pi / 180,
     pixels = 3,
     aggregate = 1
   )
  expected <- c(-0.185877565337396, 0.000000000000000, 0.185877565337396)
  expect_equal(expected, actual)
})

