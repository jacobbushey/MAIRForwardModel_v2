
# TleCheckSum ----

test_that("TleCheckSum works", {
  tle <-
    c(
      "1 88888U 16001A   16001.00000000  .00000000  00000-0  00000-0 0  9996",
      "2 88888  97.7053 306.9476 0010625  90.0000  89.0000 14.9608950 1    1"
     )
  actual <- c(TleCheckSum(tle[1]), TleCheckSum(tle[2]))
  expected <- c(6, 1)
  expect_equal(actual, expected)
})

# ReadTle ----

test_that("ReadTle works", {
  tle <-
    c(
      "1 88888U 16001A   16001.00000000  .00000000  00000-0  00000-0 0  9996",
      "2 88888  97.7053 306.9476 0010625  90.0000  89.0000 14.9608950 1    1"
     )
  actual <- ReadTle(tle)
  expected <-
    list(
      direct =
        list(
          satellite_number = 88888,
          classification = "U",
          launch_year = 16,
          launch_number_of_year = 1,
          peice_of_the_launch = "A",
          epoch_year = 16,
          epoch_doy = 1,
          first_deriv_mean_motion = 0,
          second_deriv_mean_motion = 0,
          bstar_drag_term = 0,
          ephemeris_type = "0",
          element_number = 999,
          checksum1 = 6,
          inclination = 97.7053,
          right_ascension = 306.9476,
          eccentricity = 0.0010625,
          argument_of_perigree = 90,
          mean_anomaly = 89,
          mean_motion = 14.960895,
          rev_at_epoch = 1,
          checksum2 = 1
        ),
      computed =
        list(
          epoch_utc = lubridate::ymd_hms("2016-01-01 00:00:00 UTC"),
          checksum1test = TRUE,
          checksum2test = TRUE
        )
    )
  expect_equal(actual, expected)
})

# MeanMotion ----

test_that("MeanMotion works", {
  actual <- MeanMotion(500000)
  expected <-15.2198196
  expect_equal(actual, expected)
})

# MeanMotion ----

test_that("SunSynchronousInclination works", {
  actual <- SunSynchronousInclination(500000)
  expected <- 1.70006473
  expect_equal(actual, expected)
})
