# UtcFromJulian ----

test_that("UtcFromJulian works", {
  actual <- UtcFromJulian(2446848.50000)
  expected <- lubridate::ymd_hms("1987-02-22 00:00:00 UTC")
  expect_equal(actual, expected)
})

test_that("Utc Julian loops", {
  expected <- 2446848.50000
  actual <- 2446848.50000 %>% UtcFromJulian() %>% JulianFromUtc()
  expect_equal(actual, expected)
})

# ModifiedJulianFromJulian ----

test_that("ModifiedJulianFromJulian works", {
  actual <- ModifiedJulianFromJulian(2446848.50000)
  expected <- 46848
  expect_equal(actual, expected)
})

test_that("ModifiedJulian Julian loops", {
  expected <- 2446848.50000
  actual <-
    2446848.50000 %>%
    ModifiedJulianFromJulian() %>%
    JulianFromModifiedJulian()
  expect_equal(actual, expected)
})

# JulianFromModifiedJulian ----

test_that("JulianFromModifiedJulian works", {
  actual <- JulianFromModifiedJulian(46848)
  expected <- 2446848.5
  expect_equal(actual, expected)
})

test_that("Julian ModifiedJulian loops", {
  expected <- 46848
  actual <- 46848 %>% JulianFromModifiedJulian() %>% ModifiedJulianFromJulian()
  expect_equal(actual, expected)
})

# UtcFromModifiedJulian ----

test_that("UtcFromModifiedJulian works", {
  actual <- UtcFromModifiedJulian(46848)
  expected <- lubridate::ymd_hms("1987-02-22 00:00:00 UTC")
  expect_equal(actual, expected)
})

test_that("Utc ModifiedJulian loops", {
  expected <- 46848
  actual <- 46848 %>% UtcFromModifiedJulian() %>% ModifiedJulianFromUtc()
  expect_equal(actual, expected)
})

# JulianFromUtc ----

test_that("JulianFromUtc works", {
  actual <- JulianFromUtc("1987-02-22")
  expected <- 2446848.5
  expect_equal(actual, expected)
})

test_that("Julian Utc loops", {
  expected <- lubridate::ymd_hms("1987-02-22 00:00:00 UTC")
  actual <- "1987-02-22" %>% JulianFromUtc() %>% UtcFromJulian()
  expect_equal(actual, expected)
})

# ModifiedJulianFromUtc ----

test_that("ModifiedJulianFromUtc works", {
  actual <- ModifiedJulianFromUtc("1987-02-22")
  expected <- 46848
  expect_equal(actual, expected)
})

test_that("ModifiedJulian Utc loops", {
  expected <- lubridate::ymd_hms("1987-02-22 00:00:00 UTC")
  actual <- "1987-02-22" %>% ModifiedJulianFromUtc() %>% UtcFromModifiedJulian()
  expect_equal(actual, expected)
})

# UtcFromYyyyDoy ----

test_that("UtcFromYyyyDoy works for scalars", {
  actual <- UtcFromYyyyDoy(1987, 53)
  expected <- lubridate::ymd_hms("1987-02-22 00:00:00 UTC")
  expect_equal(actual, expected)
})

# Iso8601FromUtc ----

test_that("Iso8601FromUtc works", {
  actual <- Iso8601FromUtc("1987-02-22 08:00:00")
  expected <- "1987-02-22T08:00:00.000Z"
  expect_equal(actual, expected)
})

# SolarTime ----

test_that("SolarTime works", {

  eop <- data.frame(
    eop_interpolated <- data.frame(
      utc     = rep(lubridate::ymd_hms("2022-02-15 00:00:00 UTC"), 2),
      mjd     = rep(59625, 2),
      x_pole  = rep(0.016814, 2),
      y_pole  = rep(0.345848, 2),
      UT1_UTC = rep(-0.1029937, 2),
      LOD     = rep(-0.0005407, 2),
      dpsi    = rep(-0.108690, 2),
      deps    = rep(-0.006864, 2),
      dx_pole = rep(0.000227, 2),
      dy_pole = rep(0.000127, 2),
      TAI_UTC = rep(37, 2)
    )
  )
  utc <- rep(lubridate::ymd_hms("2022-02-15 00:00:00 UTC"), 2)
  sun_eci <- SolarEphemeris(utc)
  sun_geodetic <- GeodeticFromEci(eci = sun_eci, eop = eop)
  actual <- SolarTime(utc = eop_interpolated$utc, lon_spacecraft = 0, lon_sun = sun_geodetic$lon)
  expected <-
    data.frame(
      solar_time = lubridate::ymd_hms("2022-02-15 00:01:43 UTC", "2022-02-15 00:01:43 UTC"),
      solar_hour = rep(0.028781174, 2)
    )
  expect_equal(actual, expected)
})

